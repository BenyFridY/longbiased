"""
PIPELINE V7 VALIDATION - Feature Swap Robustness Check
=======================================================

V6 found that replacing weak features (funding_rate, puell_multiple, sopr_ma7,
rsi_14d) with `eth` massively improves returns: +418% vs +285% baseline.
But ALL 4 best swaps point to eth, raising concerns:

1. eth = ETH absolute price, corr 0.82 with BTC. Market beta artifact?
2. eth_btc_ratio already in baseline (corr 0.45 with eth). Is eth additive?
3. Combo tests stuff duplicate eth columns — not ideal for tree models
4. 80pp seed spread — still unstable
5. Feature selection bias: feature_ranking.csv computed on full data
6. Only tested with LGB — need cross-model validation
7. Untested high-rank features exist (kpss_stat_30d, plus_di)

V7 tests:
  Group D: ETH Ablation (6 tests)
  Group E: Cross-Model Validation (6 tests)
  Group F: Deep Seed Stability (40 tests)
  Group G: Untested High-Rank Features (8 tests)

Total: 60 tests. All walk-forward OOS (2022-2026), no look-ahead.
"""

import sys
import pandas as pd
import numpy as np
from pathlib import Path
import warnings
import json
from datetime import datetime
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import lightgbm as lgb

warnings.filterwarnings('ignore')
sys.stdout.reconfigure(line_buffering=True)

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

COST = 0.0002       # 2 bps
RF_ANNUAL = 0.15
RF_DAILY = (1 + RF_ANNUAL)**(1/365) - 1  # legacy fallback
RF_DAILY_ARR = None  # populated in main()

def P(*a, **kw):
    try:
        print(*a, **kw, flush=True)
    except UnicodeEncodeError:
        text = ' '.join(str(x) for x in a)
        text = text.encode('ascii', errors='replace').decode('ascii')
        print(text, **kw, flush=True)

# Optional dependencies
HAS_CATBOOST = False
try:
    from catboost import CatBoostRegressor
    HAS_CATBOOST = True
except ImportError:
    pass


# ============================================================
# SECTION 1: CONSTANTS
# ============================================================

DEFAULT_FEATURE_COLS = [
    'cusum_pos', 'miners_revenue_ratio', 'mr_score_30d', 'adx',
    'cusum_neg', 'exchange_netflow_ma7', 'structural_break_score',
    'macd_histogram', 'eth_btc_ratio', 'm2_yoy_growth',
    'volatility_7d', 'basis_ma7', 'nupl_ma30', 'hurst_60d',
    'funding_rate', 'bb_position', 'rsi_14d', 'puell_multiple',
    'stablecoin_zscore', 'sopr_ma7',
]

WEAK_FEATURES = ['funding_rate', 'puell_multiple', 'sopr_ma7', 'rsi_14d']


# ============================================================
# SECTION 2: DATA LOADING (from V6)
# ============================================================

def load_data():
    df = pd.read_csv(ROOT / 'outputs/feature_selection/dataset_enhanced.csv')
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)

    prices = df['price_usd'].values
    n = len(prices)

    daily_ret = np.zeros(n)
    for i in range(1, n):
        daily_ret[i] = (prices[i] - prices[i-1]) / prices[i-1]

    returns = {}
    for w in [1, 3, 5, 7, 10, 14, 20, 21, 30, 45, 60]:
        r = np.zeros(n)
        for i in range(w, n):
            r[i] = (prices[i] - prices[i-w]) / prices[i-w]
        returns[w] = r

    vols = {}
    for w in [5, 7, 10, 14, 21, 30]:
        vols[w] = pd.Series(daily_ret).rolling(w).std().fillna(0.02).values

    return prices, daily_ret, returns, vols, df


# ============================================================
# SECTION 3: CORE ENGINE (from V6)
# ============================================================

def backtest_allocations(daily_ret, allocations, start_idx, end_idx,
                         cost=COST, rf_daily=None,
                         clip_min=-0.25, clip_max=1.0):
    if rf_daily is None:
        rf_daily = RF_DAILY_ARR if RF_DAILY_ARR is not None else RF_DAILY
    strat, btc, allocs = [], [], []
    prev = 0.5
    n = len(daily_ret)
    is_arr = isinstance(rf_daily, np.ndarray)
    for t in range(start_idx, min(end_idx, n - 1)):
        a = np.clip(allocations[t], clip_min, clip_max)
        br = daily_ret[t + 1]
        rf_t = rf_daily[t] if is_arr else rf_daily
        tc = abs(a - prev) * cost * (1.5 if a < 0 else 1.0)
        sr = a * br + (1 - abs(a)) * rf_t - tc
        strat.append(sr)
        btc.append(br)
        allocs.append(a)
        prev = a
    return np.array(strat), np.array(btc), np.array(allocs)


def metrics(s, b, a, rf_daily=None):
    if len(s) < 10:
        return None
    if rf_daily is None:
        rf_daily = RF_DAILY
    ts = np.prod(1 + s) - 1
    tb = np.prod(1 + b) - 1
    ex = s - rf_daily
    ds = ex[ex < 0]
    sortino = np.mean(ex) / (np.std(ds) + 1e-10) * np.sqrt(365) if len(ds) > 0 else 0
    cum = np.cumprod(1 + s)
    pk = np.maximum.accumulate(cum)
    dd = np.min((cum - pk) / (pk + 1e-10))
    return {'total': ts, 'btc': tb, 'excess': ts - tb, 'sortino': sortino,
            'max_dd': dd, 'short_pct': float((a < 0).mean()), 'avg_alloc': float(np.mean(a))}


def get_year_boundaries(dates, n):
    yb = {}
    for i in range(n):
        yr = pd.Timestamp(dates[i]).year
        if yr not in yb:
            yb[yr] = {'start': i, 'end': i}
        yb[yr]['end'] = i
    return yb


def bootstrap_ci(daily_returns, n_bootstrap=1000, ci=0.95):
    n = len(daily_returns)
    if n < 30:
        return None
    rng = np.random.RandomState(42)
    total_returns = []
    for _ in range(n_bootstrap):
        idx = rng.choice(n, size=n, replace=True)
        resampled = daily_returns[idx]
        total = np.prod(1 + resampled) - 1
        total_returns.append(total)
    alpha = (1 - ci) / 2
    lo, hi = alpha * 100, (1 - alpha) * 100
    return {
        'return_mean': float(np.mean(total_returns)),
        'return_lo': float(np.percentile(total_returns, lo)),
        'return_hi': float(np.percentile(total_returns, hi)),
        'return_std': float(np.std(total_returns)),
        'excess_above_zero_pct': float(np.mean([r > 0 for r in total_returns]) * 100),
    }


# ============================================================
# SECTION 4: FEATURE BUILDING (from V6 + new)
# ============================================================

def build_ml_features(df, returns, vols, n, feature_cols=None):
    """Build features from column list. Always appends 5 price-derived features."""
    if feature_cols is None:
        feature_cols = DEFAULT_FEATURE_COLS

    price_derived_map = {
        'ret_3d': returns[3], 'ret_5d': returns[5], 'ret_7d': returns[7],
        'ret_10d': returns[10], 'ret_14d': returns[14], 'ret_30d': returns[30],
        'ret_45d': returns[45], 'ret_60d': returns[60],
        'vol_7d': vols[7], 'vol_14d': vols[14], 'vol_30d': vols[30],
    }

    cols, names = [], []
    for col in feature_cols:
        if col in price_derived_map:
            cols.append(price_derived_map[col])
            names.append(col)
        elif col in df.columns:
            cols.append(df[col].values.astype(float))
            names.append(col)

    # Always add base price-derived
    for pd_feat in ['ret_3d', 'ret_10d', 'ret_30d', 'ret_60d', 'vol_14d']:
        if pd_feat not in names:
            cols.append(price_derived_map[pd_feat])
            names.append(pd_feat)

    X_all = np.column_stack(cols) if cols else np.zeros((n, 0))
    return X_all, names


def build_ml_features_swap(df, returns, vols, n, swap_dict):
    """Build features with specific swaps applied.
    swap_dict: {weak_feature: strong_feature} — remove weak, add strong.
    """
    feature_cols = list(DEFAULT_FEATURE_COLS)
    for weak, strong in swap_dict.items():
        if weak in feature_cols:
            idx = feature_cols.index(weak)
            feature_cols[idx] = strong
    return build_ml_features(df, returns, vols, n, feature_cols=feature_cols)


def build_ml_features_remove(df, returns, vols, n, remove_list):
    """Build features with specified columns removed (no replacement).
    Returns fewer features than baseline.
    """
    feature_cols = [c for c in DEFAULT_FEATURE_COLS if c not in remove_list]
    return build_ml_features(df, returns, vols, n, feature_cols=feature_cols)


def build_ml_features_add(df, returns, vols, n, add_list):
    """Build features with extra columns added (no removal).
    Returns more features than baseline.
    """
    feature_cols = list(DEFAULT_FEATURE_COLS) + add_list
    return build_ml_features(df, returns, vols, n, feature_cols=feature_cols)


# ============================================================
# SECTION 5: ML TRAINING (LGB from V6, RF/CatBoost from V5)
# ============================================================

def train_lgb_bagged(X_all, target, train_end, horizon_gap=5, n_bags=5, base_seed=42):
    models = []
    for i in range(n_bags):
        seed = base_seed + i * 7
        train_mask = np.arange(60, train_end - horizon_gap + 1)
        valid_train = ~np.any(np.isnan(X_all[train_mask]), axis=1)
        train_idx = train_mask[valid_train]
        if len(train_idx) < 100:
            continue
        X_train = np.nan_to_num(X_all[train_idx], nan=0.0)
        y_train = target[train_idx]
        params = {
            'objective': 'regression', 'metric': 'mae',
            'num_leaves': 31, 'learning_rate': 0.05,
            'feature_fraction': 0.7, 'bagging_fraction': 0.8,
            'bagging_freq': 5, 'verbose': -1, 'n_jobs': 1, 'seed': seed,
        }
        dtrain = lgb.Dataset(X_train, label=y_train)
        models.append(lgb.train(params, dtrain, num_boost_round=200))
    return models if len(models) > 0 else None


def train_rf_bagged(X_all, target, train_end, horizon_gap=5, n_bags=5,
                    n_trees=200, max_depth=10, base_seed=42):
    from sklearn.ensemble import RandomForestRegressor
    models = []
    for i in range(n_bags):
        seed = base_seed + i * 7
        train_mask = np.arange(60, train_end - horizon_gap + 1)
        valid_train = ~np.any(np.isnan(X_all[train_mask]), axis=1)
        train_idx = train_mask[valid_train]
        if len(train_idx) < 100:
            continue
        X_train = np.nan_to_num(X_all[train_idx], nan=0.0)
        y_train = target[train_idx]
        model = RandomForestRegressor(n_estimators=n_trees, max_depth=max_depth,
                                      random_state=seed, n_jobs=1)
        model.fit(X_train, y_train)
        models.append(model)
    return models if len(models) > 0 else None


def train_catboost_bagged(X_all, target, train_end, horizon_gap=5, n_bags=5,
                          depth=6, lr=0.05, iterations=200, base_seed=42):
    if not HAS_CATBOOST:
        return None
    models = []
    for i in range(n_bags):
        seed = base_seed + i * 7
        train_mask = np.arange(60, train_end - horizon_gap + 1)
        valid_train = ~np.any(np.isnan(X_all[train_mask]), axis=1)
        train_idx = train_mask[valid_train]
        if len(train_idx) < 100:
            continue
        X_train = np.nan_to_num(X_all[train_idx], nan=0.0)
        y_train = target[train_idx]
        model = CatBoostRegressor(
            depth=depth, learning_rate=lr, iterations=iterations,
            random_seed=seed, verbose=0, loss_function='MAE',
        )
        model.fit(X_train, y_train)
        models.append(model)
    return models if len(models) > 0 else None


def ml_predict(models, X_all, t):
    x_t = np.nan_to_num(X_all[t:t+1].copy(), nan=0.0)
    preds = [m.predict(x_t)[0] for m in models]
    avg_pred = np.mean(preds)
    scaled = np.clip(avg_pred / 0.05, -1.0, 1.0)
    if scaled > 0:
        return 0.5 + scaled * 0.5
    else:
        return 0.5 + scaled * 0.75


# ============================================================
# SECTION 6: B7 PURE ML ENGINE (from V6 + multi-model variant)
# ============================================================

def run_b7(daily_ret, returns, vols, df, dates, n,
           n_bags=5, use_weekly=True, target_horizon=3,
           X_all_override=None, base_seed=42,
           clip_min=-0.25, clip_max=1.0,
           cost=COST, rf_daily=None,
           label="B7", verbose=True,
           return_allocs=False):
    """Run B7 Pure ML walk-forward with LightGBM."""
    if rf_daily is None:
        rf_daily = RF_DAILY_ARR if RF_DAILY_ARR is not None else RF_DAILY
    yb = get_year_boundaries(dates, n)
    prices = df['price_usd'].values

    if X_all_override is not None:
        X_all = X_all_override
    else:
        X_all, _ = build_ml_features(df, returns, vols, n)

    target = np.zeros(n)
    h = target_horizon
    for i in range(n - h):
        target[i] = (prices[i + h] - prices[i]) / prices[i]

    day_of_week = pd.to_datetime(dates).dayofweek

    all_strat, all_btc, all_alloc = [], [], []
    full_allocs = np.full(n, 0.5)

    for test_year in range(2022, 2027):
        if test_year not in yb:
            continue
        train_end = yb[test_year]['start'] - 1
        test_start = yb[test_year]['start']
        test_end = yb[test_year]['end']

        horizon_gap = max(target_horizon, 5)
        models = train_lgb_bagged(X_all, target, train_end,
                                  horizon_gap=horizon_gap, n_bags=n_bags,
                                  base_seed=base_seed)

        if verbose:
            P(f"    {test_year}: {len(models) if models else 0} models", end="")

        prev_alloc = 0.5
        for t in range(test_start, test_end + 1):
            if models is not None:
                a_ml = ml_predict(models, X_all, t)
            else:
                a_ml = 0.5

            raw_alloc = a_ml

            if use_weekly and day_of_week[t] != 4:
                raw_alloc = prev_alloc

            full_allocs[t] = np.clip(raw_alloc, clip_min, clip_max)
            prev_alloc = full_allocs[t]

        s, b, a = backtest_allocations(daily_ret, full_allocs, test_start, test_end,
                                       cost=cost, rf_daily=rf_daily,
                                       clip_min=clip_min, clip_max=clip_max)
        all_strat.extend(s)
        all_btc.extend(b)
        all_alloc.extend(a)

        m_yr = metrics(np.array(s), np.array(b), np.array(a), rf_daily=rf_daily)
        if verbose and m_yr:
            P(f" -> {m_yr['total']*100:+.1f}%")
        elif verbose:
            P(" -> N/A")

    result = metrics(np.array(all_strat), np.array(all_btc), np.array(all_alloc),
                     rf_daily=rf_daily)

    if return_allocs:
        return result, full_allocs.copy(), np.array(all_strat)
    return result


def run_b7_with_model(daily_ret, returns, vols, df, dates, n,
                      model_type='rf',
                      n_bags=5, use_weekly=True, target_horizon=3,
                      X_all_override=None, base_seed=42,
                      clip_min=-0.25, clip_max=1.0,
                      cost=COST, rf_daily=None,
                      label="B7", verbose=True,
                      return_allocs=False):
    """Run B7 Pure ML walk-forward with RF, CatBoost, or LGB+RF average."""
    yb = get_year_boundaries(dates, n)
    prices = df['price_usd'].values

    if X_all_override is not None:
        X_all = X_all_override
    else:
        X_all, _ = build_ml_features(df, returns, vols, n)

    target = np.zeros(n)
    h = target_horizon
    for i in range(n - h):
        target[i] = (prices[i + h] - prices[i]) / prices[i]

    day_of_week = pd.to_datetime(dates).dayofweek

    all_strat, all_btc, all_alloc = [], [], []
    full_allocs = np.full(n, 0.5)

    for test_year in range(2022, 2027):
        if test_year not in yb:
            continue
        train_end = yb[test_year]['start'] - 1
        test_start = yb[test_year]['start']
        test_end = yb[test_year]['end']

        horizon_gap = max(target_horizon, 5)

        # Train models based on type
        if model_type == 'rf':
            models = train_rf_bagged(X_all, target, train_end,
                                     horizon_gap=horizon_gap, n_bags=n_bags,
                                     base_seed=base_seed)
            models_lgb = None
        elif model_type == 'catboost':
            models = train_catboost_bagged(X_all, target, train_end,
                                           horizon_gap=horizon_gap, n_bags=n_bags,
                                           base_seed=base_seed)
            models_lgb = None
        elif model_type == 'lgb_rf_avg':
            models = train_rf_bagged(X_all, target, train_end,
                                     horizon_gap=horizon_gap, n_bags=n_bags,
                                     base_seed=base_seed)
            models_lgb = train_lgb_bagged(X_all, target, train_end,
                                          horizon_gap=horizon_gap, n_bags=n_bags,
                                          base_seed=base_seed)
        else:
            raise ValueError(f"Unknown model_type: {model_type}")

        n_models = (len(models) if models else 0)
        if model_type == 'lgb_rf_avg':
            n_models_lgb = len(models_lgb) if models_lgb else 0
            if verbose:
                P(f"    {test_year}: RF={n_models} LGB={n_models_lgb} models", end="")
        else:
            if verbose:
                P(f"    {test_year}: {n_models} {model_type} models", end="")

        prev_alloc = 0.5
        for t in range(test_start, test_end + 1):
            if model_type == 'lgb_rf_avg':
                a_rf = ml_predict(models, X_all, t) if models else 0.5
                a_lgb = ml_predict(models_lgb, X_all, t) if models_lgb else 0.5
                a_ml = 0.5 * a_rf + 0.5 * a_lgb
            elif models is not None:
                a_ml = ml_predict(models, X_all, t)
            else:
                a_ml = 0.5

            raw_alloc = a_ml

            if use_weekly and day_of_week[t] != 4:
                raw_alloc = prev_alloc

            full_allocs[t] = np.clip(raw_alloc, clip_min, clip_max)
            prev_alloc = full_allocs[t]

        s, b, a = backtest_allocations(daily_ret, full_allocs, test_start, test_end,
                                       cost=cost, rf_daily=rf_daily,
                                       clip_min=clip_min, clip_max=clip_max)
        all_strat.extend(s)
        all_btc.extend(b)
        all_alloc.extend(a)

        m_yr = metrics(np.array(s), np.array(b), np.array(a), rf_daily=rf_daily)
        if verbose and m_yr:
            P(f" -> {m_yr['total']*100:+.1f}%")
        elif verbose:
            P(" -> N/A")

    result = metrics(np.array(all_strat), np.array(all_btc), np.array(all_alloc),
                     rf_daily=rf_daily)

    if return_allocs:
        return result, full_allocs.copy(), np.array(all_strat)
    return result


# ============================================================
# SECTION 7: GROUP D — ETH ABLATION (6 tests)
# ============================================================

def group_d_eth_ablation(daily_ret, returns, vols, df, dates, n, baseline_result):
    """Group D: Determines if eth is genuinely helping vs if removing weak features
    is what matters."""
    P(f"\n{'='*100}")
    P("GROUP D: ETH ABLATION (6 tests)")
    P("=" * 100)
    P(f"  Baseline B7 ret_3d: {baseline_result['total']*100:+.1f}%")
    P(f"  Question: Is eth genuine, or does removing weak features explain the gain?\n")

    results = {}

    # D1: Add eth as 26th feature (no removal)
    P(f"  D1: Add eth as 26th feature (no removal)...")
    X_d1, names_d1 = build_ml_features_add(df, returns, vols, n, ['eth'])
    P(f"      Features: {len(names_d1)} cols")
    r_d1 = run_b7(daily_ret, returns, vols, df, dates, n,
                   n_bags=5, use_weekly=True, target_horizon=3,
                   X_all_override=X_d1, base_seed=42, verbose=False)
    if r_d1:
        delta = (r_d1['total'] - baseline_result['total']) * 100
        P(f"      Result: {r_d1['total']*100:+.1f}% ({delta:+.1f}pp vs baseline)")
    results['D1_add_eth'] = {
        'config': 'Add eth as 26th feature, no removal',
        'n_features': len(names_d1), 'feature_names': names_d1,
        'result': r_d1,
    }

    # D2: Remove 4 weak features (21 feat, no replacement)
    P(f"\n  D2: Remove all 4 weak features (no replacement)...")
    X_d2, names_d2 = build_ml_features_remove(df, returns, vols, n, WEAK_FEATURES)
    P(f"      Features: {len(names_d2)} cols")
    r_d2 = run_b7(daily_ret, returns, vols, df, dates, n,
                   n_bags=5, use_weekly=True, target_horizon=3,
                   X_all_override=X_d2, base_seed=42, verbose=False)
    if r_d2:
        delta = (r_d2['total'] - baseline_result['total']) * 100
        P(f"      Result: {r_d2['total']*100:+.1f}% ({delta:+.1f}pp vs baseline)")
    results['D2_remove_4weak'] = {
        'config': 'Remove 4 weak features, no replacement (21 feat)',
        'n_features': len(names_d2), 'feature_names': names_d2,
        'result': r_d2,
    }

    # D3: Remove only puell+rsi (23 feat, no replacement)
    P(f"\n  D3: Remove puell+rsi only (no replacement)...")
    X_d3, names_d3 = build_ml_features_remove(df, returns, vols, n,
                                               ['puell_multiple', 'rsi_14d'])
    P(f"      Features: {len(names_d3)} cols")
    r_d3 = run_b7(daily_ret, returns, vols, df, dates, n,
                   n_bags=5, use_weekly=True, target_horizon=3,
                   X_all_override=X_d3, base_seed=42, verbose=False)
    if r_d3:
        delta = (r_d3['total'] - baseline_result['total']) * 100
        P(f"      Result: {r_d3['total']*100:+.1f}% ({delta:+.1f}pp vs baseline)")
    results['D3_remove_puell_rsi'] = {
        'config': 'Remove puell+rsi only, no replacement (23 feat)',
        'n_features': len(names_d3), 'feature_names': names_d3,
        'result': r_d3,
    }

    # D4: Only swap puell->eth (keep other 3 weak)
    P(f"\n  D4: Swap puell->eth only (keep other 3 weak)...")
    X_d4, names_d4 = build_ml_features_swap(df, returns, vols, n,
                                             {'puell_multiple': 'eth'})
    P(f"      Features: {len(names_d4)} cols")
    r_d4 = run_b7(daily_ret, returns, vols, df, dates, n,
                   n_bags=5, use_weekly=True, target_horizon=3,
                   X_all_override=X_d4, base_seed=42, verbose=False)
    if r_d4:
        delta = (r_d4['total'] - baseline_result['total']) * 100
        P(f"      Result: {r_d4['total']*100:+.1f}% ({delta:+.1f}pp vs baseline)")
    results['D4_swap_puell_eth'] = {
        'config': 'Swap puell->eth only (keep sopr, funding, rsi)',
        'n_features': len(names_d4), 'feature_names': names_d4,
        'result': r_d4,
    }

    # D5: Mixed combo: puell+rsi->momentum_accel_7d, sopr+funding->sharpe_3y_artemis
    P(f"\n  D5: Mixed non-ETH combo (puell->momentum_accel_7d, rsi->momentum_accel_7d, "
      f"sopr->sharpe_3y_artemis, funding->sharpe_3y_artemis)...")
    swap_d5 = {
        'puell_multiple': 'momentum_accel_7d',
        'rsi_14d': 'momentum_accel_7d',
        'sopr_ma7': 'sharpe_3y_artemis',
        'funding_rate': 'sharpe_3y_artemis',
    }
    X_d5, names_d5 = build_ml_features_swap(df, returns, vols, n, swap_d5)
    P(f"      Features: {len(names_d5)} cols")
    r_d5 = run_b7(daily_ret, returns, vols, df, dates, n,
                   n_bags=5, use_weekly=True, target_horizon=3,
                   X_all_override=X_d5, base_seed=42, verbose=False)
    if r_d5:
        delta = (r_d5['total'] - baseline_result['total']) * 100
        P(f"      Result: {r_d5['total']*100:+.1f}% ({delta:+.1f}pp vs baseline)")
    results['D5_mixed_no_eth'] = {
        'config': 'puell+rsi->momentum_accel_7d, sopr+funding->sharpe_3y_artemis',
        'swap_dict': swap_d5,
        'n_features': len(names_d5), 'feature_names': names_d5,
        'result': r_d5,
    }

    # D6: Mixed v2: puell->eth, rsi->momentum_accel_7d (1 eth + 1 non-eth)
    P(f"\n  D6: Mixed v2 (puell->eth, rsi->momentum_accel_7d)...")
    swap_d6 = {
        'puell_multiple': 'eth',
        'rsi_14d': 'momentum_accel_7d',
    }
    X_d6, names_d6 = build_ml_features_swap(df, returns, vols, n, swap_d6)
    P(f"      Features: {len(names_d6)} cols")
    r_d6 = run_b7(daily_ret, returns, vols, df, dates, n,
                   n_bags=5, use_weekly=True, target_horizon=3,
                   X_all_override=X_d6, base_seed=42, verbose=False)
    if r_d6:
        delta = (r_d6['total'] - baseline_result['total']) * 100
        P(f"      Result: {r_d6['total']*100:+.1f}% ({delta:+.1f}pp vs baseline)")
    results['D6_mixed_1eth'] = {
        'config': 'puell->eth, rsi->momentum_accel_7d',
        'swap_dict': swap_d6,
        'n_features': len(names_d6), 'feature_names': names_d6,
        'result': r_d6,
    }

    # Summary
    P(f"\n  {'='*80}")
    P(f"  GROUP D SUMMARY")
    P(f"  {'='*80}")
    P(f"  {'Test':<25} {'Features':>8} {'Return':>10} {'Delta':>8} {'Sortino':>8} {'MaxDD':>8}")
    P(f"  {'-'*75}")
    P(f"  {'Baseline B7':<25} {'25':>8} {baseline_result['total']*100:>+9.1f}% {'---':>8} "
      f"{baseline_result['sortino']:>7.2f} {baseline_result['max_dd']*100:>7.1f}%")
    for key, info in results.items():
        r = info['result']
        if r:
            delta = (r['total'] - baseline_result['total']) * 100
            P(f"  {key:<25} {info['n_features']:>8} {r['total']*100:>+9.1f}% "
              f"{delta:>+7.1f}pp {r['sortino']:>7.2f} {r['max_dd']*100:>7.1f}%")

    # Analysis
    if all(results[k]['result'] for k in ['D1_add_eth', 'D2_remove_4weak', 'D4_swap_puell_eth']):
        d1_ret = results['D1_add_eth']['result']['total']
        d2_ret = results['D2_remove_4weak']['result']['total']
        d4_ret = results['D4_swap_puell_eth']['result']['total']
        base_ret = baseline_result['total']
        P(f"\n  KEY ANALYSIS:")
        P(f"    Adding eth (D1):     {(d1_ret-base_ret)*100:+.1f}pp -> "
          f"{'ETH adds signal' if d1_ret > base_ret * 1.03 else 'ETH alone not enough'}")
        P(f"    Removing weak (D2):  {(d2_ret-base_ret)*100:+.1f}pp -> "
          f"{'Removal helps' if d2_ret > base_ret * 1.03 else 'Removal alone not enough'}")
        P(f"    Swap puell->eth (D4): {(d4_ret-base_ret)*100:+.1f}pp -> "
          f"{'Swap is best' if d4_ret > max(d1_ret, d2_ret) else 'Not better than add/remove'}")

    return results


# ============================================================
# SECTION 8: GROUP E — CROSS-MODEL VALIDATION (6 tests)
# ============================================================

def group_e_cross_model(daily_ret, returns, vols, df, dates, n, baseline_result):
    """Group E: Tests if improvement generalizes across RF, CatBoost, LGB+RF avg."""
    P(f"\n{'='*100}")
    P("GROUP E: CROSS-MODEL VALIDATION (6 tests)")
    P("=" * 100)
    P(f"  Baseline B7 LGB ret_3d: {baseline_result['total']*100:+.1f}%")
    P(f"  Testing: top2 swap (puell+rsi->eth) AND D5 mixed (no eth)")
    P(f"  Models: RandomForest, CatBoost, LGB+RF average\n")

    # Prepare feature sets
    swap_top2 = {'puell_multiple': 'eth', 'rsi_14d': 'eth'}
    X_top2, names_top2 = build_ml_features_swap(df, returns, vols, n, swap_top2)

    swap_d5 = {
        'puell_multiple': 'momentum_accel_7d',
        'rsi_14d': 'momentum_accel_7d',
        'sopr_ma7': 'sharpe_3y_artemis',
        'funding_rate': 'sharpe_3y_artemis',
    }
    X_d5, names_d5 = build_ml_features_swap(df, returns, vols, n, swap_d5)

    results = {}

    # E1: top2 swap + RF
    P(f"  E1: top2 (puell+rsi->eth) + RandomForest...")
    r_e1 = run_b7_with_model(daily_ret, returns, vols, df, dates, n,
                              model_type='rf', n_bags=5, use_weekly=True,
                              target_horizon=3, X_all_override=X_top2,
                              base_seed=42, verbose=False)
    if r_e1:
        P(f"      Result: {r_e1['total']*100:+.1f}%")
    results['E1_top2_RF'] = {
        'config': 'top2 (puell+rsi->eth) + RF',
        'model': 'RandomForest', 'swap': 'top2_eth', 'result': r_e1,
    }

    # E2: top2 swap + CatBoost
    P(f"  E2: top2 (puell+rsi->eth) + CatBoost...")
    if HAS_CATBOOST:
        r_e2 = run_b7_with_model(daily_ret, returns, vols, df, dates, n,
                                  model_type='catboost', n_bags=5, use_weekly=True,
                                  target_horizon=3, X_all_override=X_top2,
                                  base_seed=42, verbose=False)
        if r_e2:
            P(f"      Result: {r_e2['total']*100:+.1f}%")
    else:
        P(f"      SKIPPED (catboost not installed)")
        r_e2 = None
    results['E2_top2_CatBoost'] = {
        'config': 'top2 (puell+rsi->eth) + CatBoost',
        'model': 'CatBoost', 'swap': 'top2_eth', 'result': r_e2,
    }

    # E3: top2 swap + LGB+RF average
    P(f"  E3: top2 (puell+rsi->eth) + LGB+RF average...")
    r_e3 = run_b7_with_model(daily_ret, returns, vols, df, dates, n,
                              model_type='lgb_rf_avg', n_bags=5, use_weekly=True,
                              target_horizon=3, X_all_override=X_top2,
                              base_seed=42, verbose=False)
    if r_e3:
        P(f"      Result: {r_e3['total']*100:+.1f}%")
    results['E3_top2_LGB_RF'] = {
        'config': 'top2 (puell+rsi->eth) + LGB+RF avg',
        'model': 'LGB+RF', 'swap': 'top2_eth', 'result': r_e3,
    }

    # E4: D5 mixed + RF
    P(f"  E4: D5 mixed (no eth) + RandomForest...")
    r_e4 = run_b7_with_model(daily_ret, returns, vols, df, dates, n,
                              model_type='rf', n_bags=5, use_weekly=True,
                              target_horizon=3, X_all_override=X_d5,
                              base_seed=42, verbose=False)
    if r_e4:
        P(f"      Result: {r_e4['total']*100:+.1f}%")
    results['E4_D5mixed_RF'] = {
        'config': 'D5 mixed (no eth) + RF',
        'model': 'RandomForest', 'swap': 'D5_mixed', 'result': r_e4,
    }

    # E5: D5 mixed + CatBoost
    P(f"  E5: D5 mixed (no eth) + CatBoost...")
    if HAS_CATBOOST:
        r_e5 = run_b7_with_model(daily_ret, returns, vols, df, dates, n,
                                  model_type='catboost', n_bags=5, use_weekly=True,
                                  target_horizon=3, X_all_override=X_d5,
                                  base_seed=42, verbose=False)
        if r_e5:
            P(f"      Result: {r_e5['total']*100:+.1f}%")
    else:
        P(f"      SKIPPED (catboost not installed)")
        r_e5 = None
    results['E5_D5mixed_CatBoost'] = {
        'config': 'D5 mixed (no eth) + CatBoost',
        'model': 'CatBoost', 'swap': 'D5_mixed', 'result': r_e5,
    }

    # E6: D5 mixed + LGB+RF average
    P(f"  E6: D5 mixed (no eth) + LGB+RF average...")
    r_e6 = run_b7_with_model(daily_ret, returns, vols, df, dates, n,
                              model_type='lgb_rf_avg', n_bags=5, use_weekly=True,
                              target_horizon=3, X_all_override=X_d5,
                              base_seed=42, verbose=False)
    if r_e6:
        P(f"      Result: {r_e6['total']*100:+.1f}%")
    results['E6_D5mixed_LGB_RF'] = {
        'config': 'D5 mixed (no eth) + LGB+RF avg',
        'model': 'LGB+RF', 'swap': 'D5_mixed', 'result': r_e6,
    }

    # Summary
    P(f"\n  {'='*80}")
    P(f"  GROUP E SUMMARY")
    P(f"  {'='*80}")
    P(f"  {'Test':<25} {'Model':>12} {'Swap':>12} {'Return':>10} {'Sortino':>8} {'MaxDD':>8}")
    P(f"  {'-'*80}")
    P(f"  {'Baseline (LGB)':<25} {'LGB':>12} {'none':>12} "
      f"{baseline_result['total']*100:>+9.1f}% "
      f"{baseline_result['sortino']:>7.2f} {baseline_result['max_dd']*100:>7.1f}%")
    for key, info in results.items():
        r = info['result']
        if r:
            P(f"  {key:<25} {info['model']:>12} {info['swap']:>12} "
              f"{r['total']*100:>+9.1f}% {r['sortino']:>7.2f} {r['max_dd']*100:>7.1f}%")
        else:
            P(f"  {key:<25} {info['model']:>12} {info['swap']:>12} {'SKIPPED':>10}")

    # Cross-model analysis
    top2_results = [r for k, r in results.items()
                    if 'top2' in k and r['result'] is not None]
    if top2_results:
        top2_rets = [r['result']['total']*100 for r in top2_results]
        P(f"\n  top2 swap cross-model: min={min(top2_rets):+.1f}%, max={max(top2_rets):+.1f}%, "
          f"spread={max(top2_rets)-min(top2_rets):.0f}pp")
        all_beat_baseline = all(r > baseline_result['total']*100 for r in top2_rets)
        P(f"    All beat baseline? {'YES' if all_beat_baseline else 'NO'}")

    return results


# ============================================================
# SECTION 9: GROUP F — DEEP SEED STABILITY (40 tests)
# ============================================================

def group_f_seed_stability(daily_ret, returns, vols, df, dates, n, baseline_result):
    """Group F: 10 seeds each on 4 key strategies."""
    P(f"\n{'='*100}")
    P("GROUP F: DEEP SEED STABILITY (40 tests)")
    P("=" * 100)
    P(f"  10 seeds each on 4 strategies. Seeds: 42 + trial * 100")
    P(f"  Baseline B7 ret_3d: {baseline_result['total']*100:+.1f}%\n")

    # Define strategies
    swap_top2 = {'puell_multiple': 'eth', 'rsi_14d': 'eth'}
    swap_d5 = {
        'puell_multiple': 'momentum_accel_7d',
        'rsi_14d': 'momentum_accel_7d',
        'sopr_ma7': 'sharpe_3y_artemis',
        'funding_rate': 'sharpe_3y_artemis',
    }
    swap_d6 = {
        'puell_multiple': 'eth',
        'rsi_14d': 'momentum_accel_7d',
    }

    X_top2, _ = build_ml_features_swap(df, returns, vols, n, swap_top2)
    X_d5, _ = build_ml_features_swap(df, returns, vols, n, swap_d5)
    X_d6, _ = build_ml_features_swap(df, returns, vols, n, swap_d6)

    strategies = {
        'F1_top2_Bag5': {
            'label': 'A3 top2 swap (puell+rsi->eth), Bag5',
            'X_override': X_top2, 'n_bags': 5,
        },
        'F2_top2_Bag30': {
            'label': 'C1 combined (top2 swap + Bag30)',
            'X_override': X_top2, 'n_bags': 30,
        },
        'F3_D5mixed_Bag5': {
            'label': 'D5 mixed combo (no eth), Bag5',
            'X_override': X_d5, 'n_bags': 5,
        },
        'F4_D6mixed_Bag5': {
            'label': 'D6 mixed v2 (1 eth + 1 non-eth), Bag5',
            'X_override': X_d6, 'n_bags': 5,
        },
    }

    results = {}

    for strat_key, strat_cfg in strategies.items():
        P(f"\n  --- {strat_key}: {strat_cfg['label']} ---")
        seed_results = []
        for trial in range(10):
            base_seed = 42 + trial * 100
            P(f"    Seed {trial} (base={base_seed})...", end="")
            r = run_b7(daily_ret, returns, vols, df, dates, n,
                       n_bags=strat_cfg['n_bags'], use_weekly=True,
                       target_horizon=3,
                       X_all_override=strat_cfg['X_override'],
                       base_seed=base_seed, verbose=False)
            if r:
                seed_results.append(r)
                P(f" {r['total']*100:+.1f}%")
            else:
                P(" FAILED")

        if seed_results:
            pcts = [r['total'] * 100 for r in seed_results]
            spread = max(pcts) - min(pcts)
            mean_ret = np.mean(pcts)
            median_ret = np.median(pcts)
            beat_v2 = sum(1 for p in pcts if p > 219)
            beat_baseline = sum(1 for p in pcts if p > baseline_result['total'] * 100)
            verdict = 'STABLE' if spread < 30 else ('MODERATE' if spread < 60 else 'UNSTABLE')

            P(f"    {strat_key}: mean={mean_ret:+.1f}%, median={median_ret:+.1f}%, "
              f"spread={spread:.0f}pp -> {verdict}")
            P(f"    Beat V2 (+219%): {beat_v2}/10 | Beat B7 baseline: {beat_baseline}/10")

            results[strat_key] = {
                'label': strat_cfg['label'],
                'n_bags': strat_cfg['n_bags'],
                'returns': [float(p) for p in pcts],
                'mean': float(mean_ret),
                'median': float(median_ret),
                'spread': float(spread),
                'min': float(min(pcts)),
                'max': float(max(pcts)),
                'verdict': verdict,
                'beat_v2': beat_v2,
                'beat_baseline': beat_baseline,
                'sortinos': [float(r['sortino']) for r in seed_results],
                'max_dds': [float(r['max_dd'] * 100) for r in seed_results],
            }

    # Bootstrap CI on F1 and F3
    P(f"\n  BOOTSTRAP CI (on seed 42 runs):")
    for strat_key in ['F1_top2_Bag5', 'F3_D5mixed_Bag5']:
        if strat_key in strategies:
            P(f"\n    {strat_key}:")
            _, _, strat_rets = run_b7(
                daily_ret, returns, vols, df, dates, n,
                n_bags=strategies[strat_key]['n_bags'], use_weekly=True,
                target_horizon=3,
                X_all_override=strategies[strat_key]['X_override'],
                base_seed=42, verbose=False, return_allocs=True)
            if len(strat_rets) > 30:
                bs = bootstrap_ci(strat_rets, n_bootstrap=1000)
                P(f"      95% CI: [{bs['return_lo']*100:+.0f}%, {bs['return_hi']*100:+.0f}%]")
                P(f"      P(return > 0): {bs['excess_above_zero_pct']:.1f}%")
                if strat_key in results:
                    results[strat_key]['bootstrap'] = bs

    # Summary
    P(f"\n  {'='*80}")
    P(f"  GROUP F SUMMARY")
    P(f"  {'='*80}")
    P(f"  {'Strategy':<25} {'Mean':>8} {'Median':>8} {'Spread':>8} {'Min':>8} {'Max':>8} {'BeatV2':>8}")
    P(f"  {'-'*80}")
    for key, info in results.items():
        P(f"  {key:<25} {info['mean']:>+7.1f}% {info['median']:>+7.1f}% "
          f"{info['spread']:>7.0f}pp {info['min']:>+7.1f}% {info['max']:>+7.1f}% "
          f"{info['beat_v2']:>5}/10")

    return results


# ============================================================
# SECTION 10: GROUP G — UNTESTED HIGH-RANK FEATURES (8 tests)
# ============================================================

def group_g_untested_features(daily_ret, returns, vols, df, dates, n, baseline_result):
    """Group G: Tests features from ranking that were never tested in V6."""
    P(f"\n{'='*100}")
    P("GROUP G: UNTESTED HIGH-RANK FEATURES (8 tests)")
    P("=" * 100)
    P(f"  Baseline B7 ret_3d: {baseline_result['total']*100:+.1f}%")
    P(f"  Testing puell and rsi swaps with kpss_stat_30d, plus_di, "
      f"miners_revenue_usd, eth_pctchg_30d\n")

    tests = [
        ('G1', 'puell_multiple', 'kpss_stat_30d', 13),
        ('G2', 'puell_multiple', 'plus_di', 15),
        ('G3', 'puell_multiple', 'miners_revenue_usd', 17),
        ('G4', 'puell_multiple', 'eth_pctchg_30d', 29),
        ('G5', 'rsi_14d', 'kpss_stat_30d', 13),
        ('G6', 'rsi_14d', 'plus_di', 15),
        ('G7', 'rsi_14d', 'miners_revenue_usd', 17),
        ('G8', 'rsi_14d', 'eth_pctchg_30d', 29),
    ]

    results = {}
    for test_id, weak, strong, rank in tests:
        label = f"{test_id}_{weak[:5]}->{strong}"
        P(f"  {label} (rank {rank})...", end="")

        # Check if feature exists in dataset
        if strong not in df.columns:
            P(f" SKIPPED ('{strong}' not in dataset)")
            results[f'{test_id}_{weak}_to_{strong}'] = {
                'weak': weak, 'strong': strong, 'rank': rank,
                'result': None, 'reason': 'feature not in dataset',
            }
            continue

        swap = {weak: strong}
        X_swap, names_swap = build_ml_features_swap(df, returns, vols, n, swap)

        r = run_b7(daily_ret, returns, vols, df, dates, n,
                   n_bags=5, use_weekly=True, target_horizon=3,
                   X_all_override=X_swap, base_seed=42, verbose=False)
        if r:
            delta = (r['total'] - baseline_result['total']) * 100
            verdict = 'BETTER' if delta > 5 else ('similar' if delta > -5 else 'worse')
            P(f" {r['total']*100:+.1f}% ({delta:+.1f}pp) [{verdict}]")
        else:
            P(" FAILED")

        results[f'{test_id}_{weak}_to_{strong}'] = {
            'weak': weak, 'strong': strong, 'rank': rank,
            'n_features': len(names_swap),
            'result': r,
        }

    # Summary
    P(f"\n  {'='*80}")
    P(f"  GROUP G SUMMARY")
    P(f"  {'='*80}")
    P(f"  {'Test':<40} {'Rank':>6} {'Return':>10} {'Delta':>8} {'Sortino':>8}")
    P(f"  {'-'*75}")
    sorted_tests = sorted(results.items(),
                          key=lambda x: x[1]['result']['total'] if x[1]['result'] else -999,
                          reverse=True)
    for key, info in sorted_tests:
        r = info['result']
        if r:
            delta = (r['total'] - baseline_result['total']) * 100
            P(f"  {key:<40} {info['rank']:>6} {r['total']*100:>+9.1f}% "
              f"{delta:>+7.1f}pp {r['sortino']:>7.2f}")
        else:
            reason = info.get('reason', 'FAILED')
            P(f"  {key:<40} {info['rank']:>6} {'---':>10} {'---':>8} {reason}")

    # Compare best G result with eth swaps
    valid_results = [(k, v) for k, v in results.items() if v['result']]
    if valid_results:
        best_g = max(valid_results, key=lambda x: x[1]['result']['total'])
        P(f"\n  Best G result: {best_g[0]} at {best_g[1]['result']['total']*100:+.1f}%")
        P(f"  vs eth swap (V6 A3 top2): ~+418% (for reference)")

    return results


# ============================================================
# SECTION 11: CHARTS
# ============================================================

def generate_charts_v7(all_results, group_d, group_e, group_f, chart_dir):
    chart_dir.mkdir(parents=True, exist_ok=True)

    # --- Chart 1: D1-D6 ETH Ablation bar chart ---
    if group_d:
        fig, ax = plt.subplots(1, 1, figsize=(14, 7))
        names = []
        rets = []
        colors = []
        baseline_ret = all_results.get('B7 Baseline', {})
        baseline_val = baseline_ret['total'] * 100 if baseline_ret else 285

        for key, info in group_d.items():
            r = info['result']
            if r:
                names.append(key.replace('_', '\n'))
                rets.append(r['total'] * 100)
                delta = r['total'] * 100 - baseline_val
                colors.append('#2ecc71' if delta > 10 else
                             ('#f39c12' if delta > -10 else '#e74c3c'))

        # Add baseline
        names.insert(0, 'Baseline\nB7')
        rets.insert(0, baseline_val)
        colors.insert(0, '#4A90D9')

        x = np.arange(len(names))
        bars = ax.bar(x, rets, color=colors, alpha=0.85, edgecolor='black', linewidth=0.5)
        for v, bar in zip(rets, bars):
            ax.text(bar.get_x() + bar.get_width()/2, v + 5,
                    f'{v:+.0f}%', ha='center', fontsize=9, fontweight='bold')
        ax.axhline(y=baseline_val, color='blue', ls='--', lw=1, alpha=0.5,
                   label=f'Baseline ({baseline_val:+.0f}%)')
        ax.set_xticks(x)
        ax.set_xticklabels(names, fontsize=8)
        ax.set_ylabel('Total Return (%)')
        ax.set_title('V7 Group D: ETH Ablation — Is eth genuine or artifact?',
                     fontsize=13, fontweight='bold')
        ax.legend()
        ax.grid(True, alpha=0.3, axis='y')
        plt.tight_layout()
        plt.savefig(chart_dir / 'v7_eth_ablation.png', dpi=150, bbox_inches='tight')
        plt.close()
        P(f"  Chart saved: {chart_dir / 'v7_eth_ablation.png'}")

    # --- Chart 2: E1-E6 Cross-Model grouped bar chart ---
    if group_e:
        fig, ax = plt.subplots(1, 1, figsize=(14, 7))

        # Group by swap type
        swap_types = ['top2_eth', 'D5_mixed']
        model_types = ['RandomForest', 'CatBoost', 'LGB+RF']
        model_colors = {'RandomForest': '#2ecc71', 'CatBoost': '#e74c3c', 'LGB+RF': '#3498db'}

        x = np.arange(len(swap_types))
        width = 0.25
        for i, model in enumerate(model_types):
            vals = []
            for swap in swap_types:
                found = None
                for k, v in group_e.items():
                    if v.get('model') == model and v.get('swap') == swap:
                        found = v['result']
                        break
                vals.append(found['total'] * 100 if found else 0)
            bars = ax.bar(x + i * width, vals, width, label=model,
                         color=model_colors.get(model, '#999'),
                         alpha=0.85, edgecolor='black', linewidth=0.5)
            for v, bar in zip(vals, bars):
                if v != 0:
                    ax.text(bar.get_x() + bar.get_width()/2, v + 3,
                            f'{v:+.0f}%', ha='center', fontsize=8, fontweight='bold')

        baseline_ret = all_results.get('B7 Baseline', {})
        baseline_val = baseline_ret['total'] * 100 if baseline_ret else 285
        ax.axhline(y=baseline_val, color='blue', ls='--', lw=1, alpha=0.5,
                   label=f'LGB Baseline ({baseline_val:+.0f}%)')

        ax.set_xticks(x + width)
        ax.set_xticklabels(['top2 swap\n(puell+rsi->eth)', 'D5 mixed\n(no eth)'], fontsize=10)
        ax.set_ylabel('Total Return (%)')
        ax.set_title('V7 Group E: Cross-Model Validation — Feature swaps across algorithms',
                     fontsize=13, fontweight='bold')
        ax.legend()
        ax.grid(True, alpha=0.3, axis='y')
        plt.tight_layout()
        plt.savefig(chart_dir / 'v7_cross_model.png', dpi=150, bbox_inches='tight')
        plt.close()
        P(f"  Chart saved: {chart_dir / 'v7_cross_model.png'}")

    # --- Chart 3: F1-F4 Box Plots ---
    if group_f:
        fig, ax = plt.subplots(1, 1, figsize=(14, 7))
        data = []
        labels = []
        for key in ['F1_top2_Bag5', 'F2_top2_Bag30', 'F3_D5mixed_Bag5', 'F4_D6mixed_Bag5']:
            if key in group_f:
                data.append(group_f[key]['returns'])
                labels.append(key.replace('_', '\n'))

        if data:
            bp = ax.boxplot(data, labels=labels, patch_artist=True,
                           boxprops=dict(facecolor='lightsteelblue', alpha=0.7),
                           medianprops=dict(color='red', linewidth=2))

            # Overlay scatter
            for i, pts in enumerate(data, 1):
                jitter = np.random.RandomState(42).uniform(-0.1, 0.1, len(pts))
                ax.scatter([i] * len(pts) + jitter, pts, alpha=0.6, s=40, zorder=3,
                          color='steelblue', edgecolors='black', linewidth=0.5)

            baseline_ret = all_results.get('B7 Baseline', {})
            baseline_val = baseline_ret['total'] * 100 if baseline_ret else 285
            ax.axhline(y=baseline_val, color='blue', ls='--', lw=1, alpha=0.5,
                       label=f'B7 Baseline ({baseline_val:+.0f}%)')
            ax.axhline(y=219, color='orange', ls='--', lw=1, alpha=0.5,
                       label='V2 Baseline (+219%)')

            ax.set_ylabel('Total Return (%)')
            ax.set_title('V7 Group F: Seed Stability — 10 seeds per strategy',
                         fontsize=13, fontweight='bold')
            ax.legend()
            ax.grid(True, alpha=0.3, axis='y')

            # Add stats text
            for i, key in enumerate(['F1_top2_Bag5', 'F2_top2_Bag30',
                                     'F3_D5mixed_Bag5', 'F4_D6mixed_Bag5']):
                if key in group_f:
                    info = group_f[key]
                    ax.text(i + 1, min(info['returns']) - 15,
                            f'μ={info["mean"]:+.0f}%\nσ={info["spread"]:.0f}pp',
                            ha='center', fontsize=8, style='italic')

        plt.tight_layout()
        plt.savefig(chart_dir / 'v7_seed_stability.png', dpi=150, bbox_inches='tight')
        plt.close()
        P(f"  Chart saved: {chart_dir / 'v7_seed_stability.png'}")


# ============================================================
# SECTION 12: REPORT GENERATION
# ============================================================

def generate_report_v7(all_results, group_d, group_e, group_f, group_g, docs_dir):
    docs_dir.mkdir(parents=True, exist_ok=True)
    report_path = docs_dir / 'PIPELINE_V7_VALIDATION.md'

    baseline = all_results.get('B7 Baseline', {})
    baseline_ret = baseline['total'] * 100 if baseline else 285

    lines = [
        "# Pipeline V7 Validation — Feature Swap Robustness Check",
        "",
        f"**Generated**: {datetime.now().strftime('%Y-%m-%d %H:%M')}",
        f"**Test Period**: 2022-2026 (walk-forward OOS)",
        f"**Baseline**: B7 Pure ML + ret_3d + Bag5 + Weekly = {baseline_ret:+.1f}%",
        "",
        "---",
        "",
        "## Executive Summary",
        "",
    ]

    # Build summary from results
    d_available = group_d is not None and len(group_d) > 0
    e_available = group_e is not None and len(group_e) > 0
    f_available = group_f is not None and len(group_f) > 0
    g_available = group_g is not None and len(group_g) > 0

    if d_available:
        d1_r = group_d.get('D1_add_eth', {}).get('result')
        d2_r = group_d.get('D2_remove_4weak', {}).get('result')
        d4_r = group_d.get('D4_swap_puell_eth', {}).get('result')
        d5_r = group_d.get('D5_mixed_no_eth', {}).get('result')

        lines.append("### Is ETH genuine?")
        if d1_r:
            lines.append(f"- **D1** (add eth): {d1_r['total']*100:+.1f}% "
                        f"({(d1_r['total']-baseline['total'])*100:+.1f}pp vs baseline)")
        if d2_r:
            lines.append(f"- **D2** (remove 4 weak): {d2_r['total']*100:+.1f}% "
                        f"({(d2_r['total']-baseline['total'])*100:+.1f}pp vs baseline)")
        if d4_r:
            lines.append(f"- **D4** (swap puell->eth): {d4_r['total']*100:+.1f}% "
                        f"({(d4_r['total']-baseline['total'])*100:+.1f}pp vs baseline)")
        if d5_r:
            lines.append(f"- **D5** (non-ETH replacements): {d5_r['total']*100:+.1f}% "
                        f"({(d5_r['total']-baseline['total'])*100:+.1f}pp vs baseline)")
        lines.append("")

    if e_available:
        lines.append("### Cross-Model Validation")
        for key, info in group_e.items():
            r = info['result']
            if r:
                lines.append(f"- **{key}**: {r['total']*100:+.1f}% "
                            f"(Sortino {r['sortino']:.2f})")
        lines.append("")

    if f_available:
        lines.append("### Seed Stability")
        for key, info in group_f.items():
            lines.append(f"- **{key}**: mean={info['mean']:+.1f}%, "
                        f"spread={info['spread']:.0f}pp, "
                        f"beat V2: {info['beat_v2']}/10")
        lines.append("")

    lines.extend([
        "---",
        "",
        "## Group D: ETH Ablation",
        "",
        "| Test | Config | Features | Return | Delta | Sortino | MaxDD |",
        "|------|--------|----------|--------|-------|---------|-------|",
    ])

    if d_available:
        lines.append(f"| Baseline | B7 ret_3d | 25 | {baseline_ret:+.1f}% | --- | "
                    f"{baseline['sortino']:.2f} | {baseline['max_dd']*100:.1f}% |")
        for key, info in group_d.items():
            r = info['result']
            if r:
                delta = (r['total'] - baseline['total']) * 100
                lines.append(f"| {key} | {info['config'][:40]} | {info['n_features']} | "
                            f"{r['total']*100:+.1f}% | {delta:+.1f}pp | "
                            f"{r['sortino']:.2f} | {r['max_dd']*100:.1f}% |")

    lines.extend([
        "",
        "## Group E: Cross-Model Validation",
        "",
        "| Test | Model | Swap | Return | Sortino | MaxDD |",
        "|------|-------|------|--------|---------|-------|",
    ])

    if e_available:
        for key, info in group_e.items():
            r = info['result']
            if r:
                lines.append(f"| {key} | {info['model']} | {info['swap']} | "
                            f"{r['total']*100:+.1f}% | {r['sortino']:.2f} | "
                            f"{r['max_dd']*100:.1f}% |")
            else:
                lines.append(f"| {key} | {info['model']} | {info['swap']} | SKIPPED | - | - |")

    lines.extend([
        "",
        "## Group F: Seed Stability",
        "",
        "| Strategy | Mean | Median | Spread | Min | Max | Beat V2 |",
        "|----------|------|--------|--------|-----|-----|---------|",
    ])

    if f_available:
        for key, info in group_f.items():
            lines.append(f"| {key} | {info['mean']:+.1f}% | {info['median']:+.1f}% | "
                        f"{info['spread']:.0f}pp | {info['min']:+.1f}% | "
                        f"{info['max']:+.1f}% | {info['beat_v2']}/10 |")

        # Bootstrap results
        for key, info in group_f.items():
            if 'bootstrap' in info:
                bs = info['bootstrap']
                lines.extend([
                    "",
                    f"### {key} Bootstrap 95% CI",
                    f"- Return CI: [{bs['return_lo']*100:+.0f}%, {bs['return_hi']*100:+.0f}%]",
                    f"- P(return > 0): {bs['excess_above_zero_pct']:.1f}%",
                ])

    lines.extend([
        "",
        "## Group G: Untested High-Rank Features",
        "",
        "| Test | Weak | Strong | Rank | Return | Delta | Sortino |",
        "|------|------|--------|------|--------|-------|---------|",
    ])

    if g_available:
        sorted_g = sorted(group_g.items(),
                         key=lambda x: x[1]['result']['total'] if x[1]['result'] else -999,
                         reverse=True)
        for key, info in sorted_g:
            r = info['result']
            if r:
                delta = (r['total'] - baseline['total']) * 100
                lines.append(f"| {key.split('_')[0]} | {info['weak']} | {info['strong']} | "
                            f"{info['rank']} | {r['total']*100:+.1f}% | "
                            f"{delta:+.1f}pp | {r['sortino']:.2f} |")
            else:
                reason = info.get('reason', 'FAILED')
                lines.append(f"| {key.split('_')[0]} | {info['weak']} | {info['strong']} | "
                            f"{info['rank']} | {reason} | - | - |")

    lines.extend([
        "",
        "---",
        "",
        "## Key Conclusions",
        "",
        "1. **Is ETH genuine?** — See Group D results above",
        "2. **Do non-ETH combos work?** — See D5 result + F3 stability",
        "3. **Model-robust?** — See Group E (>+50pp improvement across models = real)",
        "4. **Most stable strategy?** — See F1-F4 spreads",
        "5. **Better features than ETH?** — See Group G results",
    ])

    report_text = '\n'.join(lines)
    report_path.write_text(report_text, encoding='utf-8')
    P(f"  Report saved: {report_path}")
    return report_path


# ============================================================
# SECTION 13: MAIN
# ============================================================

def main():
    P("=" * 100)
    P("PIPELINE V7 VALIDATION - Feature Swap Robustness Check")
    P("=" * 100)
    P(f"  Start time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    P("\nLoading data...")
    prices, daily_ret, returns, vols, df = load_data()
    dates = df['date'].values
    n = len(prices)
    P(f"  {n} days | {len(df.columns)} columns | {dates[0]} to {dates[-1]}")

    # Build real CDI/Selic risk-free rate series
    global RF_DAILY_ARR
    try:
        from src.features.macro.cdi_rates import build_rf_daily
        RF_DAILY_ARR = build_rf_daily(dates, source='auto')
        P(f"  RF: Real CDI/Selic rates loaded ({len(RF_DAILY_ARR)} days)")
    except Exception as e:
        P(f"  WARNING: Could not load real CDI rates ({e}), using flat 15%")
        RF_DAILY_ARR = None

    all_results = {}
    full_output = {
        'timestamp': datetime.now().isoformat(),
        'method': 'pipeline_v7_validation',
        'test_period': '2022-2026',
    }

    # =========================================================
    # BASELINES
    # =========================================================
    P(f"\n{'='*100}")
    P("BASELINES")
    P("=" * 100)

    # BTC Buy & Hold
    yb = get_year_boundaries(dates, n)
    bh_s, bh_b, bh_a = [], [], []
    for yr in range(2022, 2027):
        if yr not in yb:
            continue
        allocs_bh = np.full(n, 1.0)
        s, b, a = backtest_allocations(daily_ret, allocs_bh, yb[yr]['start'], yb[yr]['end'])
        bh_s.extend(s); bh_b.extend(b); bh_a.extend(a)
    bh_result = metrics(np.array(bh_s), np.array(bh_b), np.array(bh_a))
    all_results['BTC Buy & Hold'] = bh_result
    P(f"  BTC Buy & Hold: {bh_result['total']*100:+.1f}%")

    # B7 Baseline (100/0 + ret_3d)
    P(f"\n  B7 Baseline (100/0 + ret_3d)...")
    r_b7 = run_b7(daily_ret, returns, vols, df, dates, n,
                   n_bags=5, use_weekly=True, target_horizon=3,
                   base_seed=42, verbose=False)
    all_results['B7 Baseline'] = r_b7
    if r_b7:
        P(f"  B7 Baseline: {r_b7['total']*100:+.1f}% | Sortino {r_b7['sortino']:.2f} | "
          f"MaxDD {r_b7['max_dd']*100:.1f}%")

    # V6 A3 top2 reference (puell+rsi->eth) — run for comparison
    P(f"\n  V6 A3 top2 reference (puell+rsi->eth)...")
    swap_top2 = {'puell_multiple': 'eth', 'rsi_14d': 'eth'}
    X_top2, _ = build_ml_features_swap(df, returns, vols, n, swap_top2)
    r_a3 = run_b7(daily_ret, returns, vols, df, dates, n,
                   n_bags=5, use_weekly=True, target_horizon=3,
                   X_all_override=X_top2, base_seed=42, verbose=False)
    all_results['V6 A3 top2 (puell+rsi->eth)'] = r_a3
    if r_a3:
        P(f"  V6 A3 top2: {r_a3['total']*100:+.1f}% | Sortino {r_a3['sortino']:.2f} | "
          f"MaxDD {r_a3['max_dd']*100:.1f}%")

    full_output['baselines'] = {
        'btc_buy_hold': bh_result,
        'b7_baseline': r_b7,
        'v6_a3_top2': r_a3,
    }

    # =========================================================
    # GROUP D: ETH ABLATION
    # =========================================================
    P(f"\n\n{'#'*100}")
    P("GROUP D: ETH ABLATION")
    P("#" * 100)

    group_d_results = group_d_eth_ablation(daily_ret, returns, vols, df, dates, n, r_b7)
    full_output['group_d'] = {}
    for k, v in group_d_results.items():
        entry = dict(v)
        entry.pop('feature_names', None)  # Don't store full list in JSON
        full_output['group_d'][k] = entry

    # =========================================================
    # GROUP E: CROSS-MODEL VALIDATION
    # =========================================================
    P(f"\n\n{'#'*100}")
    P("GROUP E: CROSS-MODEL VALIDATION")
    P("#" * 100)

    group_e_results = group_e_cross_model(daily_ret, returns, vols, df, dates, n, r_b7)
    full_output['group_e'] = group_e_results

    # =========================================================
    # GROUP F: DEEP SEED STABILITY
    # =========================================================
    P(f"\n\n{'#'*100}")
    P("GROUP F: DEEP SEED STABILITY")
    P("#" * 100)

    group_f_results = group_f_seed_stability(daily_ret, returns, vols, df, dates, n, r_b7)
    full_output['group_f'] = group_f_results

    # =========================================================
    # GROUP G: UNTESTED HIGH-RANK FEATURES
    # =========================================================
    P(f"\n\n{'#'*100}")
    P("GROUP G: UNTESTED HIGH-RANK FEATURES")
    P("#" * 100)

    group_g_results = group_g_untested_features(daily_ret, returns, vols, df, dates, n, r_b7)
    full_output['group_g'] = group_g_results

    # =========================================================
    # FINAL SUMMARY
    # =========================================================
    P(f"\n\n{'#'*100}")
    P("FINAL SUMMARY")
    P("#" * 100)

    # Count total tests
    n_d = len(group_d_results)
    n_e = len(group_e_results)
    n_f = sum(len(v.get('returns', [])) for v in group_f_results.values())
    n_g = len(group_g_results)
    total = n_d + n_e + n_f + n_g
    P(f"  Total tests: {total} (D={n_d}, E={n_e}, F_seeds={n_f}, G={n_g})")

    # Best strategies from each group
    P(f"\n  BEST FROM EACH GROUP:")
    if group_d_results:
        best_d = max(((k, v) for k, v in group_d_results.items() if v['result']),
                     key=lambda x: x[1]['result']['total'], default=None)
        if best_d:
            P(f"    Group D: {best_d[0]} at {best_d[1]['result']['total']*100:+.1f}%")

    if group_e_results:
        best_e = max(((k, v) for k, v in group_e_results.items() if v['result']),
                     key=lambda x: x[1]['result']['total'], default=None)
        if best_e:
            P(f"    Group E: {best_e[0]} at {best_e[1]['result']['total']*100:+.1f}%")

    if group_f_results:
        best_f = max(group_f_results.items(), key=lambda x: x[1]['mean'])
        P(f"    Group F: {best_f[0]} mean={best_f[1]['mean']:+.1f}%, "
          f"spread={best_f[1]['spread']:.0f}pp")

    if group_g_results:
        valid_g = [(k, v) for k, v in group_g_results.items() if v['result']]
        if valid_g:
            best_g = max(valid_g, key=lambda x: x[1]['result']['total'])
            P(f"    Group G: {best_g[0]} at {best_g[1]['result']['total']*100:+.1f}%")

    # =========================================================
    # SAVE RESULTS
    # =========================================================
    results_path = ROOT / 'outputs/results/pipeline_v7_validation.json'

    # Convert numpy types for JSON serialization
    def convert_numpy(obj):
        if isinstance(obj, (np.integer,)):
            return int(obj)
        elif isinstance(obj, (np.floating,)):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        elif isinstance(obj, dict):
            return {k: convert_numpy(v) for k, v in obj.items()}
        elif isinstance(obj, (list, tuple)):
            return [convert_numpy(i) for i in obj]
        return obj

    full_output_clean = convert_numpy(full_output)
    results_path.write_text(json.dumps(full_output_clean, indent=2, default=str),
                            encoding='utf-8')
    P(f"\n  Results saved: {results_path}")

    # =========================================================
    # CHARTS
    # =========================================================
    P(f"\n  Generating charts...")
    chart_dir = ROOT / 'outputs/results/charts'
    generate_charts_v7(all_results, group_d_results, group_e_results,
                       group_f_results, chart_dir)

    # =========================================================
    # REPORT
    # =========================================================
    P(f"\n  Generating report...")
    docs_dir = ROOT / 'docs'
    generate_report_v7(all_results, group_d_results, group_e_results,
                       group_f_results, group_g_results, docs_dir)

    P(f"\n{'='*100}")
    P(f"V7 VALIDATION COMPLETE")
    P(f"  End time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    P("=" * 100)


if __name__ == '__main__':
    main()
