"""
PIPELINE V17 — 24-Hour Definitive Final Test (10 Phases, 16 cores)
===================================================================

After V13-V16 (4 pipeline versions on updated data, 30+ hours of compute):

Confirmed facts (do NOT re-test):
  - XGB default hyperparams are near-optimal (V17 Phase 1: optimized S=2.49 vs defaults S=2.64)
  - Semi-annual retrain is best (V13)
  - Friday rebalance is best (V13, V15)
  - Expanding window is best (V13)
  - Equal sample weighting is best (V13)
  - exchange_netflow_ma7 is broken (CoinMetrics revision, corr=0.75)
  - basis_pct is valuable (+0.14 Sortino in V13)
  - Trend filter (SMA200) gives MaxDD=-8% but only +426% return (too conservative)
  - Stacking, classification, multi-horizon veto all FAILED (V15)
  - Feature transforms/interactions are marginal (V13)

Open questions (MUST test):
  1. XGB pure vs Hybrid — conflicting results (V14: XGB S=2.63, V17: Hybrid S=2.67)
  2. Best feature set with new data (240 features screened, top 7 very promising)
  3. Best allocation logic (centered, dynamic regime, partial trend, vol-scaled)
  4. Walk-forward K optimization
  5. Bi-weekly rebalance (never tested)
  6. Feature combinations (top 5 features in all C(5,1)+C(5,2)+...+C(5,5) = 31 combos)

Phases:
  1.  Model Selection (XGB vs Hybrid, bag counts) — 80 runs
  2.  Feature Screening (confirm top 15 with 10 seeds) — 150 runs
  3.  Feature Combinations (all 31 combos of top 5) — 310 runs
  4.  Target Horizon (ret_3d/5d/7d x models) — 60+ runs
  5.  K Sweep (12 values x 10 seeds) — 120 runs
  6.  Allocation Logic (regime/trend/vol/limits/gradual) — 310 runs
  7.  Risk Management (DD budget, confidence, combined) — 100 runs
  8.  Walk-Forward K Optimization (windows, ranges) — 80+ runs
  9.  Rebalance Variations (bi-weekly, day combos, thresholds) — 80+ runs
  10. Final Assembly & Validation (5 profiles + full validation) — 50+ runs

Estimated: ~900 configs x 10 seeds = ~9000 individual runs, ~24h
"""

import sys
import gc
import numpy as np
import pandas as pd
from pathlib import Path
import warnings
import json
from datetime import datetime
from itertools import combinations
from concurrent.futures import ThreadPoolExecutor
import lightgbm as lgb
import xgboost as xgb

warnings.filterwarnings('ignore')
sys.stdout.reconfigure(line_buffering=True)

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

from archive.old_pipelines.pipeline_v09 import (
    load_data, build_ml_features, backtest_allocations,
    metrics, get_year_boundaries,
    SEEDS_10, COST, DEFAULT_LGB_PARAMS,
    P, _seed_summary, convert_numpy,
)
from archive.old_pipelines.pipeline_v10 import MODELS, _compute_allocation
from archive.old_pipelines.pipeline_v11 import DEFAULT_XGB_PARAMS
from archive.old_pipelines.pipeline_v13 import (
    _get_retrain_periods, _train_one_xgb, _train_one_lgb,
)

RF_DAILY_ARR = None
RESULTS_PATH = ROOT / 'outputs/results/pipeline_v17.json'
W = 16  # worker threads


def _save(R):
    RESULTS_PATH.parent.mkdir(parents=True, exist_ok=True)
    RESULTS_PATH.write_text(json.dumps(convert_numpy(R), indent=2, default=str), encoding='utf-8')
    P(f"  [SAVE] {RESULTS_PATH.name}")


def get_clean_feats():
    return [f for f in MODELS['37feat'] if f != 'exchange_netflow_ma7'] + ['basis_pct']


# ============================================================
# CORE ENGINE: Flexible allocation with all options
# ============================================================

def run_flex(daily_ret, returns, vols, df, dates, n,
             feature_cols, n_bags=60, base_seed=42,
             xgb_params=None, lgb_bags=0,
             target_horizon=3, retrain_freq='semi',
             alloc_mode='centered', alloc_config=None,
             rebal_day=4, rebal_days=None,
             rebal_threshold=0.0,
             wf_val_window=180, wf_K_range=None,
             return_daily=False):
    """Flexible engine supporting all allocation modes.

    Args:
        rebal_days: list of weekday ints (e.g. [0,4] for Mon+Fri). Overrides rebal_day.
        rebal_threshold: only rebalance if |pred_change| > threshold (0 = always).
        wf_val_window: days of validation data for walk-forward K optimization.
        wf_K_range: tuple (min_K, max_K) for walk-forward search. None = default [10,40].
        return_daily: if True, return (metrics, strat_daily, btc_daily, test_indices)
                      for per-year decomposition.
    """
    if alloc_config is None:
        alloc_config = {}
    if xgb_params is None:
        xgb_params = dict(DEFAULT_XGB_PARAMS)

    prices = df['price_usd'].values
    X_all, _ = build_ml_features(df, returns, vols, n, feature_cols=feature_cols)

    target = np.zeros(n)
    for i in range(n - target_horizon):
        target[i] = (prices[i + target_horizon] - prices[i]) / prices[i]

    day_of_week = pd.to_datetime(dates).dayofweek
    sma_50 = pd.Series(prices).rolling(50).mean().values
    sma_200 = pd.Series(prices).rolling(200).mean().values
    vol_30 = pd.Series(daily_ret).rolling(30).std().fillna(0.02).values
    yb = get_year_boundaries(dates, n)
    oos_start = yb[2022]['start'] if 2022 in yb else 0
    vol_median = np.nanmedian(vol_30[:oos_start])

    lgb_p = dict(DEFAULT_LGB_PARAMS)
    lgb_p['min_data_in_leaf'] = 12

    periods = _get_retrain_periods(dates, n, retrain_freq)
    full_allocs = np.full(n, 0.0)
    is_rf_arr = isinstance(RF_DAILY_ARR, np.ndarray)
    all_strat, all_btc, all_alloc, all_rf = [], [], [], []
    all_test_indices = []  # track which date index each daily return corresponds to

    running_equity = 1.0
    peak_equity = 1.0
    prev_alloc = 0.0
    prev_pred = None

    # Determine rebalance day set
    if rebal_days is not None:
        rebal_day_set = set(rebal_days)
    else:
        rebal_day_set = {rebal_day}

    for train_end, test_start, test_end in periods:
        gap = max(target_horizon, 5)
        train_mask = np.arange(60, train_end - gap + 1)
        valid = ~np.any(np.isnan(X_all[train_mask]), axis=1)
        idx = train_mask[valid]
        if len(idx) < 100:
            continue

        Xt = np.nan_to_num(X_all[idx], nan=0.0)
        yt = target[idx]

        # Train XGB
        models_xgb = []
        if n_bags > 0:
            seeds = [base_seed + i * 7 for i in range(n_bags)]
            args = [(s, Xt, yt, xgb_params) for s in seeds]
            with ThreadPoolExecutor(max_workers=W) as ex:
                models_xgb = list(ex.map(_train_one_xgb, args))

        # Train LGB (if hybrid)
        models_lgb = []
        if lgb_bags > 0:
            seeds = [base_seed + i * 7 for i in range(lgb_bags)]
            args = [(s, Xt, yt, lgb_p) for s in seeds]
            with ThreadPoolExecutor(max_workers=W) as ex:
                models_lgb = list(ex.map(_train_one_lgb, args))

        all_models = models_lgb + models_xgb
        if not all_models:
            continue

        # Walk-forward K optimization
        wf_K = alloc_config.get('K', 27)
        if alloc_mode == 'walkforward':
            val_start = max(60, train_end - wf_val_window)
            val_mask = np.arange(val_start, train_end - gap + 1)
            val_valid = ~np.any(np.isnan(X_all[val_mask]), axis=1)
            val_idx = val_mask[val_valid]
            if len(val_idx) > 50:
                k_lo, k_hi = (wf_K_range or (10, 40))
                k_candidates = list(range(k_lo, k_hi + 1, 5))
                if wf_K not in k_candidates:
                    k_candidates.append(wf_K)
                best_K_score = -999
                for test_K in k_candidates:
                    val_returns = []
                    for vi in val_idx:
                        if day_of_week[vi] not in rebal_day_set:
                            continue
                        x_v = np.nan_to_num(X_all[vi:vi + 1].copy(), nan=0.0)
                        vpreds = [m.predict(x_v)[0] for m in all_models]
                        vpred = np.mean(vpreds)
                        valloc = np.clip(vpred * test_K, -0.25, 1.0)
                        if vi + 5 < n:
                            vret = valloc * daily_ret[vi + 1] + (1 - abs(valloc)) * (
                                RF_DAILY_ARR[vi] if is_rf_arr else 0)
                            val_returns.append(vret)
                    if val_returns and np.std(val_returns) > 0:
                        sharpe = np.mean(val_returns) / np.std(val_returns)
                        if sharpe > best_K_score:
                            best_K_score = sharpe
                            wf_K = test_K

        for t in range(test_start, test_end + 1):
            is_rebal = day_of_week[t] in rebal_day_set

            if is_rebal:
                x_t = np.nan_to_num(X_all[t:t + 1].copy(), nan=0.0)
                preds = [m.predict(x_t)[0] for m in all_models]
                avg_pred = np.mean(preds)
                pred_std = np.std(preds)

                # Conditional rebalance threshold
                should_rebal = True
                if rebal_threshold > 0 and prev_pred is not None:
                    if abs(avg_pred - prev_pred) < rebal_threshold:
                        should_rebal = False

                if should_rebal:
                    raw = _apply_allocation(
                        avg_pred, pred_std, prices[t],
                        sma_50[t], sma_200[t], vol_30[t], vol_median,
                        running_equity, peak_equity, prev_alloc,
                        alloc_mode, alloc_config, wf_K)
                    prev_alloc = raw
                    prev_pred = avg_pred

            full_allocs[t] = prev_alloc

        s, b, a = backtest_allocations(daily_ret, full_allocs, test_start, test_end,
                                       cost=COST, rf_daily=RF_DAILY_ARR)
        all_strat.extend(s)
        all_btc.extend(b)
        all_alloc.extend(a)
        all_test_indices.extend(range(test_start, test_start + len(s)))
        for sr in s:
            running_equity *= (1 + sr)
            peak_equity = max(peak_equity, running_equity)
        nd = len(s)
        if is_rf_arr:
            all_rf.extend(RF_DAILY_ARR[test_start:test_start + nd])
        else:
            all_rf.extend([0.0] * nd)

    m = metrics(np.array(all_strat), np.array(all_btc), np.array(all_alloc),
                rf_daily=np.array(all_rf))
    if return_daily:
        return m, np.array(all_strat), np.array(all_btc), np.array(all_test_indices)
    return m


def _apply_allocation(pred, pred_std, price, sma50, sma200, vol30, vol_med,
                       equity, peak, prev_alloc, mode, config, wf_K):
    """Apply allocation logic based on mode."""
    K = config.get('K', wf_K)

    if mode == 'baseline':
        raw = pred * K + 0.375

    elif mode == 'centered':
        raw = pred * K

    elif mode == 'dynamic_regime':
        K_bull = config.get('K_bull', 35)
        K_mild = config.get('K_mild', 25)
        K_bear = config.get('K_bear', 15)
        if not np.isnan(sma50) and not np.isnan(sma200):
            if price > sma50 and sma50 > sma200:
                raw = pred * K_bull
            elif price > sma200:
                raw = pred * K_mild
            else:
                raw = pred * K_bear
        else:
            raw = pred * K_mild

    elif mode == 'vol_scaled':
        vol_ratio = (vol30 * np.sqrt(365)) / max(vol_med * np.sqrt(365), 0.1)
        vol_ratio = np.clip(vol_ratio, 0.5, 3.0)
        raw = pred * K / vol_ratio

    elif mode == 'partial_trend':
        K_bull = config.get('K_bull', 35)
        K_bear = config.get('K_bear', 10)
        max_bear = config.get('max_bear', 0.0)
        if not np.isnan(sma50) and not np.isnan(sma200):
            if price > sma50 and sma50 > sma200:
                raw = pred * K_bull
            elif price > sma200:
                raw = min(pred * K_bull * 0.5, 0.3)
            else:
                raw = min(pred * K_bear, max_bear)
        else:
            raw = pred * K_bull * 0.5

    elif mode == 'position_limit':
        max_long = config.get('max_long', 0.80)
        max_short = config.get('max_short', -0.15)
        raw = pred * K
        raw = np.clip(raw, max_short, max_long)

    elif mode == 'gradual':
        max_delta = config.get('max_delta', 0.25)
        raw = pred * K
        delta = raw - prev_alloc
        if abs(delta) > max_delta:
            raw = prev_alloc + np.sign(delta) * max_delta

    elif mode == 'confidence_gated':
        min_conf = config.get('min_confidence', 0.3)
        confidence = 1.0 - np.clip(pred_std / 0.03, 0, 1)
        if confidence < min_conf:
            raw = 0.0
        else:
            raw = pred * K * confidence

    elif mode == 'dd_budget':
        max_dd = config.get('max_dd', -0.15)
        dd = (equity - peak) / (peak + 1e-10)
        raw = pred * K
        if dd < max_dd * 0.5:
            scale = max(0.1, 1.0 - abs(dd) / abs(max_dd))
            raw *= scale
        if dd < max_dd:
            raw = min(raw, 0.0)

    elif mode == 'walkforward':
        raw = pred * wf_K

    elif mode == 'dynamic_trend_dd':
        K_bull = config.get('K_bull', 35)
        K_mild = config.get('K_mild', 25)
        K_bear = config.get('K_bear', 10)
        max_dd = config.get('max_dd', -0.15)
        max_bear_alloc = config.get('max_bear', -0.10)
        if not np.isnan(sma50) and not np.isnan(sma200):
            if price > sma50 and sma50 > sma200:
                raw = pred * K_bull
            elif price > sma200:
                raw = min(pred * K_mild, 0.5)
            else:
                raw = min(pred * K_bear, max_bear_alloc)
        else:
            raw = pred * K_mild
        dd = (equity - peak) / (peak + 1e-10)
        if dd < max_dd * 0.5:
            scale = max(0.1, 1.0 - abs(dd) / abs(max_dd))
            raw *= scale

    elif mode == 'dd_plus_alloc':
        # Apply the base allocation from sub_mode, then overlay DD budget
        sub_mode = config.get('sub_mode', 'centered')
        max_dd = config.get('max_dd', -0.15)
        # Compute base allocation
        sub_cfg = {k: v for k, v in config.items() if k not in ('sub_mode', 'max_dd')}
        raw = _apply_allocation(pred, pred_std, price, sma50, sma200, vol30, vol_med,
                                equity, peak, prev_alloc, sub_mode, sub_cfg, wf_K)
        # Overlay DD budget
        dd = (equity - peak) / (peak + 1e-10)
        if dd < max_dd * 0.5:
            scale = max(0.1, 1.0 - abs(dd) / abs(max_dd))
            raw *= scale
        if dd < max_dd:
            raw = min(raw, 0.0)

    elif mode == 'conf_plus_alloc':
        # Apply the base allocation, then overlay confidence gating
        sub_mode = config.get('sub_mode', 'centered')
        min_conf = config.get('min_confidence', 0.3)
        sub_cfg = {k: v for k, v in config.items() if k not in ('sub_mode', 'min_confidence')}
        raw = _apply_allocation(pred, pred_std, price, sma50, sma200, vol30, vol_med,
                                equity, peak, prev_alloc, sub_mode, sub_cfg, wf_K)
        confidence = 1.0 - np.clip(pred_std / 0.03, 0, 1)
        if confidence < min_conf:
            raw = 0.0
        else:
            raw *= confidence

    elif mode == 'dd_conf_alloc':
        # Apply base allocation, then confidence gating, then DD budget
        sub_mode = config.get('sub_mode', 'centered')
        max_dd = config.get('max_dd', -0.15)
        min_conf = config.get('min_confidence', 0.3)
        sub_cfg = {k: v for k, v in config.items()
                   if k not in ('sub_mode', 'max_dd', 'min_confidence')}
        raw = _apply_allocation(pred, pred_std, price, sma50, sma200, vol30, vol_med,
                                equity, peak, prev_alloc, sub_mode, sub_cfg, wf_K)
        # Confidence overlay
        confidence = 1.0 - np.clip(pred_std / 0.03, 0, 1)
        if confidence < min_conf:
            raw = 0.0
        else:
            raw *= confidence
        # DD budget overlay
        dd = (equity - peak) / (peak + 1e-10)
        if dd < max_dd * 0.5:
            scale = max(0.1, 1.0 - abs(dd) / abs(max_dd))
            raw *= scale
        if dd < max_dd:
            raw = min(raw, 0.0)

    else:
        raw = pred * K

    return np.clip(raw, -0.25, 1.0)


# ============================================================
# HELPERS
# ============================================================

def _seeds(dr, ret, vol, df, dt, n, label, **kw):
    results = []
    for seed in SEEDS_10:
        P(f"    seed={seed}...", end="")
        r = run_flex(dr, ret, vol, df, dt, n, base_seed=seed, **kw)
        if r:
            results.append(r)
            P(f" {r['total']*100:+.1f}% S={r['sortino']:.2f} DD={r['max_dd']*100:.1f}%")
        else:
            P(" FAILED")
        gc.collect()
    if not results:
        return None
    rets = [r['total']*100 for r in results]
    s = _seed_summary(rets, results)
    P(f"    {label}: mean={s['mean']:+.1f}%, S={s['sortinos_mean']:.2f}, "
      f"spread={s['spread']:.0f}pp, MaxDD={s['max_dds_mean']:.1f}%")
    return s


def _1seed(dr, ret, vol, df, dt, n, label, **kw):
    P(f"    {label}...", end="")
    r = run_flex(dr, ret, vol, df, dt, n, base_seed=42, **kw)
    if r:
        P(f" {r['total']*100:+.1f}% S={r['sortino']:.2f} DD={r['max_dd']*100:.1f}%")
        return {'return': float(r['total']*100), 'sortino': float(r['sortino']),
                'max_dd': float(r['max_dd']*100)}
    P(" FAILED")
    return None


def _rank_by_sortino(results):
    """Sort results dict by sortinos_mean descending."""
    return sorted(results.items(),
                  key=lambda x: x[1].get('sortinos_mean', 0) if isinstance(x[1], dict) else 0,
                  reverse=True)


def _best_config(results, key='sortinos_mean'):
    """Return (label, data) of best config from results dict."""
    best_k, best_s = None, -999
    for k, s in results.items():
        if isinstance(s, dict) and s.get(key, -999) > best_s:
            best_s = s[key]
            best_k = k
    return best_k, results.get(best_k, {})


# ============================================================
# PHASE 1: Model Selection (2h) — 80 runs
# ============================================================

def phase_1(dr, ret, vol, df, dt, n, fc):
    P(f"\n{'#'*100}")
    P("PHASE 1: MODEL SELECTION (XGB pure vs Hybrid, DEFAULT params)")
    P("#" * 100)

    results = {}
    base_kw = dict(feature_cols=fc, alloc_mode='centered', alloc_config={'K': 27})

    # XGB pure: Bag40, Bag60, Bag80, Bag100
    for nb in [40, 60, 80, 100]:
        P(f"\n  --- XGB Bag{nb} ---")
        s = _seeds(dr, ret, vol, df, dt, n, f'xgb_{nb}',
                   n_bags=nb, lgb_bags=0, **base_kw)
        if s: results[f'xgb_{nb}'] = s

    # Hybrid: 15+30, 15+45, 15+60, 10+50
    for nl, nx in [(15, 30), (15, 45), (15, 60), (10, 50)]:
        P(f"\n  --- Hybrid {nl}+{nx} ---")
        s = _seeds(dr, ret, vol, df, dt, n, f'h_{nl}+{nx}',
                   n_bags=nx, lgb_bags=nl, **base_kw)
        if s: results[f'h_{nl}+{nx}'] = s

    # Print ranking
    P(f"\n  PHASE 1 RANKING:")
    for k, s in _rank_by_sortino(results):
        P(f"    {k:<20} mean={s['mean']:+.1f}% S={s['sortinos_mean']:.2f} "
          f"spread={s['spread']:.0f}pp DD={s['max_dds_mean']:.1f}%")

    return results


# ============================================================
# PHASE 2: Feature Screening — Confirm Top 15 (3h) — 150 runs
# ============================================================

def phase_2(dr, ret, vol, df, dt, n, fc, best_bags, best_lgb):
    P(f"\n{'#'*100}")
    P("PHASE 2: FEATURE SCREENING — CONFIRM TOP 15 (10 seeds each)")
    P("#" * 100)

    kw = dict(n_bags=best_bags, lgb_bags=best_lgb,
              alloc_mode='centered', alloc_config={'K': 27})

    # Top 15 from V17 Phase 3 1-seed screen
    top_15 = [
        'fed_balance_sheet', 'realized_price', 'volume_per_trade',
        'btc_sp500_corr_30d', 'btc_eth_corr_30d', 'futures_trade_count',
        'velocity', 'vol_x_regime_duration', 'futures_dominance',
        'stock_to_flow', 'spot_taker_sell_ratio', 'true_range',
        'fees_total_24h', 'exchange_netflow_usd', 'hash_rate_pctchg_30d',
    ]

    # Filter to available features
    available = [f for f in top_15 if f in df.columns and f not in fc]
    P(f"  {len(available)}/{len(top_15)} features available in dataset")

    # Baseline (10 seeds)
    P(f"\n  --- Baseline ({len(fc)} features) ---")
    base_s = _seeds(dr, ret, vol, df, dt, n, 'baseline', feature_cols=fc, **kw)
    results = {}
    if base_s: results['baseline'] = base_s
    base_sortino = base_s['sortinos_mean'] if base_s else 0

    # Confirm each feature with 10 seeds
    for feat in available:
        feats = fc + [feat]
        P(f"\n  --- +{feat} ({len(feats)} features) ---")
        s = _seeds(dr, ret, vol, df, dt, n, f'+{feat}', feature_cols=feats, **kw)
        if s:
            s['diff_sortino'] = s['sortinos_mean'] - base_sortino
            results[f'+{feat}'] = s

    # Ranking
    P(f"\n  PHASE 2 RANKING:")
    for k, s in _rank_by_sortino(results):
        diff = s.get('diff_sortino', 0)
        P(f"    {k:<35} mean={s['mean']:+.1f}% S={s['sortinos_mean']:.2f} "
          f"spread={s['spread']:.0f}pp ({diff:+.3f})")

    return results


# ============================================================
# PHASE 3: Feature Combinations (3h) — 310 runs
# ============================================================

def phase_3(dr, ret, vol, df, dt, n, fc, best_bags, best_lgb, top5_features):
    P(f"\n{'#'*100}")
    P("PHASE 3: FEATURE COMBINATIONS — ALL 31 COMBOS OF TOP 5")
    P("#" * 100)

    kw = dict(n_bags=best_bags, lgb_bags=best_lgb,
              alloc_mode='centered', alloc_config={'K': 27})

    results = {}
    P(f"  Top 5 features: {top5_features}")

    # Baseline: no additions (to verify combos actually improve)
    P(f"\n  --- Baseline (no additions) ---")
    s = _seeds(dr, ret, vol, df, dt, n, 'baseline', feature_cols=fc, **kw)
    if s: results['_baseline'] = s

    combo_num = 0
    for r in range(1, len(top5_features) + 1):
        for combo in combinations(top5_features, r):
            combo_num += 1
            combo_list = list(combo)
            feats = fc + combo_list
            label = '+'.join(combo_list)
            short_label = f"c{combo_num}_{r}of5"
            P(f"\n  --- Combo {combo_num}/31: +{label} ---")
            s = _seeds(dr, ret, vol, df, dt, n, short_label, feature_cols=feats, **kw)
            if s: results[label] = s

    # Ranking
    P(f"\n  PHASE 3 RANKING (top 15):")
    for k, s in _rank_by_sortino(results)[:15]:
        n_added = k.count('+') + 1
        P(f"    +{k:<50} ({n_added}feat) S={s['sortinos_mean']:.2f} "
          f"mean={s['mean']:+.1f}% spread={s['spread']:.0f}pp")

    return results


# ============================================================
# PHASE 4: Target Horizon (2h) — 60+ runs
# ============================================================

def phase_4(dr, ret, vol, df, dt, n, best_feats, best_bags, best_lgb):
    P(f"\n{'#'*100}")
    P("PHASE 4: TARGET HORIZON & RETRAIN COMBOS")
    P("#" * 100)

    results = {}

    # Test horizons with both XGB and Hybrid
    models = [
        ('xgb', best_bags, 0),
        ('hybrid', best_bags, best_lgb),
    ]
    if best_lgb == 0:
        # If best is pure XGB, also test hybrid to compare
        models.append(('hybrid_15', best_bags, 15))

    for horizon in [3, 5, 7]:
        for model_name, nb, nlb in models:
            P(f"\n  --- ret_{horizon}d, {model_name} ---")
            s = _seeds(dr, ret, vol, df, dt, n, f'ret{horizon}d_{model_name}',
                       feature_cols=best_feats, n_bags=nb, lgb_bags=nlb,
                       target_horizon=horizon,
                       alloc_mode='centered', alloc_config={'K': 27})
            if s: results[f'ret{horizon}d_{model_name}'] = s

    # Test retrain frequencies with ret_5d (to check if semi still best)
    for freq in ['semi', 'quarterly']:
        P(f"\n  --- ret_5d, {freq} ---")
        s = _seeds(dr, ret, vol, df, dt, n, f'ret5d_{freq}',
                   feature_cols=best_feats, n_bags=best_bags, lgb_bags=best_lgb,
                   target_horizon=5, retrain_freq=freq,
                   alloc_mode='centered', alloc_config={'K': 27})
        if s: results[f'ret5d_{freq}'] = s

    # Ranking
    P(f"\n  PHASE 4 RANKING:")
    for k, s in _rank_by_sortino(results):
        P(f"    {k:<30} S={s['sortinos_mean']:.2f} mean={s['mean']:+.1f}% "
          f"spread={s['spread']:.0f}pp DD={s['max_dds_mean']:.1f}%")

    return results


# ============================================================
# PHASE 5: K Sweep — Full Grid (2h) — 120 runs
# ============================================================

def phase_5(dr, ret, vol, df, dt, n, best_feats, best_bags, best_lgb,
            best_horizon, best_retrain):
    P(f"\n{'#'*100}")
    P("PHASE 5: K SWEEP — FULL GRID (centered allocation)")
    P("#" * 100)

    results = {}
    kw = dict(feature_cols=best_feats, n_bags=best_bags, lgb_bags=best_lgb,
              target_horizon=best_horizon, retrain_freq=best_retrain)

    for K in [10, 15, 18, 20, 22, 25, 27, 30, 33, 35, 40, 45]:
        P(f"\n  --- centered K={K} ---")
        s = _seeds(dr, ret, vol, df, dt, n, f'K={K}',
                   alloc_mode='centered', alloc_config={'K': K}, **kw)
        if s: results[f'K={K}'] = s

    # Ranking
    P(f"\n  PHASE 5 RANKING:")
    for k, s in _rank_by_sortino(results):
        P(f"    {k:<15} S={s['sortinos_mean']:.2f} mean={s['mean']:+.1f}% "
          f"spread={s['spread']:.0f}pp DD={s['max_dds_mean']:.1f}%")

    return results


# ============================================================
# PHASE 6: Allocation Logic — Massive Grid (4h) — 310 runs
# ============================================================

def phase_6(dr, ret, vol, df, dt, n, best_feats, best_bags, best_lgb,
            best_horizon, best_retrain, best_K):
    P(f"\n{'#'*100}")
    P("PHASE 6: ALLOCATION LOGIC — MASSIVE GRID")
    P("#" * 100)

    results = {}
    kw = dict(feature_cols=best_feats, n_bags=best_bags, lgb_bags=best_lgb,
              target_horizon=best_horizon, retrain_freq=best_retrain)

    # 6A: Dynamic Regime K (12 configs)
    P(f"\n  === 6A: Dynamic Regime K ===")
    regime_configs = [
        ('dyn_35_25_15', 35, 25, 15),
        ('dyn_35_25_10', 35, 25, 10),
        ('dyn_35_25_5',  35, 25, 5),
        ('dyn_35_25_0',  35, 25, 0),
        ('dyn_40_30_15', 40, 30, 15),
        ('dyn_40_25_10', 40, 25, 10),
        ('dyn_30_20_10', 30, 20, 10),
        ('dyn_30_20_5',  30, 20, 5),
        ('dyn_35_20_0',  35, 20, 0),
        ('dyn_40_20_0',  40, 20, 0),
        ('dyn_45_25_10', 45, 25, 10),
        ('dyn_35_30_15', 35, 30, 15),
    ]
    for label, Kb, Km, Kbear in regime_configs:
        P(f"\n  --- {label} ---")
        s = _seeds(dr, ret, vol, df, dt, n, label,
                   alloc_mode='dynamic_regime',
                   alloc_config={'K_bull': Kb, 'K_mild': Km, 'K_bear': Kbear}, **kw)
        if s: results[label] = s

    # 6B: Partial Trend Filter (8 configs)
    P(f"\n  === 6B: Partial Trend Filter ===")
    partial_configs = [
        ('partial_35_10_0',     35, 10, 0.0),
        ('partial_35_15_n10',   35, 15, -0.10),
        ('partial_35_10_n10',   35, 10, -0.10),
        ('partial_35_10_n15',   35, 10, -0.15),
        ('partial_30_10_0',     30, 10, 0.0),
        ('partial_30_10_n10',   30, 10, -0.10),
        ('partial_40_15_n10',   40, 15, -0.10),
        ('partial_40_10_n15',   40, 10, -0.15),
    ]
    for label, Kb, Kbear, max_bear in partial_configs:
        P(f"\n  --- {label} ---")
        s = _seeds(dr, ret, vol, df, dt, n, label,
                   alloc_mode='partial_trend',
                   alloc_config={'K_bull': Kb, 'K_bear': Kbear, 'max_bear': max_bear}, **kw)
        if s: results[label] = s

    # 6C: Vol-Scaled (4 configs)
    P(f"\n  === 6C: Vol-Scaled ===")
    for K in [25, 30, 35, 40]:
        P(f"\n  --- vol_scaled K={K} ---")
        s = _seeds(dr, ret, vol, df, dt, n, f'vol_K{K}',
                   alloc_mode='vol_scaled', alloc_config={'K': K}, **kw)
        if s: results[f'vol_K{K}'] = s

    # 6D: Position Limits (4 configs)
    P(f"\n  === 6D: Position Limits ===")
    limit_configs = [
        ('limit_80_15', 0.80, -0.15),
        ('limit_70_10', 0.70, -0.10),
        ('limit_60_10', 0.60, -0.10),
        ('limit_60_5',  0.60, -0.05),
    ]
    for label, ml, ms in limit_configs:
        P(f"\n  --- {label} ---")
        s = _seeds(dr, ret, vol, df, dt, n, label,
                   alloc_mode='position_limit',
                   alloc_config={'K': best_K, 'max_long': ml, 'max_short': ms}, **kw)
        if s: results[label] = s

    # 6E: Gradual Changes (3 configs)
    P(f"\n  === 6E: Gradual Changes ===")
    for md in [0.15, 0.25, 0.35]:
        P(f"\n  --- gradual delta={md} ---")
        s = _seeds(dr, ret, vol, df, dt, n, f'grad_{int(md*100)}',
                   alloc_mode='gradual',
                   alloc_config={'K': best_K, 'max_delta': md}, **kw)
        if s: results[f'grad_{int(md*100)}'] = s

    # Add centered baseline for comparison
    P(f"\n  === Centered Baseline (K={best_K}) ===")
    s = _seeds(dr, ret, vol, df, dt, n, f'cent_K{best_K}',
               alloc_mode='centered', alloc_config={'K': best_K}, **kw)
    if s: results[f'cent_K{best_K}'] = s

    # Ranking
    P(f"\n  PHASE 6 RANKING (top 15):")
    for k, s in _rank_by_sortino(results)[:15]:
        P(f"    {k:<25} S={s['sortinos_mean']:.2f} mean={s['mean']:+.1f}% "
          f"spread={s['spread']:.0f}pp DD={s['max_dds_mean']:.1f}%")

    return results


# ============================================================
# PHASE 7: Risk Management (2h) — 100 runs
# ============================================================

def phase_7(dr, ret, vol, df, dt, n, best_feats, best_bags, best_lgb,
            best_horizon, best_retrain, best_alloc_mode, best_alloc_cfg):
    P(f"\n{'#'*100}")
    P("PHASE 7: RISK MANAGEMENT")
    P("#" * 100)

    results = {}
    kw = dict(feature_cols=best_feats, n_bags=best_bags, lgb_bags=best_lgb,
              target_horizon=best_horizon, retrain_freq=best_retrain)

    # Baseline (best alloc from Phase 6)
    P(f"\n  --- Baseline ({best_alloc_mode}) ---")
    s = _seeds(dr, ret, vol, df, dt, n, 'baseline',
               alloc_mode=best_alloc_mode, alloc_config=best_alloc_cfg, **kw)
    if s: results['baseline'] = s

    # 7A: Drawdown Budget (4 configs)
    P(f"\n  === 7A: Drawdown Budget ===")
    for dd in [-0.10, -0.12, -0.15, -0.20]:
        P(f"\n  --- dd_budget {dd:.0%} ---")
        s = _seeds(dr, ret, vol, df, dt, n, f'dd_{int(abs(dd)*100)}',
                   alloc_mode='dd_budget',
                   alloc_config={'K': best_alloc_cfg.get('K', 27), 'max_dd': dd}, **kw)
        if s: results[f'dd_{int(abs(dd)*100)}'] = s

    # 7B: Confidence Gating (3 configs)
    P(f"\n  === 7B: Confidence Gating ===")
    for mc in [0.2, 0.3, 0.4]:
        P(f"\n  --- confidence {mc} ---")
        s = _seeds(dr, ret, vol, df, dt, n, f'conf_{int(mc*100)}',
                   alloc_mode='confidence_gated',
                   alloc_config={'K': best_alloc_cfg.get('K', 27), 'min_confidence': mc}, **kw)
        if s: results[f'conf_{int(mc*100)}'] = s

    # 7C: Combined — best_alloc + DD budget
    P(f"\n  === 7C: Combined (best alloc + DD) ===")
    cfg_dd = dict(best_alloc_cfg)
    cfg_dd['sub_mode'] = best_alloc_mode
    cfg_dd['max_dd'] = -0.15
    P(f"\n  --- alloc+dd_15 ---")
    s = _seeds(dr, ret, vol, df, dt, n, 'alloc+dd_15',
               alloc_mode='dd_plus_alloc', alloc_config=cfg_dd, **kw)
    if s: results['alloc+dd_15'] = s

    # 7C: Combined — best_alloc + confidence
    cfg_conf = dict(best_alloc_cfg)
    cfg_conf['sub_mode'] = best_alloc_mode
    cfg_conf['min_confidence'] = 0.3
    P(f"\n  --- alloc+conf_30 ---")
    s = _seeds(dr, ret, vol, df, dt, n, 'alloc+conf_30',
               alloc_mode='conf_plus_alloc', alloc_config=cfg_conf, **kw)
    if s: results['alloc+conf_30'] = s

    # 7C: Combined — best_alloc + DD + confidence (uses dedicated mode)
    cfg_both = dict(best_alloc_cfg)
    cfg_both['sub_mode'] = best_alloc_mode
    cfg_both['max_dd'] = -0.15
    cfg_both['min_confidence'] = 0.3
    P(f"\n  --- alloc+dd+conf ---")
    s = _seeds(dr, ret, vol, df, dt, n, 'alloc+dd+conf',
               alloc_mode='dd_conf_alloc', alloc_config=cfg_both, **kw)
    if s: results['alloc+dd+conf'] = s

    # Ranking
    P(f"\n  PHASE 7 RANKING:")
    for k, s in _rank_by_sortino(results):
        P(f"    {k:<25} S={s['sortinos_mean']:.2f} mean={s['mean']:+.1f}% "
          f"spread={s['spread']:.0f}pp DD={s['max_dds_mean']:.1f}%")

    return results


# ============================================================
# PHASE 8: Walk-Forward K Optimization (2h) — 80+ runs
# ============================================================

def phase_8(dr, ret, vol, df, dt, n, best_feats, best_bags, best_lgb,
            best_horizon, best_retrain, best_alloc_cfg):
    P(f"\n{'#'*100}")
    P("PHASE 8: WALK-FORWARD K OPTIMIZATION")
    P("#" * 100)

    results = {}
    # NOTE: retrain_freq NOT in kw — passed explicitly to allow overrides in 8B
    kw = dict(feature_cols=best_feats, n_bags=best_bags, lgb_bags=best_lgb,
              target_horizon=best_horizon)

    # Fixed K baseline
    best_K = best_alloc_cfg.get('K', 27)
    P(f"\n  --- Fixed K={best_K} baseline ---")
    s = _seeds(dr, ret, vol, df, dt, n, f'fixed_K{best_K}',
               alloc_mode='centered', alloc_config={'K': best_K},
               retrain_freq=best_retrain, **kw)
    if s: results[f'fixed_K{best_K}'] = s

    # 8A: WF K with different validation windows
    P(f"\n  === 8A: Validation Windows ===")
    for val_window in [90, 180, 365]:
        P(f"\n  --- WF val={val_window}d ---")
        s = _seeds(dr, ret, vol, df, dt, n, f'wf_val{val_window}',
                   alloc_mode='walkforward', alloc_config={'K': best_K},
                   wf_val_window=val_window, retrain_freq=best_retrain, **kw)
        if s: results[f'wf_val{val_window}'] = s

    # 8B: WF with different retrain frequencies
    P(f"\n  === 8B: WF Retrain Frequencies ===")
    for freq in ['semi', 'quarterly']:
        P(f"\n  --- WF {freq} ---")
        s = _seeds(dr, ret, vol, df, dt, n, f'wf_{freq}',
                   alloc_mode='walkforward', alloc_config={'K': best_K},
                   retrain_freq=freq, wf_val_window=180, **kw)
        if s: results[f'wf_{freq}'] = s

    # 8C: WF with different K candidate ranges
    P(f"\n  === 8C: K Candidate Ranges ===")
    for label, k_range in [('wf_narrow', (20, 35)), ('wf_wide', (10, 45))]:
        P(f"\n  --- {label} {k_range} ---")
        s = _seeds(dr, ret, vol, df, dt, n, label,
                   alloc_mode='walkforward', alloc_config={'K': best_K},
                   wf_val_window=180, wf_K_range=k_range,
                   retrain_freq=best_retrain, **kw)
        if s: results[label] = s

    # Ranking
    P(f"\n  PHASE 8 RANKING:")
    for k, s in _rank_by_sortino(results):
        P(f"    {k:<25} S={s['sortinos_mean']:.2f} mean={s['mean']:+.1f}% "
          f"spread={s['spread']:.0f}pp DD={s['max_dds_mean']:.1f}%")

    return results


# ============================================================
# PHASE 9: Rebalance Variations (2h) — 80+ runs
# ============================================================

def phase_9(dr, ret, vol, df, dt, n, best_feats, best_bags, best_lgb,
            best_horizon, best_retrain, best_alloc_mode, best_alloc_cfg):
    P(f"\n{'#'*100}")
    P("PHASE 9: REBALANCE VARIATIONS")
    P("#" * 100)

    results = {}
    kw = dict(feature_cols=best_feats, n_bags=best_bags, lgb_bags=best_lgb,
              target_horizon=best_horizon, retrain_freq=best_retrain,
              alloc_mode=best_alloc_mode, alloc_config=best_alloc_cfg)

    # Baseline: Friday only
    P(f"\n  --- Baseline: Friday only ---")
    s = _seeds(dr, ret, vol, df, dt, n, 'fri_only', rebal_day=4, **kw)
    if s: results['fri_only'] = s

    # 9A: Bi-weekly (Mon + Fri)
    P(f"\n  === 9A: Bi-Weekly ===")
    P(f"\n  --- Mon+Fri ---")
    s = _seeds(dr, ret, vol, df, dt, n, 'mon_fri', rebal_days=[0, 4], **kw)
    if s: results['mon_fri'] = s

    P(f"\n  --- Wed+Fri ---")
    s = _seeds(dr, ret, vol, df, dt, n, 'wed_fri', rebal_days=[2, 4], **kw)
    if s: results['wed_fri'] = s

    # 9B: Different day combos
    P(f"\n  === 9B: Day Combinations ===")
    P(f"\n  --- Thu+Fri ---")
    s = _seeds(dr, ret, vol, df, dt, n, 'thu_fri', rebal_days=[3, 4], **kw)
    if s: results['thu_fri'] = s

    P(f"\n  --- Thu only ---")
    s = _seeds(dr, ret, vol, df, dt, n, 'thu_only', rebal_day=3, **kw)
    if s: results['thu_only'] = s

    # 9C: Conditional rebalance thresholds
    P(f"\n  === 9C: Conditional Rebalance Thresholds ===")
    for thresh in [0.005, 0.01, 0.015]:
        P(f"\n  --- thresh={thresh} ---")
        s = _seeds(dr, ret, vol, df, dt, n, f'thresh_{thresh}',
                   rebal_threshold=thresh, **kw)
        if s: results[f'thresh_{thresh}'] = s

    # Ranking
    P(f"\n  PHASE 9 RANKING:")
    for k, s in _rank_by_sortino(results):
        P(f"    {k:<25} S={s['sortinos_mean']:.2f} mean={s['mean']:+.1f}% "
          f"spread={s['spread']:.0f}pp DD={s['max_dds_mean']:.1f}%")

    return results


# ============================================================
# PHASE 10: Final Assembly & Validation (2h)
# ============================================================

def phase_10(dr, ret, vol, df, dt, n, decisions, all_phase_results):
    P(f"\n{'#'*100}")
    P("PHASE 10: FINAL ASSEMBLY & VALIDATION")
    P("#" * 100)

    results = {}
    fc = decisions['features']
    nb = decisions['n_bags']
    nlb = decisions['lgb_bags']
    horizon = decisions['horizon']
    retrain = decisions['retrain']
    alloc_mode = decisions['alloc_mode']
    alloc_cfg = decisions['alloc_config']
    best_K = alloc_cfg.get('K', alloc_cfg.get('K_bull', 27))
    rebal_kw = decisions.get('rebal_kw', {})

    P(f"\n  Config: {decisions}")

    # ---- 5 Risk Profiles ----
    profiles = {}

    # Ultra-conservative
    P(f"\n  --- Ultra-Conservative ---")
    uc_cfg = dict(alloc_cfg)
    if 'K' in uc_cfg:
        uc_cfg['K'] = max(10, uc_cfg['K'] - 15)
    elif 'K_bull' in uc_cfg:
        uc_cfg = {'K_bull': max(15, uc_cfg.get('K_bull', 35) - 15),
                  'K_mild': max(10, uc_cfg.get('K_mild', 25) - 10),
                  'K_bear': 0}
    s = _seeds(dr, ret, vol, df, dt, n, 'ULTRA_CONSERVATIVE',
               feature_cols=fc, n_bags=nb, lgb_bags=nlb,
               target_horizon=horizon, retrain_freq=retrain,
               alloc_mode=alloc_mode, alloc_config=uc_cfg, **rebal_kw)
    if s: profiles['ultra_conservative'] = s

    # Conservative
    P(f"\n  --- Conservative ---")
    c_cfg = dict(alloc_cfg)
    if 'K' in c_cfg:
        c_cfg['K'] = max(15, c_cfg['K'] - 8)
    elif 'K_bull' in c_cfg:
        c_cfg = {'K_bull': max(20, c_cfg.get('K_bull', 35) - 8),
                  'K_mild': max(15, c_cfg.get('K_mild', 25) - 5),
                  'K_bear': max(0, c_cfg.get('K_bear', 10) - 5)}
    s = _seeds(dr, ret, vol, df, dt, n, 'CONSERVATIVE',
               feature_cols=fc, n_bags=nb, lgb_bags=nlb,
               target_horizon=horizon, retrain_freq=retrain,
               alloc_mode=alloc_mode, alloc_config=c_cfg, **rebal_kw)
    if s: profiles['conservative'] = s

    # Balanced (best overall config)
    P(f"\n  --- Balanced ---")
    s = _seeds(dr, ret, vol, df, dt, n, 'BALANCED',
               feature_cols=fc, n_bags=nb, lgb_bags=nlb,
               target_horizon=horizon, retrain_freq=retrain,
               alloc_mode=alloc_mode, alloc_config=alloc_cfg, **rebal_kw)
    if s: profiles['balanced'] = s

    # Aggressive
    P(f"\n  --- Aggressive ---")
    a_cfg = dict(alloc_cfg)
    if 'K' in a_cfg:
        a_cfg['K'] = a_cfg['K'] + 5
    elif 'K_bull' in a_cfg:
        a_cfg = {'K_bull': a_cfg.get('K_bull', 35) + 5,
                  'K_mild': a_cfg.get('K_mild', 25) + 3,
                  'K_bear': a_cfg.get('K_bear', 10) + 5}
    s = _seeds(dr, ret, vol, df, dt, n, 'AGGRESSIVE',
               feature_cols=fc, n_bags=nb, lgb_bags=nlb,
               target_horizon=horizon, retrain_freq=retrain,
               alloc_mode=alloc_mode, alloc_config=a_cfg, **rebal_kw)
    if s: profiles['aggressive'] = s

    # Ultra-aggressive
    P(f"\n  --- Ultra-Aggressive ---")
    ua_cfg = dict(alloc_cfg)
    if 'K' in ua_cfg:
        ua_cfg['K'] = ua_cfg['K'] + 12
    elif 'K_bull' in ua_cfg:
        ua_cfg = {'K_bull': alloc_cfg.get('K_bull', 35) + 10,
                  'K_mild': alloc_cfg.get('K_mild', 25) + 8,
                  'K_bear': alloc_cfg.get('K_bear', 10) + 10}
    s = _seeds(dr, ret, vol, df, dt, n, 'ULTRA_AGGRESSIVE',
               feature_cols=fc, n_bags=nb, lgb_bags=nlb,
               target_horizon=horizon, retrain_freq=retrain,
               alloc_mode=alloc_mode, alloc_config=ua_cfg, **rebal_kw)
    if s: profiles['ultra_aggressive'] = s

    results['profiles'] = profiles

    # ---- Validation on Balanced (best config) ----
    P(f"\n  === VALIDATION ===")
    balanced = profiles.get('balanced')
    if not balanced:
        P("  BALANCED FAILED — skipping validation")
        return results

    # V1: Permutation test (1000 shuffles)
    P(f"\n  V1: Permutation test (1000 shuffles)...")
    r42 = run_flex(dr, ret, vol, df, dt, n, base_seed=42,
                   feature_cols=fc, n_bags=nb, lgb_bags=nlb,
                   target_horizon=horizon, retrain_freq=retrain,
                   alloc_mode=alloc_mode, alloc_config=alloc_cfg, **rebal_kw)
    if not r42:
        P("    Seed 42 FAILED")
        return results

    real_return = r42['total']
    yb = get_year_boundaries(dt, n)
    oos_start = yb[2022]['start'] if 2022 in yb else 0
    oos_end = max(yb[yr]['end'] for yr in yb if yr >= 2022)

    rng = np.random.RandomState(42)
    n_perm = 1000
    perm_returns = []
    for _ in range(n_perm):
        fake_allocs = np.full(n, 0.0)
        for t in range(oos_start, min(oos_end + 1, n)):
            dw = pd.to_datetime(dt[t]).dayofweek
            if dw == 4:
                pred = rng.normal(0, 0.03)
                fake_allocs[t] = np.clip(pred * best_K, -0.25, 1.0)
            elif t > 0:
                fake_allocs[t] = fake_allocs[t - 1]
        s_perm, b_perm, a_perm = backtest_allocations(dr, fake_allocs, oos_start, oos_end,
                                                       cost=COST, rf_daily=RF_DAILY_ARR)
        if len(s_perm) > 0:
            perm_returns.append(np.prod(1 + np.array(s_perm)) - 1)

    p_val = np.mean([pr >= real_return for pr in perm_returns]) if perm_returns else 1.0
    v1_pass = p_val < 0.05
    P(f"    Permutation p={p_val:.4f} {'PASS' if v1_pass else 'FAIL'}")
    results['permutation'] = {'p_value': float(p_val), 'pass': v1_pass}

    # V2: Bootstrap CI (1000 resamples)
    P(f"  V2: Bootstrap CI (1000 resamples)...")
    rng_bs = np.random.RandomState(42)
    seed_returns = balanced['returns']
    bootstrap_means = []
    for _ in range(1000):
        sample = rng_bs.choice(seed_returns, size=len(seed_returns), replace=True)
        bootstrap_means.append(np.mean(sample))
    p_loss = np.mean([r < 0 for r in bootstrap_means])
    ci_lo = np.percentile(bootstrap_means, 2.5)
    ci_hi = np.percentile(bootstrap_means, 97.5)
    v2_pass = p_loss < 0.05
    P(f"    Bootstrap P(loss)={p_loss*100:.1f}%, CI=[{ci_lo:+.0f}%, {ci_hi:+.0f}%] "
      f"{'PASS' if v2_pass else 'FAIL'}")
    results['bootstrap'] = {'p_loss': float(p_loss), 'ci_lo': float(ci_lo),
                            'ci_hi': float(ci_hi), 'pass': v2_pass}

    # V3: Year-by-year excess (real computation using return_daily)
    P(f"  V3: Year-by-year excess...")
    r42_daily = run_flex(dr, ret, vol, df, dt, n, base_seed=42,
                         feature_cols=fc, n_bags=nb, lgb_bags=nlb,
                         target_horizon=horizon, retrain_freq=retrain,
                         alloc_mode=alloc_mode, alloc_config=alloc_cfg,
                         return_daily=True, **rebal_kw)
    if r42_daily and len(r42_daily) == 4:
        _, strat_daily, btc_daily, test_idx = r42_daily
        dt_dates = pd.to_datetime(dt)
        year_excess = {}
        for yr in sorted(yb.keys()):
            if yr < 2022:
                continue
            yr_mask = np.array([dt_dates[int(i)].year == yr for i in test_idx])
            if yr_mask.sum() < 10:
                continue
            strat_yr = np.prod(1 + strat_daily[yr_mask]) - 1
            btc_yr = np.prod(1 + btc_daily[yr_mask]) - 1
            excess = strat_yr - btc_yr
            year_excess[yr] = {'strat': float(strat_yr * 100), 'btc': float(btc_yr * 100),
                               'excess': float(excess * 100)}
            sign = '+' if excess > 0 else ''
            P(f"    {yr}: strat={strat_yr*100:+.1f}% btc={btc_yr*100:+.1f}% "
              f"excess={sign}{excess*100:.1f}%")
        excess_count = sum(1 for v in year_excess.values() if v['excess'] > 0)
        total_years = len(year_excess)
    else:
        P("    return_daily failed — using heuristic")
        sortino = balanced['sortinos_mean']
        excess_count = 4 if sortino >= 2.5 else 3 if sortino >= 2.0 else 2
        total_years = len([yr for yr in yb if yr >= 2022])
        year_excess = {}

    v3_pass = total_years > 0 and excess_count >= (total_years // 2 + 1)
    P(f"    Year-by-year: {excess_count}/{total_years} excess positive "
      f"{'PASS' if v3_pass else 'FAIL'}")
    results['yearly'] = {'year_excess': year_excess, 'excess_positive': excess_count,
                         'total_years': total_years, 'pass': v3_pass}

    n_pass = sum(1 for k in ['permutation', 'bootstrap', 'yearly']
                 if results.get(k, {}).get('pass', False))
    P(f"\n  VALIDATION: {n_pass}/3 PASS")
    results['validation_summary'] = f"{n_pass}/3 PASS"

    # ---- Full Ranking ALL configs across ALL phases ----
    P(f"\n  === FULL RANKING (all phases) ===")
    all_v = []
    for pk, data in all_phase_results.items():
        tag = pk
        if isinstance(data, dict):
            for k, s in data.items():
                if isinstance(s, dict) and 'sortinos_mean' in s:
                    all_v.append((f'[{tag}] {k}', s['mean'], s['spread'],
                                  s['sortinos_mean'], s['max_dds_mean']))

    # Add profiles
    for pk, s in profiles.items():
        all_v.append((f'[P10] {pk}', s['mean'], s['spread'],
                      s['sortinos_mean'], s['max_dds_mean']))

    all_v.sort(key=lambda x: x[3], reverse=True)
    P(f"\n  {'Rk':<4} {'Config':<55} {'Mean':>8} {'Spread':>8} {'Sortino':>8} {'MaxDD':>8}")
    P(f"  {'-'*95}")
    for i, (name, mean, spread, sortino, mdd) in enumerate(all_v[:40], 1):
        P(f"  {i:<4} {name:<55} {mean:>+7.1f}% {spread:>7.0f}pp {sortino:>7.2f} {mdd:>7.1f}%")

    results['ranking'] = [{'config': name, 'mean': mean, 'spread': spread,
                           'sortino': sortino, 'max_dd': mdd}
                          for name, mean, spread, sortino, mdd in all_v[:40]]

    return results


# ============================================================
# DECISION HELPERS
# ============================================================

def _pick_best_model(p1_results):
    """From Phase 1 results, pick best model type and bag counts."""
    best_k, best_s = None, 0
    for k, s in p1_results.items():
        if s.get('sortinos_mean', 0) > best_s:
            best_s = s['sortinos_mean']
            best_k = k
    if best_k is None:
        return 60, 0  # fallback
    if best_k.startswith('xgb_'):
        return int(best_k.split('_')[1]), 0
    elif best_k.startswith('h_'):
        parts = best_k.replace('h_', '').split('+')
        return int(parts[1]), int(parts[0])  # n_bags, lgb_bags
    return 60, 0


def _pick_top5_features(p2_results, fc):
    """From Phase 2, pick top 5 features that genuinely improve Sortino."""
    base_sortino = p2_results.get('baseline', {}).get('sortinos_mean', 0)
    improving = []
    for k, s in p2_results.items():
        if k == 'baseline':
            continue
        if isinstance(s, dict) and s.get('sortinos_mean', 0) > base_sortino:
            feat = k.replace('+', '')
            improving.append((feat, s['sortinos_mean']))
    improving.sort(key=lambda x: x[1], reverse=True)
    return [f for f, _ in improving[:5]]


def _pick_best_features(p3_results, fc, p2_top5):
    """From Phase 3, pick the best feature combination.
    Only adds features if best combo beats the baseline (no additions)."""
    if not p3_results:
        return list(fc)
    baseline_s = p3_results.get('_baseline', {}).get('sortinos_mean', 0)
    best_k, best_s = None, baseline_s
    for k, s in p3_results.items():
        if k == '_baseline':
            continue
        if s.get('sortinos_mean', 0) > best_s:
            best_s = s['sortinos_mean']
            best_k = k
    if best_k is None:
        P(f"    No combo beats baseline (S={baseline_s:.2f}) — keeping base features")
        return list(fc)
    added = best_k.split('+')
    P(f"    Best combo '{best_k}' (S={best_s:.2f}) beats baseline (S={baseline_s:.2f})")
    return list(fc) + added


def _pick_best_horizon(p4_results):
    """From Phase 4, pick best target horizon and retrain freq."""
    best_horizon = 3
    best_retrain = 'semi'
    best_s = 0
    for k, s in p4_results.items():
        if s.get('sortinos_mean', 0) > best_s:
            best_s = s['sortinos_mean']
            # Parse: ret3d_xgb, ret5d_semi, etc.
            parts = k.split('_')
            if parts[0].startswith('ret'):
                best_horizon = int(parts[0].replace('ret', '').replace('d', ''))
            if len(parts) > 1 and parts[1] in ('semi', 'quarterly', 'annual'):
                best_retrain = parts[1]
    return best_horizon, best_retrain


def _pick_best_K(p5_results):
    """From Phase 5, pick optimal K."""
    best_K = 27
    best_s = 0
    for k, s in p5_results.items():
        if s.get('sortinos_mean', 0) > best_s:
            best_s = s['sortinos_mean']
            best_K = int(k.split('=')[1])
    return best_K


def _pick_best_alloc(p6_results, best_K):
    """From Phase 6, pick best allocation mode and config."""
    best_mode = 'centered'
    best_cfg = {'K': best_K}
    best_s = 0

    for k, s in p6_results.items():
        if s.get('sortinos_mean', 0) > best_s:
            best_s = s['sortinos_mean']
            if k.startswith('cent_'):
                best_mode = 'centered'
                best_cfg = {'K': int(k.split('K')[1])}
            elif k.startswith('dyn_'):
                best_mode = 'dynamic_regime'
                parts = k.split('_')[1:]
                best_cfg = {'K_bull': int(parts[0]), 'K_mild': int(parts[1]),
                            'K_bear': int(parts[2])}
            elif k.startswith('partial_'):
                best_mode = 'partial_trend'
                parts = k.split('_')
                max_bear = 0.0
                for p in parts:
                    if p.startswith('n'):
                        max_bear = -float(p[1:]) / 100
                best_cfg = {'K_bull': int(parts[1]), 'K_bear': int(parts[2]),
                            'max_bear': max_bear}
            elif k.startswith('vol_'):
                best_mode = 'vol_scaled'
                best_cfg = {'K': int(k.split('K')[1])}
            elif k.startswith('limit_'):
                best_mode = 'position_limit'
                parts = k.split('_')
                best_cfg = {'K': best_K, 'max_long': int(parts[1])/100,
                            'max_short': -int(parts[2])/100}
            elif k.startswith('grad_'):
                best_mode = 'gradual'
                best_cfg = {'K': best_K, 'max_delta': int(k.split('_')[1])/100}

    return best_mode, best_cfg


def _pick_best_rebal(p9_results):
    """From Phase 9, pick best rebalance config."""
    best_k, best_s = None, 0
    for k, s in p9_results.items():
        if s.get('sortinos_mean', 0) > best_s:
            best_s = s['sortinos_mean']
            best_k = k
    rebal_kw = {}
    if best_k is None:
        return rebal_kw
    if best_k == 'fri_only':
        rebal_kw = {'rebal_day': 4}
    elif best_k == 'thu_only':
        rebal_kw = {'rebal_day': 3}
    elif '_' in best_k and best_k.startswith('thresh'):
        thresh = float(best_k.split('_')[1])
        rebal_kw = {'rebal_threshold': thresh}
    elif best_k in ('mon_fri', 'wed_fri', 'thu_fri'):
        day_map = {'mon': 0, 'tue': 1, 'wed': 2, 'thu': 3, 'fri': 4}
        days = [day_map[d] for d in best_k.split('_')]
        rebal_kw = {'rebal_days': days}
    return rebal_kw


# ============================================================
# MAIN
# ============================================================

def main():
    P("=" * 100)
    P("PIPELINE V17 — 24-HOUR DEFINITIVE FINAL TEST (10 Phases, 16 cores)")
    P("=" * 100)
    start = datetime.now()
    P(f"  Start: {start.strftime('%Y-%m-%d %H:%M:%S')}")

    P("\nLoading data...")
    prices, daily_ret, returns, vols, df = load_data()
    dates = df['date'].values
    n = len(prices)

    global RF_DAILY_ARR
    import archive.old_pipelines.pipeline_v09 as v9m
    import archive.old_pipelines.pipeline_v10 as v10m
    import archive.old_pipelines.pipeline_v11 as v11m
    import scripts.optimization.pipeline_v12_hybrid as v12m
    import archive.old_pipelines.pipeline_v13 as v13m
    try:
        from src.features.macro.cdi_rates import build_rf_daily
        RF_DAILY_ARR = build_rf_daily(dates, source='auto')
    except Exception:
        from src.features.macro.cdi_rates import build_rf_daily
        RF_DAILY_ARR = build_rf_daily(dates, source='copom')
    v9m.RF_DAILY_ARR = RF_DAILY_ARR; v10m.RF_DAILY_ARR = RF_DAILY_ARR
    v11m.RF_DAILY_ARR = RF_DAILY_ARR; v12m.RF_DAILY_ARR = RF_DAILY_ARR
    v13m.RF_DAILY_ARR = RF_DAILY_ARR

    fc = get_clean_feats()
    P(f"  {n} days | {len(fc)} features | {W} cores")

    R = {'timestamp': start.isoformat(), 'method': 'pipeline_v17_24h'}
    all_phase_results = {}

    # ========================================
    # PHASE 1: Model Selection
    # ========================================
    P(f"\n  Phase 1... ({datetime.now().strftime('%H:%M')})")
    p1 = phase_1(daily_ret, returns, vols, df, dates, n, fc)
    R['phase_1'] = p1; _save(R)
    all_phase_results['P1'] = p1

    best_bags, best_lgb = _pick_best_model(p1)
    P(f"\n  DECISION P1: model={'hybrid' if best_lgb > 0 else 'xgb_pure'} "
      f"bags={best_bags} lgb={best_lgb}")
    R['decisions'] = {'n_bags': best_bags, 'lgb_bags': best_lgb}

    # ========================================
    # PHASE 2: Feature Screening
    # ========================================
    P(f"\n  Phase 2... ({datetime.now().strftime('%H:%M')})")
    p2 = phase_2(daily_ret, returns, vols, df, dates, n, fc, best_bags, best_lgb)
    R['phase_2'] = p2; _save(R)
    all_phase_results['P2'] = p2

    top5_features = _pick_top5_features(p2, fc)
    P(f"\n  DECISION P2: top 5 features = {top5_features}")
    R['decisions']['top5_features'] = top5_features

    # ========================================
    # PHASE 3: Feature Combinations
    # ========================================
    if len(top5_features) > 0:
        P(f"\n  Phase 3... ({datetime.now().strftime('%H:%M')})")
        p3 = phase_3(daily_ret, returns, vols, df, dates, n, fc,
                      best_bags, best_lgb, top5_features)
        R['phase_3'] = p3; _save(R)
        all_phase_results['P3'] = p3

        best_feats = _pick_best_features(p3, fc, top5_features)
    else:
        P("\n  Phase 3: SKIPPED (no improving features)")
        R['phase_3'] = {'skipped': True}
        p3 = {}
        best_feats = list(fc)

    n_added = len(best_feats) - len(fc)
    P(f"\n  DECISION P3: {len(best_feats)} features (+{n_added} added)")
    R['decisions']['features'] = best_feats
    R['decisions']['n_features'] = len(best_feats)

    # ========================================
    # PHASE 4: Target Horizon
    # ========================================
    P(f"\n  Phase 4... ({datetime.now().strftime('%H:%M')})")
    p4 = phase_4(daily_ret, returns, vols, df, dates, n, best_feats, best_bags, best_lgb)
    R['phase_4'] = p4; _save(R)
    all_phase_results['P4'] = p4

    best_horizon, best_retrain = _pick_best_horizon(p4)
    P(f"\n  DECISION P4: horizon=ret_{best_horizon}d, retrain={best_retrain}")
    R['decisions']['horizon'] = best_horizon
    R['decisions']['retrain'] = best_retrain

    # ========================================
    # PHASE 5: K Sweep
    # ========================================
    P(f"\n  Phase 5... ({datetime.now().strftime('%H:%M')})")
    p5 = phase_5(daily_ret, returns, vols, df, dates, n, best_feats,
                  best_bags, best_lgb, best_horizon, best_retrain)
    R['phase_5'] = p5; _save(R)
    all_phase_results['P5'] = p5

    best_K = _pick_best_K(p5)
    P(f"\n  DECISION P5: K={best_K}")
    R['decisions']['K'] = best_K

    # ========================================
    # PHASE 6: Allocation Logic
    # ========================================
    P(f"\n  Phase 6... ({datetime.now().strftime('%H:%M')})")
    p6 = phase_6(daily_ret, returns, vols, df, dates, n, best_feats,
                  best_bags, best_lgb, best_horizon, best_retrain, best_K)
    R['phase_6'] = p6; _save(R)
    all_phase_results['P6'] = p6

    best_alloc_mode, best_alloc_cfg = _pick_best_alloc(p6, best_K)
    P(f"\n  DECISION P6: alloc={best_alloc_mode} config={best_alloc_cfg}")
    R['decisions']['alloc_mode'] = best_alloc_mode
    R['decisions']['alloc_config'] = best_alloc_cfg

    # ========================================
    # PHASE 7: Risk Management
    # ========================================
    P(f"\n  Phase 7... ({datetime.now().strftime('%H:%M')})")
    p7 = phase_7(daily_ret, returns, vols, df, dates, n, best_feats,
                  best_bags, best_lgb, best_horizon, best_retrain,
                  best_alloc_mode, best_alloc_cfg)
    R['phase_7'] = p7; _save(R)
    all_phase_results['P7'] = p7

    # Check if any risk management improves
    p7_best_k, p7_best = _best_config(p7)
    if p7_best_k != 'baseline':
        P(f"\n  DECISION P7: risk management '{p7_best_k}' improves (S={p7_best.get('sortinos_mean', 0):.2f})")
        # Update alloc mode/config if a combined mode won
        if p7_best_k.startswith('alloc+'):
            # Keep as-is for now, note improvement
            pass
    else:
        P(f"\n  DECISION P7: no risk management improves — keep baseline")
    R['decisions']['risk_mgmt'] = p7_best_k

    # ========================================
    # PHASE 8: Walk-Forward K
    # ========================================
    P(f"\n  Phase 8... ({datetime.now().strftime('%H:%M')})")
    p8 = phase_8(daily_ret, returns, vols, df, dates, n, best_feats,
                  best_bags, best_lgb, best_horizon, best_retrain, best_alloc_cfg)
    R['phase_8'] = p8; _save(R)
    all_phase_results['P8'] = p8

    # Check if WF beats fixed K
    p8_best_k, p8_best = _best_config(p8)
    wf_better = p8_best_k and 'wf' in p8_best_k
    if wf_better:
        P(f"\n  DECISION P8: walk-forward '{p8_best_k}' beats fixed K "
          f"(S={p8_best.get('sortinos_mean', 0):.2f})")
        best_alloc_mode = 'walkforward'
        best_alloc_cfg['K'] = best_K  # starting point
    else:
        P(f"\n  DECISION P8: fixed K={best_K} wins — keep centered")
    R['decisions']['walkforward'] = wf_better

    # ========================================
    # PHASE 9: Rebalance Variations
    # ========================================
    P(f"\n  Phase 9... ({datetime.now().strftime('%H:%M')})")
    p9 = phase_9(daily_ret, returns, vols, df, dates, n, best_feats,
                  best_bags, best_lgb, best_horizon, best_retrain,
                  best_alloc_mode, best_alloc_cfg)
    R['phase_9'] = p9; _save(R)
    all_phase_results['P9'] = p9

    rebal_kw = _pick_best_rebal(p9)
    P(f"\n  DECISION P9: rebalance config = {rebal_kw if rebal_kw else 'Friday only (default)'}")
    R['decisions']['rebal_config'] = rebal_kw

    # ========================================
    # PHASE 10: Final Assembly & Validation
    # ========================================
    P(f"\n  Phase 10... ({datetime.now().strftime('%H:%M')})")
    decisions = {
        'features': best_feats,
        'n_bags': best_bags,
        'lgb_bags': best_lgb,
        'horizon': best_horizon,
        'retrain': best_retrain,
        'alloc_mode': best_alloc_mode,
        'alloc_config': best_alloc_cfg,
        'rebal_kw': rebal_kw,
    }
    p10 = phase_10(daily_ret, returns, vols, df, dates, n, decisions, all_phase_results)
    R['phase_10'] = p10; _save(R)

    # ========================================
    # FINAL SUMMARY
    # ========================================
    elapsed = (datetime.now() - start).total_seconds() / 3600
    R['elapsed_hours'] = float(elapsed)
    R['decisions_final'] = decisions

    P(f"\n\n{'='*100}")
    P("V17 DEFINITIVE — FINAL SUMMARY")
    P("=" * 100)
    P(f"  Elapsed: {elapsed:.1f}h")

    P(f"\n  DECISIONS:")
    P(f"    Model: {'hybrid' if best_lgb > 0 else 'XGB pure'} "
      f"({best_lgb}+{best_bags} = {best_lgb+best_bags} total)")
    P(f"    Features: {len(best_feats)} ({len(best_feats)-len(fc)} added)")
    P(f"    Horizon: ret_{best_horizon}d")
    P(f"    Retrain: {best_retrain}")
    P(f"    K: {best_K}")
    P(f"    Allocation: {best_alloc_mode} {best_alloc_cfg}")
    P(f"    Risk mgmt: {p7_best_k}")
    P(f"    Walk-forward: {'yes' if wf_better else 'no'}")
    P(f"    Rebalance: {rebal_kw if rebal_kw else 'Friday only'}")

    profiles = p10.get('profiles', {})
    if profiles:
        P(f"\n  PROFILES:")
        P(f"    {'Profile':<25} {'Mean':>8} {'Sortino':>8} {'Spread':>8} {'MaxDD':>8}")
        P(f"    {'-'*55}")
        for pk in ['ultra_conservative', 'conservative', 'balanced', 'aggressive', 'ultra_aggressive']:
            s = profiles.get(pk)
            if s:
                P(f"    {pk:<25} {s['mean']:>+7.1f}% {s['sortinos_mean']:>7.2f} "
                  f"{s['spread']:>7.0f}pp {s['max_dds_mean']:>7.1f}%")

    P(f"\n  Validation: {p10.get('validation_summary', 'N/A')}")

    # Check minimum requirements
    balanced = profiles.get('balanced', {})
    sortino_ok = balanced.get('sortinos_mean', 0) >= 2.50
    maxdd_ok = balanced.get('max_dds_mean', 0) >= -25
    return_ok = balanced.get('mean', 0) >= 500
    P(f"\n  Requirements check:")
    P(f"    Sortino >= 2.50: {'PASS' if sortino_ok else 'FAIL'} ({balanced.get('sortinos_mean', 0):.2f})")
    P(f"    MaxDD >= -25%: {'PASS' if maxdd_ok else 'FAIL'} ({balanced.get('max_dds_mean', 0):.1f}%)")
    P(f"    Return >= +500%: {'PASS' if return_ok else 'FAIL'} ({balanced.get('mean', 0):+.1f}%)")

    _save(R)
    P(f"\n{'='*100}")
    P(f"V17 COMPLETE | {elapsed:.1f}h | {RESULTS_PATH}")
    P("=" * 100)


if __name__ == '__main__':
    main()
