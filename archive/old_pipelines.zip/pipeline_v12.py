"""
PIPELINE V12 — Decisive: XGB-Alone vs Hybrid
=============================================

Question: Can XGB-alone fix its 83pp spread to match hybrid's 45pp?
  YES → XGB-alone wins (higher return ceiling)
  NO  → Hybrid wins (already validated 3/3)

V11 validation (Phase A already done): 3/3 PASS
  - Permutation: p=0.0000
  - Bootstrap: P(loss)=0.0%, CI=[+316%, +2820%]
  - Year-by-year: 4/5 excess positive

Phases (sequenced for maximum info per hour):
  1: XGB hyperparam screen (1 seed, ~50 configs) → 1.5h
  2: XGB best params confirmed (10 seeds, top 5)  → 1.5h
  3: XGB bag count sweep (10 seeds, 4 counts)     → 2h
  4: XGB K sweep (10 seeds, 6 values)             → 2h
  5: XGB feature additions (10 seeds, 12 adds)    → 3.5h
  6: XGB best combo (10 seeds, 3 combos)          → 1h
  7: Hybrid K sweep (10 seeds, 7 values)           → 2h
  8: Hybrid bag ratios (10 seeds, 6 ratios)        → 2h
  9: Hybrid with tuned XGB (10 seeds, 3 configs)   → 1h
  10: Hybrid feature adds (10 seeds, 6 adds)       → 2h
  11: FINAL SHOWDOWN                               → 0.5h

Total: ~19h
"""

import sys
import gc
import pandas as pd
import numpy as np
from pathlib import Path
import warnings
import json
from datetime import datetime
import lightgbm as lgb
import xgboost as xgb

warnings.filterwarnings('ignore')
sys.stdout.reconfigure(line_buffering=True)

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

from scripts.optimization.pipeline_v9 import (
    load_data, build_ml_features,
    backtest_allocations, metrics, get_year_boundaries,
    SEEDS_10, COST, DEFAULT_LGB_PARAMS,
    P, _seed_summary, convert_numpy,
)
from scripts.optimization.pipeline_v10_mega import (
    C2_BASE, TOP_ADD, MODELS, _compute_allocation,
)
from scripts.optimization.pipeline_v11_xgb import DEFAULT_XGB_PARAMS

RF_DAILY_ARR = None

V11_BEST = {
    'hybrid_15_15': {'return': 925, 'sortino': 2.92, 'spread': 45, 'max_dd': -13.9},
    'xgb_alone':    {'return': 992, 'sortino': 2.91, 'spread': 83, 'max_dd': -14.5},
}

RESULTS_PATH = ROOT / 'outputs/results/pipeline_v12_hybrid.json'

# Features to test adding (rejected in LGB selection, available in dataset)
ADD_CANDIDATES = [
    'funding_rate', 'rsi_14d', 'puell_multiple', 'sopr_ma7',
    'mvrv_zscore', 'nvt_ratio', 'vix_zscore', 'btc_sp500_corr_30d',
    'fear_greed_zscore', 'hash_rate_pctchg_30d', 'supply_on_exchanges_pct',
    'days_since_ath',
]


# ============================================================
# PARALLEL TRAINING HELPERS
# ============================================================

N_WORKERS = 8  # number of CPU cores to use

def _train_one_lgb(args):
    seed, Xt, yt, params_base = args
    p = dict(params_base)
    p['seed'] = seed
    p['verbose'] = -1
    p['n_jobs'] = 1
    nr = p.pop('num_boost_round', 200)
    return lgb.train(p, lgb.Dataset(Xt, label=yt), num_boost_round=nr)


def _train_one_xgb(args):
    seed, Xt, yt, params_base = args
    p = dict(params_base)
    p['random_state'] = seed
    ne = p.pop('n_estimators', 200)
    m = xgb.XGBRegressor(n_estimators=ne, **p)
    m.fit(Xt, yt)
    return m


# ============================================================
# ENGINE (supports separate XGB features + parallel training)
# ============================================================

def run_v12(daily_ret, returns, vols, df, dates, n,
            feature_cols, n_bags_lgb=15, n_bags_xgb=15,
            base_seed=42, lgb_params=None, xgb_params=None,
            alloc_formula='linear_direct', alloc_params=None,
            scale_div=0.05, model_type='hybrid',
            feature_cols_xgb=None):
    if alloc_params is None:
        alloc_params = {}

    prices = df['price_usd'].values
    yb = get_year_boundaries(dates, n)

    X_lgb, _ = build_ml_features(df, returns, vols, n, feature_cols=feature_cols)
    X_xgb = build_ml_features(df, returns, vols, n,
                               feature_cols=feature_cols_xgb)[0] if feature_cols_xgb else X_lgb

    target = np.zeros(n)
    for i in range(n - 3):
        target[i] = (prices[i + 3] - prices[i]) / prices[i]

    day_of_week = pd.to_datetime(dates).dayofweek
    all_strat, all_btc, all_alloc, all_rf = [], [], [], []
    full_allocs = np.full(n, 0.5)
    is_rf_arr = isinstance(RF_DAILY_ARR, np.ndarray)

    lgb_p = dict(DEFAULT_LGB_PARAMS)
    if lgb_params:
        lgb_p.update(lgb_params)
    xgb_p = dict(DEFAULT_XGB_PARAMS)
    if xgb_params:
        xgb_p.update(xgb_params)

    from concurrent.futures import ThreadPoolExecutor

    for test_year in range(2022, 2027):
        if test_year not in yb:
            continue
        train_end = yb[test_year]['start'] - 1
        test_start = yb[test_year]['start']
        test_end = yb[test_year]['end']
        horizon_gap = 5
        train_mask = np.arange(60, train_end - horizon_gap + 1)

        models_lgb, models_xgb = [], []

        # LGB — parallel training
        n_lgb = n_bags_lgb if model_type in ('lgb', 'hybrid') else 0
        if n_lgb > 0:
            valid = ~np.any(np.isnan(X_lgb[train_mask]), axis=1)
            idx = train_mask[valid]
            if len(idx) >= 100:
                Xt = np.nan_to_num(X_lgb[idx], nan=0.0)
                yt = target[idx]
                seeds = [base_seed + i * 7 for i in range(n_lgb)]
                args = [(s, Xt, yt, lgb_p) for s in seeds]
                with ThreadPoolExecutor(max_workers=N_WORKERS) as ex:
                    models_lgb = list(ex.map(_train_one_lgb, args))

        # XGB — parallel training
        n_xgb = n_bags_xgb if model_type in ('xgb', 'hybrid') else 0
        if model_type == 'xgb':
            n_xgb = n_bags_lgb
        if n_xgb > 0:
            valid = ~np.any(np.isnan(X_xgb[train_mask]), axis=1)
            idx = train_mask[valid]
            if len(idx) >= 100:
                Xt = np.nan_to_num(X_xgb[idx], nan=0.0)
                yt = target[idx]
                seeds = [base_seed + i * 7 for i in range(n_xgb)]
                args = [(s, Xt, yt, xgb_p) for s in seeds]
                with ThreadPoolExecutor(max_workers=N_WORKERS) as ex:
                    models_xgb = list(ex.map(_train_one_xgb, args))

        if not models_lgb and not models_xgb:
            continue

        prev_alloc = 0.5
        for t in range(test_start, test_end + 1):
            preds = []
            xl = np.nan_to_num(X_lgb[t:t+1].copy(), nan=0.0)
            xx = np.nan_to_num(X_xgb[t:t+1].copy(), nan=0.0)
            for m in models_lgb:
                preds.append(m.predict(xl)[0])
            for m in models_xgb:
                preds.append(m.predict(xx)[0])

            raw = _compute_allocation(np.mean(preds), scale_div, alloc_formula, alloc_params)
            if day_of_week[t] != 4:
                raw = prev_alloc
            full_allocs[t] = np.clip(raw, -0.25, 1.0)
            prev_alloc = full_allocs[t]

        s, b, a = backtest_allocations(daily_ret, full_allocs, test_start, test_end,
                                       cost=COST, rf_daily=RF_DAILY_ARR)
        all_strat.extend(s)
        all_btc.extend(b)
        all_alloc.extend(a)
        nd = len(s)
        if is_rf_arr:
            all_rf.extend(RF_DAILY_ARR[test_start:test_start + nd])
        else:
            all_rf.extend([0.0] * nd)

    return metrics(np.array(all_strat), np.array(all_btc), np.array(all_alloc),
                   rf_daily=np.array(all_rf))


# ============================================================
# HELPERS
# ============================================================

def _save(all_results):
    RESULTS_PATH.parent.mkdir(parents=True, exist_ok=True)
    RESULTS_PATH.write_text(json.dumps(convert_numpy(all_results), indent=2, default=str),
                            encoding='utf-8')
    P(f"  [SAVE] {RESULTS_PATH.name}")


def _run_seeds(daily_ret, returns, vols, df, dates, n, label, **kw):
    results = []
    for seed in SEEDS_10:
        P(f"    seed={seed}...", end="")
        r = run_v12(daily_ret, returns, vols, df, dates, n, base_seed=seed, **kw)
        if r:
            results.append(r)
            P(f" {r['total']*100:+.1f}% S={r['sortino']:.2f}")
        else:
            P(" FAILED")
        gc.collect()
    if not results:
        return None
    rets = [r['total'] * 100 for r in results]
    s = _seed_summary(rets, results)
    P(f"    {label}: mean={s['mean']:+.1f}%, S={s['sortinos_mean']:.2f}, "
      f"spread={s['spread']:.0f}pp, MaxDD={s['max_dds_mean']:.1f}%")
    return s


def _print_table(results, ref_label='V11 hybrid', ref_s=2.92, ref_sp=45, ref_r=925):
    P(f"  {'Config':<40} {'Mean':>8} {'Spread':>8} {'Sortino':>8} {'MaxDD':>8} {'vs ref':>7}")
    P(f"  {'-'*78}")
    for k, s in sorted(results.items(), key=lambda x: x[1]['sortinos_mean'], reverse=True):
        wins = sum([s['sortinos_mean'] >= ref_s, s['spread'] <= ref_sp, s['mean'] >= ref_r])
        flag = f"{wins}/3" + (" ***" if wins >= 2 else "")
        P(f"  {k:<40} {s['mean']:>+7.1f}% {s['spread']:>7.0f}pp "
          f"{s['sortinos_mean']:>7.2f} {s['max_dds_mean']:>7.1f}% {flag:>7}")


# ============================================================
# PHASE 1: XGB HYPERPARAM SCREEN (1 seed)
# ============================================================

def phase_1(daily_ret, returns, vols, df, dates, n):
    P(f"\n{'#'*100}")
    P("PHASE 1: XGB HYPERPARAMETER SCREEN (1 seed x ~50 configs)")
    P("#" * 100)

    fc = MODELS['37feat']
    seed = 42

    P(f"\n  Baseline...")
    base = run_v12(daily_ret, returns, vols, df, dates, n, feature_cols=fc,
                   n_bags_lgb=50, model_type='xgb',
                   alloc_formula='linear_direct', alloc_params={'K': 25}, base_seed=seed)
    base_s = base['sortino']
    base_r = base['total'] * 100
    P(f"    => {base_r:+.1f}%, S={base_s:.2f}")

    sweeps = {
        'max_leaves':       [15, 23, 31, 47, 63],
        'min_child_weight': [5, 8, 12, 20, 30],
        'learning_rate':    [0.02, 0.03, 0.05, 0.08, 0.10],
        'n_estimators':     [100, 150, 200, 300, 400],
        'max_depth':        [4, 6, 8, 10, 0],
        'colsample_bytree': [0.5, 0.6, 0.7, 0.8, 0.9],
        'subsample':        [0.6, 0.7, 0.8, 0.9, 1.0],
        'reg_alpha':        [0, 0.01, 0.1, 1.0],
        'reg_lambda':       [0, 0.1, 1.0, 5.0],
    }

    results = {'baseline': {'return': float(base_r), 'sortino': float(base_s)}, 'sweeps': {}}
    all_runs = []

    for param, values in sweeps.items():
        P(f"\n  --- {param} ---")
        pr = []
        for val in values:
            P(f"    {param}={val}...", end="")
            r = run_v12(daily_ret, returns, vols, df, dates, n, feature_cols=fc,
                        n_bags_lgb=50, model_type='xgb', xgb_params={param: val},
                        alloc_formula='linear_direct', alloc_params={'K': 25}, base_seed=seed)
            if r:
                d = r['sortino'] - base_s
                P(f" {r['total']*100:+.1f}%, S={r['sortino']:.2f} ({d:+.3f})")
                pr.append({'value': val, 'sortino': float(r['sortino']),
                           'return': float(r['total']*100), 'diff': float(d)})
                all_runs.append((param, val, r['total']*100, r['sortino']))
            else:
                P(" FAILED")
        results['sweeps'][param] = pr

    best_per = {}
    for param, pr in results['sweeps'].items():
        if pr:
            best = max(pr, key=lambda x: x['sortino'])
            if best['diff'] > 0.01:
                best_per[param] = best['value']
    results['best_per_param'] = best_per

    all_runs.sort(key=lambda x: x[3], reverse=True)
    P(f"\n  TOP 10:")
    for p, v, ret, s in all_runs[:10]:
        P(f"    {p}={v}: {ret:+.1f}%, S={s:.2f}")
    P(f"\n  Improved params: {best_per}")

    return results


# ============================================================
# PHASE 2: XGB BEST PARAMS (10 seeds)
# ============================================================

def phase_2(daily_ret, returns, vols, df, dates, n, best_per):
    P(f"\n{'#'*100}")
    P(f"PHASE 2: XGB BEST PARAMS CONFIRMED (10 seeds)")
    P("#" * 100)
    P(f"  Improved params: {best_per}")

    fc = MODELS['37feat']
    results = {}

    # XGB alone with all best params combined
    if best_per:
        P(f"\n  --- XGB all best params combined ---")
        s = _run_seeds(daily_ret, returns, vols, df, dates, n, label='xgb_all_best',
                       feature_cols=fc, n_bags_lgb=50, model_type='xgb',
                       xgb_params=best_per,
                       alloc_formula='linear_direct', alloc_params={'K': 25})
        if s:
            results['xgb_all_best'] = s

    # Each param alone
    for param, val in best_per.items():
        P(f"\n  --- XGB {param}={val} only ---")
        s = _run_seeds(daily_ret, returns, vols, df, dates, n,
                       label=f'xgb_{param}={val}',
                       feature_cols=fc, n_bags_lgb=50, model_type='xgb',
                       xgb_params={param: val},
                       alloc_formula='linear_direct', alloc_params={'K': 25})
        if s:
            results[f'xgb_{param}={val}'] = s

    # XGB default (V11 baseline)
    P(f"\n  --- XGB defaults (V11 baseline) ---")
    s = _run_seeds(daily_ret, returns, vols, df, dates, n, label='xgb_defaults',
                   feature_cols=fc, n_bags_lgb=50, model_type='xgb',
                   alloc_formula='linear_direct', alloc_params={'K': 25})
    if s:
        results['xgb_defaults'] = s

    P(f"\n  PHASE 2:")
    _print_table(results)
    return results


# ============================================================
# PHASE 3: XGB BAG COUNT SWEEP
# ============================================================

def phase_3(daily_ret, returns, vols, df, dates, n, best_xgb):
    P(f"\n{'#'*100}")
    P(f"PHASE 3: XGB BAG COUNT SWEEP (10 seeds x 4 counts)")
    P("#" * 100)

    fc = MODELS['37feat']
    results = {}

    for nb in [50, 70, 100, 150]:
        P(f"\n  --- XGB Bag{nb} K=25 ---")
        s = _run_seeds(daily_ret, returns, vols, df, dates, n,
                       label=f'xgb_bag{nb}',
                       feature_cols=fc, n_bags_lgb=nb, model_type='xgb',
                       xgb_params=best_xgb,
                       alloc_formula='linear_direct', alloc_params={'K': 25})
        if s:
            results[f'xgb_bag{nb}'] = s
        gc.collect()

    P(f"\n  PHASE 3:")
    _print_table(results)
    return results


# ============================================================
# PHASE 4: XGB K SWEEP
# ============================================================

def phase_4(daily_ret, returns, vols, df, dates, n, best_xgb, best_bags):
    P(f"\n{'#'*100}")
    P(f"PHASE 4: XGB K SWEEP (10 seeds x 6 values, Bag{best_bags})")
    P("#" * 100)

    fc = MODELS['37feat']
    results = {}

    for K in [18, 20, 22, 25, 28, 30]:
        P(f"\n  --- XGB Bag{best_bags} K={K} ---")
        s = _run_seeds(daily_ret, returns, vols, df, dates, n,
                       label=f'xgb_K={K}',
                       feature_cols=fc, n_bags_lgb=best_bags, model_type='xgb',
                       xgb_params=best_xgb,
                       alloc_formula='linear_direct', alloc_params={'K': K})
        if s:
            results[f'xgb_K={K}'] = s

    P(f"\n  PHASE 4:")
    _print_table(results)
    return results


# ============================================================
# PHASE 5: XGB FEATURE ADDITIONS
# ============================================================

def phase_5(daily_ret, returns, vols, df, dates, n, best_xgb, best_bags, best_K):
    P(f"\n{'#'*100}")
    P(f"PHASE 5: XGB FEATURE ADDITIONS (10 seeds x 12 features, Bag{best_bags} K={best_K})")
    P("#" * 100)

    base_37 = list(MODELS['37feat'])
    available = [f for f in ADD_CANDIDATES if f in df.columns and f not in base_37]
    P(f"  Testing {len(available)} candidates")

    results = {}
    for feat in available:
        feats = base_37 + [feat]
        P(f"\n  --- XGB +{feat} ({len(feats)} feats) ---")
        s = _run_seeds(daily_ret, returns, vols, df, dates, n,
                       label=f'xgb+{feat}',
                       feature_cols=feats, n_bags_lgb=best_bags, model_type='xgb',
                       xgb_params=best_xgb,
                       alloc_formula='linear_direct', alloc_params={'K': best_K})
        if s:
            results[f'xgb+{feat}'] = s

    P(f"\n  PHASE 5:")
    _print_table(results)
    return results


# ============================================================
# PHASE 6: XGB BEST COMBO
# ============================================================

def phase_6(daily_ret, returns, vols, df, dates, n, best_xgb, best_bags, best_K, phase5_results):
    P(f"\n{'#'*100}")
    P(f"PHASE 6: XGB BEST COMBO (10 seeds)")
    P("#" * 100)

    base_37 = list(MODELS['37feat'])
    results = {}

    # Find top features from Phase 5
    top_feats = []
    baseline_s = V11_BEST['xgb_alone']['sortino']
    for k, s in phase5_results.items():
        if isinstance(s, dict) and 'sortinos_mean' in s:
            feat = k.replace('xgb+', '')
            if s['sortinos_mean'] > baseline_s:
                top_feats.append((feat, s['sortinos_mean']))

    top_feats.sort(key=lambda x: x[1], reverse=True)
    P(f"  Features that improved XGB Sortino: {[(f,round(s,2)) for f,s in top_feats]}")

    # Combo 1: XGB best params + bags + K (no feature changes)
    P(f"\n  --- XGB optimized (no feat change) Bag{best_bags} K={best_K} ---")
    s = _run_seeds(daily_ret, returns, vols, df, dates, n, label='xgb_optimized',
                   feature_cols=base_37, n_bags_lgb=best_bags, model_type='xgb',
                   xgb_params=best_xgb,
                   alloc_formula='linear_direct', alloc_params={'K': best_K})
    if s:
        results['xgb_optimized'] = s

    # Combo 2: + top 1 feature
    if top_feats:
        feats1 = base_37 + [top_feats[0][0]]
        P(f"\n  --- XGB optimized + {top_feats[0][0]} ---")
        s = _run_seeds(daily_ret, returns, vols, df, dates, n, label='xgb_opt+top1',
                       feature_cols=feats1, n_bags_lgb=best_bags, model_type='xgb',
                       xgb_params=best_xgb,
                       alloc_formula='linear_direct', alloc_params={'K': best_K})
        if s:
            results['xgb_opt+top1'] = s

    # Combo 3: + top 3 features
    if len(top_feats) >= 3:
        feats3 = base_37 + [f for f, _ in top_feats[:3]]
        P(f"\n  --- XGB optimized + top 3 feats ---")
        s = _run_seeds(daily_ret, returns, vols, df, dates, n, label='xgb_opt+top3',
                       feature_cols=feats3, n_bags_lgb=best_bags, model_type='xgb',
                       xgb_params=best_xgb,
                       alloc_formula='linear_direct', alloc_params={'K': best_K})
        if s:
            results['xgb_opt+top3'] = s

    P(f"\n  PHASE 6:")
    _print_table(results)
    return results


# ============================================================
# PHASE 7: HYBRID K SWEEP
# ============================================================

def phase_7(daily_ret, returns, vols, df, dates, n):
    P(f"\n{'#'*100}")
    P("PHASE 7: HYBRID K SWEEP (10 seeds x 7 values)")
    P("#" * 100)

    fc = MODELS['37feat']
    results = {}
    for K in [20, 22, 23, 25, 27, 30, 33]:
        P(f"\n  --- Hybrid 15+15 K={K} ---")
        s = _run_seeds(daily_ret, returns, vols, df, dates, n, label=f'hybrid_K={K}',
                       feature_cols=fc, n_bags_lgb=15, n_bags_xgb=15, model_type='hybrid',
                       lgb_params={'min_data_in_leaf': 12},
                       alloc_formula='linear_direct', alloc_params={'K': K})
        if s:
            results[f'hybrid_K={K}'] = s

    P(f"\n  PHASE 7:")
    _print_table(results)
    return results


# ============================================================
# PHASE 8: HYBRID BAG RATIOS
# ============================================================

def phase_8(daily_ret, returns, vols, df, dates, n, best_hybrid_K):
    P(f"\n{'#'*100}")
    P(f"PHASE 8: HYBRID BAG RATIOS (10 seeds x 6 ratios, K={best_hybrid_K})")
    P("#" * 100)

    fc = MODELS['37feat']
    results = {}
    ratios = [
        ('10+10', 10, 10), ('10+20', 10, 20), ('15+15', 15, 15),
        ('20+10', 20, 10), ('15+25', 15, 25), ('25+15', 25, 15),
    ]
    for label, nl, nx in ratios:
        P(f"\n  --- Hybrid {label} K={best_hybrid_K} ---")
        s = _run_seeds(daily_ret, returns, vols, df, dates, n, label=f'hybrid_{label}',
                       feature_cols=fc, n_bags_lgb=nl, n_bags_xgb=nx, model_type='hybrid',
                       lgb_params={'min_data_in_leaf': 12},
                       alloc_formula='linear_direct', alloc_params={'K': best_hybrid_K})
        if s:
            results[f'hybrid_{label}'] = s

    P(f"\n  PHASE 8:")
    _print_table(results)
    return results


# ============================================================
# PHASE 9: HYBRID WITH TUNED XGB
# ============================================================

def phase_9(daily_ret, returns, vols, df, dates, n, best_xgb, best_hybrid_K, best_ratio):
    P(f"\n{'#'*100}")
    P(f"PHASE 9: HYBRID WITH TUNED XGB (10 seeds x 3 configs)")
    P("#" * 100)

    fc = MODELS['37feat']
    nl, nx = best_ratio
    results = {}

    # Hybrid with tuned XGB params
    P(f"\n  --- Hybrid {nl}+{nx} K={best_hybrid_K} + tuned XGB ---")
    s = _run_seeds(daily_ret, returns, vols, df, dates, n, label='hybrid_tuned_xgb',
                   feature_cols=fc, n_bags_lgb=nl, n_bags_xgb=nx, model_type='hybrid',
                   lgb_params={'min_data_in_leaf': 12}, xgb_params=best_xgb,
                   alloc_formula='linear_direct', alloc_params={'K': best_hybrid_K})
    if s:
        results['hybrid_tuned_xgb'] = s

    # Also test 15+15 with tuned XGB + best K (in case ratio differs)
    P(f"\n  --- Hybrid 15+15 K={best_hybrid_K} + tuned XGB ---")
    s2 = _run_seeds(daily_ret, returns, vols, df, dates, n, label='hybrid_15+15_tuned',
                    feature_cols=fc, n_bags_lgb=15, n_bags_xgb=15, model_type='hybrid',
                    lgb_params={'min_data_in_leaf': 12}, xgb_params=best_xgb,
                    alloc_formula='linear_direct', alloc_params={'K': best_hybrid_K})
    if s2:
        results['hybrid_15+15_tuned'] = s2

    # V11 baseline for reference
    P(f"\n  --- Hybrid 15+15 K=25 (V11 baseline) ---")
    s3 = _run_seeds(daily_ret, returns, vols, df, dates, n, label='hybrid_v11_ref',
                    feature_cols=fc, n_bags_lgb=15, n_bags_xgb=15, model_type='hybrid',
                    lgb_params={'min_data_in_leaf': 12},
                    alloc_formula='linear_direct', alloc_params={'K': 25})
    if s3:
        results['hybrid_v11_ref'] = s3

    P(f"\n  PHASE 9:")
    _print_table(results)
    return results


# ============================================================
# PHASE 10: HYBRID FEATURE ADDS (XGB half only)
# ============================================================

def phase_10(daily_ret, returns, vols, df, dates, n, best_xgb, best_hybrid_K, best_ratio):
    P(f"\n{'#'*100}")
    P(f"PHASE 10: HYBRID FEATURE ADDS — XGB half only (10 seeds x top 6)")
    P("#" * 100)

    base_37 = list(MODELS['37feat'])
    available = [f for f in ADD_CANDIDATES if f in df.columns and f not in base_37]
    nl, nx = best_ratio
    results = {}

    for feat in available[:6]:
        xgb_feats = base_37 + [feat]
        P(f"\n  --- Hybrid {nl}+{nx} K={best_hybrid_K}, XGB+{feat} ---")
        s = _run_seeds(daily_ret, returns, vols, df, dates, n,
                       label=f'hybrid_xgb+{feat}',
                       feature_cols=base_37, feature_cols_xgb=xgb_feats,
                       n_bags_lgb=nl, n_bags_xgb=nx, model_type='hybrid',
                       lgb_params={'min_data_in_leaf': 12}, xgb_params=best_xgb,
                       alloc_formula='linear_direct', alloc_params={'K': best_hybrid_K})
        if s:
            results[f'hybrid_xgb+{feat}'] = s

    P(f"\n  PHASE 10:")
    _print_table(results)
    return results


# ============================================================
# PHASE 11: FINAL SHOWDOWN
# ============================================================

def phase_11(all_results):
    P(f"\n\n{'#'*100}")
    P("PHASE 11: FINAL SHOWDOWN — XGB-ALONE vs HYBRID")
    P("#" * 100)

    variants = []
    variants.append(('V11 hybrid 15+15 (ref)', 925, 45, 2.92, -13.9))
    variants.append(('V11 XGB alone (ref)', 992, 83, 2.91, -14.5))
    variants.append(('V10 LGB Bag50 (ref)', 802, 50, 2.74, -14.1))

    for pk in ['phase_2','phase_3','phase_4','phase_5','phase_6',
               'phase_7','phase_8','phase_9','phase_10']:
        data = all_results.get(pk, {})
        label = pk.replace('phase_', 'P')
        for ck, s in data.items():
            if isinstance(s, dict) and 'sortinos_mean' in s:
                variants.append((f'[{label}] {ck}', s['mean'], s['spread'],
                                 s['sortinos_mean'], s['max_dds_mean']))

    variants.sort(key=lambda x: x[3], reverse=True)

    P(f"\n  {'Rk':<4} {'Config':<45} {'Mean':>8} {'Spread':>8} {'Sortino':>8} {'MaxDD':>8}")
    P(f"  {'-'*85}")
    for i, (name, mean, spread, sortino, mdd) in enumerate(variants[:35], 1):
        P(f"  {i:<4} {name:<45} {mean:>+7.1f}% {spread:>7.0f}pp {sortino:>7.2f} {mdd:>7.1f}%")

    # Find best XGB-alone and best hybrid
    best_xgb = None
    best_hyb = None
    for name, mean, spread, sortino, mdd in variants:
        if 'ref' in name:
            continue
        is_xgb = 'xgb' in name.lower() and 'hybrid' not in name.lower()
        is_hyb = 'hybrid' in name.lower()
        if is_xgb and (best_xgb is None or sortino > best_xgb[3]):
            best_xgb = (name, mean, spread, sortino, mdd)
        if is_hyb and (best_hyb is None or sortino > best_hyb[3]):
            best_hyb = (name, mean, spread, sortino, mdd)

    P(f"\n  BEST XGB-ALONE:  {best_xgb[0] if best_xgb else 'N/A'}")
    if best_xgb:
        P(f"    {best_xgb[1]:+.1f}%, S={best_xgb[3]:.2f}, spread={best_xgb[2]:.0f}pp")
    P(f"  BEST HYBRID:     {best_hyb[0] if best_hyb else 'N/A'}")
    if best_hyb:
        P(f"    {best_hyb[1]:+.1f}%, S={best_hyb[3]:.2f}, spread={best_hyb[2]:.0f}pp")

    P(f"\n  {'='*60}")
    if best_xgb and best_hyb:
        if best_xgb[3] > best_hyb[3] and best_xgb[2] <= 50:
            P(f"  VERDICT: XGB-ALONE WINS")
            P(f"    Higher Sortino AND spread <= 50pp")
        elif best_hyb[3] >= best_xgb[3]:
            P(f"  VERDICT: HYBRID WINS")
            P(f"    Higher/equal Sortino with tighter spread")
        elif best_xgb[2] > 50:
            P(f"  VERDICT: HYBRID WINS")
            P(f"    XGB spread too wide ({best_xgb[2]:.0f}pp > 50pp)")
        else:
            P(f"  VERDICT: CLOSE CALL — compare return/spread tradeoff")
    P(f"  {'='*60}")


# ============================================================
# MAIN
# ============================================================

def main():
    P("=" * 100)
    P("PIPELINE V12 — DECISIVE: XGB-Alone vs Hybrid")
    P("=" * 100)
    start_time = datetime.now()
    P(f"  Start: {start_time.strftime('%Y-%m-%d %H:%M:%S')}")

    P("\nLoading data...")
    prices, daily_ret, returns, vols, df = load_data()
    dates = df['date'].values
    n = len(prices)
    P(f"  {n} days | {dates[0]} to {dates[-1]}")

    global RF_DAILY_ARR
    import scripts.optimization.pipeline_v9 as v9m
    import scripts.optimization.pipeline_v10_mega as v10m
    import scripts.optimization.pipeline_v11_xgb as v11m
    try:
        from src.features.macro.cdi_rates import build_rf_daily
        RF_DAILY_ARR = build_rf_daily(dates, source='auto')
    except Exception:
        from src.features.macro.cdi_rates import build_rf_daily
        RF_DAILY_ARR = build_rf_daily(dates, source='copom')
    v9m.RF_DAILY_ARR = RF_DAILY_ARR
    v10m.RF_DAILY_ARR = RF_DAILY_ARR
    v11m.RF_DAILY_ARR = RF_DAILY_ARR
    P(f"  CDI loaded | XGBoost {xgb.__version__} | LightGBM {lgb.__version__}")

    R = {'timestamp': start_time.isoformat(), 'method': 'pipeline_v12',
         'v11_ref': V11_BEST,
         'validation': {'permutation': 'p=0.0000 PASS', 'bootstrap': 'P(loss)=0.0% PASS',
                        'yearly': '4/5 PASS', 'result': '3/3 PASS'}}

    # === TRACK 1: XGB-ALONE OPTIMIZATION ===
    P(f"\n{'='*50}")
    P("  TRACK 1: XGB-ALONE OPTIMIZATION")
    P(f"{'='*50}")

    P(f"\n  Phase 1... ({datetime.now().strftime('%H:%M')})")
    R['phase_1'] = phase_1(daily_ret, returns, vols, df, dates, n)
    _save(R)
    best_xgb = R['phase_1'].get('best_per_param', {})

    P(f"\n  Phase 2... ({datetime.now().strftime('%H:%M')})")
    R['phase_2'] = phase_2(daily_ret, returns, vols, df, dates, n, best_xgb)
    _save(R)

    P(f"\n  Phase 3... ({datetime.now().strftime('%H:%M')})")
    R['phase_3'] = phase_3(daily_ret, returns, vols, df, dates, n, best_xgb)
    _save(R)
    # Find best bag count (lowest spread with S >= 2.85)
    best_bags = 50
    for k, s in R['phase_3'].items():
        if isinstance(s, dict) and s.get('sortinos_mean', 0) >= 2.85 and s.get('spread', 999) < 999:
            nb = int(k.replace('xgb_bag', ''))
            if nb > best_bags:
                best_bags = nb
    P(f"  Best XGB bags: {best_bags}")

    P(f"\n  Phase 4... ({datetime.now().strftime('%H:%M')})")
    R['phase_4'] = phase_4(daily_ret, returns, vols, df, dates, n, best_xgb, best_bags)
    _save(R)
    # Find best K
    best_xgb_K = 25
    best_xgb_K_s = 0
    for k, s in R['phase_4'].items():
        if isinstance(s, dict) and s.get('sortinos_mean', 0) > best_xgb_K_s:
            best_xgb_K_s = s['sortinos_mean']
            best_xgb_K = int(k.split('=')[1])
    P(f"  Best XGB K: {best_xgb_K} (S={best_xgb_K_s:.2f})")

    P(f"\n  Phase 5... ({datetime.now().strftime('%H:%M')})")
    R['phase_5'] = phase_5(daily_ret, returns, vols, df, dates, n, best_xgb, best_bags, best_xgb_K)
    _save(R)

    P(f"\n  Phase 6... ({datetime.now().strftime('%H:%M')})")
    R['phase_6'] = phase_6(daily_ret, returns, vols, df, dates, n, best_xgb, best_bags, best_xgb_K, R['phase_5'])
    _save(R)

    # === TRACK 2: HYBRID OPTIMIZATION ===
    P(f"\n{'='*50}")
    P("  TRACK 2: HYBRID OPTIMIZATION")
    P(f"{'='*50}")

    P(f"\n  Phase 7... ({datetime.now().strftime('%H:%M')})")
    R['phase_7'] = phase_7(daily_ret, returns, vols, df, dates, n)
    _save(R)
    best_hybrid_K = 25
    best_hybrid_K_s = 0
    for k, s in R['phase_7'].items():
        if isinstance(s, dict) and s.get('sortinos_mean', 0) > best_hybrid_K_s:
            best_hybrid_K_s = s['sortinos_mean']
            best_hybrid_K = int(k.split('=')[1])
    P(f"  Best hybrid K: {best_hybrid_K} (S={best_hybrid_K_s:.2f})")

    P(f"\n  Phase 8... ({datetime.now().strftime('%H:%M')})")
    R['phase_8'] = phase_8(daily_ret, returns, vols, df, dates, n, best_hybrid_K)
    _save(R)
    best_ratio = (15, 15)
    best_ratio_s = 0
    for k, s in R['phase_8'].items():
        if isinstance(s, dict) and s.get('sortinos_mean', 0) > best_ratio_s:
            best_ratio_s = s['sortinos_mean']
            parts = k.replace('hybrid_', '').split('+')
            best_ratio = (int(parts[0]), int(parts[1]))
    P(f"  Best ratio: {best_ratio[0]}+{best_ratio[1]} (S={best_ratio_s:.2f})")

    P(f"\n  Phase 9... ({datetime.now().strftime('%H:%M')})")
    R['phase_9'] = phase_9(daily_ret, returns, vols, df, dates, n, best_xgb, best_hybrid_K, best_ratio)
    _save(R)

    P(f"\n  Phase 10... ({datetime.now().strftime('%H:%M')})")
    R['phase_10'] = phase_10(daily_ret, returns, vols, df, dates, n, best_xgb, best_hybrid_K, best_ratio)
    _save(R)

    # === FINAL ===
    phase_11(R)

    elapsed = (datetime.now() - start_time).total_seconds() / 3600
    R['elapsed_hours'] = float(elapsed)
    _save(R)

    P(f"\n{'='*100}")
    P(f"V12 COMPLETE | {elapsed:.1f}h | {RESULTS_PATH}")
    P("=" * 100)


if __name__ == '__main__':
    main()
