"""
V19 Rebalance — Focused: Fri+X combos + Emergency triggers only
"""

import sys
import gc
import numpy as np
import pandas as pd
from pathlib import Path
import warnings
import json
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor

warnings.filterwarnings('ignore')
sys.stdout.reconfigure(line_buffering=True)

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

from archive.old_pipelines.pipeline_v09 import (
    load_data, build_ml_features, backtest_allocations,
    metrics, SEEDS_10, COST, P, _seed_summary, convert_numpy,
)
from archive.old_pipelines.pipeline_v10 import MODELS
from archive.old_pipelines.pipeline_v11 import DEFAULT_XGB_PARAMS
from archive.old_pipelines.pipeline_v13 import _get_retrain_periods, _train_one_xgb

W = 16
RF_DAILY_ARR = None
RESULTS_PATH = ROOT / 'outputs/results/v19_rebal_focused.json'

def get_v18_feats():
    base = [f for f in MODELS['37feat'] if f != 'exchange_netflow_ma7'] + ['basis_pct']
    extra = ['fed_balance_sheet', 'futures_trade_count', 'vol_x_regime_duration',
             'velocity', 'hash_rate_pctchg_30d']
    return base + [f for f in extra if f not in base]


def run_rebal(daily_ret, returns, vols, df, dates, n,
              feature_cols, n_bags=80, base_seed=42,
              K_bull=50, K_mild=30, K_bear=15,
              rebal_days=None, emergency_threshold=None,
              emergency_bear_only=False):
    if rebal_days is None:
        rebal_days = [4]

    xgb_params = dict(DEFAULT_XGB_PARAMS)
    prices = df['price_usd'].values
    X_all, _ = build_ml_features(df, returns, vols, n, feature_cols=feature_cols)

    target = np.zeros(n)
    for i in range(n - 3):
        target[i] = (prices[i + 3] - prices[i]) / prices[i]

    dow = pd.to_datetime(dates).dayofweek
    sma_50 = pd.Series(prices).rolling(50).mean().values
    sma_200 = pd.Series(prices).rolling(200).mean().values
    periods = _get_retrain_periods(dates, n, 'semi')

    full_allocs = np.full(n, 0.0)
    is_rf = isinstance(RF_DAILY_ARR, np.ndarray)
    a_s, a_b, a_a, a_r, a_i = [], [], [], [], []
    prev = 0.0

    for te, ts, tend in periods:
        gap = 5
        tm = np.arange(60, te - gap + 1)
        v = ~np.any(np.isnan(X_all[tm]), axis=1)
        idx = tm[v]
        if len(idx) < 100:
            continue
        Xt, yt = np.nan_to_num(X_all[idx], nan=0.0), target[idx]
        seeds = [base_seed + i * 7 for i in range(n_bags)]
        with ThreadPoolExecutor(max_workers=W) as ex:
            models = list(ex.map(_train_one_xgb, [(s, Xt, yt, xgb_params) for s in seeds]))
        if not models:
            continue

        for t in range(ts, tend + 1):
            if not np.isnan(sma_50[t]) and not np.isnan(sma_200[t]):
                if prices[t] > sma_50[t] and sma_50[t] > sma_200[t]:
                    regime = 'BULL'
                elif prices[t] > sma_200[t]:
                    regime = 'MILD'
                else:
                    regime = 'BEAR'
            else:
                regime = 'MILD'

            is_rebal = dow[t] in rebal_days
            is_emerg = False
            if emergency_threshold is not None and t > 0:
                if abs(daily_ret[t]) > emergency_threshold:
                    if emergency_bear_only:
                        is_emerg = (regime == 'BEAR')
                    else:
                        is_emerg = True

            if not is_rebal and not is_emerg:
                full_allocs[t] = prev
                continue

            x_t = np.nan_to_num(X_all[t:t + 1].copy(), nan=0.0)
            avg = np.mean([m.predict(x_t)[0] for m in models])
            K = {'BULL': K_bull, 'MILD': K_mild, 'BEAR': K_bear}[regime]
            full_allocs[t] = np.clip(avg * K, -0.25, 1.0)
            prev = full_allocs[t]

        s, b, a = backtest_allocations(daily_ret, full_allocs, ts, tend,
                                       cost=COST, rf_daily=RF_DAILY_ARR)
        a_s.extend(s); a_b.extend(b); a_a.extend(a)
        a_i.extend(range(ts, ts + len(s)))
        nd = len(s)
        a_r.extend(RF_DAILY_ARR[ts:ts + nd] if is_rf else [0.0] * nd)

    return np.array(a_s), np.array(a_b), np.array(a_a), np.array(a_r), np.array(a_i)


DAY = {0: 'Mon', 1: 'Tue', 2: 'Wed', 3: 'Thu', 4: 'Fri'}


def run_config(label, daily_ret, returns, vols, df, dates, n, fc, **kwargs):
    P(f"\n  {label} (10 seeds)...")
    results = []
    for seed in SEEDS_10:
        s, b, a, r, idx = run_rebal(daily_ret, returns, vols, df, dates, n, fc,
                                     base_seed=seed, **kwargs)
        m = metrics(s, b, a, rf_daily=r)
        results.append(m)
        gc.collect()
    rets = [r['total'] * 100 for r in results]
    summary = _seed_summary(rets, results)
    P(f"  {label}: S={summary['sortinos_mean']:.2f} ret={summary['mean']:+.1f}% "
      f"spread={summary['spread']:.0f}pp DD={summary['max_dds_mean']:.1f}%")
    return {
        'config': label,
        'sortino': summary['sortinos_mean'],
        'return': summary['mean'],
        'spread': summary['spread'],
        'max_dd': summary['max_dds_mean'],
    }


def main():
    P("=" * 80)
    P("V19 REBALANCE — Fri+X COMBOS + EMERGENCY TRIGGERS")
    P("=" * 80)
    start = datetime.now()

    prices, daily_ret, returns, vols, df = load_data()
    dates = df['date'].values; n = len(prices)

    global RF_DAILY_ARR
    import archive.old_pipelines.pipeline_v09 as v9m
    import archive.old_pipelines.pipeline_v13 as v13m
    try:
        from src.features.macro.cdi_rates import build_rf_daily
        RF_DAILY_ARR = build_rf_daily(dates, source='auto')
    except Exception:
        from src.features.macro.cdi_rates import build_rf_daily
        RF_DAILY_ARR = build_rf_daily(dates, source='copom')
    v9m.RF_DAILY_ARR = RF_DAILY_ARR; v13m.RF_DAILY_ARR = RF_DAILY_ARR

    fc = get_v18_feats()
    fc = [f for f in fc if f in df.columns]
    P(f"  {n} days | {len(fc)} features\n")

    results = []

    # BASELINE: Fri only
    P(f"{'#' * 70}")
    P("BASELINE: Friday only")
    P('#' * 70)
    results.append(run_config('Fri_only (baseline)', daily_ret, returns, vols, df, dates, n, fc,
                              rebal_days=[4]))

    # PART 1: Fri + another day (4 combos)
    P(f"\n{'#' * 70}")
    P("PART 1: Fri + another day (4 combos)")
    P('#' * 70)
    for d in [0, 1, 2, 3]:
        results.append(run_config(f'Fri+{DAY[d]}', daily_ret, returns, vols, df, dates, n, fc,
                                  rebal_days=[d, 4]))

    # PART 2: Emergency triggers (all regimes)
    P(f"\n{'#' * 70}")
    P("PART 2: Fri + Emergency (all regimes)")
    P('#' * 70)
    for thr in [0.03, 0.05, 0.08, 0.10]:
        results.append(run_config(f'Fri+emerg_{int(thr*100)}%_all', daily_ret, returns, vols, df, dates, n, fc,
                                  rebal_days=[4], emergency_threshold=thr, emergency_bear_only=False))

    # PART 3: Emergency triggers (bear only)
    P(f"\n{'#' * 70}")
    P("PART 3: Fri + Emergency (bear only)")
    P('#' * 70)
    for thr in [0.03, 0.05, 0.08, 0.10]:
        results.append(run_config(f'Fri+emerg_{int(thr*100)}%_bear', daily_ret, returns, vols, df, dates, n, fc,
                                  rebal_days=[4], emergency_threshold=thr, emergency_bear_only=True))

    # RANKING
    results.sort(key=lambda x: x['sortino'], reverse=True)
    P(f"\n\n{'=' * 80}")
    P("FINAL RANKING")
    P("=" * 80)
    P(f"  {'Config':<30} {'Sortino':>8} {'Return':>10} {'Spread':>8} {'MaxDD':>8}")
    P(f"  {'-' * 65}")
    for r in results:
        marker = ' <-- BEST' if r == results[0] else ''
        P(f"  {r['config']:<30} {r['sortino']:>8.2f} {r['return']:>+9.1f}% "
          f"{r['spread']:>7.0f}pp {r['max_dd']:>7.1f}%{marker}")

    elapsed = (datetime.now() - start).total_seconds() / 60
    P(f"\n  Best: {results[0]['config']} (S={results[0]['sortino']:.2f})")
    P(f"  Elapsed: {elapsed:.1f} min")

    output = {'pipeline': 'V19_rebal_focused', 'timestamp': start.isoformat(),
              'elapsed_min': float(elapsed), 'results': results}
    RESULTS_PATH.parent.mkdir(parents=True, exist_ok=True)
    RESULTS_PATH.write_text(json.dumps(convert_numpy(output), indent=2, default=str), encoding='utf-8')
    P(f"  Saved: {RESULTS_PATH}")


if __name__ == '__main__':
    main()
