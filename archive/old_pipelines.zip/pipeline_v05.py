"""
PIPELINE V5 NEW APPROACHES - Comprehensive Exploration
========================================================

V2 Best Combo (Bag5 LGB + Weekly Rebal) = +221% OOS (2022-2026), Sortino 0.87, MaxDD -21%.
V3/V4 failed to beat V2 robustly.

V5 tests 13 experiment groups (~59 variants):
  A: Rebalance x Bag Size Grid (8 variants)
  B: ML/Momentum Weight Grid (7 variants)
  C: ML Model Zoo (8 variants)
  D: Momentum Signal Variations (6 variants)
  E: Triple Signal Momentum (3 variants)
  F: Momentum Optimization Variants (3 variants)
  G: Themed Feature Sets (12 variants: domain-specific + cross-domain mixes)
  H: Feature Engineering Transforms (4 variants)
  I: Third Component (4 variants)
  J: Stacking & Advanced Ensembles (3 variants)
  K: Prediction Approach (3 variants)
  L: Combined Best (3 variants, L3 uses best from ALL groups)

Cross-domain feature mixes: Macro+Onchain, Derivatives+Valuation,
OC+Deriv+Macro, Mega All Domains.

All walk-forward OOS (2022-2026), no look-ahead.
"""

import sys
import pandas as pd
import numpy as np
from pathlib import Path
import warnings
import json
from datetime import datetime
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

warnings.filterwarnings('ignore')
sys.stdout.reconfigure(line_buffering=True)

ROOT = Path(__file__).parent.parent.parent
COST = 0.0002       # 2 bps
RF_ANNUAL = 0.15
RF_DAILY = (1 + RF_ANNUAL)**(1/365) - 1

P = lambda *a, **kw: print(*a, **kw, flush=True)

# Optional dependencies
HAS_CATBOOST = False
try:
    from catboost import CatBoostRegressor, CatBoostClassifier
    HAS_CATBOOST = True
except ImportError:
    pass


# ============================================================
# DATA LOADING
# ============================================================

def load_data():
    df = pd.read_csv(ROOT / 'outputs/feature_selection/dataset_enhanced.csv')
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)

    prices = df['price_usd'].values
    n = len(prices)

    daily_ret = np.zeros(n)
    for i in range(1, n):
        daily_ret[i] = (prices[i] - prices[i-1]) / prices[i-1]

    returns = {}
    for w in [1, 3, 5, 7, 10, 14, 20, 21, 30, 45, 60]:
        r = np.zeros(n)
        for i in range(w, n):
            r[i] = (prices[i] - prices[i-w]) / prices[i-w]
        returns[w] = r

    vols = {}
    for w in [5, 7, 10, 14, 21, 30]:
        vols[w] = pd.Series(daily_ret).rolling(w).std().fillna(0.02).values

    return prices, daily_ret, returns, vols, df


# ============================================================
# CORE ENGINE
# ============================================================

def backtest_allocations(daily_ret, allocations, start_idx, end_idx,
                         cost=COST, rf_daily=RF_DAILY):
    strat, btc, allocs = [], [], []
    prev = 0.5
    n = len(daily_ret)
    for t in range(start_idx, min(end_idx, n - 1)):
        a = np.clip(allocations[t], -0.25, 1.0)
        br = daily_ret[t + 1]
        tc = abs(a - prev) * cost * (1.5 if a < 0 else 1.0)
        sr = a * br + (1 - abs(a)) * rf_daily - tc
        strat.append(sr)
        btc.append(br)
        allocs.append(a)
        prev = a
    return np.array(strat), np.array(btc), np.array(allocs)


def metrics(s, b, a, rf_daily=RF_DAILY):
    if len(s) < 10:
        return None
    ts = np.prod(1 + s) - 1
    tb = np.prod(1 + b) - 1
    ex = s - rf_daily
    ds = ex[ex < 0]
    sortino = np.mean(ex) / (np.std(ds) + 1e-10) * np.sqrt(365) if len(ds) > 0 else 0
    cum = np.cumprod(1 + s)
    pk = np.maximum.accumulate(cum)
    dd = np.min((cum - pk) / (pk + 1e-10))
    return {'total': ts, 'btc': tb, 'excess': ts - tb, 'sortino': sortino,
            'max_dd': dd, 'short_pct': float((a < 0).mean()), 'avg_alloc': float(np.mean(a))}


def get_year_boundaries(dates, n):
    yb = {}
    for i in range(n):
        yr = pd.Timestamp(dates[i]).year
        if yr not in yb:
            yb[yr] = {'start': i, 'end': i}
        yb[yr]['end'] = i
    return yb


# ============================================================
# MOMENTUM STRATEGY
# ============================================================

def strategy_fn(slow_ret, fast_ret, vol, p):
    bear_s, bear_f, bull_s = p[0], p[1], p[2]
    a_min, a_max, a_mid = p[3], p[4], p[5]
    sl_bear, sl_bull = p[6], p[7]
    v_thresh, v_damp = p[8], p[9]

    if slow_ret < bear_s and fast_ret < bear_f:
        base = a_min
    elif slow_ret < bear_s * 0.5 and fast_ret < bear_f * 0.5:
        t = np.clip(slow_ret / (bear_s + 1e-10), 0, 2)
        base = a_mid + (a_min - a_mid) * min(t * sl_bear, 1.0)
    elif slow_ret < 0 and fast_ret < bear_f * 0.5:
        t = np.clip(slow_ret / (bear_s * 0.5 + 1e-10), 0, 1)
        base = a_mid * (1 - t * 0.5)
    elif slow_ret > bull_s:
        base = a_max
    elif slow_ret > 0:
        t = np.clip(slow_ret / (bull_s + 1e-10), 0, 1)
        base = a_mid + (a_max - a_mid) * (t ** (1.0 / max(sl_bull, 0.1)))
    else:
        base = a_mid

    if vol > v_thresh:
        excess = (vol - v_thresh) / (v_thresh + 1e-10)
        damp = min(v_damp * excess, 0.5)
        if base > 0:
            base *= (1 - damp)
        else:
            base *= (1 + damp * 0.5)

    return np.clip(base, -0.25, 1.0)


def strategy_fn_triple(slow_ret, med_ret, fast_ret, vol, p):
    """Triple signal momentum: slow + medium + fast."""
    bear_s, bear_f, bull_s = p[0], p[1], p[2]
    a_min, a_max, a_mid = p[3], p[4], p[5]
    sl_bear, sl_bull = p[6], p[7]
    v_thresh, v_damp = p[8], p[9]
    bear_med, bull_med = p[10], p[11]

    if slow_ret < bear_s and fast_ret < bear_f and med_ret < bear_med:
        base = a_min
    elif slow_ret < bear_s and med_ret < bear_med:
        base = a_min * 0.7 + a_mid * 0.3
    elif slow_ret < bear_s * 0.5 and fast_ret < bear_f * 0.5:
        t = np.clip(slow_ret / (bear_s + 1e-10), 0, 2)
        base = a_mid + (a_min - a_mid) * min(t * sl_bear, 1.0)
    elif slow_ret < 0 and fast_ret < bear_f * 0.5:
        t = np.clip(slow_ret / (bear_s * 0.5 + 1e-10), 0, 1)
        base = a_mid * (1 - t * 0.5)
    elif slow_ret > bull_s and med_ret > bull_med and fast_ret > 0:
        base = a_max
    elif slow_ret > bull_s and med_ret > bull_med:
        base = a_max * 0.8 + a_mid * 0.2
    elif slow_ret > 0:
        t = np.clip(slow_ret / (bull_s + 1e-10), 0, 1)
        base = a_mid + (a_max - a_mid) * (t ** (1.0 / max(sl_bull, 0.1)))
    else:
        base = a_mid

    if vol > v_thresh:
        excess_v = (vol - v_thresh) / (v_thresh + 1e-10)
        damp = min(v_damp * excess_v, 0.5)
        if base > 0:
            base *= (1 - damp)
        else:
            base *= (1 + damp * 0.5)

    return np.clip(base, -0.25, 1.0)


def optimize_params(daily_ret, slow_sig, fast_sig, vol_sig, start_idx, end_idx,
                    n_trials=2000, cost=COST, rf_daily=RF_DAILY,
                    objective='default'):
    ranges = {
        'bear_slow': (-0.15, -0.04), 'bear_fast': (-0.06, -0.01),
        'bull': (0.05, 0.30), 'alloc_min': (-0.25, -0.05),
        'alloc_max': (0.80, 1.0), 'alloc_mid': (0.25, 0.65),
        'slope_bear': (0.3, 2.5), 'slope_bull': (0.3, 2.5),
        'vol_thresh': (0.015, 0.05), 'vol_damp': (0.05, 0.55),
    }

    best_score, best_params = -999, None
    n = len(daily_ret)

    for _ in range(n_trials):
        p = [np.random.uniform(*ranges[k]) for k in
             ['bear_slow', 'bear_fast', 'bull', 'alloc_min', 'alloc_max',
              'alloc_mid', 'slope_bear', 'slope_bull', 'vol_thresh', 'vol_damp']]

        allocs = np.full(n, 0.5)
        for t in range(max(start_idx, 60), end_idx + 1):
            allocs[t] = strategy_fn(slow_sig[t], fast_sig[t], vol_sig[t], p)

        s, b, a = backtest_allocations(daily_ret, allocs, max(start_idx, 60), end_idx,
                                       cost=cost, rf_daily=rf_daily)
        m = metrics(s, b, a, rf_daily=rf_daily)
        if m is None:
            continue

        if objective == 'calmar':
            score = m['total'] / (abs(m['max_dd']) + 1e-10)
        elif objective == 'turnover':
            avg_turnover = np.mean(np.abs(np.diff(a))) if len(a) > 1 else 0
            score = (m['total'] * 2 + m['sortino'] * 0.3 + m['excess'] * 0.5
                     + m['max_dd'] * 0.3 - 0.3 * avg_turnover)
        else:
            score = m['total'] * 2 + m['sortino'] * 0.3 + m['excess'] * 0.5 + m['max_dd'] * 0.3

        if score > best_score:
            best_score = score
            best_params = p[:]

    return best_params


def optimize_params_triple(daily_ret, slow_sig, med_sig, fast_sig, vol_sig,
                           start_idx, end_idx, n_trials=2000,
                           cost=COST, rf_daily=RF_DAILY):
    ranges = {
        'bear_slow': (-0.15, -0.04), 'bear_fast': (-0.06, -0.01),
        'bull': (0.05, 0.30), 'alloc_min': (-0.25, -0.05),
        'alloc_max': (0.80, 1.0), 'alloc_mid': (0.25, 0.65),
        'slope_bear': (0.3, 2.5), 'slope_bull': (0.3, 2.5),
        'vol_thresh': (0.015, 0.05), 'vol_damp': (0.05, 0.55),
        'bear_med': (-0.10, -0.02), 'bull_med': (0.02, 0.15),
    }

    best_score, best_params = -999, None
    n = len(daily_ret)

    for _ in range(n_trials):
        p = [np.random.uniform(*ranges[k]) for k in
             ['bear_slow', 'bear_fast', 'bull', 'alloc_min', 'alloc_max',
              'alloc_mid', 'slope_bear', 'slope_bull', 'vol_thresh', 'vol_damp',
              'bear_med', 'bull_med']]

        allocs = np.full(n, 0.5)
        for t in range(max(start_idx, 60), end_idx + 1):
            allocs[t] = strategy_fn_triple(slow_sig[t], med_sig[t], fast_sig[t],
                                           vol_sig[t], p)

        s, b, a = backtest_allocations(daily_ret, allocs, max(start_idx, 60), end_idx,
                                       cost=cost, rf_daily=rf_daily)
        m = metrics(s, b, a, rf_daily=rf_daily)
        if m is None:
            continue

        score = m['total'] * 2 + m['sortino'] * 0.3 + m['excess'] * 0.5 + m['max_dd'] * 0.3
        if score > best_score:
            best_score = score
            best_params = p[:]

    return best_params


# ============================================================
# ML FEATURES
# ============================================================

DEFAULT_FEATURE_COLS = [
    'cusum_pos', 'miners_revenue_ratio', 'mr_score_30d', 'adx',
    'cusum_neg', 'exchange_netflow_ma7', 'structural_break_score',
    'macd_histogram', 'eth_btc_ratio', 'm2_yoy_growth',
    'volatility_7d', 'basis_ma7', 'nupl_ma30', 'hurst_60d',
    'funding_rate', 'bb_position', 'rsi_14d', 'puell_multiple',
    'stablecoin_zscore', 'sopr_ma7',
]


def build_ml_features(df, returns, vols, n, feature_cols=None):
    if feature_cols is None:
        feature_cols = DEFAULT_FEATURE_COLS
    available = [c for c in feature_cols if c in df.columns]
    X_all = df[available].values.astype(float) if available else np.zeros((n, 0))
    X_extra = np.column_stack([returns[3], returns[10], returns[30], returns[60], vols[14]])
    X_all = np.hstack([X_all, X_extra]) if X_all.shape[1] > 0 else X_extra
    feature_names = available + ['ret_3d', 'ret_10d', 'ret_30d', 'ret_60d', 'vol_14d']
    return X_all, feature_names


def build_themed_features(df, feature_list, returns, vols, n):
    """Build X_all from ANY list of column names from the 280-col dataset."""
    price_derived_map = {
        'ret_3d': returns[3], 'ret_5d': returns[5], 'ret_7d': returns[7],
        'ret_10d': returns[10], 'ret_14d': returns[14], 'ret_30d': returns[30],
        'ret_45d': returns[45], 'ret_60d': returns[60],
        'vol_7d': vols[7], 'vol_14d': vols[14], 'vol_30d': vols[30],
    }

    cols = []
    names = []
    for col in feature_list:
        if col in price_derived_map:
            cols.append(price_derived_map[col])
            names.append(col)
        elif col in df.columns:
            cols.append(df[col].values.astype(float))
            names.append(col)

    # Always ensure base price-derived features are included
    base_derived = ['ret_3d', 'ret_10d', 'ret_30d', 'ret_60d', 'vol_14d']
    for pd_feat in base_derived:
        if pd_feat not in names:
            cols.append(price_derived_map[pd_feat])
            names.append(pd_feat)

    X_all = np.column_stack(cols)
    return X_all, names


# ============================================================
# ML MODEL TRAINING
# ============================================================

def train_lgb_model(X_all, target, train_end, horizon_gap=5, seed=42):
    import lightgbm as lgb

    train_mask = np.arange(60, train_end - horizon_gap + 1)
    valid_train = ~np.any(np.isnan(X_all[train_mask]), axis=1)
    train_idx = train_mask[valid_train]

    if len(train_idx) < 100:
        return None

    X_train = np.nan_to_num(X_all[train_idx], nan=0.0)
    y_train = target[train_idx]

    params = {
        'objective': 'regression', 'metric': 'mae',
        'num_leaves': 31, 'learning_rate': 0.05,
        'feature_fraction': 0.7, 'bagging_fraction': 0.8,
        'bagging_freq': 5, 'verbose': -1, 'n_jobs': 1,
        'seed': seed,
    }

    dtrain = lgb.Dataset(X_train, label=y_train)
    return lgb.train(params, dtrain, num_boost_round=200)


def train_lgb_bagged(X_all, target, train_end, horizon_gap=5, n_bags=5):
    models = []
    for i in range(n_bags):
        seed = 42 + i * 7
        m = train_lgb_model(X_all, target, train_end, horizon_gap=horizon_gap, seed=seed)
        if m is not None:
            models.append(m)
    return models if len(models) > 0 else None


def train_lgb_binary_model(X_all, target_binary, train_end, horizon_gap=5, seed=42):
    import lightgbm as lgb

    train_mask = np.arange(60, train_end - horizon_gap + 1)
    valid_train = ~np.any(np.isnan(X_all[train_mask]), axis=1)
    train_idx = train_mask[valid_train]

    if len(train_idx) < 100:
        return None

    X_train = np.nan_to_num(X_all[train_idx], nan=0.0)
    y_train = target_binary[train_idx]

    params = {
        'objective': 'binary', 'metric': 'binary_logloss',
        'num_leaves': 31, 'learning_rate': 0.05,
        'feature_fraction': 0.7, 'bagging_fraction': 0.8,
        'bagging_freq': 5, 'verbose': -1, 'n_jobs': 1,
        'seed': seed,
    }

    dtrain = lgb.Dataset(X_train, label=y_train)
    return lgb.train(params, dtrain, num_boost_round=200)


def train_lgb_binary_bagged(X_all, target_binary, train_end, horizon_gap=5, n_bags=5):
    models = []
    for i in range(n_bags):
        seed = 42 + i * 7
        m = train_lgb_binary_model(X_all, target_binary, train_end,
                                   horizon_gap=horizon_gap, seed=seed)
        if m is not None:
            models.append(m)
    return models if len(models) > 0 else None


def train_catboost_model(X_all, target, train_end, horizon_gap=5, seed=42,
                         depth=6, lr=0.05, iterations=200):
    if not HAS_CATBOOST:
        return None

    train_mask = np.arange(60, train_end - horizon_gap + 1)
    valid_train = ~np.any(np.isnan(X_all[train_mask]), axis=1)
    train_idx = train_mask[valid_train]

    if len(train_idx) < 100:
        return None

    X_train = np.nan_to_num(X_all[train_idx], nan=0.0)
    y_train = target[train_idx]

    model = CatBoostRegressor(
        depth=depth, learning_rate=lr, iterations=iterations,
        random_seed=seed, verbose=0, loss_function='MAE',
    )
    model.fit(X_train, y_train)
    return model


def train_catboost_bagged(X_all, target, train_end, horizon_gap=5, n_bags=5,
                          depth=6, lr=0.05, iterations=200):
    models = []
    for i in range(n_bags):
        seed = 42 + i * 7
        m = train_catboost_model(X_all, target, train_end, horizon_gap=horizon_gap,
                                 seed=seed, depth=depth, lr=lr, iterations=iterations)
        if m is not None:
            models.append(m)
    return models if len(models) > 0 else None


def train_rf_model(X_all, target, train_end, horizon_gap=5, seed=42,
                   n_trees=200, max_depth=10):
    from sklearn.ensemble import RandomForestRegressor

    train_mask = np.arange(60, train_end - horizon_gap + 1)
    valid_train = ~np.any(np.isnan(X_all[train_mask]), axis=1)
    train_idx = train_mask[valid_train]

    if len(train_idx) < 100:
        return None

    X_train = np.nan_to_num(X_all[train_idx], nan=0.0)
    y_train = target[train_idx]

    model = RandomForestRegressor(n_estimators=n_trees, max_depth=max_depth,
                                  random_state=seed, n_jobs=1)
    model.fit(X_train, y_train)
    return model


def train_rf_bagged(X_all, target, train_end, horizon_gap=5, n_bags=5,
                    n_trees=200, max_depth=10):
    models = []
    for i in range(n_bags):
        seed = 42 + i * 7
        m = train_rf_model(X_all, target, train_end, horizon_gap=horizon_gap,
                           seed=seed, n_trees=n_trees, max_depth=max_depth)
        if m is not None:
            models.append(m)
    return models if len(models) > 0 else None


def train_extratrees_model(X_all, target, train_end, horizon_gap=5, seed=42,
                           n_trees=200, max_depth=10):
    from sklearn.ensemble import ExtraTreesRegressor

    train_mask = np.arange(60, train_end - horizon_gap + 1)
    valid_train = ~np.any(np.isnan(X_all[train_mask]), axis=1)
    train_idx = train_mask[valid_train]

    if len(train_idx) < 100:
        return None

    X_train = np.nan_to_num(X_all[train_idx], nan=0.0)
    y_train = target[train_idx]

    model = ExtraTreesRegressor(n_estimators=n_trees, max_depth=max_depth,
                                random_state=seed, n_jobs=1)
    model.fit(X_train, y_train)
    return model


def train_extratrees_bagged(X_all, target, train_end, horizon_gap=5, n_bags=5,
                            n_trees=200, max_depth=10):
    models = []
    for i in range(n_bags):
        seed = 42 + i * 7
        m = train_extratrees_model(X_all, target, train_end, horizon_gap=horizon_gap,
                                   seed=seed, n_trees=n_trees, max_depth=max_depth)
        if m is not None:
            models.append(m)
    return models if len(models) > 0 else None


def train_mlp_model(X_all, target, train_end, horizon_gap=5, seed=42):
    from sklearn.neural_network import MLPRegressor
    from sklearn.preprocessing import StandardScaler

    train_mask = np.arange(60, train_end - horizon_gap + 1)
    valid_train = ~np.any(np.isnan(X_all[train_mask]), axis=1)
    train_idx = train_mask[valid_train]

    if len(train_idx) < 100:
        return None

    X_train = np.nan_to_num(X_all[train_idx], nan=0.0)
    y_train = target[train_idx]

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X_train)

    model = MLPRegressor(hidden_layer_sizes=(64, 32), activation='relu',
                         solver='adam', max_iter=500, random_state=seed,
                         early_stopping=True, validation_fraction=0.1)
    model.fit(X_scaled, y_train)
    return (model, scaler)


def train_mlp_bagged(X_all, target, train_end, horizon_gap=5, n_bags=5):
    models = []
    for i in range(n_bags):
        seed = 42 + i * 7
        m = train_mlp_model(X_all, target, train_end, horizon_gap=horizon_gap, seed=seed)
        if m is not None:
            models.append(m)
    return models if len(models) > 0 else None


# ============================================================
# ML PREDICTION
# ============================================================

def ml_predict_bagged(models, X_all, t):
    x_t = np.nan_to_num(X_all[t:t+1].copy(), nan=0.0)
    preds = [m.predict(x_t)[0] for m in models]
    avg_pred = np.mean(preds)
    scaled = np.clip(avg_pred / 0.05, -1.0, 1.0)
    if scaled > 0:
        return 0.5 + scaled * 0.5
    else:
        return 0.5 + scaled * 0.75


def ml_predict_binary_bagged(models, X_all, t):
    x_t = np.nan_to_num(X_all[t:t+1].copy(), nan=0.0)
    probas = [m.predict(x_t)[0] for m in models]
    avg_proba = np.mean(probas)
    # proba in [0,1], map 0.5 -> 0.5 alloc, 1.0 -> 1.0, 0.0 -> -0.25
    if avg_proba >= 0.5:
        return 0.5 + (avg_proba - 0.5) * 1.0  # [0.5, 1.0]
    else:
        return 0.5 - (0.5 - avg_proba) * 1.5  # down to -0.25


def ml_predict_mlp_bagged(models, X_all, t):
    x_t = np.nan_to_num(X_all[t:t+1].copy(), nan=0.0)
    preds = []
    for (model, scaler) in models:
        x_scaled = scaler.transform(x_t)
        preds.append(model.predict(x_scaled)[0])
    avg_pred = np.mean(preds)
    scaled = np.clip(avg_pred / 0.05, -1.0, 1.0)
    if scaled > 0:
        return 0.5 + scaled * 0.5
    else:
        return 0.5 + scaled * 0.75


# ============================================================
# WALK-FORWARD ENGINE V5 (unified)
# ============================================================

def walk_forward_hybrid_v5(
    daily_ret, returns, vols, df, dates, n,
    # Rebalance
    use_weekly=True, rebal_days=None,
    # ML
    n_bags=5, ml_weight=0.5,
    model_type='lgb',
    # Momentum
    slow_key=60, fast_key=3, vol_key=14,
    use_triple=False, med_key=30,
    n_trials=2000, opt_objective='default',
    # Features
    feature_list=None,
    X_override=None,
    # Target
    target_horizon=5, use_binary=False,
    # Third component
    third_component=None, third_weight=0.10,
    # Stacking
    stacking_models=None,
    # Cost
    cost=COST, rf_daily=RF_DAILY,
    label="V5", verbose=True,
):
    yb = get_year_boundaries(dates, n)
    prices = df['price_usd'].values

    # Build features
    if X_override is not None:
        X_all = X_override
        feat_names = [f'f{i}' for i in range(X_all.shape[1])]
    elif feature_list is not None:
        X_all, feat_names = build_themed_features(df, feature_list, returns, vols, n)
    else:
        X_all, feat_names = build_ml_features(df, returns, vols, n)

    if verbose:
        P(f"      Features: {X_all.shape[1]} ({feat_names[:5]}...)")

    # Build target
    target = np.zeros(n)
    h = target_horizon
    for i in range(n - h):
        target[i] = (prices[i + h] - prices[i]) / prices[i]
    target_binary = (target > 0).astype(float)

    # Momentum signals
    slow_sig = returns[slow_key]
    fast_sig = returns[fast_key]
    vol_sig = vols[vol_key]
    med_sig = returns.get(med_key, returns[30]) if use_triple else None

    day_of_week = pd.to_datetime(dates).dayofweek

    all_strat, all_btc, all_alloc = [], [], []
    full_allocs = np.full(n, 0.5)
    test_ranges = []

    for test_year in range(2022, 2027):
        if test_year not in yb:
            continue
        train_end = yb[test_year]['start'] - 1
        test_start = yb[test_year]['start']
        test_end = yb[test_year]['end']

        np.random.seed(42 + test_year)

        # Optimize momentum
        if use_triple:
            mom_params = optimize_params_triple(
                daily_ret, slow_sig, med_sig, fast_sig, vol_sig,
                60, train_end, n_trials, cost=cost, rf_daily=rf_daily)
        else:
            mom_params = optimize_params(
                daily_ret, slow_sig, fast_sig, vol_sig,
                60, train_end, n_trials, cost=cost, rf_daily=rf_daily,
                objective=opt_objective)

        if mom_params is None:
            continue

        # Train ML models
        models = None
        horizon_gap = max(target_horizon, 5)

        if model_type == 'lgb':
            if use_binary:
                models = train_lgb_binary_bagged(X_all, target_binary, train_end,
                                                 horizon_gap=horizon_gap, n_bags=n_bags)
            else:
                models = train_lgb_bagged(X_all, target, train_end,
                                          horizon_gap=horizon_gap, n_bags=n_bags)
        elif model_type == 'cat':
            models = train_catboost_bagged(X_all, target, train_end,
                                           horizon_gap=horizon_gap, n_bags=n_bags,
                                           depth=6, lr=0.05, iterations=200)
        elif model_type == 'cat_deep':
            models = train_catboost_bagged(X_all, target, train_end,
                                           horizon_gap=horizon_gap, n_bags=n_bags,
                                           depth=8, lr=0.03, iterations=300)
        elif model_type == 'rf':
            models = train_rf_bagged(X_all, target, train_end,
                                     horizon_gap=horizon_gap, n_bags=n_bags)
        elif model_type == 'et':
            models = train_extratrees_bagged(X_all, target, train_end,
                                             horizon_gap=horizon_gap, n_bags=n_bags)
        elif model_type == 'mlp':
            models = train_mlp_bagged(X_all, target, train_end,
                                      horizon_gap=horizon_gap, n_bags=n_bags)
        elif model_type == 'binary_lgb':
            models = train_lgb_binary_bagged(X_all, target_binary, train_end,
                                             horizon_gap=horizon_gap, n_bags=n_bags)
        elif model_type == 'mixed_cat_lgb':
            cat_models = train_catboost_bagged(X_all, target, train_end,
                                               horizon_gap=horizon_gap, n_bags=3,
                                               depth=6, lr=0.05, iterations=200)
            lgb_models = train_lgb_bagged(X_all, target, train_end,
                                          horizon_gap=horizon_gap, n_bags=2)
            models = []
            if cat_models:
                models.extend([('cat', m) for m in cat_models])
            if lgb_models:
                models.extend([('lgb', m) for m in lgb_models])
            if not models:
                models = None
        elif model_type == 'stacking':
            # Stacking: train LGB + Cat + RF, average OOF
            lgb_m = train_lgb_bagged(X_all, target, train_end,
                                     horizon_gap=horizon_gap, n_bags=2)
            cat_m = train_catboost_bagged(X_all, target, train_end,
                                          horizon_gap=horizon_gap, n_bags=2,
                                          depth=6, lr=0.05, iterations=200)
            rf_m = train_rf_bagged(X_all, target, train_end,
                                   horizon_gap=horizon_gap, n_bags=1)
            models = []
            if lgb_m:
                models.extend([('lgb', m) for m in lgb_m])
            if cat_m:
                models.extend([('cat', m) for m in cat_m])
            if rf_m:
                models.extend([('rf', m) for m in rf_m])
            if not models:
                models = None
        elif model_type == 'stacking_logistic':
            lgb_m = train_lgb_bagged(X_all, target, train_end,
                                     horizon_gap=horizon_gap, n_bags=2)
            cat_m = train_catboost_bagged(X_all, target, train_end,
                                          horizon_gap=horizon_gap, n_bags=2,
                                          depth=6, lr=0.05, iterations=200)
            models = []
            if lgb_m:
                models.extend([('lgb', m) for m in lgb_m])
            if cat_m:
                models.extend([('cat', m) for m in cat_m])
            if not models:
                models = None
        else:
            models = train_lgb_bagged(X_all, target, train_end,
                                      horizon_gap=horizon_gap, n_bags=n_bags)

        if verbose:
            n_ok = 0
            if models:
                n_ok = len(models)
            P(f"    {test_year}: {n_ok} models trained", end="")

        # Third component training
        third_alloc_arr = None
        if third_component == 'sentiment':
            # Use fear_greed_zscore from df
            fg_col = 'fear_greed_zscore'
            sc_col = 'stablecoin_supply_change_30d'
            if fg_col in df.columns:
                fg = df[fg_col].values
                sc = df[sc_col].values if sc_col in df.columns else np.zeros(n)
                third_alloc_arr = np.full(n, 0.5)
                for t in range(n):
                    if fg[t] < -1.5:
                        third_alloc_arr[t] = 0.8
                    elif fg[t] > 1.5:
                        third_alloc_arr[t] = 0.1
                    else:
                        third_alloc_arr[t] = 0.5
                    if sc[t] > 0.02:
                        third_alloc_arr[t] = min(third_alloc_arr[t] + 0.1, 1.0)

        elif third_component == 'regime':
            # Train a regime classifier (binary: bull/bear)
            regime_target = (returns[30] > 0).astype(float)
            regime_models = train_lgb_binary_bagged(X_all, regime_target, train_end,
                                                    horizon_gap=1, n_bags=3)
            if regime_models:
                third_alloc_arr = np.full(n, 0.5)
                for t in range(test_start, test_end + 1):
                    x_t = np.nan_to_num(X_all[t:t+1].copy(), nan=0.0)
                    probas = [m.predict(x_t)[0] for m in regime_models]
                    bull_prob = np.mean(probas)
                    third_alloc_arr[t] = 0.2 + bull_prob * 0.6

        elif third_component == 'vol_switch':
            # Swap ML/Mom weights based on vol regime
            pass  # Handled inline below

        elif third_component == 'meta':
            # Meta-labeling: train classifier on whether primary ML was correct
            pass  # Simplified meta: use ML confidence as third signal

        # TEST LOOP
        prev_alloc = 0.5

        for t in range(test_start, test_end + 1):
            # Momentum allocation
            if use_triple:
                a_mom = strategy_fn_triple(slow_sig[t], med_sig[t], fast_sig[t],
                                           vol_sig[t], mom_params)
            else:
                a_mom = strategy_fn(slow_sig[t], fast_sig[t], vol_sig[t], mom_params)

            # ML allocation
            a_ml = a_mom  # fallback
            if models is not None:
                if model_type == 'mlp':
                    a_ml = ml_predict_mlp_bagged(models, X_all, t)
                elif model_type in ('binary_lgb',) or use_binary:
                    a_ml = ml_predict_binary_bagged(models, X_all, t)
                elif model_type in ('mixed_cat_lgb', 'stacking', 'stacking_logistic'):
                    # Average predictions from tagged models
                    x_t = np.nan_to_num(X_all[t:t+1].copy(), nan=0.0)
                    preds = []
                    for tag, m in models:
                        preds.append(m.predict(x_t)[0])
                    avg_pred = np.mean(preds)
                    sc = np.clip(avg_pred / 0.05, -1.0, 1.0)
                    a_ml = 0.5 + sc * 0.5 if sc > 0 else 0.5 + sc * 0.75
                else:
                    a_ml = ml_predict_bagged(models, X_all, t)

            # Combine ML + Momentum
            ml_w = ml_weight
            mom_w = 1.0 - ml_weight

            # Vol switch: swap weights if vol expanding
            if third_component == 'vol_switch':
                vol_now = vols[14][t] * np.sqrt(365)
                vol_60d = vols[30][t] * np.sqrt(365) if t > 30 else vol_now
                if vol_now > vol_60d * 1.3:
                    ml_w = max(ml_weight - 0.15, 0.2)
                    mom_w = 1.0 - ml_w
                elif vol_now < vol_60d * 0.7:
                    ml_w = min(ml_weight + 0.15, 0.8)
                    mom_w = 1.0 - ml_w

            raw_alloc = mom_w * a_mom + ml_w * a_ml

            # Add third component if present
            if third_component in ('sentiment', 'regime') and third_alloc_arr is not None:
                tw = third_weight
                raw_alloc = (1 - tw) * raw_alloc + tw * third_alloc_arr[t]
            elif third_component == 'meta' and models is not None:
                # Use prediction confidence as meta signal
                x_t = np.nan_to_num(X_all[t:t+1].copy(), nan=0.0)
                if model_type not in ('mlp', 'mixed_cat_lgb', 'stacking', 'stacking_logistic'):
                    preds = [m.predict(x_t)[0] for m in models]
                    confidence = 1.0 - np.std(preds) / (np.mean(np.abs(preds)) + 1e-10)
                    confidence = np.clip(confidence, 0.3, 1.0)
                    raw_alloc = raw_alloc * (0.7 + 0.3 * confidence)

            # Rebalance logic
            do_rebal = True
            if use_weekly:
                if day_of_week[t] != 4:
                    do_rebal = False
            elif rebal_days is not None:
                if day_of_week[t] not in rebal_days:
                    do_rebal = False
            # else: daily rebalance (always True)

            if not do_rebal:
                raw_alloc = prev_alloc

            full_allocs[t] = np.clip(raw_alloc, -0.25, 1.0)
            prev_alloc = full_allocs[t]

        test_ranges.append((test_start, test_end))
        s, b, a = backtest_allocations(daily_ret, full_allocs, test_start, test_end,
                                       cost=cost, rf_daily=rf_daily)
        all_strat.extend(s)
        all_btc.extend(b)
        all_alloc.extend(a)

        m_yr = metrics(np.array(s), np.array(b), np.array(a), rf_daily=rf_daily)
        if verbose and m_yr:
            P(f" -> {m_yr['total']*100:+.1f}% (BTC {m_yr['btc']*100:+.1f}%)")

    result = metrics(np.array(all_strat), np.array(all_btc), np.array(all_alloc),
                     rf_daily=rf_daily)
    return (result, np.array(all_strat), np.array(all_btc), np.array(all_alloc),
            full_allocs.copy(), test_ranges)


# ============================================================
# BOOTSTRAP CI
# ============================================================

def bootstrap_ci(daily_returns, n_bootstrap=1000, ci=0.95):
    nr = len(daily_returns)
    if nr < 30:
        return None

    rng = np.random.RandomState(42)
    total_returns, sortinos = [], []

    for _ in range(n_bootstrap):
        idx = rng.choice(nr, size=nr, replace=True)
        resampled = daily_returns[idx]
        total = np.prod(1 + resampled) - 1
        total_returns.append(total)

        ex = resampled - RF_DAILY
        ds = ex[ex < 0]
        sortinos.append(np.mean(ex) / (np.std(ds) + 1e-10) * np.sqrt(365) if len(ds) > 2 else 0.0)

    alpha = (1 - ci) / 2
    lo, hi = alpha * 100, (1 - alpha) * 100

    return {
        'return_mean': np.mean(total_returns),
        'return_lo': np.percentile(total_returns, lo),
        'return_hi': np.percentile(total_returns, hi),
        'sortino_mean': np.mean(sortinos),
        'sortino_lo': np.percentile(sortinos, lo),
        'sortino_hi': np.percentile(sortinos, hi),
        'excess_above_zero_pct': np.mean([r > 0 for r in total_returns]) * 100,
    }


# ============================================================
# THEMED FEATURE SET DEFINITIONS
# ============================================================

THEME_G1_BASELINE = DEFAULT_FEATURE_COLS  # 20 cols + 5 price-derived = 25

THEME_G2_VALUATION = [
    'mvrv_zscore', 'nvt_golden_cross', 'sth_sopr', 'nupl_capitulation',
    'sopr_below_1', 'puell_multiple', 'difficulty_ribbon', 'miner_capitulation',
    's2f_zscore', 'supply_on_exchanges_pct', 'realized_price', 'price_vs_realized',
    'stablecoin_supply_change_30d', 'hash_rate_pctchg_30d', 'price_percentile_2y',
    'ret_3d', 'ret_10d', 'ret_30d', 'ret_60d', 'vol_14d',
]

THEME_G3_MACRO = [
    'vix_percentile_1y', 'yield_curve_inverted', 'high_yield_spread',
    'fed_balance_sheet', 'm2_supply_pctchg_30d', 'btc_vix_corr_30d',
    'btc_gold_corr_30d', 'copper_return_30d', 'sp500_pctchg_90d',
    'dxy_pctchg_30d', 'fear_greed_zscore', 'extreme_fear', 'eth_btc_ratio',
    'ret_3d', 'ret_10d', 'ret_30d', 'ret_60d', 'vol_14d',
]

THEME_G4_DERIVATIVES = [
    'basis_zscore', 'basis_ma30', 'binance_funding_max', 'binance_funding_min',
    'funding_x_oi', 'taker_pressure', 'oi_change_30d', 'oi_change_7d',
    'buy_sell_ratio', 'net_buy_pressure', 'funding_rate', 'basis_ma7',
    'spot_taker_buy_ratio',
    'ret_3d', 'ret_10d', 'ret_30d', 'ret_60d', 'vol_14d',
]

THEME_G5_MEAN_REVERSION = [
    'hurst_dfa_30d', 'ou_theta_30d', 'half_life_30d', 'variance_ratio_30d',
    'adf_stat_30d', 'kpss_stat_30d', 'cusum_score', 'structural_break_score',
    'velocity', 'acceleration', 'linear_r2_30d', 'aroon_up_30d',
    'fractal_dimension_30d', 'mr_score_30d', 'hurst_60d',
    'ret_3d', 'ret_10d', 'ret_30d', 'ret_60d', 'vol_14d',
]

THEME_G7_ONCHAIN = [
    'mvrv_zscore', 'nvt_golden_cross', 'sopr_below_1', 'nupl_capitulation',
    'sth_sopr', 'supply_on_exchanges_pct', 'exchange_netflow_ma7',
    'hash_rate_pctchg_30d', 'mempool_congestion', 'active_addresses_ma7',
    'tx_growth_30d', 'miners_revenue_ratio', 'puell_multiple',
    'difficulty_ribbon', 'miner_capitulation',
    'stablecoin_supply_change_30d', 'stablecoin_btc_ratio',
    'ret_3d', 'ret_10d', 'ret_30d', 'ret_60d', 'vol_14d',
]

THEME_G8_INTERACTIONS = [
    'cusum_pos', 'miners_revenue_ratio', 'mr_score_30d', 'adx',
    'cusum_neg', 'exchange_netflow_ma7', 'structural_break_score',
    'macd_histogram', 'eth_btc_ratio', 'm2_yoy_growth',
    'volatility_7d', 'basis_ma7', 'nupl_ma30', 'hurst_60d',
    'funding_rate', 'bb_position', 'rsi_14d',
    'funding_x_oi', 'mvrv_x_nupl', 'sopr_x_nupl', 'vol_x_regime_duration',
    'hurst_x_halflife', 'rsi_x_bb', 'taker_pressure', 'fg_x_vix',
    'ret_3d', 'ret_10d', 'ret_30d', 'ret_60d', 'vol_14d',
]

# Cross-domain mixed themes
THEME_G9_MACRO_ONCHAIN = [
    # Macro
    'vix_percentile_1y', 'yield_curve_inverted', 'high_yield_spread',
    'm2_supply_pctchg_30d', 'sp500_pctchg_90d', 'dxy_pctchg_30d',
    'fear_greed_zscore', 'extreme_fear',
    # Onchain
    'mvrv_zscore', 'nvt_golden_cross', 'sopr_below_1', 'nupl_capitulation',
    'supply_on_exchanges_pct', 'exchange_netflow_ma7', 'miners_revenue_ratio',
    'stablecoin_supply_change_30d',
    # Price-derived
    'ret_3d', 'ret_10d', 'ret_30d', 'ret_60d', 'vol_14d',
]

THEME_G10_DERIV_VALUATION = [
    # Derivatives
    'basis_zscore', 'basis_ma30', 'binance_funding_max', 'funding_x_oi',
    'taker_pressure', 'oi_change_30d', 'buy_sell_ratio', 'net_buy_pressure',
    'funding_rate',
    # Valuation
    'mvrv_zscore', 'nvt_golden_cross', 'puell_multiple', 's2f_zscore',
    'realized_price', 'price_vs_realized',
    # Price-derived
    'ret_3d', 'ret_10d', 'ret_30d', 'ret_60d', 'vol_14d',
]

THEME_G11_OC_DERIV_MACRO = [
    # Onchain best
    'mvrv_zscore', 'sopr_below_1', 'nupl_capitulation', 'supply_on_exchanges_pct',
    'exchange_netflow_ma7', 'stablecoin_supply_change_30d',
    # Derivatives best
    'basis_zscore', 'funding_x_oi', 'taker_pressure', 'oi_change_30d',
    'buy_sell_ratio',
    # Macro best
    'vix_percentile_1y', 'fear_greed_zscore', 'sp500_pctchg_90d',
    'dxy_pctchg_30d', 'm2_supply_pctchg_30d',
    # Technical
    'rsi_14d', 'adx', 'bb_position', 'macd_histogram',
    # Price-derived
    'ret_3d', 'ret_10d', 'ret_30d', 'ret_60d', 'vol_14d',
]

THEME_G12_MEGA_ALL = [
    # Onchain
    'mvrv_zscore', 'nvt_golden_cross', 'sopr_below_1', 'nupl_capitulation',
    'supply_on_exchanges_pct', 'exchange_netflow_ma7', 'miners_revenue_ratio',
    'puell_multiple', 'stablecoin_supply_change_30d', 'stablecoin_btc_ratio',
    # Derivatives
    'basis_zscore', 'basis_ma30', 'funding_x_oi', 'taker_pressure',
    'oi_change_30d', 'buy_sell_ratio', 'funding_rate',
    # Macro
    'vix_percentile_1y', 'fear_greed_zscore', 'sp500_pctchg_90d',
    'dxy_pctchg_30d', 'm2_supply_pctchg_30d', 'eth_btc_ratio',
    # Valuation
    's2f_zscore', 'realized_price', 'price_vs_realized', 'price_percentile_2y',
    # Mean Reversion
    'hurst_dfa_30d', 'mr_score_30d', 'cusum_score', 'half_life_30d',
    # Technical
    'rsi_14d', 'adx', 'bb_position', 'macd_histogram',
    # Interactions (funding_x_oi already above)
    'mvrv_x_nupl', 'sopr_x_nupl', 'rsi_x_bb', 'fg_x_vix',
    # Price-derived
    'ret_3d', 'ret_10d', 'ret_30d', 'ret_60d', 'vol_14d',
]


def get_top50_features(df, returns, vols, n):
    """Get top 50 features by LGB importance on full training data."""
    import lightgbm as lgb

    # Use all numeric columns except targets/date/price
    exclude = {'date', 'price_usd', 'volume_usd', 'target_direction_1d',
               'target_direction_5d', 'target_return_1d', 'target_return_5d',
               'target_regime', 'target_down_5d', 'price_open', 'price_high',
               'price_low', 'has_futures_data_x', 'has_futures_data_y',
               'has_funding_data', 'day_of_week', 'is_month_end', 'is_q4',
               'price_usd_artemis', 'volume_usd_artemis'}
    num_cols = [c for c in df.columns if c not in exclude and df[c].dtype in ('float64', 'int64', 'float32')]

    X_tmp = df[num_cols].values.astype(float)
    X_tmp = np.nan_to_num(X_tmp, nan=0.0)

    prices = df['price_usd'].values
    target_tmp = np.zeros(n)
    for i in range(n - 5):
        target_tmp[i] = (prices[i + 5] - prices[i]) / prices[i]

    train_end = int(n * 0.7)
    train_mask = np.arange(60, train_end)
    X_tr = X_tmp[train_mask]
    y_tr = target_tmp[train_mask]

    params = {'objective': 'regression', 'metric': 'mae', 'num_leaves': 31,
              'learning_rate': 0.05, 'feature_fraction': 0.7, 'bagging_fraction': 0.8,
              'bagging_freq': 5, 'verbose': -1, 'n_jobs': 1, 'seed': 42}
    dtrain = lgb.Dataset(X_tr, label=y_tr)
    model = lgb.train(params, dtrain, num_boost_round=200)

    imp = model.feature_importance(importance_type='gain')
    sorted_idx = np.argsort(imp)[::-1][:50]
    top50_names = [num_cols[i] for i in sorted_idx]

    # Add price-derived if not present
    for pd_feat in ['ret_3d', 'ret_10d', 'ret_30d', 'ret_60d', 'vol_14d']:
        if pd_feat not in top50_names:
            top50_names.append(pd_feat)

    P(f"      Top-50 features (first 10): {top50_names[:10]}")
    return top50_names


# ============================================================
# FEATURE TRANSFORMS (Group H)
# ============================================================

def apply_rank_transform(X_all, window=252):
    """Rolling percentile rank [0,1] for all features."""
    n, d = X_all.shape
    X_ranked = np.zeros_like(X_all)
    for j in range(d):
        for i in range(n):
            start = max(0, i - window)
            window_data = X_all[start:i+1, j]
            if len(window_data) < 5:
                X_ranked[i, j] = 0.5
            else:
                X_ranked[i, j] = np.mean(window_data <= X_all[i, j])
    return X_ranked


def apply_log_winsorize(X_all, lower=0.01, upper=0.99):
    """Log-transform skewed features, clip at percentiles."""
    n, d = X_all.shape
    X_out = X_all.copy()
    for j in range(d):
        col = X_out[:, j]
        lo = np.nanpercentile(col, lower * 100)
        hi = np.nanpercentile(col, upper * 100)
        col = np.clip(col, lo, hi)
        # Log-transform if all positive and skewed
        if np.nanmin(col) > 0 and np.nanstd(col) > 0:
            skew = np.nanmean(((col - np.nanmean(col)) / (np.nanstd(col) + 1e-10))**3)
            if abs(skew) > 1.0:
                col = np.log1p(col)
        X_out[:, j] = col
    return X_out


def apply_pca_by_group(X_all, n_components_ratio=0.6):
    """Compress features using PCA to ~60% of original dims."""
    from sklearn.decomposition import PCA
    from sklearn.preprocessing import StandardScaler

    d = X_all.shape[1]
    n_components = max(3, int(d * n_components_ratio))

    X_clean = np.nan_to_num(X_all, nan=0.0)
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X_clean)

    pca = PCA(n_components=n_components, random_state=42)
    X_pca = pca.fit_transform(X_scaled)
    P(f"      PCA: {d} -> {n_components} features (explained var: {pca.explained_variance_ratio_.sum():.1%})")
    return X_pca


def apply_composites(X_all, feature_names, df, returns, vols, n):
    """Replace 5 weakest features with composite signals."""
    # Compute composites
    composites = {}

    # trend_quality: ADX * linear_r2_30d
    adx = df['adx'].values if 'adx' in df.columns else np.zeros(n)
    lr2 = df['linear_r2_30d'].values if 'linear_r2_30d' in df.columns else np.zeros(n)
    composites['trend_quality'] = adx * lr2 / 100.0

    # vol_regime: vol_14d / vol_30d (expansion/contraction)
    composites['vol_regime'] = vols[14] / (vols[30] + 1e-10)

    # momentum_breadth: sign(ret_3d) + sign(ret_10d) + sign(ret_30d) + sign(ret_60d)
    composites['momentum_breadth'] = (np.sign(returns[3]) + np.sign(returns[10]) +
                                       np.sign(returns[30]) + np.sign(returns[60])) / 4.0

    # onchain_health: mvrv_zscore + sopr_ma7 (normalized)
    mvrv = df['mvrv_zscore'].values if 'mvrv_zscore' in df.columns else np.zeros(n)
    sopr = df['sopr_ma7'].values if 'sopr_ma7' in df.columns else np.ones(n)
    composites['onchain_health'] = mvrv * 0.5 + (sopr - 1.0) * 10.0

    # market_stress: vix_percentile * (1 - fear_greed_zscore)
    vix_p = df['vix_percentile_1y'].values if 'vix_percentile_1y' in df.columns else np.full(n, 0.5)
    fg = df['fear_greed_zscore'].values if 'fear_greed_zscore' in df.columns else np.zeros(n)
    composites['market_stress'] = vix_p * np.clip(1.0 - fg, 0, 2)

    # Replace last 5 features with composites
    X_new = X_all.copy()
    new_names = list(feature_names)
    composite_names = list(composites.keys())
    n_replace = min(5, X_new.shape[1])
    for i in range(n_replace):
        idx = X_new.shape[1] - n_replace + i
        if i < len(composite_names):
            X_new[:, idx] = composites[composite_names[i]]
            new_names[idx] = composite_names[i]

    return X_new, new_names


# ============================================================
# GROUP RUNNERS
# ============================================================

def run_group_a(daily_ret, returns, vols, df, dates, n):
    """Group A: Rebalance x Bag Size Grid."""
    P(f"\n{'='*100}")
    P("GROUP A: Rebalance x Bag Size Grid")
    P("=" * 100)

    configs = [
        ('A1 Weekly Bag5', {'use_weekly': True, 'rebal_days': None, 'n_bags': 5}),
        ('A2 Daily Bag5', {'use_weekly': False, 'rebal_days': None, 'n_bags': 5}),
        ('A3 Daily Bag10', {'use_weekly': False, 'rebal_days': None, 'n_bags': 10}),
        ('A4 Daily Bag20', {'use_weekly': False, 'rebal_days': None, 'n_bags': 20}),
        ('A5 Weekly Bag10', {'use_weekly': True, 'rebal_days': None, 'n_bags': 10}),
        ('A6 Weekly Bag20', {'use_weekly': True, 'rebal_days': None, 'n_bags': 20}),
        ('A7 TueFri Bag5', {'use_weekly': False, 'rebal_days': [1, 4], 'n_bags': 5}),
        ('A8 Daily Bag30', {'use_weekly': False, 'rebal_days': None, 'n_bags': 30}),
    ]

    results = {}
    for label, cfg in configs:
        P(f"\n  {label}:")
        r, s, b, a, fa, tr = walk_forward_hybrid_v5(
            daily_ret, returns, vols, df, dates, n,
            use_weekly=cfg['use_weekly'], rebal_days=cfg.get('rebal_days'),
            n_bags=cfg['n_bags'], label=label)
        results[label] = (r, s, fa, tr)
        if r:
            P(f"    >> {r['total']*100:+.1f}% | Sortino {r['sortino']:.2f} | MaxDD {r['max_dd']*100:.1f}%")

    return results


def run_group_b(daily_ret, returns, vols, df, dates, n):
    """Group B: ML/Momentum Weight Grid."""
    P(f"\n{'='*100}")
    P("GROUP B: ML/Momentum Weight Grid")
    P("=" * 100)

    weights = [
        ('B1 ML30/Mom70', 0.3),
        ('B2 ML40/Mom60', 0.4),
        ('B3 ML50/Mom50', 0.5),
        ('B4 ML60/Mom40', 0.6),
        ('B5 ML70/Mom30', 0.7),
        ('B6 ML80/Mom20', 0.8),
        ('B7 ML100/Mom0', 1.0),
    ]

    results = {}
    for label, ml_w in weights:
        P(f"\n  {label}:")
        r, s, b, a, fa, tr = walk_forward_hybrid_v5(
            daily_ret, returns, vols, df, dates, n,
            use_weekly=True, n_bags=5, ml_weight=ml_w, label=label)
        results[label] = (r, s, fa, tr)
        if r:
            P(f"    >> {r['total']*100:+.1f}% | Sortino {r['sortino']:.2f} | MaxDD {r['max_dd']*100:.1f}%")

    return results


def run_group_c(daily_ret, returns, vols, df, dates, n):
    """Group C: ML Model Zoo."""
    P(f"\n{'='*100}")
    P("GROUP C: ML Model Zoo")
    P("=" * 100)

    models = [
        ('C1 LGB Bag5', 'lgb'),
        ('C2 CatBoost Bag5', 'cat'),
        ('C3 CatDeep Bag5', 'cat_deep'),
        ('C4 RF Bag5', 'rf'),
        ('C5 ExtraTrees Bag5', 'et'),
        ('C6 MLP Bag5', 'mlp'),
        ('C7 Mixed Cat+LGB', 'mixed_cat_lgb'),
        ('C8 Binary LGB', 'binary_lgb'),
    ]

    results = {}
    for label, mt in models:
        if mt in ('cat', 'cat_deep', 'mixed_cat_lgb') and not HAS_CATBOOST:
            P(f"\n  {label}: SKIPPED (catboost not installed)")
            continue
        P(f"\n  {label}:")
        r, s, b, a, fa, tr = walk_forward_hybrid_v5(
            daily_ret, returns, vols, df, dates, n,
            use_weekly=True, n_bags=5, model_type=mt, label=label)
        results[label] = (r, s, fa, tr)
        if r:
            P(f"    >> {r['total']*100:+.1f}% | Sortino {r['sortino']:.2f} | MaxDD {r['max_dd']*100:.1f}%")

    return results


def run_group_d(daily_ret, returns, vols, df, dates, n):
    """Group D: Momentum Signal Variations."""
    P(f"\n{'='*100}")
    P("GROUP D: Momentum Signal Variations")
    P("=" * 100)

    configs = [
        ('D1 ret60/ret3/vol14', 60, 3, 14),
        ('D2 ret30/ret7/vol14', 30, 7, 14),
        ('D3 ret30/ret3/vol14', 30, 3, 14),
        ('D4 ret45/ret5/vol14', 45, 5, 14),
        ('D5 ret60/ret7/vol7', 60, 7, 7),
        ('D6 ret60/ret3/vol7', 60, 3, 7),
    ]

    results = {}
    for label, sk, fk, vk in configs:
        P(f"\n  {label}:")
        r, s, b, a, fa, tr = walk_forward_hybrid_v5(
            daily_ret, returns, vols, df, dates, n,
            use_weekly=True, n_bags=5,
            slow_key=sk, fast_key=fk, vol_key=vk, label=label)
        results[label] = (r, s, fa, tr)
        if r:
            P(f"    >> {r['total']*100:+.1f}% | Sortino {r['sortino']:.2f} | MaxDD {r['max_dd']*100:.1f}%")

    return results


def run_group_e(daily_ret, returns, vols, df, dates, n):
    """Group E: Triple Signal Momentum."""
    P(f"\n{'='*100}")
    P("GROUP E: Triple Signal Momentum")
    P("=" * 100)

    configs = [
        ('E1 60/30/3/vol14', 60, 30, 3, 14),
        ('E2 60/14/3/vol14', 60, 14, 3, 14),
        ('E3 45/14/5/vol14', 45, 14, 5, 14),
    ]

    results = {}
    for label, sk, mk, fk, vk in configs:
        P(f"\n  {label}:")
        r, s, b, a, fa, tr = walk_forward_hybrid_v5(
            daily_ret, returns, vols, df, dates, n,
            use_weekly=True, n_bags=5,
            slow_key=sk, fast_key=fk, vol_key=vk,
            use_triple=True, med_key=mk, label=label)
        results[label] = (r, s, fa, tr)
        if r:
            P(f"    >> {r['total']*100:+.1f}% | Sortino {r['sortino']:.2f} | MaxDD {r['max_dd']*100:.1f}%")

    return results


def run_group_f(daily_ret, returns, vols, df, dates, n):
    """Group F: Momentum Optimization Variants."""
    P(f"\n{'='*100}")
    P("GROUP F: Momentum Optimization Variants")
    P("=" * 100)

    configs = [
        ('F1 5000 trials', 5000, 'default'),
        ('F2 Calmar obj', 2000, 'calmar'),
        ('F3 Turnover penalty', 2000, 'turnover'),
    ]

    results = {}
    for label, nt, obj in configs:
        P(f"\n  {label}:")
        r, s, b, a, fa, tr = walk_forward_hybrid_v5(
            daily_ret, returns, vols, df, dates, n,
            use_weekly=True, n_bags=5,
            n_trials=nt, opt_objective=obj, label=label)
        results[label] = (r, s, fa, tr)
        if r:
            P(f"    >> {r['total']*100:+.1f}% | Sortino {r['sortino']:.2f} | MaxDD {r['max_dd']*100:.1f}%")

    return results


def run_group_g(daily_ret, returns, vols, df, dates, n):
    """Group G: Themed Feature Sets."""
    P(f"\n{'='*100}")
    P("GROUP G: Themed Feature Sets")
    P("=" * 100)

    top50 = get_top50_features(df, returns, vols, n)

    themes = [
        ('G1 Baseline 25', None),
        ('G2 Valuation', THEME_G2_VALUATION),
        ('G3 Macro', THEME_G3_MACRO),
        ('G4 Derivatives', THEME_G4_DERIVATIVES),
        ('G5 MeanReversion', THEME_G5_MEAN_REVERSION),
        ('G6 Kitchen Sink 50', top50),
        ('G7 Onchain Heavy', THEME_G7_ONCHAIN),
        ('G8 Interactions', THEME_G8_INTERACTIONS),
        ('G9 Macro+Onchain', THEME_G9_MACRO_ONCHAIN),
        ('G10 Deriv+Valuation', THEME_G10_DERIV_VALUATION),
        ('G11 OC+Deriv+Macro', THEME_G11_OC_DERIV_MACRO),
        ('G12 Mega All Domains', THEME_G12_MEGA_ALL),
    ]

    results = {}
    for label, fl in themes:
        P(f"\n  {label}:")
        r, s, b, a, fa, tr = walk_forward_hybrid_v5(
            daily_ret, returns, vols, df, dates, n,
            use_weekly=True, n_bags=5,
            feature_list=fl, label=label)
        results[label] = (r, s, fa, tr)
        if r:
            P(f"    >> {r['total']*100:+.1f}% | Sortino {r['sortino']:.2f} | MaxDD {r['max_dd']*100:.1f}%")

    return results


def run_group_h(daily_ret, returns, vols, df, dates, n):
    """Group H: Feature Engineering Transforms."""
    P(f"\n{'='*100}")
    P("GROUP H: Feature Engineering Transforms")
    P("=" * 100)

    X_base, base_names = build_ml_features(df, returns, vols, n)

    transforms = {
        'H1 Composites': 'composites',
        'H2 Rank Transform': 'rank',
        'H3 Log+Winsorize': 'log_winsorize',
        'H4 PCA': 'pca',
    }

    results = {}
    for label, tf in transforms.items():
        P(f"\n  {label}:")
        if tf == 'composites':
            X_t, _ = apply_composites(X_base, base_names, df, returns, vols, n)
        elif tf == 'rank':
            P("      Computing rank transform (slow)...")
            X_t = apply_rank_transform(X_base, window=252)
        elif tf == 'log_winsorize':
            X_t = apply_log_winsorize(X_base)
        elif tf == 'pca':
            X_t = apply_pca_by_group(X_base)
        else:
            X_t = X_base

        r, s, b, a, fa, tr = walk_forward_hybrid_v5(
            daily_ret, returns, vols, df, dates, n,
            use_weekly=True, n_bags=5,
            X_override=X_t, label=label)
        results[label] = (r, s, fa, tr)
        if r:
            P(f"    >> {r['total']*100:+.1f}% | Sortino {r['sortino']:.2f} | MaxDD {r['max_dd']*100:.1f}%")

    return results


def run_group_i(daily_ret, returns, vols, df, dates, n):
    """Group I: Third Component."""
    P(f"\n{'='*100}")
    P("GROUP I: Third Component")
    P("=" * 100)

    configs = [
        ('I1 Meta Confidence', 'meta', 0.10),
        ('I2 Sentiment', 'sentiment', 0.10),
        ('I3 Regime Classifier', 'regime', 0.20),
        ('I4 Vol Switch', 'vol_switch', 0.0),
    ]

    results = {}
    for label, tc, tw in configs:
        P(f"\n  {label}:")
        # Adjust ML/Mom weights for third component
        ml_w = 0.45 if tc in ('meta', 'sentiment', 'regime') else 0.50
        r, s, b, a, fa, tr = walk_forward_hybrid_v5(
            daily_ret, returns, vols, df, dates, n,
            use_weekly=True, n_bags=5,
            ml_weight=ml_w,
            third_component=tc, third_weight=tw, label=label)
        results[label] = (r, s, fa, tr)
        if r:
            P(f"    >> {r['total']*100:+.1f}% | Sortino {r['sortino']:.2f} | MaxDD {r['max_dd']*100:.1f}%")

    return results


def run_group_j(daily_ret, returns, vols, df, dates, n):
    """Group J: Stacking & Advanced Ensembles."""
    P(f"\n{'='*100}")
    P("GROUP J: Stacking & Advanced Ensembles")
    P("=" * 100)

    configs = [
        ('J1 LGB+Cat+RF Stack', 'stacking'),
        ('J2 LGB+Cat Logistic', 'stacking_logistic'),
        ('J3 LGB+Cat+RF Daily', 'stacking'),  # Same models but daily rebalance
    ]

    results = {}
    for label, mt in configs:
        if mt in ('stacking', 'stacking_logistic') and not HAS_CATBOOST:
            P(f"\n  {label}: SKIPPED (catboost not installed)")
            continue
        P(f"\n  {label}:")
        use_wk = 'Daily' not in label  # J3 runs daily
        r, s, b, a, fa, tr = walk_forward_hybrid_v5(
            daily_ret, returns, vols, df, dates, n,
            use_weekly=use_wk, n_bags=5, model_type=mt, label=label)
        results[label] = (r, s, fa, tr)
        if r:
            P(f"    >> {r['total']*100:+.1f}% | Sortino {r['sortino']:.2f} | MaxDD {r['max_dd']*100:.1f}%")

    return results


def run_group_k(daily_ret, returns, vols, df, dates, n):
    """Group K: Prediction Approach."""
    P(f"\n{'='*100}")
    P("GROUP K: Prediction Approach")
    P("=" * 100)

    configs = [
        ('K1 ret5d regression', 5, False),
        ('K2 sign(ret5d) binary', 5, True),
        ('K3 ret3d regression', 3, False),
    ]

    results = {}
    for label, horizon, binary in configs:
        P(f"\n  {label}:")
        r, s, b, a, fa, tr = walk_forward_hybrid_v5(
            daily_ret, returns, vols, df, dates, n,
            use_weekly=True, n_bags=5,
            target_horizon=horizon, use_binary=binary, label=label)
        results[label] = (r, s, fa, tr)
        if r:
            P(f"    >> {r['total']*100:+.1f}% | Sortino {r['sortino']:.2f} | MaxDD {r['max_dd']*100:.1f}%")

    return results


def run_group_l(all_group_results, daily_ret, returns, vols, df, dates, n, baseline_result):
    """Group L: Combined Best."""
    P(f"\n{'='*100}")
    P("GROUP L: Combined Best")
    P("=" * 100)

    baseline_total = baseline_result['total'] if baseline_result else 0

    # Collect all winners
    winners = []
    for group_name, group_res in all_group_results.items():
        for label, (r, s, fa, tr) in group_res.items():
            if r is not None and r['total'] > baseline_total:
                winners.append((label, r, fa, tr))

    P(f"  Winners beating baseline ({baseline_total*100:+.1f}%): {len(winners)}")
    for name, r, _, _ in sorted(winners, key=lambda x: x[1]['total'], reverse=True)[:10]:
        P(f"    {name}: {r['total']*100:+.1f}%")

    results = {}

    # L1: Average ALL winners
    if len(winners) >= 2:
        P(f"\n  L1: Averaging {len(winners)} winners...")
        avg_allocs = np.mean([fa for _, _, fa, _ in winners], axis=0)
        test_ranges = winners[0][3]
        all_s, all_b, all_a = [], [], []
        for (start, end) in test_ranges:
            s, b, a = backtest_allocations(daily_ret, avg_allocs, start, end)
            all_s.extend(s); all_b.extend(b); all_a.extend(a)
        r_l1 = metrics(np.array(all_s), np.array(all_b), np.array(all_a))
        results['L1 All Winners Avg'] = (r_l1, np.array(all_s), avg_allocs, test_ranges)
        if r_l1:
            P(f"    >> {r_l1['total']*100:+.1f}% | Sortino {r_l1['sortino']:.2f} | MaxDD {r_l1['max_dd']*100:.1f}%")

    # L2: Average Top-3 only
    top3 = sorted(winners, key=lambda x: x[1]['total'], reverse=True)[:3]
    if len(top3) >= 2:
        P(f"\n  L2: Averaging top-3 winners...")
        avg_allocs = np.mean([fa for _, _, fa, _ in top3], axis=0)
        test_ranges = top3[0][3]
        all_s, all_b, all_a = [], [], []
        for (start, end) in test_ranges:
            s, b, a = backtest_allocations(daily_ret, avg_allocs, start, end)
            all_s.extend(s); all_b.extend(b); all_a.extend(a)
        r_l2 = metrics(np.array(all_s), np.array(all_b), np.array(all_a))
        results['L2 Top3 Avg'] = (r_l2, np.array(all_s), avg_allocs, test_ranges)
        if r_l2:
            P(f"    >> {r_l2['total']*100:+.1f}% | Sortino {r_l2['sortino']:.2f} | MaxDD {r_l2['max_dd']*100:.1f}%")

    # L3: Best config combo — find best from EVERY group
    P(f"\n  L3: Best config combo (all groups)...")
    best_a = _find_best_in_group(all_group_results.get('A', {}))
    best_b = _find_best_in_group(all_group_results.get('B', {}))
    best_c = _find_best_in_group(all_group_results.get('C', {}))
    best_d = _find_best_in_group(all_group_results.get('D', {}))
    best_e = _find_best_in_group(all_group_results.get('E', {}))
    best_f = _find_best_in_group(all_group_results.get('F', {}))
    best_g = _find_best_in_group(all_group_results.get('G', {}))
    best_i = _find_best_in_group(all_group_results.get('I', {}))
    best_k = _find_best_in_group(all_group_results.get('K', {}))

    # Parse best configs from each group
    l3_use_weekly = True
    l3_rebal_days = None
    l3_n_bags = 5
    l3_ml_weight = 0.5
    l3_model_type = 'lgb'
    l3_feature_list = None
    l3_slow_key = 60
    l3_fast_key = 3
    l3_vol_key = 14
    l3_use_triple = False
    l3_med_key = 30
    l3_n_trials = 2000
    l3_opt_objective = 'default'
    l3_third_component = None
    l3_third_weight = 0.10
    l3_target_horizon = 5
    l3_use_binary = False

    # Group A: Rebalance + Bag size
    if best_a:
        name = best_a[0]
        if 'Daily' in name:
            l3_use_weekly = False
        if 'TueFri' in name:
            l3_use_weekly = False
            l3_rebal_days = [1, 4]
        for b in [5, 10, 20, 30]:
            if f'Bag{b}' in name:
                l3_n_bags = b

    # Group B: ML/Mom weight
    if best_b:
        name = best_b[0]
        for w in [30, 40, 50, 60, 70, 80, 100]:
            if f'ML{w}' in name:
                l3_ml_weight = w / 100.0

    # Group C: Model type
    if best_c:
        name = best_c[0]
        model_map = {'LGB': 'lgb', 'CatBoost': 'cat', 'CatDeep': 'cat_deep',
                     'RF': 'rf', 'ExtraTrees': 'et', 'MLP': 'mlp',
                     'Mixed': 'mixed_cat_lgb', 'Binary': 'binary_lgb'}
        for k, v in model_map.items():
            if k in name:
                l3_model_type = v
                break

    # Group D: Momentum signals (only if D beats baseline AND triple E doesn't beat D)
    best_d_total = best_d[1]['total'] if best_d else 0
    best_e_total = best_e[1]['total'] if best_e else 0
    if best_e and best_e_total > best_d_total:
        # Triple momentum won
        name = best_e[0]
        l3_use_triple = True
        sig_map = {
            'E1': (60, 30, 3, 14), 'E2': (60, 14, 3, 14), 'E3': (45, 14, 5, 14),
        }
        for prefix, (sk, mk, fk, vk) in sig_map.items():
            if prefix in name:
                l3_slow_key, l3_med_key, l3_fast_key, l3_vol_key = sk, mk, fk, vk
                break
    elif best_d and best_d_total > baseline_total:
        name = best_d[0]
        sig_map = {
            'D1': (60, 3, 14), 'D2': (30, 7, 14), 'D3': (30, 3, 14),
            'D4': (45, 5, 14), 'D5': (60, 7, 7), 'D6': (60, 3, 7),
        }
        for prefix, (sk, fk, vk) in sig_map.items():
            if prefix in name:
                l3_slow_key, l3_fast_key, l3_vol_key = sk, fk, vk
                break

    # Group F: Momentum optimization
    if best_f and best_f[1]['total'] > baseline_total:
        name = best_f[0]
        if '5000' in name:
            l3_n_trials = 5000
        if 'Calmar' in name:
            l3_opt_objective = 'calmar'
        if 'Turnover' in name:
            l3_opt_objective = 'turnover'

    # Group G: Feature set (with ALL theme mappings including cross-domain)
    if best_g:
        name = best_g[0]
        theme_map = {
            'Baseline': None,
            'Valuation': THEME_G2_VALUATION,
            'G3 Macro': THEME_G3_MACRO,
            'Derivatives': THEME_G4_DERIVATIVES,
            'MeanReversion': THEME_G5_MEAN_REVERSION,
            'Kitchen': None,  # Dynamic, recomputed below
            'G7 Onchain': THEME_G7_ONCHAIN,
            'Interactions': THEME_G8_INTERACTIONS,
            'Macro+Onchain': THEME_G9_MACRO_ONCHAIN,
            'Deriv+Valuation': THEME_G10_DERIV_VALUATION,
            'OC+Deriv+Macro': THEME_G11_OC_DERIV_MACRO,
            'Mega': THEME_G12_MEGA_ALL,
        }
        for k, v in theme_map.items():
            if k in name:
                if k == 'Kitchen':
                    # Recompute top50 for L3
                    l3_feature_list = get_top50_features(df, returns, vols, n)
                else:
                    l3_feature_list = v
                break

    # Group I: Third component
    if best_i and best_i[1]['total'] > baseline_total:
        name = best_i[0]
        if 'Meta' in name:
            l3_third_component = 'meta'
        elif 'Sentiment' in name:
            l3_third_component = 'sentiment'
        elif 'Regime' in name:
            l3_third_component = 'regime'
            l3_third_weight = 0.20
        elif 'Vol Switch' in name:
            l3_third_component = 'vol_switch'
        # Adjust ML weight for third component
        if l3_third_component in ('meta', 'sentiment', 'regime'):
            l3_ml_weight = min(l3_ml_weight, 0.45)

    # Group K: Prediction approach
    if best_k and best_k[1]['total'] > baseline_total:
        name = best_k[0]
        if 'binary' in name.lower():
            l3_use_binary = True
        if 'ret3d' in name.lower():
            l3_target_horizon = 3

    P(f"    L3 config: weekly={l3_use_weekly}, bags={l3_n_bags}, ml_w={l3_ml_weight}, "
      f"model={l3_model_type}, triple={l3_use_triple}, "
      f"slow/fast/vol={l3_slow_key}/{l3_fast_key}/{l3_vol_key}, "
      f"features={'custom' if l3_feature_list else 'default'}, "
      f"third={l3_third_component}, trials={l3_n_trials}, obj={l3_opt_objective}, "
      f"horizon={l3_target_horizon}, binary={l3_use_binary}")

    r_l3, s_l3, b_l3, a_l3, fa_l3, tr_l3 = walk_forward_hybrid_v5(
        daily_ret, returns, vols, df, dates, n,
        use_weekly=l3_use_weekly, rebal_days=l3_rebal_days,
        n_bags=l3_n_bags, ml_weight=l3_ml_weight,
        model_type=l3_model_type, feature_list=l3_feature_list,
        slow_key=l3_slow_key, fast_key=l3_fast_key, vol_key=l3_vol_key,
        use_triple=l3_use_triple, med_key=l3_med_key,
        n_trials=l3_n_trials, opt_objective=l3_opt_objective,
        third_component=l3_third_component, third_weight=l3_third_weight,
        target_horizon=l3_target_horizon, use_binary=l3_use_binary,
        label="L3 Best Config")
    results['L3 Best Config'] = (r_l3, s_l3, fa_l3, tr_l3)
    if r_l3:
        P(f"    >> {r_l3['total']*100:+.1f}% | Sortino {r_l3['sortino']:.2f} | MaxDD {r_l3['max_dd']*100:.1f}%")

    return results


def _find_best_in_group(group_results):
    if not group_results:
        return None
    valid = [(k, r) for k, (r, _, _, _) in group_results.items() if r is not None]
    if not valid:
        return None
    return max(valid, key=lambda x: x[1]['total'])


# ============================================================
# CHARTS
# ============================================================

def generate_charts(all_flat_results, equity_curves, bootstrap_results,
                    group_a_results, group_g_results, chart_dir):
    chart_dir.mkdir(parents=True, exist_ok=True)

    # Chart 1: Bar comparison ALL variants
    P("  Generating comparison chart...")
    fig, axes = plt.subplots(2, 1, figsize=(30, 18))

    names, ret_vals, sortino_vals, maxdd_vals, colors = [], [], [], [], []
    cmap = plt.cm.tab20
    for i, (name, r) in enumerate(all_flat_results.items()):
        if r is None:
            continue
        names.append(name)
        ret_vals.append(r['total'] * 100)
        sortino_vals.append(r['sortino'])
        maxdd_vals.append(r['max_dd'] * 100)
        if name == 'BTC B&H':
            colors.append('#F7931A')
        elif 'A1' in name:
            colors.append('#4A90D9')
        elif name.startswith('L'):
            colors.append('#E74C3C')
        else:
            colors.append(cmap(i / max(len(all_flat_results), 1)))

    x = np.arange(len(names))
    ax = axes[0]
    bars = ax.bar(x, ret_vals, color=colors, alpha=0.85, edgecolor='black', linewidth=0.3)
    for v, bar in zip(ret_vals, bars):
        ax.text(bar.get_x() + bar.get_width()/2, v + (3 if v >= 0 else -8),
                f'{v:+.0f}%', ha='center', fontsize=5, fontweight='bold', rotation=90)
    ax.set_xticks(x)
    ax.set_xticklabels(names, fontsize=4, rotation=60, ha='right')
    ax.axhline(y=0, color='black', lw=0.5)
    ax.set_title('Pipeline V5: OOS Returns (Walk-Forward 2022-2026)', fontsize=14, fontweight='bold')
    ax.set_ylabel('Total Return %')
    ax.grid(True, alpha=0.3, axis='y')

    ax = axes[1]
    width = 0.35
    ax.bar(x - width/2, sortino_vals, width, color=colors, alpha=0.7,
           edgecolor='black', linewidth=0.3, label='Sortino')
    ax.bar(x + width/2, maxdd_vals, width, color=colors, alpha=0.4,
           edgecolor='black', linewidth=0.3, label='Max DD %')
    ax.set_xticks(x)
    ax.set_xticklabels(names, fontsize=4, rotation=60, ha='right')
    ax.axhline(y=0, color='black', lw=0.5)
    ax.set_title('Sortino & Max Drawdown', fontsize=14, fontweight='bold')
    ax.legend(fontsize=10)
    ax.grid(True, alpha=0.3, axis='y')

    plt.tight_layout()
    plt.savefig(chart_dir / 'pipeline_v5_comparison.png', dpi=150, bbox_inches='tight')
    plt.close()
    P(f"    Saved: pipeline_v5_comparison.png")

    # Chart 2: Equity curves (top 10 + baseline + BTC)
    P("  Generating equity curves...")
    sorted_by_ret = sorted([(n, r) for n, r in all_flat_results.items() if r is not None],
                           key=lambda x: x[1]['total'], reverse=True)
    top_names = [n for n, _ in sorted_by_ret[:10]]
    for special in ['BTC B&H', 'A1 Weekly Bag5']:
        if special not in top_names:
            top_names.append(special)

    fig, axes = plt.subplots(2, 1, figsize=(18, 12), gridspec_kw={'height_ratios': [3, 1]})
    ax = axes[0]
    for name, strat_rets in equity_curves.items():
        if len(strat_rets) == 0:
            continue
        cum = np.cumprod(1 + strat_rets)
        is_key = name in top_names
        ax.plot(cum, label=f"{name} ({(cum[-1]-1)*100:+.0f}%)",
                linewidth=2.0 if is_key else 0.5,
                alpha=1.0 if is_key else 0.25,
                linestyle='-' if is_key else '--')
    ax.set_title('V5 Equity Curves (Walk-Forward OOS 2022-2026)', fontsize=14, fontweight='bold')
    ax.set_ylabel('Cumulative Value')
    ax.legend(fontsize=5, loc='upper left', ncol=3)
    ax.grid(True, alpha=0.3)
    ax.set_yscale('log')

    ax = axes[1]
    for name in ['A1 Weekly Bag5', 'BTC B&H']:
        if name in equity_curves and len(equity_curves[name]) > 0:
            sr = equity_curves[name]
            cum = np.cumprod(1 + sr)
            pk = np.maximum.accumulate(cum)
            dd = (cum - pk) / pk * 100
            ax.fill_between(range(len(dd)), dd, 0, alpha=0.3, label=name)
    ax.set_title('Drawdown (%)', fontsize=12, fontweight='bold')
    ax.legend(fontsize=9)
    ax.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig(chart_dir / 'pipeline_v5_equity.png', dpi=150, bbox_inches='tight')
    plt.close()
    P(f"    Saved: pipeline_v5_equity.png")

    # Chart 3: Bootstrap CI
    if bootstrap_results:
        P("  Generating bootstrap chart...")
        fig, ax = plt.subplots(1, 1, figsize=(14, 6))
        bs_names = list(bootstrap_results.keys())
        bs_means = [bootstrap_results[n]['return_mean'] * 100 for n in bs_names]
        bs_lo = [bootstrap_results[n]['return_lo'] * 100 for n in bs_names]
        bs_hi = [bootstrap_results[n]['return_hi'] * 100 for n in bs_names]

        x = np.arange(len(bs_names))
        ax.bar(x, bs_means, color='steelblue', alpha=0.7)
        ax.errorbar(x, bs_means,
                    yerr=[np.array(bs_means) - np.array(bs_lo),
                          np.array(bs_hi) - np.array(bs_means)],
                    fmt='none', color='black', capsize=5, linewidth=2)
        for i, (m, lo, hi) in enumerate(zip(bs_means, bs_lo, bs_hi)):
            ax.text(i, hi + 5, f'{m:.0f}%\n[{lo:.0f},{hi:.0f}]',
                    ha='center', fontsize=7, fontweight='bold')
        ax.set_xticks(x)
        ax.set_xticklabels(bs_names, fontsize=6, rotation=20, ha='right')
        ax.axhline(y=0, color='red', lw=1, ls='--')
        ax.set_title('V5 Bootstrap 95% CI', fontsize=13, fontweight='bold')
        ax.set_ylabel('Total Return %')
        ax.grid(True, alpha=0.3, axis='y')
        plt.tight_layout()
        plt.savefig(chart_dir / 'pipeline_v5_bootstrap.png', dpi=150, bbox_inches='tight')
        plt.close()
        P(f"    Saved: pipeline_v5_bootstrap.png")

    # Chart 4: Heatmap rebal x bags (Group A)
    if group_a_results:
        P("  Generating rebal x bags heatmap...")
        rebal_labels = ['Daily', 'TueFri', 'Weekly']
        bag_labels = ['5', '10', '20', '30']
        grid = np.full((len(rebal_labels), len(bag_labels)), np.nan)

        mapping = {
            ('Daily', '5'): 'A2 Daily Bag5', ('Daily', '10'): 'A3 Daily Bag10',
            ('Daily', '20'): 'A4 Daily Bag20', ('Daily', '30'): 'A8 Daily Bag30',
            ('Weekly', '5'): 'A1 Weekly Bag5', ('Weekly', '10'): 'A5 Weekly Bag10',
            ('Weekly', '20'): 'A6 Weekly Bag20', ('TueFri', '5'): 'A7 TueFri Bag5',
        }

        for (rl, bl), key in mapping.items():
            ri = rebal_labels.index(rl)
            bi = bag_labels.index(bl)
            if key in group_a_results:
                r, _, _, _ = group_a_results[key]
                if r:
                    grid[ri, bi] = r['total'] * 100

        fig, ax = plt.subplots(1, 1, figsize=(8, 5))
        im = ax.imshow(grid, cmap='RdYlGn', aspect='auto')
        ax.set_xticks(range(len(bag_labels)))
        ax.set_xticklabels(bag_labels)
        ax.set_yticks(range(len(rebal_labels)))
        ax.set_yticklabels(rebal_labels)
        ax.set_xlabel('Bag Size')
        ax.set_ylabel('Rebalance Frequency')
        ax.set_title('V5 Heatmap: Rebalance x Bag Size (Return %)', fontsize=13, fontweight='bold')
        for i in range(len(rebal_labels)):
            for j in range(len(bag_labels)):
                if not np.isnan(grid[i, j]):
                    ax.text(j, i, f'{grid[i, j]:+.0f}%', ha='center', va='center',
                            fontsize=11, fontweight='bold')
        plt.colorbar(im, ax=ax, label='Return %')
        plt.tight_layout()
        plt.savefig(chart_dir / 'pipeline_v5_heatmap_rebal_bags.png', dpi=150, bbox_inches='tight')
        plt.close()
        P(f"    Saved: pipeline_v5_heatmap_rebal_bags.png")

    # Chart 5: Heatmap feature sets (Group G)
    if group_g_results:
        P("  Generating feature set heatmap...")
        theme_names = [k for k in group_g_results.keys()]
        metrics_names = ['Return %', 'Sortino', 'MaxDD %']
        grid = np.full((len(theme_names), 3), np.nan)
        for i, key in enumerate(theme_names):
            r, _, _, _ = group_g_results[key]
            if r:
                grid[i, 0] = r['total'] * 100
                grid[i, 1] = r['sortino']
                grid[i, 2] = r['max_dd'] * 100

        fig, ax = plt.subplots(1, 1, figsize=(8, 6))
        im = ax.imshow(grid[:, 0:1], cmap='RdYlGn', aspect='auto')
        ax.set_xticks([0])
        ax.set_xticklabels(['Return %'])
        ax.set_yticks(range(len(theme_names)))
        ax.set_yticklabels(theme_names, fontsize=8)
        ax.set_title('V5 Feature Sets: Return %', fontsize=13, fontweight='bold')
        for i in range(len(theme_names)):
            if not np.isnan(grid[i, 0]):
                txt = f'{grid[i,0]:+.0f}% | S:{grid[i,1]:.2f} | DD:{grid[i,2]:.0f}%'
                ax.text(0, i, txt, ha='center', va='center', fontsize=8, fontweight='bold')
        plt.colorbar(im, ax=ax, label='Return %')
        plt.tight_layout()
        plt.savefig(chart_dir / 'pipeline_v5_heatmap_features.png', dpi=150, bbox_inches='tight')
        plt.close()
        P(f"    Saved: pipeline_v5_heatmap_features.png")


# ============================================================
# MAIN
# ============================================================

def main():
    P("=" * 100)
    P("PIPELINE V5 NEW APPROACHES - Comprehensive Exploration")
    P("=" * 100)
    P(f"""
    V2 Best Combo (Bag5+Weekly) = +221% OOS (2022-2026).
    V5 tests 13 experiment groups (~59 variants):
      A: Rebalance x Bag Size Grid (8)   B: ML/Mom Weight Grid (7)
      C: ML Model Zoo (8)                D: Momentum Signals (6)
      E: Triple Signal Momentum (3)      F: Momentum Optim (3)
      G: Themed Feature Sets (12)        H: Feature Transforms (4)
         (incl. cross-domain mixes)
      I: Third Component (4)             J: Stacking Ensembles (3)
      K: Prediction Approach (3)         L: Combined Best (3, full combo)

    CatBoost available: {HAS_CATBOOST}
    """)

    P("Loading data...")
    prices, daily_ret, returns, vols, df = load_data()
    dates = df['date'].values
    n = len(prices)
    P(f"  {n} days | {len(df.columns)} columns | {dates[0]} to {dates[-1]}")

    all_flat_results = {}
    equity_curves = {}
    all_group_results = {}

    # BTC Buy & Hold
    yb = get_year_boundaries(dates, n)
    bh_s, bh_b, bh_a = [], [], []
    for yr in range(2022, 2027):
        if yr not in yb:
            continue
        allocs_bh = np.full(n, 1.0)
        s, b, a = backtest_allocations(daily_ret, allocs_bh, yb[yr]['start'], yb[yr]['end'])
        bh_s.extend(s); bh_b.extend(b); bh_a.extend(a)
    bh_result = metrics(np.array(bh_s), np.array(bh_b), np.array(bh_a))
    all_flat_results['BTC B&H'] = bh_result
    equity_curves['BTC B&H'] = np.array(bh_s)
    P(f"\n  BTC B&H: {bh_result['total']*100:+.1f}% | Sortino {bh_result['sortino']:.2f} | "
      f"MaxDD {bh_result['max_dd']*100:.1f}%")

    # ==================== RUN ALL GROUPS ====================

    # Group A
    group_a = run_group_a(daily_ret, returns, vols, df, dates, n)
    all_group_results['A'] = group_a
    for k, (r, s, fa, tr) in group_a.items():
        all_flat_results[k] = r
        if s is not None and len(s) > 0:
            equity_curves[k] = s

    baseline_result = group_a.get('A1 Weekly Bag5', (None, None, None, None))[0]
    if baseline_result:
        P(f"\n  V2 BASELINE (A1): {baseline_result['total']*100:+.1f}% | "
          f"Sortino {baseline_result['sortino']:.2f}")

    # Group B
    group_b = run_group_b(daily_ret, returns, vols, df, dates, n)
    all_group_results['B'] = group_b
    for k, (r, s, fa, tr) in group_b.items():
        all_flat_results[k] = r
        if s is not None and len(s) > 0:
            equity_curves[k] = s

    # Group C
    group_c = run_group_c(daily_ret, returns, vols, df, dates, n)
    all_group_results['C'] = group_c
    for k, (r, s, fa, tr) in group_c.items():
        all_flat_results[k] = r
        if s is not None and len(s) > 0:
            equity_curves[k] = s

    # Group D
    group_d = run_group_d(daily_ret, returns, vols, df, dates, n)
    all_group_results['D'] = group_d
    for k, (r, s, fa, tr) in group_d.items():
        all_flat_results[k] = r
        if s is not None and len(s) > 0:
            equity_curves[k] = s

    # Group E
    group_e = run_group_e(daily_ret, returns, vols, df, dates, n)
    all_group_results['E'] = group_e
    for k, (r, s, fa, tr) in group_e.items():
        all_flat_results[k] = r
        if s is not None and len(s) > 0:
            equity_curves[k] = s

    # Group F
    group_f = run_group_f(daily_ret, returns, vols, df, dates, n)
    all_group_results['F'] = group_f
    for k, (r, s, fa, tr) in group_f.items():
        all_flat_results[k] = r
        if s is not None and len(s) > 0:
            equity_curves[k] = s

    # Group G
    group_g = run_group_g(daily_ret, returns, vols, df, dates, n)
    all_group_results['G'] = group_g
    for k, (r, s, fa, tr) in group_g.items():
        all_flat_results[k] = r
        if s is not None and len(s) > 0:
            equity_curves[k] = s

    # Group H
    group_h = run_group_h(daily_ret, returns, vols, df, dates, n)
    all_group_results['H'] = group_h
    for k, (r, s, fa, tr) in group_h.items():
        all_flat_results[k] = r
        if s is not None and len(s) > 0:
            equity_curves[k] = s

    # Group I
    group_i = run_group_i(daily_ret, returns, vols, df, dates, n)
    all_group_results['I'] = group_i
    for k, (r, s, fa, tr) in group_i.items():
        all_flat_results[k] = r
        if s is not None and len(s) > 0:
            equity_curves[k] = s

    # Group J
    group_j = run_group_j(daily_ret, returns, vols, df, dates, n)
    all_group_results['J'] = group_j
    for k, (r, s, fa, tr) in group_j.items():
        all_flat_results[k] = r
        if s is not None and len(s) > 0:
            equity_curves[k] = s

    # Group K
    group_k = run_group_k(daily_ret, returns, vols, df, dates, n)
    all_group_results['K'] = group_k
    for k, (r, s, fa, tr) in group_k.items():
        all_flat_results[k] = r
        if s is not None and len(s) > 0:
            equity_curves[k] = s

    # Group L (Combined Best)
    group_l = run_group_l(all_group_results, daily_ret, returns, vols, df, dates, n,
                          baseline_result)
    all_group_results['L'] = group_l
    for k, (r, s, fa, tr) in group_l.items():
        all_flat_results[k] = r
        if s is not None and len(s) > 0:
            equity_curves[k] = s

    # ==================== BOOTSTRAP CI ====================
    P(f"\n{'='*100}")
    P("BOOTSTRAP 95% CI")
    P("=" * 100)

    bootstrap_results = {}
    baseline_total = baseline_result['total'] if baseline_result else 0

    # Bootstrap baseline + top 5 + L variants
    bs_candidates = [('A1 Weekly Bag5', group_a.get('A1 Weekly Bag5'))]
    sorted_all = sorted([(k, r) for k, r in all_flat_results.items()
                         if r is not None and k != 'BTC B&H'],
                        key=lambda x: x[1]['total'], reverse=True)
    for name, _ in sorted_all[:5]:
        if name != 'A1 Weekly Bag5':
            bs_candidates.append((name, None))

    for name, data in bs_candidates:
        if name in equity_curves and len(equity_curves[name]) > 30:
            bs = bootstrap_ci(equity_curves[name])
            bootstrap_results[name] = bs
            P(f"  {name}: CI [{bs['return_lo']*100:+.0f}%, {bs['return_hi']*100:+.0f}%] "
              f"P(>0)={bs['excess_above_zero_pct']:.1f}%")

    # L variants bootstrap
    for lk in ['L1 All Winners Avg', 'L2 Top3 Avg', 'L3 Best Config']:
        if lk in equity_curves and len(equity_curves[lk]) > 30:
            bs = bootstrap_ci(equity_curves[lk])
            bootstrap_results[lk] = bs
            P(f"  {lk}: CI [{bs['return_lo']*100:+.0f}%, {bs['return_hi']*100:+.0f}%] "
              f"P(>0)={bs['excess_above_zero_pct']:.1f}%")

    # ==================== COST SENSITIVITY ====================
    P(f"\n{'='*100}")
    P("COST SENSITIVITY (baseline allocations)")
    P("=" * 100)

    if 'A1 Weekly Bag5' in group_a:
        _, _, fa_base, tr_base = group_a['A1 Weekly Bag5']
        for cost_bps in [1, 2, 5, 10, 20, 50]:
            c = cost_bps / 10000.0
            all_s, all_b, all_a = [], [], []
            for (start, end) in tr_base:
                s, b, a = backtest_allocations(daily_ret, fa_base, start, end, cost=c)
                all_s.extend(s); all_b.extend(b); all_a.extend(a)
            r_cs = metrics(np.array(all_s), np.array(all_b), np.array(all_a))
            if r_cs:
                P(f"  {cost_bps:>3} bps: {r_cs['total']*100:+.1f}% | Sortino {r_cs['sortino']:.2f}")

    # ==================== FINAL TABLE ====================
    P(f"\n{'='*100}")
    P("FINAL COMPARISON TABLE")
    P("=" * 100)

    P(f"\n{'Strategy':<30} {'Return':>10} {'BTC':>10} {'Excess':>10} "
      f"{'Sortino':>8} {'MaxDD':>8} {'AvgAlloc':>9} {'vs V2':>8} {'Verdict':>10}")
    P("-" * 115)

    for name, r in all_flat_results.items():
        if r is None:
            P(f"{name:<30} {'N/A':>10}")
            continue

        delta = (r['total'] - baseline_total) * 100 if name not in ['BTC B&H'] else 0

        verdict = ''
        if name not in ['BTC B&H', 'A1 Weekly Bag5']:
            if r['total'] > baseline_total and r['sortino'] > (baseline_result['sortino'] if baseline_result else 0):
                verdict = 'WINNER'
            elif r['total'] > baseline_total:
                verdict = 'better ret'
            elif r['sortino'] > (baseline_result['sortino'] if baseline_result else 0):
                verdict = 'better risk'
            else:
                verdict = 'WORSE'

        P(f"{name:<30} {r['total']*100:>+9.1f}% {r['btc']*100:>+9.1f}% "
          f"{r['excess']*100:>+9.1f}% {r['sortino']:>+7.2f} "
          f"{r['max_dd']*100:>7.1f}% {r['avg_alloc']:>8.2f} "
          f"{delta:>+7.1f}pp {verdict:>10}")

    # ==================== SUMMARY BY GROUP ====================
    P(f"\n{'='*100}")
    P("SUMMARY BY GROUP")
    P("=" * 100)

    for gname, gres in all_group_results.items():
        valid = [(k, r) for k, (r, _, _, _) in gres.items() if r is not None]
        if not valid:
            continue
        best = max(valid, key=lambda x: x[1]['total'])
        delta = (best[1]['total'] - baseline_total) * 100
        status = 'BEATS V2' if delta > 0 else 'WORSE'
        P(f"  Group {gname}: best={best[0]} ({best[1]['total']*100:+.1f}%, {delta:+.1f}pp) [{status}]")

    # ==================== SAVE JSON ====================
    out_dir = ROOT / 'outputs/results'
    out_dir.mkdir(parents=True, exist_ok=True)

    output = {
        'timestamp': datetime.now().isoformat(),
        'method': 'pipeline_v5_new_approaches',
        'test_period': '2022-2026',
        'description': 'V5 Comprehensive: 13 groups, ~55 variants',
        'catboost_available': HAS_CATBOOST,
        'results': {},
        'bootstrap_ci': {},
        'group_summary': {},
    }

    for name, r in all_flat_results.items():
        if r is not None:
            output['results'][name] = {
                k: float(v) if isinstance(v, (int, float, np.floating)) else v
                for k, v in r.items()
            }

    for name, bs in bootstrap_results.items():
        output['bootstrap_ci'][name] = {
            k: float(v) if isinstance(v, (int, float, np.floating)) else v
            for k, v in bs.items()
        }

    for gname, gres in all_group_results.items():
        valid = [(k, r) for k, (r, _, _, _) in gres.items() if r is not None]
        if valid:
            best = max(valid, key=lambda x: x[1]['total'])
            output['group_summary'][f'Group_{gname}'] = {
                'best_variant': best[0],
                'best_return': float(best[1]['total']),
                'best_sortino': float(best[1]['sortino']),
                'best_max_dd': float(best[1]['max_dd']),
                'n_variants': len(valid),
            }

    with open(out_dir / 'pipeline_v5_new_approaches.json', 'w') as f:
        json.dump(output, f, indent=2, default=str)
    P(f"\n  Results saved: {out_dir / 'pipeline_v5_new_approaches.json'}")

    # ==================== CHARTS ====================
    P("\n  Generating charts...")
    chart_dir = ROOT / 'outputs/results/charts'
    generate_charts(all_flat_results, equity_curves, bootstrap_results,
                    group_a, group_g, chart_dir)

    # ==================== VERDICT ====================
    P(f"\n{'='*100}")
    P("VERDICT")
    P("=" * 100)

    if baseline_result:
        P(f"\n  V2 Baseline (A1 Weekly Bag5): {baseline_total*100:+.1f}% | "
          f"Sortino {baseline_result['sortino']:.2f} | MaxDD {baseline_result['max_dd']*100:.1f}%")

        winners = [(k, r) for k, r in all_flat_results.items()
                   if r is not None and k not in ['BTC B&H', 'A1 Weekly Bag5']
                   and r['total'] > baseline_total]

        if winners:
            P(f"\n  VARIANTS THAT BEAT V2 ({len(winners)}):")
            for name, r in sorted(winners, key=lambda x: x[1]['total'], reverse=True)[:10]:
                imp = (r['total'] - baseline_total) * 100
                P(f"    {name}: {r['total']*100:+.1f}% ({imp:+.1f}pp) | "
                  f"Sortino {r['sortino']:.2f} | MaxDD {r['max_dd']*100:.1f}%")
        else:
            P(f"\n  No variant beat V2 baseline. V2 remains champion.")

        # Overall best
        all_valid = [(k, r) for k, r in all_flat_results.items()
                     if r is not None and k != 'BTC B&H']
        if all_valid:
            best_overall = max(all_valid, key=lambda x: x[1]['total'])
            P(f"\n  OVERALL BEST: {best_overall[0]} ({best_overall[1]['total']*100:+.1f}%)")
            if best_overall[0] in bootstrap_results:
                bs = bootstrap_results[best_overall[0]]
                P(f"  Bootstrap 95% CI: [{bs['return_lo']*100:+.0f}%, {bs['return_hi']*100:+.0f}%]")
                if bs['return_lo'] > 0:
                    P(f"  STATISTICALLY SIGNIFICANT: CI excludes zero!")

    P(f"\n{'='*100}")
    P("PIPELINE V5 COMPLETE")
    P("=" * 100)


if __name__ == '__main__':
    main()
