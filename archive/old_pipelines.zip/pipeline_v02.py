"""
PIPELINE V2 ROBUST - 8 Robustness Improvements
=================================================

Tests 8 improvements independently on the Hybrid (50% ML + 50% Momentum) baseline:

1. Drop sentiment     -> Use Hybrid puro as new baseline
2. Bagging 5 seeds    -> Average predictions from 5 LightGBM models
3. Early stopping     -> 80/20 split with early_stopping(20)
4. Bootstrap CI       -> 1000 resamples of OOS daily returns, 95% CI
5. Cost/RF sensitivity-> Replay baseline allocs at costs=[1,2,5,10] bps and RF=[5%,10%,15%]
6. Vol targeting      -> target_vol / realized_vol * base_alloc overlay
7. Weekly rebalance   -> Only update allocation on Fridays
8. Sortino-only obj   -> Change optimization score to sortino*0.7 + max_dd*0.3

Each improvement tested independently, then best combo tested cumulatively.
All walk-forward OOS (2022-2026), no look-ahead.
"""

import sys
import pandas as pd
import numpy as np
from pathlib import Path
import warnings
import json
from datetime import datetime
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

warnings.filterwarnings('ignore')

# Force unbuffered stdout so we see progress in real time
sys.stdout.reconfigure(line_buffering=True)

ROOT = Path(__file__).parent.parent.parent
COST_DEFAULT = 0.0002   # 2 bps
RF_ANNUAL_DEFAULT = 0.15
RF_DAILY_DEFAULT = (1 + RF_ANNUAL_DEFAULT)**(1/365) - 1

P = lambda *a, **kw: print(*a, **kw, flush=True)


# ============================================================
# DATA LOADING
# ============================================================

def load_data():
    df = pd.read_csv(ROOT / 'outputs/feature_selection/dataset_enhanced.csv')
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)

    prices = df['price_usd'].values
    n = len(prices)

    daily_ret = np.zeros(n)
    for i in range(1, n):
        daily_ret[i] = (prices[i] - prices[i-1]) / prices[i-1]

    returns = {}
    for w in [1, 3, 5, 7, 10, 14, 20, 21, 30, 45, 60]:
        r = np.zeros(n)
        for i in range(w, n):
            r[i] = (prices[i] - prices[i-w]) / prices[i-w]
        returns[w] = r

    vols = {}
    for w in [5, 7, 10, 14, 21, 30]:
        vols[w] = pd.Series(daily_ret).rolling(w).std().fillna(0.02).values

    return prices, daily_ret, returns, vols, df


# ============================================================
# CORE ENGINE
# ============================================================

def backtest_allocations(daily_ret, allocations, start_idx, end_idx,
                         cost=COST_DEFAULT, rf_daily=RF_DAILY_DEFAULT):
    strat, btc, allocs = [], [], []
    prev = 0.5
    n = len(daily_ret)
    for t in range(start_idx, min(end_idx, n - 1)):
        a = np.clip(allocations[t], -0.25, 1.0)
        br = daily_ret[t + 1]
        tc = abs(a - prev) * cost * (1.5 if a < 0 else 1.0)
        sr = a * br + (1 - abs(a)) * rf_daily - tc
        strat.append(sr)
        btc.append(br)
        allocs.append(a)
        prev = a
    return np.array(strat), np.array(btc), np.array(allocs)


def metrics(s, b, a, rf_daily=RF_DAILY_DEFAULT):
    if len(s) < 10:
        return None
    ts = np.prod(1 + s) - 1
    tb = np.prod(1 + b) - 1
    ex = s - rf_daily
    ds = ex[ex < 0]
    sortino = np.mean(ex) / (np.std(ds) + 1e-10) * np.sqrt(365) if len(ds) > 0 else 0
    cum = np.cumprod(1 + s)
    pk = np.maximum.accumulate(cum)
    dd = np.min((cum - pk) / (pk + 1e-10))
    return {'total': ts, 'btc': tb, 'excess': ts - tb, 'sortino': sortino,
            'max_dd': dd, 'short_pct': float((a < 0).mean()), 'avg_alloc': float(np.mean(a))}


def get_year_boundaries(dates, n):
    yb = {}
    for i in range(n):
        yr = pd.Timestamp(dates[i]).year
        if yr not in yb:
            yb[yr] = {'start': i, 'end': i}
        yb[yr]['end'] = i
    return yb


# ============================================================
# MOMENTUM STRATEGY
# ============================================================

def strategy_fn(slow_ret, fast_ret, vol, p):
    bear_s, bear_f, bull_s = p[0], p[1], p[2]
    a_min, a_max, a_mid = p[3], p[4], p[5]
    sl_bear, sl_bull = p[6], p[7]
    v_thresh, v_damp = p[8], p[9]

    if slow_ret < bear_s and fast_ret < bear_f:
        base = a_min
    elif slow_ret < bear_s * 0.5 and fast_ret < bear_f * 0.5:
        t = np.clip(slow_ret / (bear_s + 1e-10), 0, 2)
        base = a_mid + (a_min - a_mid) * min(t * sl_bear, 1.0)
    elif slow_ret < 0 and fast_ret < bear_f * 0.5:
        t = np.clip(slow_ret / (bear_s * 0.5 + 1e-10), 0, 1)
        base = a_mid * (1 - t * 0.5)
    elif slow_ret > bull_s:
        base = a_max
    elif slow_ret > 0:
        t = np.clip(slow_ret / (bull_s + 1e-10), 0, 1)
        base = a_mid + (a_max - a_mid) * (t ** (1.0 / max(sl_bull, 0.1)))
    else:
        base = a_mid

    if vol > v_thresh:
        excess = (vol - v_thresh) / (v_thresh + 1e-10)
        damp = min(v_damp * excess, 0.5)
        if base > 0:
            base *= (1 - damp)
        else:
            base *= (1 + damp * 0.5)

    return np.clip(base, -0.25, 1.0)


def optimize_params(daily_ret, slow_sig, fast_sig, vol_sig, start_idx, end_idx,
                    n_trials=2000, use_sortino_obj=False,
                    cost=COST_DEFAULT, rf_daily=RF_DAILY_DEFAULT):
    ranges = {
        'bear_slow': (-0.15, -0.04), 'bear_fast': (-0.06, -0.01),
        'bull': (0.05, 0.30), 'alloc_min': (-0.25, -0.05),
        'alloc_max': (0.80, 1.0), 'alloc_mid': (0.25, 0.65),
        'slope_bear': (0.3, 2.5), 'slope_bull': (0.3, 2.5),
        'vol_thresh': (0.015, 0.05), 'vol_damp': (0.05, 0.55),
    }

    best_score, best_params = -999, None
    n = len(daily_ret)

    for _ in range(n_trials):
        p = [np.random.uniform(*ranges[k]) for k in
             ['bear_slow', 'bear_fast', 'bull', 'alloc_min', 'alloc_max',
              'alloc_mid', 'slope_bear', 'slope_bull', 'vol_thresh', 'vol_damp']]

        allocs = np.full(n, 0.5)
        for t in range(max(start_idx, 60), end_idx + 1):
            allocs[t] = strategy_fn(slow_sig[t], fast_sig[t], vol_sig[t], p)

        s, b, a = backtest_allocations(daily_ret, allocs, max(start_idx, 60), end_idx,
                                       cost=cost, rf_daily=rf_daily)
        m = metrics(s, b, a, rf_daily=rf_daily)
        if m is None:
            continue

        if use_sortino_obj:
            # Improvement #8: Sortino-focused objective
            score = m['sortino'] * 0.7 + m['max_dd'] * 0.3
        else:
            score = m['total'] * 2 + m['sortino'] * 0.3 + m['excess'] * 0.5 + m['max_dd'] * 0.3

        if score > best_score:
            best_score = score
            best_params = p[:]

    return best_params


# ============================================================
# ML UTILITIES
# ============================================================

def build_ml_features(df, returns, vols, n):
    feature_cols = [
        'cusum_pos', 'miners_revenue_ratio', 'mr_score_30d', 'adx',
        'cusum_neg', 'exchange_netflow_ma7', 'structural_break_score',
        'macd_histogram', 'eth_btc_ratio', 'm2_yoy_growth',
        'volatility_7d', 'basis_ma7', 'nupl_ma30', 'hurst_60d',
        'funding_rate', 'bb_position', 'rsi_14d', 'puell_multiple',
        'stablecoin_zscore', 'sopr_ma7',
    ]
    available = [c for c in feature_cols if c in df.columns]
    X_all = df[available].values.astype(float)
    X_extra = np.column_stack([returns[3], returns[10], returns[30], returns[60], vols[14]])
    X_all = np.hstack([X_all, X_extra])
    feature_names = available + ['ret_3d', 'ret_10d', 'ret_30d', 'ret_60d', 'vol_14d']
    return X_all, feature_names


def train_lgb_model(X_all, target, train_end, horizon_gap=5, seed=42,
                    use_early_stopping=False):
    import lightgbm as lgb

    train_mask = np.arange(60, train_end - horizon_gap + 1)
    valid_train = ~np.any(np.isnan(X_all[train_mask]), axis=1)
    train_idx = train_mask[valid_train]

    if len(train_idx) < 100:
        return None

    X_train = np.nan_to_num(X_all[train_idx], nan=0.0)
    y_train = target[train_idx]

    params = {
        'objective': 'regression', 'metric': 'mae',
        'num_leaves': 31, 'learning_rate': 0.05,
        'feature_fraction': 0.7, 'bagging_fraction': 0.8,
        'bagging_freq': 5, 'verbose': -1, 'n_jobs': 1,
        'seed': seed,
    }

    if use_early_stopping:
        # Improvement #3: 80/20 temporal split for early stopping
        split_point = int(len(X_train) * 0.8)
        X_tr, X_val = X_train[:split_point], X_train[split_point:]
        y_tr, y_val = y_train[:split_point], y_train[split_point:]

        if len(X_val) < 20:
            dtrain = lgb.Dataset(X_train, label=y_train)
            return lgb.train(params, dtrain, num_boost_round=200)

        dtrain = lgb.Dataset(X_tr, label=y_tr)
        dval = lgb.Dataset(X_val, label=y_val, reference=dtrain)
        return lgb.train(
            params, dtrain, num_boost_round=500,
            valid_sets=[dval], valid_names=['val'],
            callbacks=[lgb.early_stopping(20, verbose=False)]
        )
    else:
        dtrain = lgb.Dataset(X_train, label=y_train)
        return lgb.train(params, dtrain, num_boost_round=200)


def train_lgb_bagged(X_all, target, train_end, horizon_gap=5, n_bags=5,
                     use_early_stopping=False):
    models = []
    for i in range(n_bags):
        seed = 42 + i * 7
        m = train_lgb_model(X_all, target, train_end, horizon_gap=horizon_gap,
                            seed=seed, use_early_stopping=use_early_stopping)
        if m is not None:
            models.append(m)
    return models if len(models) > 0 else None


def ml_predict_to_alloc(model, X_all, t):
    x_t = np.nan_to_num(X_all[t:t+1].copy(), nan=0.0)
    pred = model.predict(x_t)[0]
    scaled = np.clip(pred / 0.05, -1.0, 1.0)
    if scaled > 0:
        return 0.5 + scaled * 0.5
    else:
        return 0.5 + scaled * 0.75


def ml_predict_bagged(models, X_all, t):
    x_t = np.nan_to_num(X_all[t:t+1].copy(), nan=0.0)
    preds = [m.predict(x_t)[0] for m in models]
    avg_pred = np.mean(preds)
    scaled = np.clip(avg_pred / 0.05, -1.0, 1.0)
    if scaled > 0:
        return 0.5 + scaled * 0.5
    else:
        return 0.5 + scaled * 0.75


# ============================================================
# WALK-FORWARD ENGINE (returns allocation arrays for sensitivity reuse)
# ============================================================

def walk_forward_hybrid(daily_ret, returns, vols, df, dates, n,
                        use_bagging=False, n_bags=5,
                        use_early_stopping=False,
                        use_vol_targeting=False, target_vol=0.03,
                        use_weekly_rebalance=False,
                        use_sortino_obj=False,
                        cost=COST_DEFAULT, rf_daily=RF_DAILY_DEFAULT,
                        label="Hybrid", verbose=True):
    """Walk-forward Hybrid with configurable improvements.
    Returns: (result_dict, strat_rets, btc_rets, alloc_array, full_allocs_array)
    full_allocs_array is the full-length allocation vector for sensitivity replay.
    """

    yb = get_year_boundaries(dates, n)
    slow_sig, fast_sig, vol_sig = returns[60], returns[3], vols[14]

    X_all, _ = build_ml_features(df, returns, vols, n)
    prices = df['price_usd'].values
    target_5d = np.zeros(n)
    for i in range(n - 5):
        target_5d[i] = (prices[i + 5] - prices[i]) / prices[i]

    day_of_week = pd.to_datetime(dates).dayofweek  # 0=Mon, 4=Fri

    all_strat, all_btc, all_alloc = [], [], []
    # Store the full allocation vector for sensitivity replays
    full_allocs = np.full(n, 0.5)
    test_ranges = []  # (start, end) pairs

    for test_year in range(2022, 2027):
        if test_year not in yb:
            continue
        train_end = yb[test_year]['start'] - 1
        test_start = yb[test_year]['start']
        test_end = yb[test_year]['end']

        np.random.seed(42 + test_year)
        if verbose:
            P(f"    {test_year}: optimizing momentum...", end="")
        mom_params = optimize_params(daily_ret, slow_sig, fast_sig, vol_sig,
                                     60, train_end, 2000,
                                     use_sortino_obj=use_sortino_obj,
                                     cost=cost, rf_daily=rf_daily)
        if mom_params is None:
            if verbose:
                P(" FAILED")
            continue

        # ML model(s)
        model = None
        models = None
        if use_bagging:
            models = train_lgb_bagged(X_all, target_5d, train_end, horizon_gap=5,
                                      n_bags=n_bags,
                                      use_early_stopping=use_early_stopping)
            if verbose:
                n_ok = len(models) if models else 0
                P(f" training {n_bags} ML models ({n_ok} ok)...", end="")
        else:
            model = train_lgb_model(X_all, target_5d, train_end, seed=42+test_year,
                                    use_early_stopping=use_early_stopping)
            if verbose:
                P(f" training ML...", end="")

        prev_alloc = 0.5

        for t in range(test_start, test_end + 1):
            a_mom = strategy_fn(slow_sig[t], fast_sig[t], vol_sig[t], mom_params)

            if use_bagging:
                if models is not None:
                    a_ml = ml_predict_bagged(models, X_all, t)
                    raw_alloc = 0.5 * a_mom + 0.5 * a_ml
                else:
                    raw_alloc = a_mom
            else:
                if model is not None:
                    a_ml = ml_predict_to_alloc(model, X_all, t)
                    raw_alloc = 0.5 * a_mom + 0.5 * a_ml
                else:
                    raw_alloc = a_mom

            # Improvement #6: Vol targeting overlay
            if use_vol_targeting:
                rolling_vol = vols[14][t] * np.sqrt(365)
                if rolling_vol > 0.01:
                    vol_scalar = target_vol * np.sqrt(365) / rolling_vol
                    vol_scalar = np.clip(vol_scalar, 0.5, 1.5)
                    deviation = raw_alloc - 0.5
                    raw_alloc = 0.5 + deviation * vol_scalar

            # Improvement #7: Weekly rebalance
            if use_weekly_rebalance:
                if day_of_week[t] != 4:
                    raw_alloc = prev_alloc

            full_allocs[t] = np.clip(raw_alloc, -0.25, 1.0)
            prev_alloc = full_allocs[t]

        test_ranges.append((test_start, test_end))
        s, b, a = backtest_allocations(daily_ret, full_allocs, test_start, test_end,
                                       cost=cost, rf_daily=rf_daily)
        all_strat.extend(s)
        all_btc.extend(b)
        all_alloc.extend(a)

        m_yr = metrics(np.array(s), np.array(b), np.array(a), rf_daily=rf_daily)
        if verbose and m_yr:
            P(f" {m_yr['total']*100:+.1f}% (BTC {m_yr['btc']*100:+.1f}%)")

    result = metrics(np.array(all_strat), np.array(all_btc), np.array(all_alloc),
                     rf_daily=rf_daily)
    return (result, np.array(all_strat), np.array(all_btc), np.array(all_alloc),
            full_allocs, test_ranges)


# ============================================================
# IMPROVEMENT #4: BOOTSTRAP CONFIDENCE INTERVALS
# ============================================================

def bootstrap_ci(daily_returns, n_bootstrap=1000, ci=0.95):
    n = len(daily_returns)
    if n < 30:
        return None

    rng = np.random.RandomState(42)
    total_returns = []
    sortinos = []

    for _ in range(n_bootstrap):
        idx = rng.choice(n, size=n, replace=True)
        resampled = daily_returns[idx]
        total = np.prod(1 + resampled) - 1
        total_returns.append(total)

        ex = resampled - RF_DAILY_DEFAULT
        ds = ex[ex < 0]
        if len(ds) > 2:
            sortino = np.mean(ex) / (np.std(ds) + 1e-10) * np.sqrt(365)
        else:
            sortino = 0.0
        sortinos.append(sortino)

    alpha = (1 - ci) / 2
    lo, hi = alpha * 100, (1 - alpha) * 100

    return {
        'return_mean': np.mean(total_returns),
        'return_lo': np.percentile(total_returns, lo),
        'return_hi': np.percentile(total_returns, hi),
        'return_std': np.std(total_returns),
        'sortino_mean': np.mean(sortinos),
        'sortino_lo': np.percentile(sortinos, lo),
        'sortino_hi': np.percentile(sortinos, hi),
        'excess_above_zero_pct': np.mean([r > 0 for r in total_returns]) * 100,
    }


# ============================================================
# IMPROVEMENT #5: COST/RF SENSITIVITY (fast replay, no re-optimization)
# ============================================================

def cost_rf_sensitivity(daily_ret, full_allocs, test_ranges):
    """Replay cached allocation decisions with different cost/RF.
    This is O(n) per combo instead of re-optimizing everything.
    """
    costs_bps = [1, 2, 5, 10]
    rf_annuals = [0.05, 0.10, 0.15]

    results = {}
    for cost_bps in costs_bps:
        for rf_ann in rf_annuals:
            cost = cost_bps / 10000.0
            rf_d = (1 + rf_ann)**(1/365) - 1
            label = f"cost={cost_bps}bps_rf={int(rf_ann*100)}%"

            all_s, all_b, all_a = [], [], []
            for (start, end) in test_ranges:
                s, b, a = backtest_allocations(daily_ret, full_allocs, start, end,
                                               cost=cost, rf_daily=rf_d)
                all_s.extend(s)
                all_b.extend(b)
                all_a.extend(a)

            r = metrics(np.array(all_s), np.array(all_b), np.array(all_a), rf_daily=rf_d)
            if r:
                results[label] = r
    return results


# ============================================================
# CHARTS
# ============================================================

def generate_charts(all_results, all_equity_curves, bootstrap_results, sensitivity_results, chart_dir):
    chart_dir.mkdir(parents=True, exist_ok=True)

    # --- Chart 1: Bar comparison of all improvements ---
    fig, axes = plt.subplots(2, 1, figsize=(20, 14))

    names, ret_vals, sortino_vals, maxdd_vals, colors_list = [], [], [], [], []
    cmap = plt.cm.Set2
    for i, (name, r) in enumerate(all_results.items()):
        if r is None:
            continue
        names.append(name)
        ret_vals.append(r['total'] * 100)
        sortino_vals.append(r['sortino'])
        maxdd_vals.append(r['max_dd'] * 100)
        if name == 'BTC Buy & Hold':
            colors_list.append('#F7931A')
        elif 'Baseline' in name:
            colors_list.append('#4A90D9')
        elif 'Best Combo' in name:
            colors_list.append('#E74C3C')
        else:
            colors_list.append(cmap(i / max(len(all_results), 1)))

    x = np.arange(len(names))

    ax = axes[0]
    bars = ax.bar(x, ret_vals, color=colors_list, alpha=0.85, edgecolor='black', linewidth=0.5)
    for v, bar in zip(ret_vals, bars):
        ax.text(bar.get_x() + bar.get_width()/2, v + (5 if v >= 0 else -12),
                f'{v:+.0f}%', ha='center', fontsize=9, fontweight='bold')
    ax.set_xticks(x)
    ax.set_xticklabels(names, fontsize=7, rotation=30, ha='right')
    ax.axhline(y=0, color='black', lw=0.5)
    ax.set_title('Pipeline V2 Robust: OOS Returns per Improvement (Walk-Forward 2022-2026)',
                 fontsize=13, fontweight='bold')
    ax.set_ylabel('Total Return %')
    ax.grid(True, alpha=0.3, axis='y')

    ax = axes[1]
    width = 0.35
    ax.bar(x - width/2, sortino_vals, width, color=colors_list, alpha=0.7,
           edgecolor='black', linewidth=0.5, label='Sortino')
    bars2 = ax.bar(x + width/2, maxdd_vals, width, color=colors_list, alpha=0.4,
                   edgecolor='black', linewidth=0.5, label='Max Drawdown %')
    for v, bar in zip(sortino_vals, ax.patches[:len(names)]):
        ax.text(bar.get_x() + bar.get_width()/2, v + 0.03,
                f'{v:.2f}', ha='center', fontsize=8, fontweight='bold')
    for v, bar in zip(maxdd_vals, bars2):
        ax.text(bar.get_x() + bar.get_width()/2, v - 3,
                f'{v:.0f}%', ha='center', fontsize=8, fontweight='bold')
    ax.set_xticks(x)
    ax.set_xticklabels(names, fontsize=7, rotation=30, ha='right')
    ax.axhline(y=0, color='black', lw=0.5)
    ax.set_title('Sortino Ratio & Max Drawdown', fontsize=13, fontweight='bold')
    ax.legend(fontsize=10)
    ax.grid(True, alpha=0.3, axis='y')

    plt.tight_layout()
    plt.savefig(chart_dir / 'pipeline_v2_robust.png', dpi=150, bbox_inches='tight')
    plt.close()
    P(f"  Chart saved: {chart_dir / 'pipeline_v2_robust.png'}")

    # --- Chart 2: Equity curves ---
    if len(all_equity_curves) > 1:
        fig, axes = plt.subplots(2, 1, figsize=(18, 12), gridspec_kw={'height_ratios': [3, 1]})

        ax = axes[0]
        key_curves = ['BTC Buy & Hold', 'Hybrid Baseline', 'Best Combo']
        for name, (strat_rets, _) in all_equity_curves.items():
            if len(strat_rets) == 0:
                continue
            cum = np.cumprod(1 + strat_rets)
            lw = 2.5 if name in key_curves else 1.0
            alpha = 1.0 if name in key_curves else 0.5
            ls = '-' if name in key_curves else '--'
            ax.plot(cum, label=f"{name} ({(cum[-1]-1)*100:+.0f}%)",
                    linewidth=lw, alpha=alpha, linestyle=ls)
        ax.set_title('Equity Curves (Walk-Forward OOS 2022-2026)', fontsize=14, fontweight='bold')
        ax.set_ylabel('Cumulative Value ($1 start)')
        ax.legend(fontsize=7, loc='upper left', ncol=2)
        ax.grid(True, alpha=0.3)
        ax.set_yscale('log')

        ax = axes[1]
        for name in key_curves:
            if name in all_equity_curves and len(all_equity_curves[name][0]) > 0:
                strat_rets = all_equity_curves[name][0]
                cum = np.cumprod(1 + strat_rets)
                pk = np.maximum.accumulate(cum)
                dd = (cum - pk) / pk * 100
                ax.fill_between(range(len(dd)), dd, 0, alpha=0.3, label=name)
                ax.plot(dd, linewidth=0.8)
        ax.set_title('Drawdown (%)', fontsize=12, fontweight='bold')
        ax.set_ylabel('Drawdown %')
        ax.legend(fontsize=9)
        ax.grid(True, alpha=0.3)

        plt.tight_layout()
        plt.savefig(chart_dir / 'pipeline_v2_equity.png', dpi=150, bbox_inches='tight')
        plt.close()
        P(f"  Chart saved: {chart_dir / 'pipeline_v2_equity.png'}")

    # --- Chart 3: Bootstrap CI ---
    if bootstrap_results:
        fig, ax = plt.subplots(1, 1, figsize=(12, 6))
        bs_names, bs_means, bs_lo, bs_hi = [], [], [], []
        for name, bs in bootstrap_results.items():
            bs_names.append(name)
            bs_means.append(bs['return_mean'] * 100)
            bs_lo.append(bs['return_lo'] * 100)
            bs_hi.append(bs['return_hi'] * 100)

        x = np.arange(len(bs_names))
        ax.bar(x, bs_means, color='steelblue', alpha=0.7, edgecolor='black', linewidth=0.5)
        ax.errorbar(x, bs_means,
                    yerr=[np.array(bs_means) - np.array(bs_lo),
                          np.array(bs_hi) - np.array(bs_means)],
                    fmt='none', color='black', capsize=5, linewidth=2)
        for i, (m, lo, hi) in enumerate(zip(bs_means, bs_lo, bs_hi)):
            ax.text(i, hi + 5, f'{m:.0f}%\n[{lo:.0f}, {hi:.0f}]',
                    ha='center', fontsize=8, fontweight='bold')

        ax.set_xticks(x)
        ax.set_xticklabels(bs_names, fontsize=8, rotation=20, ha='right')
        ax.axhline(y=0, color='red', lw=1, ls='--', label='Zero return')
        ax.set_title('Bootstrap 95% CI on Total Return (1000 resamples)', fontsize=13, fontweight='bold')
        ax.set_ylabel('Total Return %')
        ax.legend()
        ax.grid(True, alpha=0.3, axis='y')

        plt.tight_layout()
        plt.savefig(chart_dir / 'pipeline_v2_bootstrap.png', dpi=150, bbox_inches='tight')
        plt.close()
        P(f"  Chart saved: {chart_dir / 'pipeline_v2_bootstrap.png'}")

    # --- Chart 4: Sensitivity heatmap ---
    if sensitivity_results:
        costs_bps = [1, 2, 5, 10]
        rf_annuals = [0.05, 0.10, 0.15]
        grid = np.full((len(costs_bps), len(rf_annuals)), np.nan)
        for ci_idx, c in enumerate(costs_bps):
            for ri, rf in enumerate(rf_annuals):
                key = f"cost={c}bps_rf={int(rf*100)}%"
                if key in sensitivity_results:
                    grid[ci_idx, ri] = sensitivity_results[key]['total'] * 100

        fig, ax = plt.subplots(1, 1, figsize=(8, 6))
        im = ax.imshow(grid, cmap='RdYlGn', aspect='auto', origin='lower')
        ax.set_xticks(range(len(rf_annuals)))
        ax.set_xticklabels([f'{int(r*100)}%' for r in rf_annuals])
        ax.set_yticks(range(len(costs_bps)))
        ax.set_yticklabels([f'{c} bps' for c in costs_bps])
        ax.set_xlabel('Risk-Free Rate (annual)')
        ax.set_ylabel('Transaction Cost')
        ax.set_title('Sensitivity: Total OOS Return (%) by Cost & RF', fontsize=13, fontweight='bold')

        for ci_idx in range(len(costs_bps)):
            for ri in range(len(rf_annuals)):
                if not np.isnan(grid[ci_idx, ri]):
                    ax.text(ri, ci_idx, f'{grid[ci_idx, ri]:+.0f}%',
                            ha='center', va='center', fontsize=11, fontweight='bold')

        plt.colorbar(im, ax=ax, label='Total Return %')
        plt.tight_layout()
        plt.savefig(chart_dir / 'pipeline_v2_sensitivity.png', dpi=150, bbox_inches='tight')
        plt.close()
        P(f"  Chart saved: {chart_dir / 'pipeline_v2_sensitivity.png'}")


# ============================================================
# MAIN
# ============================================================

def main():
    P("=" * 100)
    P("PIPELINE V2 ROBUST - 8 Robustness Improvements")
    P("=" * 100)
    P("""
    Testing 8 improvements independently on Hybrid (50% ML + 50% Momentum):

    #1: Drop sentiment (use Hybrid puro as baseline)
    #2: Bagging 5 seeds (average 5 LightGBM models)
    #3: Early stopping (80/20 temporal split, early_stopping(20))
    #4: Bootstrap CI (1000 resamples, 95% CI on all variants)
    #5: Cost/RF sensitivity (replay allocs at costs=1,2,5,10 bps; RF=5%,10%,15%)
    #6: Vol targeting (target_vol / realized_vol overlay)
    #7: Weekly rebalance (only update on Fridays)
    #8: Sortino-only objective (sortino*0.7 + max_dd*0.3)

    + Combo tests: Bagging+EarlyStop, Best Combo (all winners)
    All walk-forward OOS (2022-2026), no look-ahead.
    """)

    P("Loading data...")
    prices, daily_ret, returns, vols, df = load_data()
    dates = df['date'].values
    n = len(prices)
    P(f"  {n} days | {len(df.columns)} columns | {dates[0]} to {dates[-1]}")

    all_results = {}
    all_equity_curves = {}
    bootstrap_results = {}

    # ---------------------------------------------------------
    # BTC Buy & Hold reference
    # ---------------------------------------------------------
    yb = get_year_boundaries(dates, n)
    bh_strat, bh_btc, bh_alloc = [], [], []
    for test_year in range(2022, 2027):
        if test_year not in yb:
            continue
        allocs_bh = np.full(n, 1.0)
        s, b, a = backtest_allocations(daily_ret, allocs_bh,
                                       yb[test_year]['start'], yb[test_year]['end'])
        bh_strat.extend(s); bh_btc.extend(b); bh_alloc.extend(a)
    bh_result = metrics(np.array(bh_strat), np.array(bh_btc), np.array(bh_alloc))
    all_results['BTC Buy & Hold'] = bh_result
    all_equity_curves['BTC Buy & Hold'] = (np.array(bh_strat), np.array(bh_btc))
    P(f"\n  BTC Buy & Hold: {bh_result['total']*100:+.1f}% | "
      f"Sortino: {bh_result['sortino']:.2f} | MaxDD: {bh_result['max_dd']*100:.1f}%")

    # ---------------------------------------------------------
    # #1: HYBRID BASELINE (NO sentiment)
    # ---------------------------------------------------------
    P(f"\n{'='*100}")
    P("  #1: HYBRID BASELINE (50% ML + 50% Momentum, no sentiment)")
    P("  " + "-" * 60)
    r1, s1, b1, a1, allocs1, ranges1 = walk_forward_hybrid(
        daily_ret, returns, vols, df, dates, n)
    all_results['Hybrid Baseline'] = r1
    all_equity_curves['Hybrid Baseline'] = (s1, b1)
    if r1:
        P(f"  >> TOTAL: {r1['total']*100:+.1f}% | Sortino: {r1['sortino']:.2f} | "
          f"MaxDD: {r1['max_dd']*100:.1f}% | AvgAlloc: {r1['avg_alloc']:.2f}")

    # ---------------------------------------------------------
    # #2: BAGGING 5 SEEDS
    # ---------------------------------------------------------
    P(f"\n{'='*100}")
    P("  #2: BAGGING 5 SEEDS")
    P("  " + "-" * 60)
    r2, s2, b2, a2, allocs2, ranges2 = walk_forward_hybrid(
        daily_ret, returns, vols, df, dates, n,
        use_bagging=True, n_bags=5)
    all_results['#2 Bagging5'] = r2
    all_equity_curves['#2 Bagging5'] = (s2, b2)
    if r2:
        P(f"  >> TOTAL: {r2['total']*100:+.1f}% | Sortino: {r2['sortino']:.2f} | "
          f"MaxDD: {r2['max_dd']*100:.1f}%")

    # ---------------------------------------------------------
    # #3: EARLY STOPPING
    # ---------------------------------------------------------
    P(f"\n{'='*100}")
    P("  #3: EARLY STOPPING (80/20 temporal split, early_stopping(20))")
    P("  " + "-" * 60)
    r3, s3, b3, a3, allocs3, ranges3 = walk_forward_hybrid(
        daily_ret, returns, vols, df, dates, n,
        use_early_stopping=True)
    all_results['#3 EarlyStop'] = r3
    all_equity_curves['#3 EarlyStop'] = (s3, b3)
    if r3:
        P(f"  >> TOTAL: {r3['total']*100:+.1f}% | Sortino: {r3['sortino']:.2f} | "
          f"MaxDD: {r3['max_dd']*100:.1f}%")

    # ---------------------------------------------------------
    # #2+#3 COMBO: Bagging + Early Stopping (natural pair)
    # ---------------------------------------------------------
    P(f"\n{'='*100}")
    P("  #2+#3: BAGGING 5 + EARLY STOPPING")
    P("  " + "-" * 60)
    r23, s23, b23, a23, allocs23, ranges23 = walk_forward_hybrid(
        daily_ret, returns, vols, df, dates, n,
        use_bagging=True, n_bags=5, use_early_stopping=True)
    all_results['#2+#3 Bag+ES'] = r23
    all_equity_curves['#2+#3 Bag+ES'] = (s23, b23)
    if r23:
        P(f"  >> TOTAL: {r23['total']*100:+.1f}% | Sortino: {r23['sortino']:.2f} | "
          f"MaxDD: {r23['max_dd']*100:.1f}%")

    # ---------------------------------------------------------
    # #6: VOL TARGETING
    # ---------------------------------------------------------
    P(f"\n{'='*100}")
    P("  #6: VOL TARGETING (target_vol=3% daily)")
    P("  " + "-" * 60)
    r6, s6, b6, a6, allocs6, ranges6 = walk_forward_hybrid(
        daily_ret, returns, vols, df, dates, n,
        use_vol_targeting=True, target_vol=0.03)
    all_results['#6 VolTarget'] = r6
    all_equity_curves['#6 VolTarget'] = (s6, b6)
    if r6:
        P(f"  >> TOTAL: {r6['total']*100:+.1f}% | Sortino: {r6['sortino']:.2f} | "
          f"MaxDD: {r6['max_dd']*100:.1f}%")

    # ---------------------------------------------------------
    # #7: WEEKLY REBALANCE
    # ---------------------------------------------------------
    P(f"\n{'='*100}")
    P("  #7: WEEKLY REBALANCE (Fridays only)")
    P("  " + "-" * 60)
    r7, s7, b7, a7, allocs7, ranges7 = walk_forward_hybrid(
        daily_ret, returns, vols, df, dates, n,
        use_weekly_rebalance=True)
    all_results['#7 WeeklyRebal'] = r7
    all_equity_curves['#7 WeeklyRebal'] = (s7, b7)
    if r7:
        P(f"  >> TOTAL: {r7['total']*100:+.1f}% | Sortino: {r7['sortino']:.2f} | "
          f"MaxDD: {r7['max_dd']*100:.1f}%")

    # ---------------------------------------------------------
    # #8: SORTINO-ONLY OBJECTIVE
    # ---------------------------------------------------------
    P(f"\n{'='*100}")
    P("  #8: SORTINO-ONLY OBJECTIVE (sortino*0.7 + max_dd*0.3)")
    P("  " + "-" * 60)
    r8, s8, b8, a8, allocs8, ranges8 = walk_forward_hybrid(
        daily_ret, returns, vols, df, dates, n,
        use_sortino_obj=True)
    all_results['#8 SortinoObj'] = r8
    all_equity_curves['#8 SortinoObj'] = (s8, b8)
    if r8:
        P(f"  >> TOTAL: {r8['total']*100:+.1f}% | Sortino: {r8['sortino']:.2f} | "
          f"MaxDD: {r8['max_dd']*100:.1f}%")

    # ---------------------------------------------------------
    # #4: BOOTSTRAP CI on all variants
    # ---------------------------------------------------------
    P(f"\n{'='*100}")
    P("  #4: BOOTSTRAP 95% CI (1000 resamples)")
    P("  " + "-" * 60)
    variants_for_bs = [
        ('Hybrid Baseline', s1), ('#2 Bagging5', s2), ('#3 EarlyStop', s3),
        ('#2+#3 Bag+ES', s23), ('#6 VolTarget', s6),
        ('#7 WeeklyRebal', s7), ('#8 SortinoObj', s8),
    ]
    for name, strat_rets in variants_for_bs:
        if len(strat_rets) > 30:
            bs = bootstrap_ci(strat_rets, n_bootstrap=1000)
            bootstrap_results[name] = bs
            P(f"    {name}:")
            P(f"      Return 95% CI: [{bs['return_lo']*100:+.0f}%, {bs['return_hi']*100:+.0f}%] "
              f"(mean: {bs['return_mean']*100:+.0f}%)")
            P(f"      Sortino 95% CI: [{bs['sortino_lo']:.2f}, {bs['sortino_hi']:.2f}]")
            P(f"      P(return > 0): {bs['excess_above_zero_pct']:.1f}%")

    # ---------------------------------------------------------
    # #5: COST/RF SENSITIVITY (fast replay using cached allocations)
    # ---------------------------------------------------------
    P(f"\n{'='*100}")
    P("  #5: COST / RF SENSITIVITY (replaying baseline allocations)")
    P("  " + "-" * 60)
    sensitivity_results = cost_rf_sensitivity(daily_ret, allocs1, ranges1)

    P(f"\n    {'Setting':<25} {'Return':>10} {'Sortino':>8} {'MaxDD':>8}")
    P("    " + "-" * 55)
    for label, r in sorted(sensitivity_results.items()):
        P(f"    {label:<25} {r['total']*100:>+9.1f}% {r['sortino']:>+7.2f} {r['max_dd']*100:>7.1f}%")

    # Find breakeven cost (fast replay)
    for cost_bps in [1, 2, 5, 10, 15, 20, 25, 30, 40, 50]:
        cost = cost_bps / 10000.0
        all_s, all_b, all_a = [], [], []
        for (start, end) in ranges1:
            s, b, a = backtest_allocations(daily_ret, allocs1, start, end,
                                           cost=cost, rf_daily=RF_DAILY_DEFAULT)
            all_s.extend(s); all_b.extend(b); all_a.extend(a)
        r_test = metrics(np.array(all_s), np.array(all_b), np.array(all_a))
        if r_test and r_test['total'] < bh_result['total']:
            P(f"\n    Breakeven cost (vs BTC B&H): ~{cost_bps} bps "
              f"(strategy={r_test['total']*100:+.1f}% < BTC={bh_result['total']*100:+.1f}%)")
            break

    # ---------------------------------------------------------
    # BEST COMBO: cumulative improvements that helped
    # ---------------------------------------------------------
    P(f"\n{'='*100}")
    P("  BEST COMBO (all improvements that individually helped)")
    P("  " + "-" * 60)

    baseline_total = r1['total'] if r1 else 0
    baseline_sortino = r1['sortino'] if r1 else 0

    combo_flags = {
        'bagging': False, 'early_stop': False, 'vol_target': False,
        'weekly': False, 'sortino_obj': False
    }

    improvements = [
        ('#2 Bagging5', r2, 'bagging'),
        ('#3 EarlyStop', r3, 'early_stop'),
        ('#6 VolTarget', r6, 'vol_target'),
        ('#7 WeeklyRebal', r7, 'weekly'),
        ('#8 SortinoObj', r8, 'sortino_obj'),
    ]

    P("    Checking which improvements beat baseline...")
    for name, r, flag in improvements:
        if r is None:
            P(f"      {name}: N/A")
            continue
        better_return = r['total'] > baseline_total
        better_sortino = r['sortino'] > baseline_sortino
        better_dd = r['max_dd'] > (r1['max_dd'] if r1 else -1)

        if better_return or better_sortino:
            combo_flags[flag] = True
            reason = []
            if better_return:
                reason.append(f"ret {r['total']*100:+.1f}% > {baseline_total*100:+.1f}%")
            if better_sortino:
                reason.append(f"sortino {r['sortino']:.2f} > {baseline_sortino:.2f}")
            if better_dd:
                reason.append(f"dd {r['max_dd']*100:.1f}% > {r1['max_dd']*100:.1f}%")
            P(f"      {name}: INCLUDED ({', '.join(reason)})")
        else:
            P(f"      {name}: excluded (ret={r['total']*100:+.1f}%, sortino={r['sortino']:.2f})")

    active = [k for k, v in combo_flags.items() if v]
    P(f"\n    Active improvements: {active if active else 'NONE (baseline only)'}")

    rc, sc, bc, ac, allocsc, rangesc = walk_forward_hybrid(
        daily_ret, returns, vols, df, dates, n,
        use_bagging=combo_flags['bagging'], n_bags=5,
        use_early_stopping=combo_flags['early_stop'],
        use_vol_targeting=combo_flags['vol_target'], target_vol=0.03,
        use_weekly_rebalance=combo_flags['weekly'],
        use_sortino_obj=combo_flags['sortino_obj'],
    )
    all_results['Best Combo'] = rc
    all_equity_curves['Best Combo'] = (sc, bc)
    if rc:
        P(f"  >> TOTAL: {rc['total']*100:+.1f}% | Sortino: {rc['sortino']:.2f} | "
          f"MaxDD: {rc['max_dd']*100:.1f}%")

    # Bootstrap CI for best combo
    if len(sc) > 30:
        bs_combo = bootstrap_ci(sc, n_bootstrap=1000)
        bootstrap_results['Best Combo'] = bs_combo
        P(f"    Bootstrap 95% CI: [{bs_combo['return_lo']*100:+.0f}%, {bs_combo['return_hi']*100:+.0f}%]")
        P(f"    P(return > 0): {bs_combo['excess_above_zero_pct']:.1f}%")

    # ---------------------------------------------------------
    # FINAL COMPARISON TABLE
    # ---------------------------------------------------------
    P(f"\n{'='*100}")
    P("FINAL COMPARISON TABLE")
    P("=" * 100)

    P(f"\n{'Strategy':<25} {'Return':>10} {'BTC':>10} {'Excess':>10} "
      f"{'Sortino':>8} {'MaxDD':>8} {'AvgAlloc':>9} {'Verdict':>12}")
    P("-" * 100)

    for name, r in all_results.items():
        if r is None:
            P(f"{name:.<25} {'N/A':>10}")
            continue

        verdict = ''
        if name not in ['BTC Buy & Hold', 'Hybrid Baseline']:
            if r['total'] > baseline_total and r['sortino'] > baseline_sortino:
                verdict = 'WINNER'
            elif r['total'] > baseline_total:
                verdict = 'better ret'
            elif r['sortino'] > baseline_sortino:
                verdict = 'better risk'
            elif r['max_dd'] > (r1['max_dd'] if r1 else -1):
                verdict = 'better dd'
            else:
                verdict = 'WORSE'

        P(f"{name:.<25} {r['total']*100:>+9.1f}% {r['btc']*100:>+9.1f}% "
          f"{r['excess']*100:>+9.1f}% {r['sortino']:>+7.2f} "
          f"{r['max_dd']*100:>7.1f}% {r['avg_alloc']:>8.2f} {verdict:>12}")

    # ---------------------------------------------------------
    # SAVE RESULTS
    # ---------------------------------------------------------
    out_dir = ROOT / 'outputs/results'
    out_dir.mkdir(parents=True, exist_ok=True)

    output = {
        'timestamp': datetime.now().isoformat(),
        'method': 'pipeline_v2_robust',
        'test_period': '2022-2026',
        'description': '8 robustness improvements on Hybrid baseline',
        'results': {},
        'bootstrap_ci': {},
        'sensitivity': {},
    }

    for name, r in all_results.items():
        if r is not None:
            output['results'][name] = {
                k: float(v) if isinstance(v, (int, float, np.floating)) else v
                for k, v in r.items()
            }

    for name, bs in bootstrap_results.items():
        output['bootstrap_ci'][name] = {
            k: float(v) if isinstance(v, (int, float, np.floating)) else v
            for k, v in bs.items()
        }

    for label, r in sensitivity_results.items():
        output['sensitivity'][label] = {
            k: float(v) if isinstance(v, (int, float, np.floating)) else v
            for k, v in r.items()
        }

    with open(out_dir / 'pipeline_v2_robust.json', 'w') as f:
        json.dump(output, f, indent=2, default=str)
    P(f"\n  Results saved: {out_dir / 'pipeline_v2_robust.json'}")

    # ---------------------------------------------------------
    # CHARTS
    # ---------------------------------------------------------
    P("\n  Generating charts...")
    chart_dir = ROOT / 'outputs/results/charts'
    generate_charts(all_results, all_equity_curves, bootstrap_results, sensitivity_results, chart_dir)

    # ---------------------------------------------------------
    # VERDICT
    # ---------------------------------------------------------
    P(f"\n{'='*100}")
    P("VERDICT")
    P("=" * 100)

    if r1:
        P(f"\n  Hybrid Baseline: {r1['total']*100:+.1f}% | Sortino: {r1['sortino']:.2f} | "
          f"MaxDD: {r1['max_dd']*100:.1f}%")

        winners = []
        for name, r in all_results.items():
            if name in ['BTC Buy & Hold', 'Hybrid Baseline']:
                continue
            if r is not None and r['total'] > baseline_total:
                winners.append((name, r))

        if winners:
            P(f"\n  IMPROVEMENTS THAT BEAT BASELINE ({baseline_total*100:+.1f}%):")
            for name, r in sorted(winners, key=lambda x: x[1]['total'], reverse=True):
                imp = (r['total'] - baseline_total) * 100
                P(f"    {name}: {r['total']*100:+.1f}% ({imp:+.1f}pp) | "
                  f"Sortino: {r['sortino']:.2f} | MaxDD: {r['max_dd']*100:.1f}%")
        else:
            P(f"\n  No improvement beat baseline on return. Baseline is already robust.")

        # Check risk-adjusted improvements
        risk_winners = []
        for name, r in all_results.items():
            if name in ['BTC Buy & Hold', 'Hybrid Baseline']:
                continue
            if r is not None and r['sortino'] > baseline_sortino:
                risk_winners.append((name, r))
        if risk_winners:
            P(f"\n  BETTER RISK-ADJUSTED (Sortino > {baseline_sortino:.2f}):")
            for name, r in sorted(risk_winners, key=lambda x: x[1]['sortino'], reverse=True):
                P(f"    {name}: Sortino {r['sortino']:.2f} | MaxDD: {r['max_dd']*100:.1f}%")

        if 'Best Combo' in bootstrap_results:
            bs = bootstrap_results['Best Combo']
            P(f"\n  Best Combo Bootstrap 95% CI: [{bs['return_lo']*100:+.0f}%, {bs['return_hi']*100:+.0f}%]")
            if bs['return_lo'] > 0:
                P(f"  STATISTICALLY SIGNIFICANT: CI excludes zero!")
            else:
                P(f"  NOT significant at 95%: CI includes zero.")

        if sensitivity_results:
            key_2bps = 'cost=2bps_rf=15%'
            key_10bps = 'cost=10bps_rf=15%'
            if key_2bps in sensitivity_results and key_10bps in sensitivity_results:
                r_2 = sensitivity_results[key_2bps]['total']
                r_10 = sensitivity_results[key_10bps]['total']
                P(f"\n  Cost sensitivity: 2bps={r_2*100:+.1f}% vs 10bps={r_10*100:+.1f}% "
                  f"(diff: {(r_2-r_10)*100:.1f}pp)")

    P(f"\n{'='*100}")
    P("PIPELINE V2 ROBUST COMPLETE")
    P("=" * 100)


if __name__ == '__main__':
    main()
