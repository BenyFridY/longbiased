"""
Pipeline V21 — MODELO FINAL
BTC Allocation Strategy using XGBoost

Sortino: 4.00 | Return: +1067% | MaxDD: -9.9% (10 seeds, 2022-2026)

Usage:
    python scripts/optimization/pipeline_v21.py              # 10 seeds (default)
    python scripts/optimization/pipeline_v21.py --seeds 20   # 20 seeds
    python scripts/optimization/pipeline_v21.py --seeds 1    # Quick single-seed
"""
import sys, gc, json, argparse, numpy as np, pandas as pd
from pathlib import Path
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
import warnings; warnings.filterwarnings('ignore')
sys.stdout.reconfigure(line_buffering=True)

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

from archive.old_pipelines.pipeline_v09 import (
    load_data, build_ml_features, backtest_allocations,
    metrics, COST, P, convert_numpy,
)
from archive.old_pipelines.pipeline_v10 import MODELS
from archive.old_pipelines.pipeline_v11 import DEFAULT_XGB_PARAMS
from archive.old_pipelines.pipeline_v13 import _get_retrain_periods, _train_one_xgb


# ═══════════════════════════════════════════════════════════════════════
# V21 MODEL CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════

# XGBoost hyperparameters (V21: colsample_bytree 0.7 → 0.5)
XGB_PARAMS = {
    'max_leaves': 31,
    'grow_policy': 'lossguide',
    'tree_method': 'hist',
    'colsample_bytree': 0.5,       # V21 change (was 0.7)
    'subsample': 0.8,
    'learning_rate': 0.05,
    'min_child_weight': 12,
    'n_estimators': 200,
    'objective': 'reg:squarederror',
    'verbosity': 0,
    'nthread': 1,
}

# Allocation parameters
K_REGIME = {'BULL': 50, 'MILD': 30, 'BEAR': 15}
ALLOC_MIN = -0.25
ALLOC_MAX = 1.0

# Model parameters
BAGS = 80                  # Number of bagged XGBoost models
HORIZON = 3                # Prediction horizon (days)
RETRAIN = 'semi'           # Retrain frequency (semi-annual)
REBAL_DOW = [4]            # Rebalance day (4=Friday)
EMERGENCY_THRESHOLD = 0.08 # Emergency rebalance if |daily_ret| > 8%
WORKERS = 16               # Parallel workers for bagging

# Features (37 total = 32 base + 5 extra)
BASE_FEATURES = [f for f in MODELS['37feat'] if f != 'exchange_netflow_ma7'] + ['basis_pct']
EXTRA_FEATURES = [
    'fed_balance_sheet', 'futures_trade_count',
    'vol_x_regime_duration', 'velocity', 'hash_rate_pctchg_30d',
]


# ═══════════════════════════════════════════════════════════════════════
# FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════

def get_regime(t, prices, sma50, sma200):
    """Classify market regime using SMA50/200 crossover."""
    if np.isnan(sma50[t]) or np.isnan(sma200[t]):
        return 'MILD'
    if prices[t] > sma50[t] and sma50[t] > sma200[t]:
        return 'BULL'
    elif prices[t] > sma200[t]:
        return 'MILD'
    return 'BEAR'


def compute_allocation(prediction, regime):
    """Convert model prediction to portfolio allocation."""
    K = K_REGIME[regime]
    return np.clip(prediction * K, ALLOC_MIN, ALLOC_MAX)


def run_single_seed(seed, X_all, target, prices, daily_ret, dates, periods,
                    dow, sma50, sma200, rf_daily, n):
    """Run full pipeline for a single seed. Returns metrics dict."""
    full_allocs = np.full(n, 0.0)
    prev_alloc = 0.0
    a_s, a_b, a_a, a_r = [], [], [], []

    for te, ts, tend in periods:
        # Prepare training data
        gap = max(HORIZON, 5)
        tm = np.arange(60, te - gap + 1)
        valid = ~np.any(np.isnan(X_all[tm]), axis=1)
        idx = tm[valid]
        if len(idx) < 100:
            continue

        Xt = np.nan_to_num(X_all[idx], nan=0.0)
        yt = target[idx]

        # Train bagged ensemble
        bag_seeds = [seed + i * 7 for i in range(BAGS)]
        with ThreadPoolExecutor(max_workers=WORKERS) as ex:
            models = list(ex.map(_train_one_xgb,
                [(s, Xt, yt, XGB_PARAMS) for s in bag_seeds]))

        # Generate predictions and allocations for test period
        for t in range(ts, tend + 1):
            is_rebal = dow[t] in REBAL_DOW
            is_emerg = t > 0 and abs(daily_ret[t]) > EMERGENCY_THRESHOLD
            if not is_rebal and not is_emerg:
                full_allocs[t] = prev_alloc
                continue

            x_t = np.nan_to_num(X_all[t:t + 1].copy(), nan=0.0)
            prediction = float(np.mean([m.predict(x_t)[0] for m in models]))
            regime = get_regime(t, prices, sma50, sma200)
            full_allocs[t] = compute_allocation(prediction, regime)
            prev_alloc = full_allocs[t]

        # Backtest this period
        s, b, a = backtest_allocations(daily_ret, full_allocs, ts, tend,
                                       cost=COST, rf_daily=rf_daily)
        a_s.extend(s)
        a_b.extend(b)
        a_a.extend(a)
        a_r.extend(rf_daily[ts:ts + len(s)])

        del models
        gc.collect()

    return metrics(np.array(a_s), np.array(a_b), np.array(a_a),
                   rf_daily=np.array(a_r))


# ═══════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(description='Pipeline V21 — BTC Allocation Strategy')
    parser.add_argument('--seeds', type=int, default=10, help='Number of seeds (default: 10)')
    args = parser.parse_args()

    num_seeds = args.seeds
    seeds = [42 + i * 100 for i in range(num_seeds)]

    P("=" * 80)
    P("PIPELINE V21 — MODELO FINAL")
    P("=" * 80)
    P(f"  XGBoost Bag{BAGS} | colsample={XGB_PARAMS['colsample_bytree']} | "
      f"lr={XGB_PARAMS['learning_rate']} | n_est={XGB_PARAMS['n_estimators']}")
    P(f"  Horizon: {HORIZON}d | Retrain: {RETRAIN}-annual | "
      f"Rebalance: Friday + emergency {EMERGENCY_THRESHOLD*100:.0f}%")
    P(f"  K: BULL={K_REGIME['BULL']}, MILD={K_REGIME['MILD']}, BEAR={K_REGIME['BEAR']}")
    P(f"  Allocation range: [{ALLOC_MIN*100:.0f}%, {ALLOC_MAX*100:.0f}%]")
    P(f"  Seeds: {num_seeds}")
    P("")

    start = datetime.now()

    # Load data
    P("Loading data...")
    prices, daily_ret, returns, vols, df = load_data()
    dates = df['date'].values
    n = len(prices)
    P(f"  {n} days | {dates[0]} to {dates[-1]}")

    # Risk-free rate
    try:
        from src.features.macro.cdi_rates import build_rf_daily
        rf_daily = build_rf_daily(dates, source='auto')
    except Exception:
        from src.features.macro.cdi_rates import build_rf_daily
        rf_daily = build_rf_daily(dates, source='copom')

    import archive.old_pipelines.pipeline_v09 as v9m
    import archive.old_pipelines.pipeline_v13 as v13m
    v9m.RF_DAILY_ARR = rf_daily
    v13m.RF_DAILY_ARR = rf_daily

    # Build features
    fc = BASE_FEATURES + [f for f in EXTRA_FEATURES if f not in BASE_FEATURES]
    fc = [f for f in fc if f in df.columns]
    P(f"  {len(fc)} features")

    X_all, _ = build_ml_features(df, returns, vols, n, feature_cols=fc)

    # Build target (3-day return)
    target = np.zeros(n)
    for i in range(n - HORIZON):
        target[i] = (prices[i + HORIZON] - prices[i]) / prices[i]

    # Precompute signals
    dow = pd.to_datetime(dates).dayofweek
    periods = _get_retrain_periods(dates, n, RETRAIN)
    sma50 = pd.Series(prices).rolling(50).mean().values
    sma200 = pd.Series(prices).rolling(200).mean().values

    # Run all seeds
    P("")
    P("Running backtest...")
    all_metrics = []

    for si, seed in enumerate(seeds):
        P(f"  Seed {seed} ({si+1}/{num_seeds})...")
        m = run_single_seed(seed, X_all, target, prices, daily_ret, dates,
                           periods, dow, sma50, sma200, rf_daily, n)
        all_metrics.append(m)
        P(f"    Sortino={m['sortino']:.2f}  Return={m['total']*100:+.0f}%  "
          f"MaxDD={m['max_dd']*100:.1f}%")

    elapsed = (datetime.now() - start).total_seconds() / 60

    # Aggregate results
    sortinos = [m['sortino'] for m in all_metrics]
    rets = [m['total'] * 100 for m in all_metrics]
    dds = [m['max_dd'] * 100 for m in all_metrics]
    spreads = [m.get('spread', 0) for m in all_metrics]

    P("")
    P("=" * 80)
    P(f"RESULTS — {num_seeds} seeds ({elapsed:.0f} min)")
    P("=" * 80)
    P("")
    P(f"  Sortino:  {np.mean(sortinos):.2f} +/- {np.std(sortinos):.2f}")
    P(f"            min={np.min(sortinos):.2f}  median={np.median(sortinos):.2f}  "
      f"max={np.max(sortinos):.2f}")
    P(f"  Return:   {np.mean(rets):+.0f}% +/- {np.std(rets):.0f}%")
    P(f"            min={np.min(rets):+.0f}%  median={np.median(rets):+.0f}%  "
      f"max={np.max(rets):+.0f}%")
    P(f"  MaxDD:    {np.mean(dds):.1f}% +/- {np.std(dds):.1f}%")
    P(f"  Elapsed:  {elapsed:.1f} min")

    # Save results
    output = {
        'pipeline': 'V21_final',
        'timestamp': datetime.now().isoformat(),
        'elapsed_min': elapsed,
        'n_seeds': num_seeds,
        'params': {
            'xgb': {k: v for k, v in XGB_PARAMS.items()
                    if k not in ['objective', 'verbosity', 'nthread', 'tree_method']},
            'bags': BAGS,
            'horizon': HORIZON,
            'retrain': RETRAIN,
            'rebal_dow': REBAL_DOW,
            'emergency_threshold': EMERGENCY_THRESHOLD,
            'K_regime': K_REGIME,
            'alloc_range': [ALLOC_MIN, ALLOC_MAX],
            'n_features': len(fc),
            'features': fc,
        },
        'results': {
            'sortino_avg': float(np.mean(sortinos)),
            'sortino_std': float(np.std(sortinos)),
            'sortino_min': float(np.min(sortinos)),
            'sortino_max': float(np.max(sortinos)),
            'return_avg': float(np.mean(rets)),
            'return_std': float(np.std(rets)),
            'max_dd_avg': float(np.mean(dds)),
            'max_dd_std': float(np.std(dds)),
        },
        'seed_results': [
            {
                'seed': seeds[i],
                'sortino': float(sortinos[i]),
                'return_pct': float(rets[i]),
                'max_dd_pct': float(dds[i]),
            }
            for i in range(num_seeds)
        ],
    }

    out_path = ROOT / 'outputs' / 'results' / 'pipeline_v21_final.json'
    with open(out_path, 'w') as f:
        json.dump(output, f, indent=2, default=convert_numpy)
    P(f"\n  Saved: {out_path}")


if __name__ == '__main__':
    main()
