"""
PIPELINE V4 EXPLORATION - Fundamentally Different Approaches
=============================================================

V2 Best Combo (Bagging 5 LGB + Weekly Rebal) achieved +221% OOS (2022-2026).
V3 tested 6 incremental improvements and ALL failed to beat V2.
Incremental optimization has converged.

V4 tests 6 FUNDAMENTALLY DIFFERENT approaches never tried before:

1. Optuna Hyperparameter Tuning (2 variants: 50 & 100 trials)
2. SHAP Feature Pruning (3 variants: top-10, top-15, top-20)
3. Larger Bag (2 variants: 10 & 20 models)
4. Target Engineering (3 variants: 10d, quantile, risk-adjusted)
5. Linear Ensemble (2 variants: Ridge, ElasticNet)
6. Asymmetric Bull/Bear Models (1 variant)

Total: 14 variants + V2 baseline + best combo.
All walk-forward OOS (2022-2026), no look-ahead.
"""

import sys
import pandas as pd
import numpy as np
from pathlib import Path
import warnings
import json
from datetime import datetime
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

warnings.filterwarnings('ignore')
sys.stdout.reconfigure(line_buffering=True)

ROOT = Path(__file__).parent.parent.parent
COST_DEFAULT = 0.0002   # 2 bps
RF_ANNUAL_DEFAULT = 0.15
RF_DAILY_DEFAULT = (1 + RF_ANNUAL_DEFAULT)**(1/365) - 1

P = lambda *a, **kw: print(*a, **kw, flush=True)

# Check optional dependencies
HAS_OPTUNA = False
try:
    import optuna
    optuna.logging.set_verbosity(optuna.logging.WARNING)
    HAS_OPTUNA = True
except ImportError:
    pass

HAS_SHAP = False
try:
    import shap
    HAS_SHAP = True
except ImportError:
    pass


# ============================================================
# DATA LOADING
# ============================================================

def load_data():
    df = pd.read_csv(ROOT / 'outputs/feature_selection/dataset_enhanced.csv')
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)

    prices = df['price_usd'].values
    n = len(prices)

    daily_ret = np.zeros(n)
    for i in range(1, n):
        daily_ret[i] = (prices[i] - prices[i-1]) / prices[i-1]

    returns = {}
    for w in [1, 3, 5, 7, 10, 14, 20, 21, 30, 45, 60]:
        r = np.zeros(n)
        for i in range(w, n):
            r[i] = (prices[i] - prices[i-w]) / prices[i-w]
        returns[w] = r

    vols = {}
    for w in [5, 7, 10, 14, 21, 30]:
        vols[w] = pd.Series(daily_ret).rolling(w).std().fillna(0.02).values

    return prices, daily_ret, returns, vols, df


# ============================================================
# CORE ENGINE
# ============================================================

def backtest_allocations(daily_ret, allocations, start_idx, end_idx,
                         cost=COST_DEFAULT, rf_daily=RF_DAILY_DEFAULT):
    strat, btc, allocs = [], [], []
    prev = 0.5
    n = len(daily_ret)
    for t in range(start_idx, min(end_idx, n - 1)):
        a = np.clip(allocations[t], -0.25, 1.0)
        br = daily_ret[t + 1]
        tc = abs(a - prev) * cost * (1.5 if a < 0 else 1.0)
        sr = a * br + (1 - abs(a)) * rf_daily - tc
        strat.append(sr)
        btc.append(br)
        allocs.append(a)
        prev = a
    return np.array(strat), np.array(btc), np.array(allocs)


def metrics(s, b, a, rf_daily=RF_DAILY_DEFAULT):
    if len(s) < 10:
        return None
    ts = np.prod(1 + s) - 1
    tb = np.prod(1 + b) - 1
    ex = s - rf_daily
    ds = ex[ex < 0]
    sortino = np.mean(ex) / (np.std(ds) + 1e-10) * np.sqrt(365) if len(ds) > 0 else 0
    cum = np.cumprod(1 + s)
    pk = np.maximum.accumulate(cum)
    dd = np.min((cum - pk) / (pk + 1e-10))
    return {'total': ts, 'btc': tb, 'excess': ts - tb, 'sortino': sortino,
            'max_dd': dd, 'short_pct': float((a < 0).mean()), 'avg_alloc': float(np.mean(a))}


def get_year_boundaries(dates, n):
    yb = {}
    for i in range(n):
        yr = pd.Timestamp(dates[i]).year
        if yr not in yb:
            yb[yr] = {'start': i, 'end': i}
        yb[yr]['end'] = i
    return yb


# ============================================================
# MOMENTUM STRATEGY
# ============================================================

def strategy_fn(slow_ret, fast_ret, vol, p):
    bear_s, bear_f, bull_s = p[0], p[1], p[2]
    a_min, a_max, a_mid = p[3], p[4], p[5]
    sl_bear, sl_bull = p[6], p[7]
    v_thresh, v_damp = p[8], p[9]

    if slow_ret < bear_s and fast_ret < bear_f:
        base = a_min
    elif slow_ret < bear_s * 0.5 and fast_ret < bear_f * 0.5:
        t = np.clip(slow_ret / (bear_s + 1e-10), 0, 2)
        base = a_mid + (a_min - a_mid) * min(t * sl_bear, 1.0)
    elif slow_ret < 0 and fast_ret < bear_f * 0.5:
        t = np.clip(slow_ret / (bear_s * 0.5 + 1e-10), 0, 1)
        base = a_mid * (1 - t * 0.5)
    elif slow_ret > bull_s:
        base = a_max
    elif slow_ret > 0:
        t = np.clip(slow_ret / (bull_s + 1e-10), 0, 1)
        base = a_mid + (a_max - a_mid) * (t ** (1.0 / max(sl_bull, 0.1)))
    else:
        base = a_mid

    if vol > v_thresh:
        excess = (vol - v_thresh) / (v_thresh + 1e-10)
        damp = min(v_damp * excess, 0.5)
        if base > 0:
            base *= (1 - damp)
        else:
            base *= (1 + damp * 0.5)

    return np.clip(base, -0.25, 1.0)


def optimize_params(daily_ret, slow_sig, fast_sig, vol_sig, start_idx, end_idx,
                    n_trials=2000, cost=COST_DEFAULT, rf_daily=RF_DAILY_DEFAULT):
    ranges = {
        'bear_slow': (-0.15, -0.04), 'bear_fast': (-0.06, -0.01),
        'bull': (0.05, 0.30), 'alloc_min': (-0.25, -0.05),
        'alloc_max': (0.80, 1.0), 'alloc_mid': (0.25, 0.65),
        'slope_bear': (0.3, 2.5), 'slope_bull': (0.3, 2.5),
        'vol_thresh': (0.015, 0.05), 'vol_damp': (0.05, 0.55),
    }

    best_score, best_params = -999, None
    n = len(daily_ret)

    for _ in range(n_trials):
        p = [np.random.uniform(*ranges[k]) for k in
             ['bear_slow', 'bear_fast', 'bull', 'alloc_min', 'alloc_max',
              'alloc_mid', 'slope_bear', 'slope_bull', 'vol_thresh', 'vol_damp']]

        allocs = np.full(n, 0.5)
        for t in range(max(start_idx, 60), end_idx + 1):
            allocs[t] = strategy_fn(slow_sig[t], fast_sig[t], vol_sig[t], p)

        s, b, a = backtest_allocations(daily_ret, allocs, max(start_idx, 60), end_idx,
                                       cost=cost, rf_daily=rf_daily)
        m = metrics(s, b, a, rf_daily=rf_daily)
        if m is None:
            continue

        score = m['total'] * 2 + m['sortino'] * 0.3 + m['excess'] * 0.5 + m['max_dd'] * 0.3
        if score > best_score:
            best_score = score
            best_params = p[:]

    return best_params


# ============================================================
# ML FEATURES (V2: 25 features)
# ============================================================

def build_ml_features(df, returns, vols, n):
    feature_cols = [
        'cusum_pos', 'miners_revenue_ratio', 'mr_score_30d', 'adx',
        'cusum_neg', 'exchange_netflow_ma7', 'structural_break_score',
        'macd_histogram', 'eth_btc_ratio', 'm2_yoy_growth',
        'volatility_7d', 'basis_ma7', 'nupl_ma30', 'hurst_60d',
        'funding_rate', 'bb_position', 'rsi_14d', 'puell_multiple',
        'stablecoin_zscore', 'sopr_ma7',
    ]
    available = [c for c in feature_cols if c in df.columns]
    X_all = df[available].values.astype(float)
    X_extra = np.column_stack([returns[3], returns[10], returns[30], returns[60], vols[14]])
    X_all = np.hstack([X_all, X_extra])
    feature_names = available + ['ret_3d', 'ret_10d', 'ret_30d', 'ret_60d', 'vol_14d']
    return X_all, feature_names


def build_ml_features_selected(df, returns, vols, n, selected_indices):
    """Build feature matrix using only selected feature indices."""
    X_all, feature_names = build_ml_features(df, returns, vols, n)
    X_sel = X_all[:, selected_indices]
    names_sel = [feature_names[i] for i in selected_indices]
    return X_sel, names_sel


# ============================================================
# ML MODEL TRAINING - BASE
# ============================================================

def train_lgb_model(X_all, target, train_end, horizon_gap=5, seed=42,
                    params_override=None):
    import lightgbm as lgb

    train_mask = np.arange(60, train_end - horizon_gap + 1)
    valid_train = ~np.any(np.isnan(X_all[train_mask]), axis=1)
    train_idx = train_mask[valid_train]

    if len(train_idx) < 100:
        return None

    X_train = np.nan_to_num(X_all[train_idx], nan=0.0)
    y_train = target[train_idx]

    params = {
        'objective': 'regression', 'metric': 'mae',
        'num_leaves': 31, 'learning_rate': 0.05,
        'feature_fraction': 0.7, 'bagging_fraction': 0.8,
        'bagging_freq': 5, 'verbose': -1, 'n_jobs': 1,
        'seed': seed,
    }

    num_boost_round = 200
    if params_override:
        if 'num_boost_round' in params_override:
            num_boost_round = params_override.pop('num_boost_round')
        params.update(params_override)

    dtrain = lgb.Dataset(X_train, label=y_train)
    return lgb.train(params, dtrain, num_boost_round=num_boost_round)


def train_lgb_bagged(X_all, target, train_end, horizon_gap=5, n_bags=5,
                     params_override=None):
    models = []
    for i in range(n_bags):
        seed = 42 + i * 7
        m = train_lgb_model(X_all, target, train_end, horizon_gap=horizon_gap,
                            seed=seed,
                            params_override=dict(params_override) if params_override else None)
        if m is not None:
            models.append(m)
    return models if len(models) > 0 else None


def ml_predict_bagged(models, X_all, t):
    x_t = np.nan_to_num(X_all[t:t+1].copy(), nan=0.0)
    preds = [m.predict(x_t)[0] for m in models]
    avg_pred = np.mean(preds)
    scaled = np.clip(avg_pred / 0.05, -1.0, 1.0)
    if scaled > 0:
        return 0.5 + scaled * 0.5
    else:
        return 0.5 + scaled * 0.75


# ============================================================
# APPROACH 1: OPTUNA HYPERPARAMETER TUNING
# ============================================================

def create_ts_cv_splits(n_samples, n_splits=3):
    """Create time-series cross-validation splits (expanding window)."""
    splits = []
    min_train = max(100, n_samples // (n_splits + 1))
    fold_size = (n_samples - min_train) // n_splits

    for i in range(n_splits):
        train_end = min_train + i * fold_size
        val_start = train_end
        val_end = min(val_start + fold_size, n_samples)
        if val_end <= val_start:
            continue
        splits.append((np.arange(0, train_end), np.arange(val_start, val_end)))
    return splits


def objective_lgb(trial, X_train_full, y_train_full):
    """Optuna objective: 3-fold time-series CV MAE."""
    import lightgbm as lgb

    params = {
        'objective': 'regression', 'metric': 'mae',
        'num_leaves': trial.suggest_int('num_leaves', 15, 63),
        'learning_rate': trial.suggest_float('learning_rate', 0.01, 0.15, log=True),
        'min_child_samples': trial.suggest_int('min_child_samples', 5, 50),
        'reg_alpha': trial.suggest_float('reg_alpha', 1e-5, 10.0, log=True),
        'reg_lambda': trial.suggest_float('reg_lambda', 1e-5, 10.0, log=True),
        'feature_fraction': trial.suggest_float('feature_fraction', 0.4, 0.9),
        'bagging_fraction': 0.8,
        'bagging_freq': 5,
        'verbose': -1, 'n_jobs': 1, 'seed': 42,
    }
    num_boost_round = trial.suggest_int('num_boost_round', 100, 400)

    splits = create_ts_cv_splits(len(X_train_full), n_splits=3)
    if len(splits) == 0:
        return 1e10

    mae_scores = []
    for train_idx, val_idx in splits:
        X_tr, y_tr = X_train_full[train_idx], y_train_full[train_idx]
        X_val, y_val = X_train_full[val_idx], y_train_full[val_idx]

        dtrain = lgb.Dataset(X_tr, label=y_tr)
        dval = lgb.Dataset(X_val, label=y_val, reference=dtrain)

        model = lgb.train(
            params, dtrain, num_boost_round=num_boost_round,
            valid_sets=[dval], valid_names=['val'],
            callbacks=[lgb.early_stopping(20, verbose=False)]
        )
        preds = model.predict(X_val)
        mae_scores.append(np.mean(np.abs(preds - y_val)))

    return np.mean(mae_scores)


def optuna_tune_lgb(X_all, target, train_end, horizon_gap=5, n_trials=50, seed=42):
    """Run Optuna to find best LGB hyperparameters on training data."""
    if not HAS_OPTUNA:
        return None

    train_mask = np.arange(60, train_end - horizon_gap + 1)
    valid_train = ~np.any(np.isnan(X_all[train_mask]), axis=1)
    train_idx = train_mask[valid_train]

    if len(train_idx) < 200:
        return None

    X_train = np.nan_to_num(X_all[train_idx], nan=0.0)
    y_train = target[train_idx]

    sampler = optuna.samplers.TPESampler(seed=seed)
    study = optuna.create_study(direction='minimize', sampler=sampler)
    study.optimize(lambda trial: objective_lgb(trial, X_train, y_train),
                   n_trials=n_trials, show_progress_bar=False)

    best = study.best_params
    # Convert to LGB-compatible format
    params_override = {
        'num_leaves': best['num_leaves'],
        'learning_rate': best['learning_rate'],
        'min_child_samples': best['min_child_samples'],
        'reg_alpha': best['reg_alpha'],
        'reg_lambda': best['reg_lambda'],
        'feature_fraction': best['feature_fraction'],
        'num_boost_round': best['num_boost_round'],
    }
    return params_override


# ============================================================
# APPROACH 2: SHAP FEATURE PRUNING
# ============================================================

def compute_feature_importance(models, X_all, train_end, feature_names):
    """Compute feature importance using SHAP (with LGB fallback)."""
    if HAS_SHAP and len(models) > 0:
        # Use SHAP TreeExplainer on first model
        try:
            train_mask = np.arange(60, min(train_end + 1, len(X_all)))
            X_sample = np.nan_to_num(X_all[train_mask[-500:]], nan=0.0)  # Last 500 training points

            explainer = shap.TreeExplainer(models[0])
            shap_values = explainer.shap_values(X_sample)
            importance = np.mean(np.abs(shap_values), axis=0)

            result = {}
            for i, name in enumerate(feature_names):
                if i < len(importance):
                    result[name] = float(importance[i])
            return result
        except Exception:
            pass  # Fall through to LGB importance

    # Fallback: average LGB feature_importance across all bag models
    if len(models) == 0:
        return {name: 1.0 for name in feature_names}

    importances = np.zeros(len(feature_names))
    for m in models:
        imp = m.feature_importance(importance_type='gain')
        if len(imp) == len(feature_names):
            importances += imp

    importances /= max(len(models), 1)
    result = {}
    for i, name in enumerate(feature_names):
        if i < len(importances):
            result[name] = float(importances[i])
    return result


# ============================================================
# APPROACH 4: TARGET ENGINEERING
# ============================================================

def build_target_5d(prices, n):
    target = np.zeros(n)
    for i in range(n - 5):
        target[i] = (prices[i + 5] - prices[i]) / prices[i]
    return target


def build_target_10d(prices, n):
    target = np.zeros(n)
    for i in range(n - 10):
        target[i] = (prices[i + 10] - prices[i]) / prices[i]
    return target


def build_target_risk_adjusted(prices, daily_ret, vols, n):
    """Target = ret_5d / vol_5d, clipped to [-3, 3]."""
    ret_5d = build_target_5d(prices, n)
    vol_5d = vols[5]
    target = np.zeros(n)
    for i in range(n):
        v = vol_5d[i] * np.sqrt(5) if vol_5d[i] > 0.001 else 0.02 * np.sqrt(5)
        target[i] = np.clip(ret_5d[i] / v, -3.0, 3.0)
    return target


# ============================================================
# APPROACH 4b: QUANTILE REGRESSION
# ============================================================

def train_lgb_quantile(X_all, target, train_end, horizon_gap=5, seed=42, alpha=0.5):
    """Train LGB with quantile objective (median regression)."""
    import lightgbm as lgb

    train_mask = np.arange(60, train_end - horizon_gap + 1)
    valid_train = ~np.any(np.isnan(X_all[train_mask]), axis=1)
    train_idx = train_mask[valid_train]

    if len(train_idx) < 100:
        return None

    X_train = np.nan_to_num(X_all[train_idx], nan=0.0)
    y_train = target[train_idx]

    params = {
        'objective': 'quantile', 'alpha': alpha,
        'metric': 'quantile',
        'num_leaves': 31, 'learning_rate': 0.05,
        'feature_fraction': 0.7, 'bagging_fraction': 0.8,
        'bagging_freq': 5, 'verbose': -1, 'n_jobs': 1,
        'seed': seed,
    }

    dtrain = lgb.Dataset(X_train, label=y_train)
    return lgb.train(params, dtrain, num_boost_round=200)


def train_lgb_quantile_bagged(X_all, target, train_end, horizon_gap=5, n_bags=5, alpha=0.5):
    models = []
    for i in range(n_bags):
        seed = 42 + i * 7
        m = train_lgb_quantile(X_all, target, train_end, horizon_gap=horizon_gap,
                               seed=seed, alpha=alpha)
        if m is not None:
            models.append(m)
    return models if len(models) > 0 else None


# ============================================================
# APPROACH 5: LINEAR ENSEMBLE
# ============================================================

def train_ridge_model(X_all, target, train_end, horizon_gap=5, seed=42):
    """Train Ridge regression with StandardScaler."""
    from sklearn.linear_model import Ridge
    from sklearn.preprocessing import StandardScaler

    train_mask = np.arange(60, train_end - horizon_gap + 1)
    valid_train = ~np.any(np.isnan(X_all[train_mask]), axis=1)
    train_idx = train_mask[valid_train]

    if len(train_idx) < 100:
        return None, None

    X_train = np.nan_to_num(X_all[train_idx], nan=0.0)
    y_train = target[train_idx]

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X_train)

    model = Ridge(alpha=1.0, random_state=seed)
    model.fit(X_scaled, y_train)
    return model, scaler


def train_elasticnet_model(X_all, target, train_end, horizon_gap=5, seed=42):
    """Train ElasticNet regression with StandardScaler."""
    from sklearn.linear_model import ElasticNet
    from sklearn.preprocessing import StandardScaler

    train_mask = np.arange(60, train_end - horizon_gap + 1)
    valid_train = ~np.any(np.isnan(X_all[train_mask]), axis=1)
    train_idx = train_mask[valid_train]

    if len(train_idx) < 100:
        return None, None

    X_train = np.nan_to_num(X_all[train_idx], nan=0.0)
    y_train = target[train_idx]

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X_train)

    model = ElasticNet(alpha=0.001, l1_ratio=0.5, random_state=seed, max_iter=5000)
    model.fit(X_scaled, y_train)
    return model, scaler


def predict_linear(model, scaler, X_all, t):
    """Predict with linear model -> allocation float."""
    x_t = np.nan_to_num(X_all[t:t+1].copy(), nan=0.0)
    x_scaled = scaler.transform(x_t)
    pred = model.predict(x_scaled)[0]
    scaled = np.clip(pred / 0.05, -1.0, 1.0)
    if scaled > 0:
        return 0.5 + scaled * 0.5
    else:
        return 0.5 + scaled * 0.75


# ============================================================
# APPROACH 6: ASYMMETRIC BULL/BEAR MODELS
# ============================================================

def build_target_bull_bear(prices, n):
    """Separate bull (positive) and bear (negative) targets."""
    ret_5d = build_target_5d(prices, n)
    target_bull = np.maximum(ret_5d, 0.0)
    target_bear = np.minimum(ret_5d, 0.0)
    return target_bull, target_bear


def predict_asymmetric(bull_models, bear_models, X_all, t):
    """Use bull model for sizing long, bear model for gating short."""
    x_t = np.nan_to_num(X_all[t:t+1].copy(), nan=0.0)

    # Bull prediction (positive side)
    bull_preds = [m.predict(x_t)[0] for m in bull_models]
    bull_pred = np.mean(bull_preds)

    # Bear prediction (negative side, values <= 0)
    bear_preds = [m.predict(x_t)[0] for m in bear_models]
    bear_pred = np.mean(bear_preds)

    # Net signal: bull - |bear|
    net = bull_pred + bear_pred  # bear_pred is negative
    scaled = np.clip(net / 0.05, -1.0, 1.0)

    if scaled > 0:
        # Use bull prediction for long sizing
        bull_scaled = np.clip(bull_pred / 0.05, 0.0, 1.0)
        return 0.5 + bull_scaled * 0.5
    else:
        # Use bear prediction for short gating
        bear_scaled = np.clip(bear_pred / 0.05, -1.0, 0.0)
        if bear_scaled < -0.3:  # Strong bear signal
            return 0.5 + scaled * 0.75
        else:
            return 0.3  # Mild bear -> reduced allocation, no short


# ============================================================
# WALK-FORWARD V4 ENGINE
# ============================================================

def walk_forward_v4(daily_ret, returns, vols, df, dates, n,
                    config, label="V4",
                    cost=COST_DEFAULT, rf_daily=RF_DAILY_DEFAULT,
                    verbose=True):
    """Generic walk-forward engine for V4 approaches.

    config dict keys:
        approach: str - one of 'baseline', 'optuna', 'shap_prune', 'larger_bag',
                       'target_10d', 'quantile', 'risk_adj_target',
                       'ridge_ensemble', 'elasticnet_ensemble', 'asymmetric'
        n_bags: int - number of bag models (default 5)
        optuna_trials: int - number of Optuna trials (for 'optuna')
        shap_top_k: int - number of top features to keep (for 'shap_prune')
        params_override: dict - LGB params override

    Returns: (result_dict, strat_rets, btc_rets, alloc_array, full_allocs, test_ranges, extra_info)
    """

    approach = config.get('approach', 'baseline')
    n_bags = config.get('n_bags', 5)

    yb = get_year_boundaries(dates, n)
    slow_sig, fast_sig, vol_sig = returns[60], returns[3], vols[14]
    prices = df['price_usd'].values

    X_all, feature_names = build_ml_features(df, returns, vols, n)

    # Build targets
    target_5d = build_target_5d(prices, n)
    target_10d = build_target_10d(prices, n) if approach == 'target_10d' else None
    target_ra = build_target_risk_adjusted(prices, daily_ret, vols, n) if approach == 'risk_adj_target' else None
    target_bull, target_bear = (build_target_bull_bear(prices, n)
                                if approach == 'asymmetric' else (None, None))

    day_of_week = pd.to_datetime(dates).dayofweek

    all_strat, all_btc, all_alloc = [], [], []
    full_allocs = np.full(n, 0.5)
    test_ranges = []
    extra_info = {}  # Store per-year details (Optuna params, SHAP features, etc.)

    for test_year in range(2022, 2027):
        if test_year not in yb:
            continue
        train_end = yb[test_year]['start'] - 1
        test_start = yb[test_year]['start']
        test_end = yb[test_year]['end']

        np.random.seed(42 + test_year)
        if verbose:
            P(f"    {test_year}: optimizing momentum...", end="")
        mom_params = optimize_params(daily_ret, slow_sig, fast_sig, vol_sig,
                                     60, train_end, 2000, cost=cost, rf_daily=rf_daily)
        if mom_params is None:
            if verbose:
                P(" FAILED")
            continue

        # ---- Approach-specific ML training ----
        models = None
        linear_model = None
        linear_scaler = None
        bull_models = None
        bear_models = None
        X_current = X_all  # May be pruned for SHAP
        year_info = {}

        if approach == 'optuna':
            optuna_trials = config.get('optuna_trials', 50)
            if HAS_OPTUNA:
                if verbose:
                    P(f" Optuna({optuna_trials})...", end="")
                params_ov = optuna_tune_lgb(X_all, target_5d, train_end,
                                            n_trials=optuna_trials, seed=42 + test_year)
                if params_ov:
                    year_info['optuna_params'] = params_ov
                    models = train_lgb_bagged(X_all, target_5d, train_end,
                                              n_bags=n_bags, params_override=params_ov)
                else:
                    models = train_lgb_bagged(X_all, target_5d, train_end, n_bags=n_bags)
            else:
                P(" [Optuna not installed, using defaults]...", end="")
                models = train_lgb_bagged(X_all, target_5d, train_end, n_bags=n_bags)

        elif approach == 'shap_prune':
            shap_top_k = config.get('shap_top_k', 15)
            # Step 1: Train full model to get importances
            full_models = train_lgb_bagged(X_all, target_5d, train_end, n_bags=n_bags)
            if full_models:
                importance_dict = compute_feature_importance(
                    full_models, X_all, train_end, feature_names)
                # Sort by importance, select top-K
                sorted_feats = sorted(importance_dict.items(), key=lambda x: x[1], reverse=True)
                top_k_names = [f[0] for f in sorted_feats[:shap_top_k]]
                selected_indices = [feature_names.index(fn) for fn in top_k_names
                                    if fn in feature_names]
                year_info['selected_features'] = top_k_names
                if verbose:
                    P(f" SHAP top-{shap_top_k}: {top_k_names[:5]}...", end="")

                # Step 2: Retrain with pruned features
                X_pruned, _ = build_ml_features_selected(
                    df, returns, vols, n, selected_indices)
                models = train_lgb_bagged(X_pruned, target_5d, train_end, n_bags=n_bags)
                X_current = X_pruned
            else:
                models = train_lgb_bagged(X_all, target_5d, train_end, n_bags=n_bags)

        elif approach == 'larger_bag':
            if verbose:
                P(f" training {n_bags} LGB models...", end="")
            models = train_lgb_bagged(X_all, target_5d, train_end, n_bags=n_bags)

        elif approach == 'target_10d':
            if verbose:
                P(f" training {n_bags} LGB(target=10d)...", end="")
            models = train_lgb_bagged(X_all, target_10d, train_end,
                                      horizon_gap=10, n_bags=n_bags)

        elif approach == 'quantile':
            if verbose:
                P(f" training {n_bags} LGB(quantile)...", end="")
            models = train_lgb_quantile_bagged(X_all, target_5d, train_end,
                                               n_bags=n_bags, alpha=0.5)

        elif approach == 'risk_adj_target':
            if verbose:
                P(f" training {n_bags} LGB(risk-adj target)...", end="")
            models = train_lgb_bagged(X_all, target_ra, train_end, n_bags=n_bags)

        elif approach == 'ridge_ensemble':
            if verbose:
                P(f" training {n_bags} LGB + Ridge...", end="")
            models = train_lgb_bagged(X_all, target_5d, train_end, n_bags=n_bags)
            linear_model, linear_scaler = train_ridge_model(
                X_all, target_5d, train_end, seed=42 + test_year)

        elif approach == 'elasticnet_ensemble':
            if verbose:
                P(f" training {n_bags} LGB + ElasticNet...", end="")
            models = train_lgb_bagged(X_all, target_5d, train_end, n_bags=n_bags)
            linear_model, linear_scaler = train_elasticnet_model(
                X_all, target_5d, train_end, seed=42 + test_year)

        elif approach == 'asymmetric':
            if verbose:
                P(f" training {n_bags} bull + {n_bags} bear models...", end="")
            bull_models = train_lgb_bagged(X_all, target_bull, train_end, n_bags=n_bags)
            bear_models = train_lgb_bagged(X_all, target_bear, train_end, n_bags=n_bags)

        else:  # baseline
            if verbose:
                P(f" training {n_bags} LGB models...", end="")
            models = train_lgb_bagged(X_all, target_5d, train_end, n_bags=n_bags)

        if verbose:
            n_ok = 0
            if models:
                n_ok = len(models)
            elif bull_models:
                n_ok = len(bull_models)
            P(f" ({n_ok} ok)...", end="")

        if year_info:
            extra_info[str(test_year)] = year_info

        # ---- TEST LOOP ----
        prev_alloc = 0.5

        for t in range(test_start, test_end + 1):
            a_mom = strategy_fn(slow_sig[t], fast_sig[t], vol_sig[t], mom_params)

            # ML allocation based on approach
            if approach == 'asymmetric':
                if bull_models and bear_models:
                    a_ml = predict_asymmetric(bull_models, bear_models, X_all, t)
                else:
                    a_ml = a_mom
            elif approach in ('ridge_ensemble', 'elasticnet_ensemble'):
                if models is not None:
                    a_lgb = ml_predict_bagged(models, X_current, t)
                    if linear_model is not None and linear_scaler is not None:
                        a_linear = predict_linear(linear_model, linear_scaler, X_all, t)
                        # ML component = average of LGB bag and linear model
                        a_ml = 0.5 * a_lgb + 0.5 * a_linear
                    else:
                        a_ml = a_lgb
                else:
                    a_ml = a_mom
            elif approach == 'risk_adj_target':
                # Risk-adjusted target has different scale, adjust scaling
                if models is not None:
                    x_t = np.nan_to_num(X_current[t:t+1].copy(), nan=0.0)
                    preds = [m.predict(x_t)[0] for m in models]
                    avg_pred = np.mean(preds)
                    # Scale: risk-adj target in [-3, 3], map to allocation
                    scaled = np.clip(avg_pred / 1.5, -1.0, 1.0)
                    if scaled > 0:
                        a_ml = 0.5 + scaled * 0.5
                    else:
                        a_ml = 0.5 + scaled * 0.75
                else:
                    a_ml = a_mom
            else:
                if models is not None:
                    a_ml = ml_predict_bagged(models, X_current, t)
                else:
                    a_ml = a_mom

            # 50% Mom + 50% ML hybrid
            raw_alloc = 0.5 * a_mom + 0.5 * a_ml

            # Weekly rebalance (always on, same as V2 baseline)
            if day_of_week[t] != 4:  # Not Friday
                raw_alloc = prev_alloc

            full_allocs[t] = np.clip(raw_alloc, -0.25, 1.0)
            prev_alloc = full_allocs[t]

        test_ranges.append((test_start, test_end))
        s, b, a = backtest_allocations(daily_ret, full_allocs, test_start, test_end,
                                       cost=cost, rf_daily=rf_daily)
        all_strat.extend(s)
        all_btc.extend(b)
        all_alloc.extend(a)

        m_yr = metrics(np.array(s), np.array(b), np.array(a), rf_daily=rf_daily)
        if verbose and m_yr:
            P(f" {m_yr['total']*100:+.1f}% (BTC {m_yr['btc']*100:+.1f}%)")

    result = metrics(np.array(all_strat), np.array(all_btc), np.array(all_alloc),
                     rf_daily=rf_daily)
    return (result, np.array(all_strat), np.array(all_btc), np.array(all_alloc),
            full_allocs, test_ranges, extra_info)


# ============================================================
# BOOTSTRAP CONFIDENCE INTERVALS
# ============================================================

def bootstrap_ci(daily_returns, n_bootstrap=1000, ci=0.95):
    n = len(daily_returns)
    if n < 30:
        return None

    rng = np.random.RandomState(42)
    total_returns = []
    sortinos = []

    for _ in range(n_bootstrap):
        idx = rng.choice(n, size=n, replace=True)
        resampled = daily_returns[idx]
        total = np.prod(1 + resampled) - 1
        total_returns.append(total)

        ex = resampled - RF_DAILY_DEFAULT
        ds = ex[ex < 0]
        if len(ds) > 2:
            sortino = np.mean(ex) / (np.std(ds) + 1e-10) * np.sqrt(365)
        else:
            sortino = 0.0
        sortinos.append(sortino)

    alpha = (1 - ci) / 2
    lo, hi = alpha * 100, (1 - alpha) * 100

    return {
        'return_mean': np.mean(total_returns),
        'return_lo': np.percentile(total_returns, lo),
        'return_hi': np.percentile(total_returns, hi),
        'return_std': np.std(total_returns),
        'sortino_mean': np.mean(sortinos),
        'sortino_lo': np.percentile(sortinos, lo),
        'sortino_hi': np.percentile(sortinos, hi),
        'excess_above_zero_pct': np.mean([r > 0 for r in total_returns]) * 100,
    }


# ============================================================
# COST/RF SENSITIVITY
# ============================================================

def cost_rf_sensitivity(daily_ret, full_allocs, test_ranges):
    costs_bps = [1, 2, 5, 10]
    rf_annuals = [0.05, 0.10, 0.15]

    results = {}
    for cost_bps in costs_bps:
        for rf_ann in rf_annuals:
            cost = cost_bps / 10000.0
            rf_d = (1 + rf_ann)**(1/365) - 1
            label = f"cost={cost_bps}bps_rf={int(rf_ann*100)}%"

            all_s, all_b, all_a = [], [], []
            for (start, end) in test_ranges:
                s, b, a = backtest_allocations(daily_ret, full_allocs, start, end,
                                               cost=cost, rf_daily=rf_d)
                all_s.extend(s)
                all_b.extend(b)
                all_a.extend(a)

            r = metrics(np.array(all_s), np.array(all_b), np.array(all_a), rf_daily=rf_d)
            if r:
                results[label] = r
    return results


# ============================================================
# CHARTS
# ============================================================

def generate_charts_v4(all_results, all_equity_curves, bootstrap_results, chart_dir):
    chart_dir.mkdir(parents=True, exist_ok=True)

    # --- Chart 1: Bar comparison ---
    fig, axes = plt.subplots(2, 1, figsize=(24, 16))

    names, ret_vals, sortino_vals, maxdd_vals, colors_list = [], [], [], [], []
    cmap = plt.cm.tab20
    for i, (name, r) in enumerate(all_results.items()):
        if r is None:
            continue
        names.append(name)
        ret_vals.append(r['total'] * 100)
        sortino_vals.append(r['sortino'])
        maxdd_vals.append(r['max_dd'] * 100)
        if name == 'BTC Buy & Hold':
            colors_list.append('#F7931A')
        elif 'V2 Baseline' in name:
            colors_list.append('#4A90D9')
        elif 'V4 Best' in name:
            colors_list.append('#E74C3C')
        else:
            colors_list.append(cmap(i / max(len(all_results), 1)))

    x = np.arange(len(names))

    ax = axes[0]
    bars = ax.bar(x, ret_vals, color=colors_list, alpha=0.85, edgecolor='black', linewidth=0.5)
    for v, bar in zip(ret_vals, bars):
        ax.text(bar.get_x() + bar.get_width()/2, v + (5 if v >= 0 else -12),
                f'{v:+.0f}%', ha='center', fontsize=7, fontweight='bold')
    ax.set_xticks(x)
    ax.set_xticklabels(names, fontsize=6, rotation=40, ha='right')
    ax.axhline(y=0, color='black', lw=0.5)
    ax.set_title('Pipeline V4 Exploration: OOS Returns (Walk-Forward 2022-2026)',
                 fontsize=13, fontweight='bold')
    ax.set_ylabel('Total Return %')
    ax.grid(True, alpha=0.3, axis='y')

    ax = axes[1]
    width = 0.35
    ax.bar(x - width/2, sortino_vals, width, color=colors_list, alpha=0.7,
           edgecolor='black', linewidth=0.5, label='Sortino')
    bars2 = ax.bar(x + width/2, maxdd_vals, width, color=colors_list, alpha=0.4,
                   edgecolor='black', linewidth=0.5, label='Max Drawdown %')
    for v, bar in zip(sortino_vals, ax.patches[:len(names)]):
        ax.text(bar.get_x() + bar.get_width()/2, v + 0.03,
                f'{v:.2f}', ha='center', fontsize=6, fontweight='bold')
    for v, bar in zip(maxdd_vals, bars2):
        ax.text(bar.get_x() + bar.get_width()/2, v - 3,
                f'{v:.0f}%', ha='center', fontsize=6, fontweight='bold')
    ax.set_xticks(x)
    ax.set_xticklabels(names, fontsize=6, rotation=40, ha='right')
    ax.axhline(y=0, color='black', lw=0.5)
    ax.set_title('Sortino Ratio & Max Drawdown', fontsize=13, fontweight='bold')
    ax.legend(fontsize=10)
    ax.grid(True, alpha=0.3, axis='y')

    plt.tight_layout()
    plt.savefig(chart_dir / 'pipeline_v4_comparison.png', dpi=150, bbox_inches='tight')
    plt.close()
    P(f"  Chart saved: {chart_dir / 'pipeline_v4_comparison.png'}")

    # --- Chart 2: Equity curves ---
    if len(all_equity_curves) > 1:
        fig, axes = plt.subplots(2, 1, figsize=(18, 12), gridspec_kw={'height_ratios': [3, 1]})

        key_curves = ['BTC Buy & Hold', 'V2 Baseline (Bag5+Weekly)']
        # Add top 3 by return
        sorted_by_ret = sorted(
            [(name, r) for name, r in all_results.items()
             if r is not None and name not in key_curves],
            key=lambda x: x[1]['total'], reverse=True
        )
        for name, _ in sorted_by_ret[:3]:
            key_curves.append(name)
        # Always include V4 Best Combo if it exists
        for name in all_results:
            if 'V4 Best' in name and name not in key_curves:
                key_curves.append(name)

        ax = axes[0]
        for name, (strat_rets, _) in all_equity_curves.items():
            if len(strat_rets) == 0:
                continue
            cum = np.cumprod(1 + strat_rets)
            lw = 2.5 if name in key_curves else 0.8
            alpha_val = 1.0 if name in key_curves else 0.35
            ls = '-' if name in key_curves else '--'
            ax.plot(cum, label=f"{name} ({(cum[-1]-1)*100:+.0f}%)",
                    linewidth=lw, alpha=alpha_val, linestyle=ls)
        ax.set_title('Equity Curves (Walk-Forward OOS 2022-2026)', fontsize=14, fontweight='bold')
        ax.set_ylabel('Cumulative Value ($1 start)')
        ax.legend(fontsize=6, loc='upper left', ncol=2)
        ax.grid(True, alpha=0.3)
        ax.set_yscale('log')

        ax = axes[1]
        for name in key_curves:
            if name in all_equity_curves and len(all_equity_curves[name][0]) > 0:
                strat_rets = all_equity_curves[name][0]
                cum = np.cumprod(1 + strat_rets)
                pk = np.maximum.accumulate(cum)
                dd = (cum - pk) / pk * 100
                ax.fill_between(range(len(dd)), dd, 0, alpha=0.3, label=name)
                ax.plot(dd, linewidth=0.8)
        ax.set_title('Drawdown (%)', fontsize=12, fontweight='bold')
        ax.set_ylabel('Drawdown %')
        ax.legend(fontsize=7)
        ax.grid(True, alpha=0.3)

        plt.tight_layout()
        plt.savefig(chart_dir / 'pipeline_v4_equity.png', dpi=150, bbox_inches='tight')
        plt.close()
        P(f"  Chart saved: {chart_dir / 'pipeline_v4_equity.png'}")

    # --- Chart 3: Bootstrap CI ---
    if bootstrap_results:
        fig, ax = plt.subplots(1, 1, figsize=(14, 6))
        bs_names, bs_means, bs_lo, bs_hi = [], [], [], []
        for name, bs in bootstrap_results.items():
            bs_names.append(name)
            bs_means.append(bs['return_mean'] * 100)
            bs_lo.append(bs['return_lo'] * 100)
            bs_hi.append(bs['return_hi'] * 100)

        x = np.arange(len(bs_names))
        ax.bar(x, bs_means, color='steelblue', alpha=0.7, edgecolor='black', linewidth=0.5)
        ax.errorbar(x, bs_means,
                    yerr=[np.array(bs_means) - np.array(bs_lo),
                          np.array(bs_hi) - np.array(bs_means)],
                    fmt='none', color='black', capsize=5, linewidth=2)
        for i, (m, lo, hi) in enumerate(zip(bs_means, bs_lo, bs_hi)):
            ax.text(i, hi + 5, f'{m:.0f}%\n[{lo:.0f}, {hi:.0f}]',
                    ha='center', fontsize=8, fontweight='bold')

        ax.set_xticks(x)
        ax.set_xticklabels(bs_names, fontsize=7, rotation=20, ha='right')
        ax.axhline(y=0, color='red', lw=1, ls='--', label='Zero return')
        ax.set_title('V4 Bootstrap 95% CI on Total Return (1000 resamples)',
                     fontsize=13, fontweight='bold')
        ax.set_ylabel('Total Return %')
        ax.legend()
        ax.grid(True, alpha=0.3, axis='y')

        plt.tight_layout()
        plt.savefig(chart_dir / 'pipeline_v4_bootstrap.png', dpi=150, bbox_inches='tight')
        plt.close()
        P(f"  Chart saved: {chart_dir / 'pipeline_v4_bootstrap.png'}")


# ============================================================
# MAIN
# ============================================================

def main():
    P("=" * 100)
    P("PIPELINE V4 EXPLORATION - Fundamentally Different Approaches")
    P("=" * 100)
    P(f"""
    V2 Best Combo (Bag5+Weekly) = +221% OOS (2022-2026).
    V3 tested 6 incremental improvements -> ALL failed to beat V2.
    V4 tests 6 FUNDAMENTALLY DIFFERENT approaches (14 variants):

    #1  Optuna HP Tuning    (50 trials)       - Auto-tune LGB hyperparameters per year
    #1b Optuna HP Tuning    (100 trials)      - More Optuna trials
    #2a SHAP Feature Prune  (top-10)          - Reduce features to most important
    #2b SHAP Feature Prune  (top-15)
    #2c SHAP Feature Prune  (top-20)
    #3a Larger Bag          (10 models)       - More ensemble diversity
    #3b Larger Bag          (20 models)
    #4a Target 10d Return                     - Longer horizon target
    #4b Quantile Regression (median)          - Robust to outliers
    #4c Risk-Adjusted Target (ret/vol)        - Predict Sharpe instead of return
    #5a Ridge Ensemble      (LGB + Ridge)     - Linear diversification
    #5b ElasticNet Ensemble (LGB + ElasticNet)
    #6  Asymmetric Bull/Bear                  - Separate models for up/down

    Optuna available: {HAS_OPTUNA}
    SHAP available: {HAS_SHAP}
    """)

    P("Loading data...")
    prices, daily_ret, returns, vols, df = load_data()
    dates = df['date'].values
    n = len(prices)
    P(f"  {n} days | {len(df.columns)} columns | {dates[0]} to {dates[-1]}")

    all_results = {}
    all_equity_curves = {}
    all_extra_info = {}
    bootstrap_results = {}

    # ---------------------------------------------------------
    # BTC Buy & Hold reference
    # ---------------------------------------------------------
    yb = get_year_boundaries(dates, n)
    bh_strat, bh_btc, bh_alloc = [], [], []
    for test_year in range(2022, 2027):
        if test_year not in yb:
            continue
        allocs_bh = np.full(n, 1.0)
        s, b, a = backtest_allocations(daily_ret, allocs_bh,
                                       yb[test_year]['start'], yb[test_year]['end'])
        bh_strat.extend(s); bh_btc.extend(b); bh_alloc.extend(a)
    bh_result = metrics(np.array(bh_strat), np.array(bh_btc), np.array(bh_alloc))
    all_results['BTC Buy & Hold'] = bh_result
    all_equity_curves['BTC Buy & Hold'] = (np.array(bh_strat), np.array(bh_btc))
    P(f"\n  BTC Buy & Hold: {bh_result['total']*100:+.1f}% | "
      f"Sortino: {bh_result['sortino']:.2f} | MaxDD: {bh_result['max_dd']*100:.1f}%")

    # ---------------------------------------------------------
    # V2 BASELINE: Bag5 + Weekly
    # ---------------------------------------------------------
    P(f"\n{'='*100}")
    P("  V2 BASELINE: Bag5 + Weekly Rebalance")
    P("  " + "-" * 60)
    r_v2, s_v2, b_v2, a_v2, allocs_v2, ranges_v2, _ = walk_forward_v4(
        daily_ret, returns, vols, df, dates, n,
        config={'approach': 'baseline', 'n_bags': 5},
        label="V2 Baseline")
    all_results['V2 Baseline (Bag5+Weekly)'] = r_v2
    all_equity_curves['V2 Baseline (Bag5+Weekly)'] = (s_v2, b_v2)
    if r_v2:
        P(f"  >> V2 BASELINE: {r_v2['total']*100:+.1f}% | Sortino: {r_v2['sortino']:.2f} | "
          f"MaxDD: {r_v2['max_dd']*100:.1f}% | AvgAlloc: {r_v2['avg_alloc']:.2f}")

    baseline_total = r_v2['total'] if r_v2 else 0
    baseline_sortino = r_v2['sortino'] if r_v2 else 0
    baseline_dd = r_v2['max_dd'] if r_v2 else -1

    # ==========================================================
    # 14 VARIANTS
    # ==========================================================

    variants = [
        # (label, config_dict)
        ('#1a Optuna 50 trials',
         {'approach': 'optuna', 'n_bags': 5, 'optuna_trials': 50}),

        ('#1b Optuna 100 trials',
         {'approach': 'optuna', 'n_bags': 5, 'optuna_trials': 100}),

        ('#2a SHAP top-10',
         {'approach': 'shap_prune', 'n_bags': 5, 'shap_top_k': 10}),

        ('#2b SHAP top-15',
         {'approach': 'shap_prune', 'n_bags': 5, 'shap_top_k': 15}),

        ('#2c SHAP top-20',
         {'approach': 'shap_prune', 'n_bags': 5, 'shap_top_k': 20}),

        ('#3a Bag10+Weekly',
         {'approach': 'larger_bag', 'n_bags': 10}),

        ('#3b Bag20+Weekly',
         {'approach': 'larger_bag', 'n_bags': 20}),

        ('#4a Target 10d',
         {'approach': 'target_10d', 'n_bags': 5}),

        ('#4b Quantile Regression',
         {'approach': 'quantile', 'n_bags': 5}),

        ('#4c Risk-Adj Target',
         {'approach': 'risk_adj_target', 'n_bags': 5}),

        ('#5a Ridge Ensemble',
         {'approach': 'ridge_ensemble', 'n_bags': 5}),

        ('#5b ElasticNet Ensemble',
         {'approach': 'elasticnet_ensemble', 'n_bags': 5}),

        ('#6 Asymmetric Bull/Bear',
         {'approach': 'asymmetric', 'n_bags': 5}),
    ]

    variant_results = {}  # name -> (result, strat_rets, full_allocs, test_ranges, extra)

    for label, config in variants:
        P(f"\n{'='*100}")
        P(f"  {label}")
        P("  " + "-" * 60)

        r, s, b, a, fallocs, tranges, extra = walk_forward_v4(
            daily_ret, returns, vols, df, dates, n,
            config=config, label=label)

        all_results[label] = r
        all_equity_curves[label] = (s, b)
        variant_results[label] = (r, s, fallocs, tranges, extra)
        if extra:
            all_extra_info[label] = extra

        if r:
            delta = (r['total'] - baseline_total) * 100
            P(f"  >> TOTAL: {r['total']*100:+.1f}% | Sortino: {r['sortino']:.2f} | "
              f"MaxDD: {r['max_dd']*100:.1f}% | vs V2: {delta:+.1f}pp")

    # ---------------------------------------------------------
    # V4 BEST COMBO: combine winners
    # ---------------------------------------------------------
    P(f"\n{'='*100}")
    P("  V4 BEST COMBO (all variants that beat V2 in return OR Sortino)")
    P("  " + "-" * 60)

    winners_return = []
    winners_sortino = []

    for label, (r, s, fallocs, tranges, extra) in variant_results.items():
        if r is None:
            continue
        if r['total'] > baseline_total:
            winners_return.append((label, r))
        if r['sortino'] > baseline_sortino:
            winners_sortino.append((label, r))

    P("    Winners by return:")
    for name, r in sorted(winners_return, key=lambda x: x[1]['total'], reverse=True):
        imp = (r['total'] - baseline_total) * 100
        P(f"      {name}: {r['total']*100:+.1f}% ({imp:+.1f}pp)")

    P("    Winners by Sortino:")
    for name, r in sorted(winners_sortino, key=lambda x: x[1]['sortino'], reverse=True):
        P(f"      {name}: Sortino {r['sortino']:.2f}")

    # Determine best single variant by total return
    all_variant_results = [(label, r) for label, (r, _, _, _, _) in variant_results.items()
                           if r is not None]
    if all_variant_results:
        best_single = max(all_variant_results, key=lambda x: x[1]['total'])
        P(f"\n    Best single variant: {best_single[0]} ({best_single[1]['total']*100:+.1f}%)")

    # For best combo: take the approach of the best-return winner and combine
    # with best-sortino winner's approach if different
    # Since approaches are fundamentally different, we combine by averaging allocations
    winner_labels = list(set(
        [name for name, _ in winners_return] + [name for name, _ in winners_sortino]
    ))

    best_combo_result = None
    best_combo_strat = None
    best_combo_allocs = None
    best_combo_ranges = None

    if len(winner_labels) >= 2:
        P(f"\n    Combining {len(winner_labels)} winners by averaging allocations...")

        # Average allocations from all winners
        winner_alloc_arrays = []
        winner_range_list = None
        for label in winner_labels:
            r, s, fallocs, tranges, extra = variant_results[label]
            winner_alloc_arrays.append(fallocs)
            if winner_range_list is None:
                winner_range_list = tranges

        avg_allocs = np.mean(winner_alloc_arrays, axis=0)

        # Backtest averaged allocations
        all_s_combo, all_b_combo, all_a_combo = [], [], []
        for (start, end) in winner_range_list:
            s, b, a = backtest_allocations(daily_ret, avg_allocs, start, end)
            all_s_combo.extend(s)
            all_b_combo.extend(b)
            all_a_combo.extend(a)

        best_combo_result = metrics(np.array(all_s_combo), np.array(all_b_combo),
                                    np.array(all_a_combo))
        best_combo_strat = np.array(all_s_combo)
        best_combo_allocs = avg_allocs
        best_combo_ranges = winner_range_list

    elif len(winner_labels) == 1:
        # Only one winner - use it directly
        label = winner_labels[0]
        r, s, fallocs, tranges, extra = variant_results[label]
        best_combo_result = r
        best_combo_strat = s
        best_combo_allocs = fallocs
        best_combo_ranges = tranges
        P(f"\n    Only 1 winner: using {label} directly as best combo")

    else:
        P("\n    No variant beat V2 baseline. Using V2 as best.")
        best_combo_result = r_v2
        best_combo_strat = s_v2
        best_combo_allocs = allocs_v2
        best_combo_ranges = ranges_v2

    all_results['V4 Best Combo'] = best_combo_result
    if best_combo_strat is not None:
        all_equity_curves['V4 Best Combo'] = (best_combo_strat,
                                               np.array(bh_btc[:len(best_combo_strat)]))

    if best_combo_result:
        delta = (best_combo_result['total'] - baseline_total) * 100
        P(f"  >> V4 BEST COMBO: {best_combo_result['total']*100:+.1f}% | "
          f"Sortino: {best_combo_result['sortino']:.2f} | "
          f"MaxDD: {best_combo_result['max_dd']*100:.1f}% | vs V2: {delta:+.1f}pp")

    # ---------------------------------------------------------
    # BOOTSTRAP CI
    # ---------------------------------------------------------
    P(f"\n{'='*100}")
    P("  BOOTSTRAP 95% CI (1000 resamples)")
    P("  " + "-" * 60)

    variants_for_bs = [('V2 Baseline', s_v2)]
    # Add top 3 variants by return
    top_3 = sorted(all_variant_results, key=lambda x: x[1]['total'], reverse=True)[:3]
    for label, r in top_3:
        _, s, _, _, _ = variant_results[label]
        variants_for_bs.append((label, s))
    if best_combo_strat is not None:
        variants_for_bs.append(('V4 Best Combo', best_combo_strat))

    for name, strat_rets in variants_for_bs:
        if strat_rets is not None and len(strat_rets) > 30:
            bs = bootstrap_ci(strat_rets, n_bootstrap=1000)
            bootstrap_results[name] = bs
            P(f"    {name}:")
            P(f"      Return 95% CI: [{bs['return_lo']*100:+.0f}%, {bs['return_hi']*100:+.0f}%] "
              f"(mean: {bs['return_mean']*100:+.0f}%)")
            P(f"      Sortino 95% CI: [{bs['sortino_lo']:.2f}, {bs['sortino_hi']:.2f}]")
            P(f"      P(return > 0): {bs['excess_above_zero_pct']:.1f}%")

    # ---------------------------------------------------------
    # COST/RF SENSITIVITY
    # ---------------------------------------------------------
    P(f"\n{'='*100}")
    P("  COST / RF SENSITIVITY (replaying V4 Best Combo allocations)")
    P("  " + "-" * 60)

    sensitivity_results = {}
    if best_combo_allocs is not None and best_combo_ranges is not None:
        sensitivity_results = cost_rf_sensitivity(daily_ret, best_combo_allocs,
                                                  best_combo_ranges)
        P(f"\n    {'Setting':<25} {'Return':>10} {'Sortino':>8} {'MaxDD':>8}")
        P("    " + "-" * 55)
        for label, r in sorted(sensitivity_results.items()):
            P(f"    {label:<25} {r['total']*100:>+9.1f}% {r['sortino']:>+7.2f} "
              f"{r['max_dd']*100:>7.1f}%")

        # Breakeven cost
        for cost_bps in [1, 2, 5, 10, 15, 20, 25, 30, 40, 50]:
            cost = cost_bps / 10000.0
            all_s, all_b, all_a = [], [], []
            for (start, end) in best_combo_ranges:
                s, b, a = backtest_allocations(daily_ret, best_combo_allocs, start, end,
                                               cost=cost, rf_daily=RF_DAILY_DEFAULT)
                all_s.extend(s); all_b.extend(b); all_a.extend(a)
            r_test = metrics(np.array(all_s), np.array(all_b), np.array(all_a))
            if r_test and r_test['total'] < bh_result['total']:
                P(f"\n    Breakeven cost (vs BTC B&H): ~{cost_bps} bps "
                  f"(strategy={r_test['total']*100:+.1f}% < BTC={bh_result['total']*100:+.1f}%)")
                break

    # ---------------------------------------------------------
    # FINAL COMPARISON TABLE
    # ---------------------------------------------------------
    P(f"\n{'='*100}")
    P("FINAL COMPARISON TABLE")
    P("=" * 100)

    P(f"\n{'Strategy':<30} {'Return':>10} {'BTC':>10} {'Excess':>10} "
      f"{'Sortino':>8} {'MaxDD':>8} {'AvgAlloc':>9} {'vs V2':>8} {'Verdict':>12}")
    P("-" * 115)

    for name, r in all_results.items():
        if r is None:
            P(f"{name:.<30} {'N/A':>10}")
            continue

        delta_pp = (r['total'] - baseline_total) * 100 if name not in ['BTC Buy & Hold'] else 0

        verdict = ''
        if name not in ['BTC Buy & Hold', 'V2 Baseline (Bag5+Weekly)']:
            if r['total'] > baseline_total and r['sortino'] > baseline_sortino:
                verdict = 'WINNER'
            elif r['total'] > baseline_total:
                verdict = 'better ret'
            elif r['sortino'] > baseline_sortino:
                verdict = 'better risk'
            elif r['max_dd'] > baseline_dd:
                verdict = 'better dd'
            else:
                verdict = 'WORSE'

        P(f"{name:.<30} {r['total']*100:>+9.1f}% {r['btc']*100:>+9.1f}% "
          f"{r['excess']*100:>+9.1f}% {r['sortino']:>+7.2f} "
          f"{r['max_dd']*100:>7.1f}% {r['avg_alloc']:>8.2f} "
          f"{delta_pp:>+7.1f}pp {verdict:>12}")

    # ---------------------------------------------------------
    # SAVE RESULTS
    # ---------------------------------------------------------
    out_dir = ROOT / 'outputs/results'
    out_dir.mkdir(parents=True, exist_ok=True)

    output = {
        'timestamp': datetime.now().isoformat(),
        'method': 'pipeline_v4_exploration',
        'test_period': '2022-2026',
        'description': 'V4 Exploration: 6 fundamentally different approaches (14 variants)',
        'optuna_available': HAS_OPTUNA,
        'shap_available': HAS_SHAP,
        'results': {},
        'bootstrap_ci': {},
        'sensitivity': {},
        'approach_details': {},
    }

    for name, r in all_results.items():
        if r is not None:
            output['results'][name] = {
                k: float(v) if isinstance(v, (int, float, np.floating)) else v
                for k, v in r.items()
            }

    for name, bs in bootstrap_results.items():
        output['bootstrap_ci'][name] = {
            k: float(v) if isinstance(v, (int, float, np.floating)) else v
            for k, v in bs.items()
        }

    for label, r in sensitivity_results.items():
        output['sensitivity'][label] = {
            k: float(v) if isinstance(v, (int, float, np.floating)) else v
            for k, v in r.items()
        }

    # Store approach details (Optuna params, SHAP features per year)
    for label, extra in all_extra_info.items():
        serializable_extra = {}
        for year, info in extra.items():
            serializable_extra[year] = {}
            for k, v in info.items():
                if isinstance(v, dict):
                    serializable_extra[year][k] = {
                        str(kk): float(vv) if isinstance(vv, (int, float, np.floating)) else vv
                        for kk, vv in v.items()
                    }
                elif isinstance(v, list):
                    serializable_extra[year][k] = v
                else:
                    serializable_extra[year][k] = str(v)
        output['approach_details'][label] = serializable_extra

    with open(out_dir / 'pipeline_v4_exploration.json', 'w') as f:
        json.dump(output, f, indent=2, default=str)
    P(f"\n  Results saved: {out_dir / 'pipeline_v4_exploration.json'}")

    # ---------------------------------------------------------
    # CHARTS
    # ---------------------------------------------------------
    P("\n  Generating charts...")
    chart_dir = ROOT / 'outputs/results/charts'
    generate_charts_v4(all_results, all_equity_curves, bootstrap_results, chart_dir)

    # ---------------------------------------------------------
    # VERDICT
    # ---------------------------------------------------------
    P(f"\n{'='*100}")
    P("VERDICT")
    P("=" * 100)

    if r_v2:
        P(f"\n  V2 Baseline (Bag5+Weekly): {baseline_total*100:+.1f}% | "
          f"Sortino: {baseline_sortino:.2f} | MaxDD: {baseline_dd*100:.1f}%")

        if winners_return:
            P(f"\n  V4 VARIANTS THAT BEAT V2 ON RETURN ({baseline_total*100:+.1f}%):")
            for name, r in sorted(winners_return, key=lambda x: x[1]['total'], reverse=True):
                imp = (r['total'] - baseline_total) * 100
                P(f"    {name}: {r['total']*100:+.1f}% ({imp:+.1f}pp) | "
                  f"Sortino: {r['sortino']:.2f} | MaxDD: {r['max_dd']*100:.1f}%")
        else:
            P(f"\n  No V4 variant beat V2 baseline on return.")

        if winners_sortino:
            P(f"\n  BETTER RISK-ADJUSTED (Sortino > {baseline_sortino:.2f}):")
            for name, r in sorted(winners_sortino, key=lambda x: x[1]['sortino'], reverse=True):
                P(f"    {name}: Sortino {r['sortino']:.2f} | MaxDD: {r['max_dd']*100:.1f}%")

        if best_combo_result:
            P(f"\n  V4 Best Combo: {best_combo_result['total']*100:+.1f}% | "
              f"Sortino: {best_combo_result['sortino']:.2f} | "
              f"MaxDD: {best_combo_result['max_dd']*100:.1f}%")
            v4_vs_v2 = (best_combo_result['total'] - baseline_total) * 100
            P(f"  V4 vs V2: {v4_vs_v2:+.1f}pp")

            if 'V4 Best Combo' in bootstrap_results:
                bs = bootstrap_results['V4 Best Combo']
                P(f"\n  V4 Best Combo Bootstrap 95% CI: "
                  f"[{bs['return_lo']*100:+.0f}%, {bs['return_hi']*100:+.0f}%]")
                if bs['return_lo'] > 0:
                    P(f"  STATISTICALLY SIGNIFICANT: CI excludes zero!")
                else:
                    P(f"  NOT significant at 95%: CI includes zero.")

        # Summary by approach category
        P(f"\n  SUMMARY BY APPROACH:")
        approach_groups = {
            'Optuna HP Tuning': ['#1a', '#1b'],
            'SHAP Feature Pruning': ['#2a', '#2b', '#2c'],
            'Larger Bag': ['#3a', '#3b'],
            'Target Engineering': ['#4a', '#4b', '#4c'],
            'Linear Ensemble': ['#5a', '#5b'],
            'Asymmetric Models': ['#6'],
        }
        for group_name, prefixes in approach_groups.items():
            group_results = []
            for label, r in all_results.items():
                if r is not None and any(label.startswith(p) for p in prefixes):
                    group_results.append((label, r))
            if group_results:
                best_in_group = max(group_results, key=lambda x: x[1]['total'])
                delta = (best_in_group[1]['total'] - baseline_total) * 100
                status = 'BEATS V2' if delta > 0 else 'WORSE'
                P(f"    {group_name:<25}: best={best_in_group[0]} "
                  f"({best_in_group[1]['total']*100:+.1f}%, {delta:+.1f}pp) [{status}]")

    P(f"\n{'='*100}")
    P("PIPELINE V4 EXPLORATION COMPLETE")
    P("=" * 100)


if __name__ == '__main__':
    main()
