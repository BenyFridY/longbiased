"""
PIPELINE V3 FINAL - Final Optimization Push
=============================================

V2 Best Combo (Bagging 5 + Weekly Rebal) achieved +221% OOS (2022-2026).
V3 tests 6 new Tier-1 improvements on top of V2:

1. Expanded Features (25->35): add 10 high-value unused signals to ML
2. Sentiment Overlay: re-integrate fear/greed + stablecoin filter from edge_quant
3. Dynamic ML/Mom Weights: rolling 60d Sharpe to weight ML vs Mom (30-70% range)
4. XGBoost+LGB Ensemble: alternate XGBoost and LightGBM models in bag
5. Drawdown Defensive Overlay: if rolling DD < -15%, pull allocation toward 0.3
6. Threshold Rebalancing: only rebalance when allocation change > 5%

Baseline = V2 Best Combo (Bagging 5 + Weekly Rebal).
All walk-forward OOS (2022-2026), no look-ahead.
"""

import sys
import pandas as pd
import numpy as np
from pathlib import Path
import warnings
import json
from datetime import datetime
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

warnings.filterwarnings('ignore')
sys.stdout.reconfigure(line_buffering=True)

ROOT = Path(__file__).parent.parent.parent
COST_DEFAULT = 0.0002   # 2 bps
RF_ANNUAL_DEFAULT = 0.15
RF_DAILY_DEFAULT = (1 + RF_ANNUAL_DEFAULT)**(1/365) - 1

P = lambda *a, **kw: print(*a, **kw, flush=True)


# ============================================================
# DATA LOADING
# ============================================================

def load_data():
    df = pd.read_csv(ROOT / 'outputs/feature_selection/dataset_enhanced.csv')
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)

    prices = df['price_usd'].values
    n = len(prices)

    daily_ret = np.zeros(n)
    for i in range(1, n):
        daily_ret[i] = (prices[i] - prices[i-1]) / prices[i-1]

    returns = {}
    for w in [1, 3, 5, 7, 10, 14, 20, 21, 30, 45, 60]:
        r = np.zeros(n)
        for i in range(w, n):
            r[i] = (prices[i] - prices[i-w]) / prices[i-w]
        returns[w] = r

    vols = {}
    for w in [5, 7, 10, 14, 21, 30]:
        vols[w] = pd.Series(daily_ret).rolling(w).std().fillna(0.02).values

    return prices, daily_ret, returns, vols, df


# ============================================================
# CORE ENGINE
# ============================================================

def backtest_allocations(daily_ret, allocations, start_idx, end_idx,
                         cost=COST_DEFAULT, rf_daily=RF_DAILY_DEFAULT):
    strat, btc, allocs = [], [], []
    prev = 0.5
    n = len(daily_ret)
    for t in range(start_idx, min(end_idx, n - 1)):
        a = np.clip(allocations[t], -0.25, 1.0)
        br = daily_ret[t + 1]
        tc = abs(a - prev) * cost * (1.5 if a < 0 else 1.0)
        sr = a * br + (1 - abs(a)) * rf_daily - tc
        strat.append(sr)
        btc.append(br)
        allocs.append(a)
        prev = a
    return np.array(strat), np.array(btc), np.array(allocs)


def metrics(s, b, a, rf_daily=RF_DAILY_DEFAULT):
    if len(s) < 10:
        return None
    ts = np.prod(1 + s) - 1
    tb = np.prod(1 + b) - 1
    ex = s - rf_daily
    ds = ex[ex < 0]
    sortino = np.mean(ex) / (np.std(ds) + 1e-10) * np.sqrt(365) if len(ds) > 0 else 0
    cum = np.cumprod(1 + s)
    pk = np.maximum.accumulate(cum)
    dd = np.min((cum - pk) / (pk + 1e-10))
    return {'total': ts, 'btc': tb, 'excess': ts - tb, 'sortino': sortino,
            'max_dd': dd, 'short_pct': float((a < 0).mean()), 'avg_alloc': float(np.mean(a))}


def get_year_boundaries(dates, n):
    yb = {}
    for i in range(n):
        yr = pd.Timestamp(dates[i]).year
        if yr not in yb:
            yb[yr] = {'start': i, 'end': i}
        yb[yr]['end'] = i
    return yb


# ============================================================
# MOMENTUM STRATEGY
# ============================================================

def strategy_fn(slow_ret, fast_ret, vol, p):
    bear_s, bear_f, bull_s = p[0], p[1], p[2]
    a_min, a_max, a_mid = p[3], p[4], p[5]
    sl_bear, sl_bull = p[6], p[7]
    v_thresh, v_damp = p[8], p[9]

    if slow_ret < bear_s and fast_ret < bear_f:
        base = a_min
    elif slow_ret < bear_s * 0.5 and fast_ret < bear_f * 0.5:
        t = np.clip(slow_ret / (bear_s + 1e-10), 0, 2)
        base = a_mid + (a_min - a_mid) * min(t * sl_bear, 1.0)
    elif slow_ret < 0 and fast_ret < bear_f * 0.5:
        t = np.clip(slow_ret / (bear_s * 0.5 + 1e-10), 0, 1)
        base = a_mid * (1 - t * 0.5)
    elif slow_ret > bull_s:
        base = a_max
    elif slow_ret > 0:
        t = np.clip(slow_ret / (bull_s + 1e-10), 0, 1)
        base = a_mid + (a_max - a_mid) * (t ** (1.0 / max(sl_bull, 0.1)))
    else:
        base = a_mid

    if vol > v_thresh:
        excess = (vol - v_thresh) / (v_thresh + 1e-10)
        damp = min(v_damp * excess, 0.5)
        if base > 0:
            base *= (1 - damp)
        else:
            base *= (1 + damp * 0.5)

    return np.clip(base, -0.25, 1.0)


def optimize_params(daily_ret, slow_sig, fast_sig, vol_sig, start_idx, end_idx,
                    n_trials=2000, cost=COST_DEFAULT, rf_daily=RF_DAILY_DEFAULT):
    ranges = {
        'bear_slow': (-0.15, -0.04), 'bear_fast': (-0.06, -0.01),
        'bull': (0.05, 0.30), 'alloc_min': (-0.25, -0.05),
        'alloc_max': (0.80, 1.0), 'alloc_mid': (0.25, 0.65),
        'slope_bear': (0.3, 2.5), 'slope_bull': (0.3, 2.5),
        'vol_thresh': (0.015, 0.05), 'vol_damp': (0.05, 0.55),
    }

    best_score, best_params = -999, None
    n = len(daily_ret)

    for _ in range(n_trials):
        p = [np.random.uniform(*ranges[k]) for k in
             ['bear_slow', 'bear_fast', 'bull', 'alloc_min', 'alloc_max',
              'alloc_mid', 'slope_bear', 'slope_bull', 'vol_thresh', 'vol_damp']]

        allocs = np.full(n, 0.5)
        for t in range(max(start_idx, 60), end_idx + 1):
            allocs[t] = strategy_fn(slow_sig[t], fast_sig[t], vol_sig[t], p)

        s, b, a = backtest_allocations(daily_ret, allocs, max(start_idx, 60), end_idx,
                                       cost=cost, rf_daily=rf_daily)
        m = metrics(s, b, a, rf_daily=rf_daily)
        if m is None:
            continue

        score = m['total'] * 2 + m['sortino'] * 0.3 + m['excess'] * 0.5 + m['max_dd'] * 0.3
        if score > best_score:
            best_score = score
            best_params = p[:]

    return best_params


# ============================================================
# ML FEATURES: V2 (25 features) and V3 (35 features)
# ============================================================

def build_ml_features_v2(df, returns, vols, n):
    """Original V2 feature set (25 features)."""
    feature_cols = [
        'cusum_pos', 'miners_revenue_ratio', 'mr_score_30d', 'adx',
        'cusum_neg', 'exchange_netflow_ma7', 'structural_break_score',
        'macd_histogram', 'eth_btc_ratio', 'm2_yoy_growth',
        'volatility_7d', 'basis_ma7', 'nupl_ma30', 'hurst_60d',
        'funding_rate', 'bb_position', 'rsi_14d', 'puell_multiple',
        'stablecoin_zscore', 'sopr_ma7',
    ]
    available = [c for c in feature_cols if c in df.columns]
    X_all = df[available].values.astype(float)
    X_extra = np.column_stack([returns[3], returns[10], returns[30], returns[60], vols[14]])
    X_all = np.hstack([X_all, X_extra])
    feature_names = available + ['ret_3d', 'ret_10d', 'ret_30d', 'ret_60d', 'vol_14d']
    return X_all, feature_names


def build_ml_features_v3(df, returns, vols, n):
    """Expanded V3 feature set (25 + 10 = 35 features).
    Adds miner health, network activity, short-term liquidity,
    derivatives detail, and macro risk signals."""
    # Start with V2 base
    X_v2, names_v2 = build_ml_features_v2(df, returns, vols, n)

    # 10 new high-value features
    extra_cols = [
        'miner_capitulation',        # miner health
        'difficulty_ribbon',         # miner health
        'ribbon_compression',        # miner health
        'active_addresses_24h',      # network activity
        'tx_growth_30d',             # network activity
        'stablecoin_supply_change_7d',  # short-term liquidity
        'stablecoin_btc_ratio',      # short-term liquidity
        'taker_pressure',            # derivatives detail
        'oi_change_7d',              # derivatives detail
        'high_yield_spread',         # macro risk
    ]

    extra_available = [c for c in extra_cols if c in df.columns]
    if extra_available:
        X_extra = df[extra_available].values.astype(float)
        X_all = np.hstack([X_v2, X_extra])
        feature_names = names_v2 + extra_available
    else:
        X_all = X_v2
        feature_names = names_v2

    return X_all, feature_names


# ============================================================
# ML MODEL TRAINING
# ============================================================

def train_lgb_model(X_all, target, train_end, horizon_gap=5, seed=42):
    import lightgbm as lgb

    train_mask = np.arange(60, train_end - horizon_gap + 1)
    valid_train = ~np.any(np.isnan(X_all[train_mask]), axis=1)
    train_idx = train_mask[valid_train]

    if len(train_idx) < 100:
        return None

    X_train = np.nan_to_num(X_all[train_idx], nan=0.0)
    y_train = target[train_idx]

    params = {
        'objective': 'regression', 'metric': 'mae',
        'num_leaves': 31, 'learning_rate': 0.05,
        'feature_fraction': 0.7, 'bagging_fraction': 0.8,
        'bagging_freq': 5, 'verbose': -1, 'n_jobs': 1,
        'seed': seed,
    }

    dtrain = lgb.Dataset(X_train, label=y_train)
    return lgb.train(params, dtrain, num_boost_round=200)


def train_xgb_model(X_all, target, train_end, horizon_gap=5, seed=42):
    """XGBoost model with same interface as train_lgb_model."""
    import xgboost as xgb

    train_mask = np.arange(60, train_end - horizon_gap + 1)
    valid_train = ~np.any(np.isnan(X_all[train_mask]), axis=1)
    train_idx = train_mask[valid_train]

    if len(train_idx) < 100:
        return None

    X_train = np.nan_to_num(X_all[train_idx], nan=0.0)
    y_train = target[train_idx]

    params = {
        'objective': 'reg:squarederror',
        'eval_metric': 'mae',
        'max_depth': 5,
        'learning_rate': 0.05,
        'subsample': 0.8,
        'colsample_bytree': 0.7,
        'verbosity': 0,
        'seed': seed,
        'nthread': 1,
    }

    dtrain = xgb.DMatrix(X_train, label=y_train)
    return xgb.train(params, dtrain, num_boost_round=200)


def train_lgb_bagged(X_all, target, train_end, horizon_gap=5, n_bags=5):
    """Train n_bags LightGBM models with different seeds."""
    models = []
    for i in range(n_bags):
        seed = 42 + i * 7
        m = train_lgb_model(X_all, target, train_end, horizon_gap=horizon_gap, seed=seed)
        if m is not None:
            models.append(('lgb', m))
    return models if len(models) > 0 else None


def train_mixed_bag(X_all, target, train_end, horizon_gap=5, n_bags=5):
    """Train a mixed bag: 3 LightGBM + 2 XGBoost models."""
    models = []
    # 3 LightGBM
    for i in range(3):
        seed = 42 + i * 7
        m = train_lgb_model(X_all, target, train_end, horizon_gap=horizon_gap, seed=seed)
        if m is not None:
            models.append(('lgb', m))
    # 2 XGBoost
    for i in range(2):
        seed = 42 + (3 + i) * 7
        m = train_xgb_model(X_all, target, train_end, horizon_gap=horizon_gap, seed=seed)
        if m is not None:
            models.append(('xgb', m))
    return models if len(models) > 0 else None


def predict_single(model_type, model, x_t):
    """Predict with either LGB or XGB model."""
    if model_type == 'lgb':
        return model.predict(x_t)[0]
    else:  # xgb
        import xgboost as xgb
        dmat = xgb.DMatrix(x_t)
        return model.predict(dmat)[0]


def ml_predict_bagged(models, X_all, t):
    """Predict using a bag of (type, model) tuples. Returns allocation."""
    x_t = np.nan_to_num(X_all[t:t+1].copy(), nan=0.0)
    preds = [predict_single(mtype, m, x_t) for mtype, m in models]
    avg_pred = np.mean(preds)
    scaled = np.clip(avg_pred / 0.05, -1.0, 1.0)
    if scaled > 0:
        return 0.5 + scaled * 0.5
    else:
        return 0.5 + scaled * 0.75


def ml_predict_to_alloc(model, X_all, t):
    """Single LGB model predict -> allocation."""
    x_t = np.nan_to_num(X_all[t:t+1].copy(), nan=0.0)
    pred = model.predict(x_t)[0]
    scaled = np.clip(pred / 0.05, -1.0, 1.0)
    if scaled > 0:
        return 0.5 + scaled * 0.5
    else:
        return 0.5 + scaled * 0.75


# ============================================================
# SENTIMENT OVERLAY (from edge_quant edge2)
# ============================================================

def get_sentiment_signals(df, n):
    """Extract sentiment-related columns with safe defaults."""
    def safe_col(name, default=0.0):
        if name in df.columns:
            v = df[name].values.astype(float)
            return np.nan_to_num(v, nan=default)
        return np.full(n, default)

    return {
        'fg_zscore': safe_col('fear_greed_zscore', 0.0),
        'extreme_fear': safe_col('extreme_fear', 0.0),
        'extreme_greed': safe_col('extreme_greed', 0.0),
        'stable_chg_30d': safe_col('stablecoin_supply_change_30d', 0.0),
        'stable_zscore': safe_col('stablecoin_zscore', 0.0),
    }


def compute_sentiment_thresholds(sent_signals, train_end):
    """Compute percentile thresholds from training data only."""
    fg = sent_signals['fg_zscore'][:train_end + 1]
    sc = sent_signals['stable_chg_30d'][:train_end + 1]
    scz = sent_signals['stable_zscore'][:train_end + 1]

    return {
        'fgz_p05': np.percentile(fg, 5),
        'fgz_p10': np.percentile(fg, 10),
        'fgz_p90': np.percentile(fg, 90),
        'sc_p80': np.percentile(sc, 80),
        'sc_p20': np.percentile(sc, 20),
        'scz_p80': np.percentile(scz, 80),
    }


def sentiment_adjustment(t, sent_signals, thresholds, ret_30d):
    """Compute additive sentiment adjustment for allocation at time t."""
    adj = 0.0
    fgz = sent_signals['fg_zscore'][t]
    is_fear = sent_signals['extreme_fear'][t] > 0.5
    is_greed = sent_signals['extreme_greed'][t] > 0.5

    # Extreme fear = contrarian buy
    if fgz < thresholds['fgz_p05'] or is_fear:
        adj += 0.10
    elif fgz < thresholds['fgz_p10']:
        adj += 0.04

    # Extreme greed = modest reduction
    if fgz > thresholds['fgz_p90'] or is_greed:
        adj -= 0.06

    # Stablecoin inflows = dry powder
    sc30 = sent_signals['stable_chg_30d'][t]
    scz = sent_signals['stable_zscore'][t]
    if sc30 > thresholds['sc_p80'] and scz > thresholds['scz_p80']:
        adj += 0.06
    elif sc30 < thresholds['sc_p20']:
        adj -= 0.04

    # Combo: extreme fear + stablecoin inflow + momentum positive
    if (fgz < thresholds['fgz_p10'] and sc30 > thresholds['sc_p80'] and ret_30d > 0):
        adj += 0.06

    return adj


# ============================================================
# WALK-FORWARD ENGINE V3
# ============================================================

def walk_forward_v3(daily_ret, returns, vols, df, dates, n,
                    # V2 baseline flags (always on by default)
                    use_bagging=True, n_bags=5,
                    use_weekly_rebalance=True,
                    # V3 new flags
                    use_expanded_features=False,
                    use_sentiment=False,
                    use_dynamic_weights=False,
                    use_mixed_models=False,
                    use_dd_overlay=False,
                    use_threshold_rebal=False,
                    threshold_pct=0.05,
                    # Cost/RF
                    cost=COST_DEFAULT, rf_daily=RF_DAILY_DEFAULT,
                    label="V3", verbose=True):
    """Walk-forward Hybrid V3 with configurable V2+V3 improvements.
    Returns: (result_dict, strat_rets, btc_rets, alloc_array, full_allocs, test_ranges)
    """

    yb = get_year_boundaries(dates, n)
    slow_sig, fast_sig, vol_sig = returns[60], returns[3], vols[14]

    # Choose feature set
    if use_expanded_features:
        X_all, feat_names = build_ml_features_v3(df, returns, vols, n)
    else:
        X_all, feat_names = build_ml_features_v2(df, returns, vols, n)

    prices = df['price_usd'].values
    target_5d = np.zeros(n)
    for i in range(n - 5):
        target_5d[i] = (prices[i + 5] - prices[i]) / prices[i]

    day_of_week = pd.to_datetime(dates).dayofweek  # 0=Mon, 4=Fri

    # Sentiment signals (loaded even if not used, cheap)
    sent_signals = get_sentiment_signals(df, n)

    all_strat, all_btc, all_alloc = [], [], []
    full_allocs = np.full(n, 0.5)
    test_ranges = []

    for test_year in range(2022, 2027):
        if test_year not in yb:
            continue
        train_end = yb[test_year]['start'] - 1
        test_start = yb[test_year]['start']
        test_end = yb[test_year]['end']

        # --- TRAIN ---
        np.random.seed(42 + test_year)
        if verbose:
            P(f"    {test_year}: optimizing momentum...", end="")
        mom_params = optimize_params(daily_ret, slow_sig, fast_sig, vol_sig,
                                     60, train_end, 2000, cost=cost, rf_daily=rf_daily)
        if mom_params is None:
            if verbose:
                P(" FAILED")
            continue

        # ML model(s)
        models = None
        if use_mixed_models:
            models = train_mixed_bag(X_all, target_5d, train_end, horizon_gap=5, n_bags=n_bags)
            if verbose:
                n_ok = len(models) if models else 0
                P(f" training {n_bags} mixed models ({n_ok} ok)...", end="")
        elif use_bagging:
            models = train_lgb_bagged(X_all, target_5d, train_end, horizon_gap=5, n_bags=n_bags)
            if verbose:
                n_ok = len(models) if models else 0
                P(f" training {n_bags} LGB models ({n_ok} ok)...", end="")
        else:
            m = train_lgb_model(X_all, target_5d, train_end, seed=42+test_year)
            if m is not None:
                models = [('lgb', m)]
            if verbose:
                P(f" training 1 ML model...", end="")

        # Sentiment thresholds from training data
        sent_thresholds = None
        if use_sentiment:
            sent_thresholds = compute_sentiment_thresholds(sent_signals, train_end)

        # --- TEST ---
        prev_alloc = 0.5

        # For dynamic weights: track rolling ML vs Mom returns
        ml_daily_rets = []
        mom_daily_rets = []

        # For drawdown overlay: track cumulative return
        cum_strat = 1.0
        peak_strat = 1.0

        for t in range(test_start, test_end + 1):
            a_mom = strategy_fn(slow_sig[t], fast_sig[t], vol_sig[t], mom_params)

            # ML allocation
            if models is not None:
                a_ml = ml_predict_bagged(models, X_all, t)
            else:
                a_ml = a_mom  # fallback

            # --- Improvement #3: Dynamic ML/Mom Weights ---
            if use_dynamic_weights and len(ml_daily_rets) >= 60:
                # Compute rolling 60d Sharpe for ML vs Mom
                ml_arr = np.array(ml_daily_rets[-60:])
                mom_arr = np.array(mom_daily_rets[-60:])
                ml_sharpe = np.mean(ml_arr) / (np.std(ml_arr) + 1e-10) * np.sqrt(365)
                mom_sharpe = np.mean(mom_arr) / (np.std(mom_arr) + 1e-10) * np.sqrt(365)

                # Weight based on relative Sharpe (range 0.30 to 0.70 for ML)
                total_sharpe = abs(ml_sharpe) + abs(mom_sharpe) + 1e-10
                ml_weight = ml_sharpe / total_sharpe if ml_sharpe > 0 else 0.30
                ml_weight = np.clip(ml_weight, 0.30, 0.70)
                raw_alloc = ml_weight * a_ml + (1 - ml_weight) * a_mom
            else:
                raw_alloc = 0.5 * a_mom + 0.5 * a_ml

            # --- Improvement #2: Sentiment Overlay ---
            if use_sentiment and sent_thresholds is not None:
                sent_adj = sentiment_adjustment(t, sent_signals, sent_thresholds, returns[30][t])
                raw_alloc += sent_adj

            # --- Improvement #5: Drawdown Defensive Overlay ---
            if use_dd_overlay:
                dd_pct = (cum_strat - peak_strat) / (peak_strat + 1e-10)
                if dd_pct < -0.15:
                    # Pull toward 0.3 (defensive)
                    dd_severity = min(abs(dd_pct) / 0.30, 1.0)  # Normalized 0-1
                    raw_alloc = raw_alloc * (1 - dd_severity * 0.5) + 0.3 * (dd_severity * 0.5)

            # --- Rebalancing logic ---
            if use_weekly_rebalance and use_threshold_rebal:
                # Threshold + weekly: only rebalance on Friday AND if change > threshold
                if day_of_week[t] != 4:
                    raw_alloc = prev_alloc
                elif abs(raw_alloc - prev_alloc) < threshold_pct:
                    raw_alloc = prev_alloc
            elif use_weekly_rebalance:
                if day_of_week[t] != 4:
                    raw_alloc = prev_alloc
            elif use_threshold_rebal:
                if abs(raw_alloc - prev_alloc) < threshold_pct:
                    raw_alloc = prev_alloc

            final_alloc = np.clip(raw_alloc, -0.25, 1.0)
            full_allocs[t] = final_alloc

            # Track for dynamic weights
            if t > test_start:
                br = daily_ret[t]
                ml_ret_approx = a_ml * br + (1 - abs(a_ml)) * rf_daily
                mom_ret_approx = a_mom * br + (1 - abs(a_mom)) * rf_daily
                ml_daily_rets.append(ml_ret_approx)
                mom_daily_rets.append(mom_ret_approx)

                # Track for DD overlay
                strat_ret = final_alloc * br + (1 - abs(final_alloc)) * rf_daily
                cum_strat *= (1 + strat_ret)
                peak_strat = max(peak_strat, cum_strat)

            prev_alloc = final_alloc

        test_ranges.append((test_start, test_end))
        s, b, a = backtest_allocations(daily_ret, full_allocs, test_start, test_end,
                                       cost=cost, rf_daily=rf_daily)
        all_strat.extend(s)
        all_btc.extend(b)
        all_alloc.extend(a)

        m_yr = metrics(np.array(s), np.array(b), np.array(a), rf_daily=rf_daily)
        if verbose and m_yr:
            P(f" {m_yr['total']*100:+.1f}% (BTC {m_yr['btc']*100:+.1f}%)")

    result = metrics(np.array(all_strat), np.array(all_btc), np.array(all_alloc),
                     rf_daily=rf_daily)
    return (result, np.array(all_strat), np.array(all_btc), np.array(all_alloc),
            full_allocs, test_ranges)


# ============================================================
# BOOTSTRAP CONFIDENCE INTERVALS
# ============================================================

def bootstrap_ci(daily_returns, n_bootstrap=1000, ci=0.95):
    n = len(daily_returns)
    if n < 30:
        return None

    rng = np.random.RandomState(42)
    total_returns = []
    sortinos = []

    for _ in range(n_bootstrap):
        idx = rng.choice(n, size=n, replace=True)
        resampled = daily_returns[idx]
        total = np.prod(1 + resampled) - 1
        total_returns.append(total)

        ex = resampled - RF_DAILY_DEFAULT
        ds = ex[ex < 0]
        if len(ds) > 2:
            sortino = np.mean(ex) / (np.std(ds) + 1e-10) * np.sqrt(365)
        else:
            sortino = 0.0
        sortinos.append(sortino)

    alpha = (1 - ci) / 2
    lo, hi = alpha * 100, (1 - alpha) * 100

    return {
        'return_mean': np.mean(total_returns),
        'return_lo': np.percentile(total_returns, lo),
        'return_hi': np.percentile(total_returns, hi),
        'return_std': np.std(total_returns),
        'sortino_mean': np.mean(sortinos),
        'sortino_lo': np.percentile(sortinos, lo),
        'sortino_hi': np.percentile(sortinos, hi),
        'excess_above_zero_pct': np.mean([r > 0 for r in total_returns]) * 100,
    }


# ============================================================
# COST/RF SENSITIVITY
# ============================================================

def cost_rf_sensitivity(daily_ret, full_allocs, test_ranges):
    costs_bps = [1, 2, 5, 10]
    rf_annuals = [0.05, 0.10, 0.15]

    results = {}
    for cost_bps in costs_bps:
        for rf_ann in rf_annuals:
            cost = cost_bps / 10000.0
            rf_d = (1 + rf_ann)**(1/365) - 1
            label = f"cost={cost_bps}bps_rf={int(rf_ann*100)}%"

            all_s, all_b, all_a = [], [], []
            for (start, end) in test_ranges:
                s, b, a = backtest_allocations(daily_ret, full_allocs, start, end,
                                               cost=cost, rf_daily=rf_d)
                all_s.extend(s)
                all_b.extend(b)
                all_a.extend(a)

            r = metrics(np.array(all_s), np.array(all_b), np.array(all_a), rf_daily=rf_d)
            if r:
                results[label] = r
    return results


# ============================================================
# CHARTS
# ============================================================

def generate_charts(all_results, all_equity_curves, bootstrap_results, chart_dir):
    chart_dir.mkdir(parents=True, exist_ok=True)

    # --- Chart 1: Bar comparison of all improvements ---
    fig, axes = plt.subplots(2, 1, figsize=(22, 14))

    names, ret_vals, sortino_vals, maxdd_vals, colors_list = [], [], [], [], []
    cmap = plt.cm.Set2
    for i, (name, r) in enumerate(all_results.items()):
        if r is None:
            continue
        names.append(name)
        ret_vals.append(r['total'] * 100)
        sortino_vals.append(r['sortino'])
        maxdd_vals.append(r['max_dd'] * 100)
        if name == 'BTC Buy & Hold':
            colors_list.append('#F7931A')
        elif 'V2 Baseline' in name:
            colors_list.append('#4A90D9')
        elif 'V3 Best' in name:
            colors_list.append('#E74C3C')
        else:
            colors_list.append(cmap(i / max(len(all_results), 1)))

    x = np.arange(len(names))

    ax = axes[0]
    bars = ax.bar(x, ret_vals, color=colors_list, alpha=0.85, edgecolor='black', linewidth=0.5)
    for v, bar in zip(ret_vals, bars):
        ax.text(bar.get_x() + bar.get_width()/2, v + (5 if v >= 0 else -12),
                f'{v:+.0f}%', ha='center', fontsize=8, fontweight='bold')
    ax.set_xticks(x)
    ax.set_xticklabels(names, fontsize=7, rotation=35, ha='right')
    ax.axhline(y=0, color='black', lw=0.5)
    ax.set_title('Pipeline V3 Final: OOS Returns per Improvement (Walk-Forward 2022-2026)',
                 fontsize=13, fontweight='bold')
    ax.set_ylabel('Total Return %')
    ax.grid(True, alpha=0.3, axis='y')

    ax = axes[1]
    width = 0.35
    ax.bar(x - width/2, sortino_vals, width, color=colors_list, alpha=0.7,
           edgecolor='black', linewidth=0.5, label='Sortino')
    bars2 = ax.bar(x + width/2, maxdd_vals, width, color=colors_list, alpha=0.4,
                   edgecolor='black', linewidth=0.5, label='Max Drawdown %')
    for v, bar in zip(sortino_vals, ax.patches[:len(names)]):
        ax.text(bar.get_x() + bar.get_width()/2, v + 0.03,
                f'{v:.2f}', ha='center', fontsize=7, fontweight='bold')
    for v, bar in zip(maxdd_vals, bars2):
        ax.text(bar.get_x() + bar.get_width()/2, v - 3,
                f'{v:.0f}%', ha='center', fontsize=7, fontweight='bold')
    ax.set_xticks(x)
    ax.set_xticklabels(names, fontsize=7, rotation=35, ha='right')
    ax.axhline(y=0, color='black', lw=0.5)
    ax.set_title('Sortino Ratio & Max Drawdown', fontsize=13, fontweight='bold')
    ax.legend(fontsize=10)
    ax.grid(True, alpha=0.3, axis='y')

    plt.tight_layout()
    plt.savefig(chart_dir / 'pipeline_v3_final.png', dpi=150, bbox_inches='tight')
    plt.close()
    P(f"  Chart saved: {chart_dir / 'pipeline_v3_final.png'}")

    # --- Chart 2: Equity curves ---
    if len(all_equity_curves) > 1:
        fig, axes = plt.subplots(2, 1, figsize=(18, 12), gridspec_kw={'height_ratios': [3, 1]})

        key_curves = ['BTC Buy & Hold', 'V2 Baseline (Bag+Weekly)', 'V3 Best Combo']
        ax = axes[0]
        for name, (strat_rets, _) in all_equity_curves.items():
            if len(strat_rets) == 0:
                continue
            cum = np.cumprod(1 + strat_rets)
            lw = 2.5 if name in key_curves else 1.0
            alpha = 1.0 if name in key_curves else 0.5
            ls = '-' if name in key_curves else '--'
            ax.plot(cum, label=f"{name} ({(cum[-1]-1)*100:+.0f}%)",
                    linewidth=lw, alpha=alpha, linestyle=ls)
        ax.set_title('Equity Curves (Walk-Forward OOS 2022-2026)', fontsize=14, fontweight='bold')
        ax.set_ylabel('Cumulative Value ($1 start)')
        ax.legend(fontsize=7, loc='upper left', ncol=2)
        ax.grid(True, alpha=0.3)
        ax.set_yscale('log')

        ax = axes[1]
        for name in key_curves:
            if name in all_equity_curves and len(all_equity_curves[name][0]) > 0:
                strat_rets = all_equity_curves[name][0]
                cum = np.cumprod(1 + strat_rets)
                pk = np.maximum.accumulate(cum)
                dd = (cum - pk) / pk * 100
                ax.fill_between(range(len(dd)), dd, 0, alpha=0.3, label=name)
                ax.plot(dd, linewidth=0.8)
        ax.set_title('Drawdown (%)', fontsize=12, fontweight='bold')
        ax.set_ylabel('Drawdown %')
        ax.legend(fontsize=9)
        ax.grid(True, alpha=0.3)

        plt.tight_layout()
        plt.savefig(chart_dir / 'pipeline_v3_equity.png', dpi=150, bbox_inches='tight')
        plt.close()
        P(f"  Chart saved: {chart_dir / 'pipeline_v3_equity.png'}")

    # --- Chart 3: Bootstrap CI ---
    if bootstrap_results:
        fig, ax = plt.subplots(1, 1, figsize=(14, 6))
        bs_names, bs_means, bs_lo, bs_hi = [], [], [], []
        for name, bs in bootstrap_results.items():
            bs_names.append(name)
            bs_means.append(bs['return_mean'] * 100)
            bs_lo.append(bs['return_lo'] * 100)
            bs_hi.append(bs['return_hi'] * 100)

        x = np.arange(len(bs_names))
        ax.bar(x, bs_means, color='steelblue', alpha=0.7, edgecolor='black', linewidth=0.5)
        ax.errorbar(x, bs_means,
                    yerr=[np.array(bs_means) - np.array(bs_lo),
                          np.array(bs_hi) - np.array(bs_means)],
                    fmt='none', color='black', capsize=5, linewidth=2)
        for i, (m, lo, hi) in enumerate(zip(bs_means, bs_lo, bs_hi)):
            ax.text(i, hi + 5, f'{m:.0f}%\n[{lo:.0f}, {hi:.0f}]',
                    ha='center', fontsize=8, fontweight='bold')

        ax.set_xticks(x)
        ax.set_xticklabels(bs_names, fontsize=7, rotation=20, ha='right')
        ax.axhline(y=0, color='red', lw=1, ls='--', label='Zero return')
        ax.set_title('Bootstrap 95% CI on Total Return (1000 resamples)', fontsize=13, fontweight='bold')
        ax.set_ylabel('Total Return %')
        ax.legend()
        ax.grid(True, alpha=0.3, axis='y')

        plt.tight_layout()
        plt.savefig(chart_dir / 'pipeline_v3_bootstrap.png', dpi=150, bbox_inches='tight')
        plt.close()
        P(f"  Chart saved: {chart_dir / 'pipeline_v3_bootstrap.png'}")


# ============================================================
# MAIN
# ============================================================

def main():
    P("=" * 100)
    P("PIPELINE V3 FINAL - Final Optimization Push")
    P("=" * 100)

    # --- V2 -> V3 Progression Recap ---
    P("""
    V2 -> V3 Progression:
    +--------------------------+---------+---------+--------+
    | Stage                    | Return  | Sortino | MaxDD  |
    +--------------------------+---------+---------+--------+
    | BTC B&H                  |  +53%   |  0.27   | -67%   |
    | Momentum Only            | +152%   |  0.59   | -41%   |
    | +ML Hybrid               | +166%   |  0.67   | -27%   |
    | +Bagging 5               | +207%   |  0.85   | -21%   |
    | +Weekly Rebal (V2 Best)  | +221%   |  0.87   | -21%   |
    | V3 Target                | +250%+  |  0.90+  | <-20%  |
    +--------------------------+---------+---------+--------+

    6 New V3 Improvements to Test:
    #1: Expanded Features (25->35) - add 10 unused high-value signals
    #2: Sentiment Overlay - fear/greed + stablecoin filter from edge_quant
    #3: Dynamic ML/Mom Weights - rolling 60d Sharpe to blend ML vs Mom
    #4: XGBoost+LGB Ensemble - mixed bag of 3 LGB + 2 XGB models
    #5: Drawdown Defensive Overlay - reduce when rolling DD < -15%
    #6: Threshold Rebalancing - only rebalance when change > 5%

    Baseline = V2 Best Combo (Bagging 5 + Weekly Rebal).
    All walk-forward OOS (2022-2026), no look-ahead.
    """)

    P("Loading data...")
    prices, daily_ret, returns, vols, df = load_data()
    dates = df['date'].values
    n = len(prices)
    P(f"  {n} days | {len(df.columns)} columns | {dates[0]} to {dates[-1]}")

    all_results = {}
    all_equity_curves = {}
    bootstrap_results = {}

    # ---------------------------------------------------------
    # BTC Buy & Hold reference
    # ---------------------------------------------------------
    yb = get_year_boundaries(dates, n)
    bh_strat, bh_btc, bh_alloc = [], [], []
    for test_year in range(2022, 2027):
        if test_year not in yb:
            continue
        allocs_bh = np.full(n, 1.0)
        s, b, a = backtest_allocations(daily_ret, allocs_bh,
                                       yb[test_year]['start'], yb[test_year]['end'])
        bh_strat.extend(s); bh_btc.extend(b); bh_alloc.extend(a)
    bh_result = metrics(np.array(bh_strat), np.array(bh_btc), np.array(bh_alloc))
    all_results['BTC Buy & Hold'] = bh_result
    all_equity_curves['BTC Buy & Hold'] = (np.array(bh_strat), np.array(bh_btc))
    P(f"\n  BTC Buy & Hold: {bh_result['total']*100:+.1f}% | "
      f"Sortino: {bh_result['sortino']:.2f} | MaxDD: {bh_result['max_dd']*100:.1f}%")

    # ---------------------------------------------------------
    # V2 BASELINE: Bagging 5 + Weekly Rebalance
    # ---------------------------------------------------------
    P(f"\n{'='*100}")
    P("  V2 BASELINE: Bagging 5 + Weekly Rebalance")
    P("  " + "-" * 60)
    r_v2, s_v2, b_v2, a_v2, allocs_v2, ranges_v2 = walk_forward_v3(
        daily_ret, returns, vols, df, dates, n,
        use_bagging=True, n_bags=5,
        use_weekly_rebalance=True,
        label="V2 Baseline")
    all_results['V2 Baseline (Bag+Weekly)'] = r_v2
    all_equity_curves['V2 Baseline (Bag+Weekly)'] = (s_v2, b_v2)
    if r_v2:
        P(f"  >> V2 BASELINE: {r_v2['total']*100:+.1f}% | Sortino: {r_v2['sortino']:.2f} | "
          f"MaxDD: {r_v2['max_dd']*100:.1f}% | AvgAlloc: {r_v2['avg_alloc']:.2f}")

    baseline_total = r_v2['total'] if r_v2 else 0
    baseline_sortino = r_v2['sortino'] if r_v2 else 0
    baseline_dd = r_v2['max_dd'] if r_v2 else -1

    # ---------------------------------------------------------
    # #1: EXPANDED FEATURES (25 -> 35)
    # ---------------------------------------------------------
    P(f"\n{'='*100}")
    P("  #1: EXPANDED FEATURES (25 -> 35)")
    P("  " + "-" * 60)
    r1, s1, b1, a1, allocs1, ranges1 = walk_forward_v3(
        daily_ret, returns, vols, df, dates, n,
        use_bagging=True, n_bags=5,
        use_weekly_rebalance=True,
        use_expanded_features=True,
        label="#1 ExpandFeat")
    all_results['#1 Expanded Features'] = r1
    all_equity_curves['#1 Expanded Features'] = (s1, b1)
    if r1:
        P(f"  >> TOTAL: {r1['total']*100:+.1f}% | Sortino: {r1['sortino']:.2f} | "
          f"MaxDD: {r1['max_dd']*100:.1f}%")

    # ---------------------------------------------------------
    # #2: SENTIMENT OVERLAY
    # ---------------------------------------------------------
    P(f"\n{'='*100}")
    P("  #2: SENTIMENT OVERLAY (fear/greed + stablecoin)")
    P("  " + "-" * 60)
    r2, s2, b2, a2, allocs2, ranges2 = walk_forward_v3(
        daily_ret, returns, vols, df, dates, n,
        use_bagging=True, n_bags=5,
        use_weekly_rebalance=True,
        use_sentiment=True,
        label="#2 Sentiment")
    all_results['#2 Sentiment Overlay'] = r2
    all_equity_curves['#2 Sentiment Overlay'] = (s2, b2)
    if r2:
        P(f"  >> TOTAL: {r2['total']*100:+.1f}% | Sortino: {r2['sortino']:.2f} | "
          f"MaxDD: {r2['max_dd']*100:.1f}%")

    # ---------------------------------------------------------
    # #3: DYNAMIC ML/MOM WEIGHTS
    # ---------------------------------------------------------
    P(f"\n{'='*100}")
    P("  #3: DYNAMIC ML/MOM WEIGHTS (rolling 60d Sharpe)")
    P("  " + "-" * 60)
    r3, s3, b3, a3, allocs3, ranges3 = walk_forward_v3(
        daily_ret, returns, vols, df, dates, n,
        use_bagging=True, n_bags=5,
        use_weekly_rebalance=True,
        use_dynamic_weights=True,
        label="#3 DynWeights")
    all_results['#3 Dynamic Weights'] = r3
    all_equity_curves['#3 Dynamic Weights'] = (s3, b3)
    if r3:
        P(f"  >> TOTAL: {r3['total']*100:+.1f}% | Sortino: {r3['sortino']:.2f} | "
          f"MaxDD: {r3['max_dd']*100:.1f}%")

    # ---------------------------------------------------------
    # #4: XGBoost + LGB ENSEMBLE
    # ---------------------------------------------------------
    P(f"\n{'='*100}")
    P("  #4: MIXED BAG (3 LGB + 2 XGB)")
    P("  " + "-" * 60)
    r4, s4, b4, a4, allocs4, ranges4 = walk_forward_v3(
        daily_ret, returns, vols, df, dates, n,
        use_bagging=True, n_bags=5,
        use_weekly_rebalance=True,
        use_mixed_models=True,
        label="#4 MixedBag")
    all_results['#4 Mixed Bag (LGB+XGB)'] = r4
    all_equity_curves['#4 Mixed Bag (LGB+XGB)'] = (s4, b4)
    if r4:
        P(f"  >> TOTAL: {r4['total']*100:+.1f}% | Sortino: {r4['sortino']:.2f} | "
          f"MaxDD: {r4['max_dd']*100:.1f}%")

    # ---------------------------------------------------------
    # #5: DRAWDOWN DEFENSIVE OVERLAY
    # ---------------------------------------------------------
    P(f"\n{'='*100}")
    P("  #5: DRAWDOWN DEFENSIVE OVERLAY (reduce when DD < -15%)")
    P("  " + "-" * 60)
    r5, s5, b5, a5, allocs5, ranges5 = walk_forward_v3(
        daily_ret, returns, vols, df, dates, n,
        use_bagging=True, n_bags=5,
        use_weekly_rebalance=True,
        use_dd_overlay=True,
        label="#5 DD Overlay")
    all_results['#5 DD Overlay'] = r5
    all_equity_curves['#5 DD Overlay'] = (s5, b5)
    if r5:
        P(f"  >> TOTAL: {r5['total']*100:+.1f}% | Sortino: {r5['sortino']:.2f} | "
          f"MaxDD: {r5['max_dd']*100:.1f}%")

    # ---------------------------------------------------------
    # #6: THRESHOLD REBALANCING
    # ---------------------------------------------------------
    P(f"\n{'='*100}")
    P("  #6: THRESHOLD REBALANCING (only rebalance when change > 5%)")
    P("  " + "-" * 60)
    r6, s6, b6, a6, allocs6, ranges6 = walk_forward_v3(
        daily_ret, returns, vols, df, dates, n,
        use_bagging=True, n_bags=5,
        use_weekly_rebalance=True,
        use_threshold_rebal=True, threshold_pct=0.05,
        label="#6 ThreshRebal")
    all_results['#6 Threshold Rebal'] = r6
    all_equity_curves['#6 Threshold Rebal'] = (s6, b6)
    if r6:
        P(f"  >> TOTAL: {r6['total']*100:+.1f}% | Sortino: {r6['sortino']:.2f} | "
          f"MaxDD: {r6['max_dd']*100:.1f}%")

    # ---------------------------------------------------------
    # NATURAL COMBOS
    # ---------------------------------------------------------
    P(f"\n{'='*100}")
    P("  NATURAL COMBOS")
    P("  " + "-" * 60)

    # Combo A: #1 + #2 (Expanded Features + Sentiment)
    P("\n  Combo A: Expanded Features + Sentiment")
    rA, sA, bA, aA, allocsA, rangesA = walk_forward_v3(
        daily_ret, returns, vols, df, dates, n,
        use_bagging=True, n_bags=5,
        use_weekly_rebalance=True,
        use_expanded_features=True,
        use_sentiment=True,
        label="Combo A")
    all_results['Combo A (#1+#2)'] = rA
    all_equity_curves['Combo A (#1+#2)'] = (sA, bA)
    if rA:
        P(f"  >> TOTAL: {rA['total']*100:+.1f}% | Sortino: {rA['sortino']:.2f} | "
          f"MaxDD: {rA['max_dd']*100:.1f}%")

    # Combo B: #3 + #4 (Dynamic Weights + Mixed Models)
    P("\n  Combo B: Dynamic Weights + Mixed Models")
    rB, sB, bB, aB, allocsB, rangesB = walk_forward_v3(
        daily_ret, returns, vols, df, dates, n,
        use_bagging=True, n_bags=5,
        use_weekly_rebalance=True,
        use_dynamic_weights=True,
        use_mixed_models=True,
        label="Combo B")
    all_results['Combo B (#3+#4)'] = rB
    all_equity_curves['Combo B (#3+#4)'] = (sB, bB)
    if rB:
        P(f"  >> TOTAL: {rB['total']*100:+.1f}% | Sortino: {rB['sortino']:.2f} | "
          f"MaxDD: {rB['max_dd']*100:.1f}%")

    # Combo C: #5 + #6 (DD Overlay + Threshold Rebal)
    P("\n  Combo C: DD Overlay + Threshold Rebal")
    rC, sC, bC, aC, allocsC, rangesC = walk_forward_v3(
        daily_ret, returns, vols, df, dates, n,
        use_bagging=True, n_bags=5,
        use_weekly_rebalance=True,
        use_dd_overlay=True,
        use_threshold_rebal=True, threshold_pct=0.05,
        label="Combo C")
    all_results['Combo C (#5+#6)'] = rC
    all_equity_curves['Combo C (#5+#6)'] = (sC, bC)
    if rC:
        P(f"  >> TOTAL: {rC['total']*100:+.1f}% | Sortino: {rC['sortino']:.2f} | "
          f"MaxDD: {rC['max_dd']*100:.1f}%")

    # ---------------------------------------------------------
    # V3 BEST COMBO: all winners combined
    # ---------------------------------------------------------
    P(f"\n{'='*100}")
    P("  V3 BEST COMBO (all improvements that individually helped)")
    P("  " + "-" * 60)

    improvements = [
        ('#1 Expanded Features', r1, 'expanded_features'),
        ('#2 Sentiment Overlay', r2, 'sentiment'),
        ('#3 Dynamic Weights', r3, 'dynamic_weights'),
        ('#4 Mixed Bag (LGB+XGB)', r4, 'mixed_models'),
        ('#5 DD Overlay', r5, 'dd_overlay'),
        ('#6 Threshold Rebal', r6, 'threshold_rebal'),
    ]

    combo_flags = {}
    P("    Checking which improvements beat V2 baseline...")
    for name, r, flag in improvements:
        if r is None:
            P(f"      {name}: N/A")
            combo_flags[flag] = False
            continue
        better_return = r['total'] > baseline_total
        better_sortino = r['sortino'] > baseline_sortino
        better_dd = r['max_dd'] > baseline_dd

        if better_return or better_sortino:
            combo_flags[flag] = True
            reason = []
            if better_return:
                reason.append(f"ret {r['total']*100:+.1f}% > {baseline_total*100:+.1f}%")
            if better_sortino:
                reason.append(f"sortino {r['sortino']:.2f} > {baseline_sortino:.2f}")
            if better_dd:
                reason.append(f"dd {r['max_dd']*100:.1f}% > {baseline_dd*100:.1f}%")
            P(f"      {name}: INCLUDED ({', '.join(reason)})")
        else:
            combo_flags[flag] = False
            P(f"      {name}: excluded (ret={r['total']*100:+.1f}%, sortino={r['sortino']:.2f})")

    active = [k for k, v in combo_flags.items() if v]
    P(f"\n    Active V3 improvements: {active if active else 'NONE (V2 baseline only)'}")

    rc, sc, bc, ac, allocsc, rangesc = walk_forward_v3(
        daily_ret, returns, vols, df, dates, n,
        use_bagging=True, n_bags=5,
        use_weekly_rebalance=True,
        use_expanded_features=combo_flags.get('expanded_features', False),
        use_sentiment=combo_flags.get('sentiment', False),
        use_dynamic_weights=combo_flags.get('dynamic_weights', False),
        use_mixed_models=combo_flags.get('mixed_models', False),
        use_dd_overlay=combo_flags.get('dd_overlay', False),
        use_threshold_rebal=combo_flags.get('threshold_rebal', False),
        label="V3 Best Combo")
    all_results['V3 Best Combo'] = rc
    all_equity_curves['V3 Best Combo'] = (sc, bc)
    if rc:
        P(f"  >> V3 BEST COMBO: {rc['total']*100:+.1f}% | Sortino: {rc['sortino']:.2f} | "
          f"MaxDD: {rc['max_dd']*100:.1f}%")

    # ---------------------------------------------------------
    # BOOTSTRAP CI on key variants
    # ---------------------------------------------------------
    P(f"\n{'='*100}")
    P("  BOOTSTRAP 95% CI (1000 resamples)")
    P("  " + "-" * 60)

    variants_for_bs = [
        ('V2 Baseline', s_v2),
        ('#1 ExpandFeat', s1),
        ('#2 Sentiment', s2),
        ('#4 MixedBag', s4),
        ('V3 Best Combo', sc),
    ]
    for name, strat_rets in variants_for_bs:
        if strat_rets is not None and len(strat_rets) > 30:
            bs = bootstrap_ci(strat_rets, n_bootstrap=1000)
            bootstrap_results[name] = bs
            P(f"    {name}:")
            P(f"      Return 95% CI: [{bs['return_lo']*100:+.0f}%, {bs['return_hi']*100:+.0f}%] "
              f"(mean: {bs['return_mean']*100:+.0f}%)")
            P(f"      Sortino 95% CI: [{bs['sortino_lo']:.2f}, {bs['sortino_hi']:.2f}]")
            P(f"      P(return > 0): {bs['excess_above_zero_pct']:.1f}%")

    # ---------------------------------------------------------
    # COST/RF SENSITIVITY on V3 Best Combo
    # ---------------------------------------------------------
    P(f"\n{'='*100}")
    P("  COST / RF SENSITIVITY (replaying V3 Best Combo allocations)")
    P("  " + "-" * 60)
    sensitivity_results = cost_rf_sensitivity(daily_ret, allocsc, rangesc)

    P(f"\n    {'Setting':<25} {'Return':>10} {'Sortino':>8} {'MaxDD':>8}")
    P("    " + "-" * 55)
    for label, r in sorted(sensitivity_results.items()):
        P(f"    {label:<25} {r['total']*100:>+9.1f}% {r['sortino']:>+7.2f} {r['max_dd']*100:>7.1f}%")

    # Find breakeven cost
    for cost_bps in [1, 2, 5, 10, 15, 20, 25, 30, 40, 50]:
        cost = cost_bps / 10000.0
        all_s, all_b, all_a = [], [], []
        for (start, end) in rangesc:
            s, b, a = backtest_allocations(daily_ret, allocsc, start, end,
                                           cost=cost, rf_daily=RF_DAILY_DEFAULT)
            all_s.extend(s); all_b.extend(b); all_a.extend(a)
        r_test = metrics(np.array(all_s), np.array(all_b), np.array(all_a))
        if r_test and r_test['total'] < bh_result['total']:
            P(f"\n    Breakeven cost (vs BTC B&H): ~{cost_bps} bps "
              f"(strategy={r_test['total']*100:+.1f}% < BTC={bh_result['total']*100:+.1f}%)")
            break

    # ---------------------------------------------------------
    # FINAL COMPARISON TABLE
    # ---------------------------------------------------------
    P(f"\n{'='*100}")
    P("FINAL COMPARISON TABLE")
    P("=" * 100)

    P(f"\n{'Strategy':<30} {'Return':>10} {'BTC':>10} {'Excess':>10} "
      f"{'Sortino':>8} {'MaxDD':>8} {'AvgAlloc':>9} {'Verdict':>12}")
    P("-" * 105)

    for name, r in all_results.items():
        if r is None:
            P(f"{name:.<30} {'N/A':>10}")
            continue

        verdict = ''
        if name not in ['BTC Buy & Hold', 'V2 Baseline (Bag+Weekly)']:
            if r['total'] > baseline_total and r['sortino'] > baseline_sortino:
                verdict = 'WINNER'
            elif r['total'] > baseline_total:
                verdict = 'better ret'
            elif r['sortino'] > baseline_sortino:
                verdict = 'better risk'
            elif r['max_dd'] > baseline_dd:
                verdict = 'better dd'
            else:
                verdict = 'WORSE'

        P(f"{name:.<30} {r['total']*100:>+9.1f}% {r['btc']*100:>+9.1f}% "
          f"{r['excess']*100:>+9.1f}% {r['sortino']:>+7.2f} "
          f"{r['max_dd']*100:>7.1f}% {r['avg_alloc']:>8.2f} {verdict:>12}")

    # ---------------------------------------------------------
    # SAVE RESULTS
    # ---------------------------------------------------------
    out_dir = ROOT / 'outputs/results'
    out_dir.mkdir(parents=True, exist_ok=True)

    output = {
        'timestamp': datetime.now().isoformat(),
        'method': 'pipeline_v3_final',
        'test_period': '2022-2026',
        'description': 'V3 Final: 6 improvements on V2 Best Combo (Bag+Weekly)',
        'v2_baseline': {},
        'results': {},
        'bootstrap_ci': {},
        'sensitivity': {},
        'combo_flags': combo_flags,
    }

    for name, r in all_results.items():
        if r is not None:
            output['results'][name] = {
                k: float(v) if isinstance(v, (int, float, np.floating)) else v
                for k, v in r.items()
            }

    if r_v2:
        output['v2_baseline'] = {
            k: float(v) if isinstance(v, (int, float, np.floating)) else v
            for k, v in r_v2.items()
        }

    for name, bs in bootstrap_results.items():
        output['bootstrap_ci'][name] = {
            k: float(v) if isinstance(v, (int, float, np.floating)) else v
            for k, v in bs.items()
        }

    for label, r in sensitivity_results.items():
        output['sensitivity'][label] = {
            k: float(v) if isinstance(v, (int, float, np.floating)) else v
            for k, v in r.items()
        }

    with open(out_dir / 'pipeline_v3_final.json', 'w') as f:
        json.dump(output, f, indent=2, default=str)
    P(f"\n  Results saved: {out_dir / 'pipeline_v3_final.json'}")

    # ---------------------------------------------------------
    # CHARTS
    # ---------------------------------------------------------
    P("\n  Generating charts...")
    chart_dir = ROOT / 'outputs/results/charts'
    generate_charts(all_results, all_equity_curves, bootstrap_results, chart_dir)

    # ---------------------------------------------------------
    # VERDICT
    # ---------------------------------------------------------
    P(f"\n{'='*100}")
    P("VERDICT")
    P("=" * 100)

    if r_v2:
        P(f"\n  V2 Baseline (Bag+Weekly): {baseline_total*100:+.1f}% | "
          f"Sortino: {baseline_sortino:.2f} | MaxDD: {baseline_dd*100:.1f}%")

        winners = []
        for name, r in all_results.items():
            if name in ['BTC Buy & Hold', 'V2 Baseline (Bag+Weekly)']:
                continue
            if r is not None and r['total'] > baseline_total:
                winners.append((name, r))

        if winners:
            P(f"\n  V3 IMPROVEMENTS THAT BEAT V2 BASELINE ({baseline_total*100:+.1f}%):")
            for name, r in sorted(winners, key=lambda x: x[1]['total'], reverse=True):
                imp = (r['total'] - baseline_total) * 100
                P(f"    {name}: {r['total']*100:+.1f}% ({imp:+.1f}pp) | "
                  f"Sortino: {r['sortino']:.2f} | MaxDD: {r['max_dd']*100:.1f}%")
        else:
            P(f"\n  No V3 improvement beat V2 baseline on return. V2 is already well-optimized.")

        # Risk-adjusted improvements
        risk_winners = []
        for name, r in all_results.items():
            if name in ['BTC Buy & Hold', 'V2 Baseline (Bag+Weekly)']:
                continue
            if r is not None and r['sortino'] > baseline_sortino:
                risk_winners.append((name, r))
        if risk_winners:
            P(f"\n  BETTER RISK-ADJUSTED (Sortino > {baseline_sortino:.2f}):")
            for name, r in sorted(risk_winners, key=lambda x: x[1]['sortino'], reverse=True):
                P(f"    {name}: Sortino {r['sortino']:.2f} | MaxDD: {r['max_dd']*100:.1f}%")

        # Best combo assessment
        if rc:
            P(f"\n  V3 Best Combo: {rc['total']*100:+.1f}% | Sortino: {rc['sortino']:.2f} | "
              f"MaxDD: {rc['max_dd']*100:.1f}%")
            v3_vs_v2 = (rc['total'] - baseline_total) * 100
            P(f"  V3 vs V2: {v3_vs_v2:+.1f}pp")

            if 'V3 Best Combo' in bootstrap_results:
                bs = bootstrap_results['V3 Best Combo']
                P(f"\n  V3 Best Combo Bootstrap 95% CI: "
                  f"[{bs['return_lo']*100:+.0f}%, {bs['return_hi']*100:+.0f}%]")
                if bs['return_lo'] > 0:
                    P(f"  STATISTICALLY SIGNIFICANT: CI excludes zero!")
                else:
                    P(f"  NOT significant at 95%: CI includes zero.")

    P(f"\n{'='*100}")
    P("PIPELINE V3 FINAL COMPLETE")
    P("=" * 100)


if __name__ == '__main__':
    main()
