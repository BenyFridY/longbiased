"""
PIPELINE V8 AUDIT - Overfitting Audit + Missing Combinations
=============================================================

V1-V7 tested 200+ variants on the same OOS (2022-2026). Best: D6 +426% (seed 42),
most stable: F2 top2+Bag30 (+412% mean, 39pp spread).

V8 objectives:
  Part A: Missing combinations (D6+Bag30, alternative swaps with Bag30, meta-ensemble)
  Part B: Overfitting audit (permutation, DSR, CAPM alpha, CPCV, per-fold ranking, etc.)
  Part C: Leverage & risk analysis (decomposition, allocation distribution, stress test)
  Part D: Robustness extensions (rolling window, LGB grid, scaling sensitivity, etc.)

Total: ~80+ tests + 1000 shuffles + 100 retrains + 20 CPCV paths
"""

import sys
import pandas as pd
import numpy as np
from pathlib import Path
import warnings
import json
from datetime import datetime
from scipy import stats as scipy_stats
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import lightgbm as lgb

warnings.filterwarnings('ignore')
sys.stdout.reconfigure(line_buffering=True)

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

COST = 0.0002       # 2 bps
N_TRIALS_TOTAL = 200  # total variants tested V1-V7

# RF_DAILY_ARR is set in main() from real CDI/Selic data.
# These scalars are legacy fallbacks only used before main() runs.
RF_ANNUAL = 0.15
RF_DAILY = (1 + RF_ANNUAL)**(1/365) - 1
RF_DAILY_ARR = None   # populated in main()

def P(*a, **kw):
    try:
        print(*a, **kw, flush=True)
    except UnicodeEncodeError:
        text = ' '.join(str(x) for x in a)
        text = text.encode('ascii', errors='replace').decode('ascii')
        print(text, **kw, flush=True)


# ============================================================
# SECTION 1: CONSTANTS (from V7)
# ============================================================

DEFAULT_FEATURE_COLS = [
    'cusum_pos', 'miners_revenue_ratio', 'mr_score_30d', 'adx',
    'cusum_neg', 'exchange_netflow_ma7', 'structural_break_score',
    'macd_histogram', 'eth_btc_ratio', 'm2_yoy_growth',
    'volatility_7d', 'basis_ma7', 'nupl_ma30', 'hurst_60d',
    'funding_rate', 'bb_position', 'rsi_14d', 'puell_multiple',
    'stablecoin_zscore', 'sopr_ma7',
]

WEAK_FEATURES = ['funding_rate', 'puell_multiple', 'sopr_ma7', 'rsi_14d']

SEEDS_10 = [42, 142, 242, 342, 442, 542, 642, 742, 842, 942]


# ============================================================
# SECTION 2: DATA LOADING (from V7)
# ============================================================

def load_data():
    df = pd.read_csv(ROOT / 'outputs/feature_selection/dataset_enhanced.csv')
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)

    prices = df['price_usd'].values
    n = len(prices)

    daily_ret = np.zeros(n)
    for i in range(1, n):
        daily_ret[i] = (prices[i] - prices[i-1]) / prices[i-1]

    returns = {}
    for w in [1, 3, 5, 7, 10, 14, 20, 21, 30, 45, 60]:
        r = np.zeros(n)
        for i in range(w, n):
            r[i] = (prices[i] - prices[i-w]) / prices[i-w]
        returns[w] = r

    vols = {}
    for w in [5, 7, 10, 14, 21, 30]:
        vols[w] = pd.Series(daily_ret).rolling(w).std().fillna(0.02).values

    return prices, daily_ret, returns, vols, df


# ============================================================
# SECTION 3: CORE ENGINE (from V7)
# ============================================================

def backtest_allocations(daily_ret, allocations, start_idx, end_idx,
                         cost=COST, rf_daily=None,
                         clip_min=-0.25, clip_max=1.0):
    if rf_daily is None:
        rf_daily = RF_DAILY_ARR if RF_DAILY_ARR is not None else RF_DAILY
    strat, btc, allocs = [], [], []
    prev = 0.5
    n = len(daily_ret)
    is_arr = isinstance(rf_daily, np.ndarray)
    for t in range(start_idx, min(end_idx, n - 1)):
        a = np.clip(allocations[t], clip_min, clip_max)
        br = daily_ret[t + 1]
        rf_t = rf_daily[t] if is_arr else rf_daily
        tc = abs(a - prev) * cost * (1.5 if a < 0 else 1.0)
        sr = a * br + (1 - abs(a)) * rf_t - tc
        strat.append(sr)
        btc.append(br)
        allocs.append(a)
        prev = a
    return np.array(strat), np.array(btc), np.array(allocs)


def metrics(s, b, a, rf_daily=None):
    if len(s) < 10:
        return None
    if rf_daily is None:
        rf_daily = RF_DAILY
    # rf_daily can be scalar or array (same length as s)
    ts = np.prod(1 + s) - 1
    tb = np.prod(1 + b) - 1
    ex = s - rf_daily
    ds = ex[ex < 0]
    sortino = np.mean(ex) / (np.std(ds) + 1e-10) * np.sqrt(365) if len(ds) > 0 else 0
    cum = np.cumprod(1 + s)
    pk = np.maximum.accumulate(cum)
    dd = np.min((cum - pk) / (pk + 1e-10))
    sharpe = np.mean(ex) / (np.std(s) + 1e-10) * np.sqrt(365)
    calmar = ts / (abs(dd) + 1e-10)
    return {'total': ts, 'btc': tb, 'excess': ts - tb, 'sortino': sortino,
            'sharpe': sharpe, 'calmar': calmar,
            'max_dd': dd, 'short_pct': float((a < 0).mean()), 'avg_alloc': float(np.mean(a))}


def get_year_boundaries(dates, n):
    yb = {}
    for i in range(n):
        yr = pd.Timestamp(dates[i]).year
        if yr not in yb:
            yb[yr] = {'start': i, 'end': i}
        yb[yr]['end'] = i
    return yb


# ============================================================
# SECTION 4: FEATURE BUILDING (from V7)
# ============================================================

def build_ml_features(df, returns, vols, n, feature_cols=None):
    if feature_cols is None:
        feature_cols = DEFAULT_FEATURE_COLS

    price_derived_map = {
        'ret_3d': returns[3], 'ret_5d': returns[5], 'ret_7d': returns[7],
        'ret_10d': returns[10], 'ret_14d': returns[14], 'ret_30d': returns[30],
        'ret_45d': returns[45], 'ret_60d': returns[60],
        'vol_7d': vols[7], 'vol_14d': vols[14], 'vol_30d': vols[30],
    }

    cols, names = [], []
    for col in feature_cols:
        if col in price_derived_map:
            cols.append(price_derived_map[col])
            names.append(col)
        elif col in df.columns:
            cols.append(df[col].values.astype(float))
            names.append(col)

    for pd_feat in ['ret_3d', 'ret_10d', 'ret_30d', 'ret_60d', 'vol_14d']:
        if pd_feat not in names:
            cols.append(price_derived_map[pd_feat])
            names.append(pd_feat)

    X_all = np.column_stack(cols) if cols else np.zeros((n, 0))
    return X_all, names


def build_ml_features_swap(df, returns, vols, n, swap_dict):
    feature_cols = list(DEFAULT_FEATURE_COLS)
    for weak, strong in swap_dict.items():
        if weak in feature_cols:
            idx = feature_cols.index(weak)
            feature_cols[idx] = strong
    return build_ml_features(df, returns, vols, n, feature_cols=feature_cols)


# ============================================================
# SECTION 5: ML TRAINING (from V7)
# ============================================================

def train_lgb_bagged(X_all, target, train_end, horizon_gap=5, n_bags=5,
                     base_seed=42, lgb_params=None):
    models = []
    for i in range(n_bags):
        seed = base_seed + i * 7
        train_mask = np.arange(60, train_end - horizon_gap + 1)
        valid_train = ~np.any(np.isnan(X_all[train_mask]), axis=1)
        train_idx = train_mask[valid_train]
        if len(train_idx) < 100:
            continue
        X_train = np.nan_to_num(X_all[train_idx], nan=0.0)
        y_train = target[train_idx]
        params = lgb_params or {
            'objective': 'regression', 'metric': 'mae',
            'num_leaves': 31, 'learning_rate': 0.05,
            'feature_fraction': 0.7, 'bagging_fraction': 0.8,
            'bagging_freq': 5, 'verbose': -1, 'n_jobs': 1, 'seed': seed,
        }
        if 'seed' not in params or lgb_params is not None:
            params = dict(params)
            params['seed'] = seed
        num_round = params.pop('num_boost_round', 200)
        dtrain = lgb.Dataset(X_train, label=y_train)
        models.append(lgb.train(params, dtrain, num_boost_round=num_round))
    return models if len(models) > 0 else None


def ml_predict(models, X_all, t, scale_div=0.05):
    x_t = np.nan_to_num(X_all[t:t+1].copy(), nan=0.0)
    preds = [m.predict(x_t)[0] for m in models]
    avg_pred = np.mean(preds)
    scaled = np.clip(avg_pred / scale_div, -1.0, 1.0)
    if scaled > 0:
        return 0.5 + scaled * 0.5
    else:
        return 0.5 + scaled * 0.75


# ============================================================
# SECTION 6: WALK-FORWARD ENGINE (from V7, enhanced)
# ============================================================

def run_strategy(daily_ret, returns, vols, df, dates, n,
                 n_bags=5, use_weekly=True, target_horizon=3,
                 X_all_override=None, base_seed=42,
                 clip_min=-0.25, clip_max=1.0,
                 cost=COST, rf_daily=None,
                 verbose=False, return_allocs=False,
                 return_per_year=False,
                 lgb_params=None, scale_div=0.05,
                 rolling_window_years=None,
                 swap_dict=None,
                 feature_cols_per_fold=None):
    if rf_daily is None:
        rf_daily = RF_DAILY_ARR if RF_DAILY_ARR is not None else RF_DAILY
    """Unified walk-forward engine. Supports:
    - X_all_override: precomputed features
    - swap_dict: build features with swaps on the fly
    - feature_cols_per_fold: dict {year: feature_cols} for per-fold feature selection (B7)
    - rolling_window_years: int, use rolling window instead of expanding
    - lgb_params: custom LGB hyperparameters
    - scale_div: prediction scaling divisor
    """
    yb = get_year_boundaries(dates, n)
    prices = df['price_usd'].values

    # Build features once if not per-fold
    if feature_cols_per_fold is None:
        if X_all_override is not None:
            X_all = X_all_override
        elif swap_dict is not None:
            X_all, _ = build_ml_features_swap(df, returns, vols, n, swap_dict)
        else:
            X_all, _ = build_ml_features(df, returns, vols, n)

    target = np.zeros(n)
    h = target_horizon
    for i in range(n - h):
        target[i] = (prices[i + h] - prices[i]) / prices[i]

    day_of_week = pd.to_datetime(dates).dayofweek

    all_strat, all_btc, all_alloc, all_rf = [], [], [], []
    full_allocs = np.full(n, 0.5)
    year_metrics = {}
    is_rf_arr = isinstance(rf_daily, np.ndarray)

    for test_year in range(2022, 2027):
        if test_year not in yb:
            continue

        # Per-fold feature building
        if feature_cols_per_fold is not None:
            if test_year in feature_cols_per_fold:
                fc = feature_cols_per_fold[test_year]
                X_all, _ = build_ml_features(df, returns, vols, n, feature_cols=fc)
            else:
                X_all, _ = build_ml_features(df, returns, vols, n)

        train_end = yb[test_year]['start'] - 1
        test_start = yb[test_year]['start']
        test_end = yb[test_year]['end']

        # Rolling window: limit training data
        if rolling_window_years is not None:
            roll_start_year = test_year - rolling_window_years
            roll_start_idx = 60
            for yr_check in range(2015, roll_start_year):
                if yr_check in yb:
                    roll_start_idx = max(roll_start_idx, yb[yr_check]['end'] + 1)
            # Mask training to rolling window
            train_mask_start = roll_start_idx
        else:
            train_mask_start = 60

        horizon_gap = max(target_horizon, 5)

        # Custom training with rolling window support
        models_list = []
        for i in range(n_bags):
            seed = base_seed + i * 7
            train_mask = np.arange(train_mask_start, train_end - horizon_gap + 1)
            valid_train = ~np.any(np.isnan(X_all[train_mask]), axis=1)
            train_idx = train_mask[valid_train]
            if len(train_idx) < 100:
                continue
            X_train = np.nan_to_num(X_all[train_idx], nan=0.0)
            y_train = target[train_idx]
            params = lgb_params or {
                'objective': 'regression', 'metric': 'mae',
                'num_leaves': 31, 'learning_rate': 0.05,
                'feature_fraction': 0.7, 'bagging_fraction': 0.8,
                'bagging_freq': 5, 'verbose': -1, 'n_jobs': 1, 'seed': seed,
            }
            params = dict(params)
            params['seed'] = seed
            params['verbose'] = -1
            params['n_jobs'] = 1
            num_round = params.pop('num_boost_round', 200)
            dtrain = lgb.Dataset(X_train, label=y_train)
            models_list.append(lgb.train(params, dtrain, num_boost_round=num_round))

        models = models_list if len(models_list) > 0 else None

        if verbose:
            P(f"    {test_year}: {len(models) if models else 0} models", end="")

        prev_alloc = 0.5
        for t in range(test_start, test_end + 1):
            if models is not None:
                a_ml = ml_predict(models, X_all, t, scale_div=scale_div)
            else:
                a_ml = 0.5

            raw_alloc = a_ml

            if use_weekly and day_of_week[t] != 4:
                raw_alloc = prev_alloc

            full_allocs[t] = np.clip(raw_alloc, clip_min, clip_max)
            prev_alloc = full_allocs[t]

        s, b, a = backtest_allocations(daily_ret, full_allocs, test_start, test_end,
                                       cost=cost, rf_daily=rf_daily,
                                       clip_min=clip_min, clip_max=clip_max)
        all_strat.extend(s)
        all_btc.extend(b)
        all_alloc.extend(a)

        # Collect matching rf slice for metrics
        n_days = len(s)
        if is_rf_arr:
            rf_slice = rf_daily[test_start:test_start + n_days]
            all_rf.extend(rf_slice)
        else:
            all_rf.extend([rf_daily] * n_days)

        rf_yr = np.array(all_rf[-n_days:])
        m_yr = metrics(np.array(s), np.array(b), np.array(a), rf_daily=rf_yr)
        if return_per_year and m_yr:
            year_metrics[test_year] = m_yr
        if verbose and m_yr:
            P(f" -> {m_yr['total']*100:+.1f}%")
        elif verbose:
            P(" -> N/A")

    result = metrics(np.array(all_strat), np.array(all_btc), np.array(all_alloc),
                     rf_daily=np.array(all_rf))

    out = [result]
    if return_allocs:
        out.append(full_allocs.copy())
        out.append(np.array(all_strat))
        out.append(np.array(all_btc))
        out.append(np.array(all_alloc))
    if return_per_year:
        out.append(year_metrics)
    if len(out) == 1:
        return out[0]
    return tuple(out)


# ============================================================
# SECTION 7: PART A — MISSING COMBINATIONS
# ============================================================

def part_a_missing_combos(daily_ret, returns, vols, df, dates, n, baseline_v2_ret=2.21):
    P(f"\n{'#'*100}")
    P("PART A: MISSING COMBINATIONS")
    P("#" * 100)

    results = {}
    alloc_store = {}  # Store allocations for Part C

    # --- A1: D6 + Bag30 (10 seeds) ---
    P(f"\n  A1: D6 (puell->eth, rsi->momentum_accel_7d) + Bag30, 10 seeds")
    swap_d6 = {'puell_multiple': 'eth', 'rsi_14d': 'momentum_accel_7d'}
    X_d6, _ = build_ml_features_swap(df, returns, vols, n, swap_d6)
    a1_seeds = []
    for seed in SEEDS_10:
        P(f"    seed={seed}...", end="")
        r, allocs, strat_r, btc_r, alloc_a = run_strategy(
            daily_ret, returns, vols, df, dates, n,
            n_bags=30, X_all_override=X_d6, base_seed=seed,
            return_allocs=True)
        if r:
            a1_seeds.append(r)
            P(f" {r['total']*100:+.1f}%")
            if seed == 42:
                alloc_store['A1_D6_Bag30'] = {
                    'allocs': allocs, 'strat_ret': strat_r,
                    'btc_ret': btc_r, 'alloc_arr': alloc_a}
        else:
            P(" FAILED")

    a1_rets = [r['total']*100 for r in a1_seeds]
    a1_summary = _seed_summary(a1_rets, a1_seeds, baseline_v2_ret)
    results['A1_D6_Bag30'] = {'swap': swap_d6, 'n_bags': 30, 'seeds': a1_summary}
    P(f"    => mean={a1_summary['mean']:+.1f}%, spread={a1_summary['spread']:.0f}pp, "
      f"beat_v2={a1_summary['beat_v2']}/10")

    # --- A2: puell->eth + rsi->plus_di, Bag30 ---
    P(f"\n  A2: puell->eth + rsi->plus_di + Bag30, 10 seeds")
    swap_a2 = {'puell_multiple': 'eth', 'rsi_14d': 'plus_di'}
    X_a2, _ = build_ml_features_swap(df, returns, vols, n, swap_a2)
    a2_seeds = []
    for seed in SEEDS_10:
        P(f"    seed={seed}...", end="")
        r, allocs, strat_r, btc_r, alloc_a = run_strategy(
            daily_ret, returns, vols, df, dates, n,
            n_bags=30, X_all_override=X_a2, base_seed=seed,
            return_allocs=True)
        if r:
            a2_seeds.append(r)
            P(f" {r['total']*100:+.1f}%")
            if seed == 42:
                alloc_store['A2_eth_plusdi_Bag30'] = {
                    'allocs': allocs, 'strat_ret': strat_r,
                    'btc_ret': btc_r, 'alloc_arr': alloc_a}
        else:
            P(" FAILED")

    a2_rets = [r['total']*100 for r in a2_seeds]
    a2_summary = _seed_summary(a2_rets, a2_seeds, baseline_v2_ret)
    results['A2_eth_plusdi_Bag30'] = {'swap': swap_a2, 'n_bags': 30, 'seeds': a2_summary}
    P(f"    => mean={a2_summary['mean']:+.1f}%, spread={a2_summary['spread']:.0f}pp, "
      f"beat_v2={a2_summary['beat_v2']}/10")

    # --- A3: puell->eth + rsi->eth_pctchg_30d, Bag30 ---
    P(f"\n  A3: puell->eth + rsi->eth_pctchg_30d + Bag30, 10 seeds")
    swap_a3 = {'puell_multiple': 'eth', 'rsi_14d': 'eth_pctchg_30d'}
    X_a3, _ = build_ml_features_swap(df, returns, vols, n, swap_a3)
    a3_seeds = []
    for seed in SEEDS_10:
        P(f"    seed={seed}...", end="")
        r, allocs, strat_r, btc_r, alloc_a = run_strategy(
            daily_ret, returns, vols, df, dates, n,
            n_bags=30, X_all_override=X_a3, base_seed=seed,
            return_allocs=True)
        if r:
            a3_seeds.append(r)
            P(f" {r['total']*100:+.1f}%")
            if seed == 42:
                alloc_store['A3_eth_ethpctchg_Bag30'] = {
                    'allocs': allocs, 'strat_ret': strat_r,
                    'btc_ret': btc_r, 'alloc_arr': alloc_a}
        else:
            P(" FAILED")

    a3_rets = [r['total']*100 for r in a3_seeds]
    a3_summary = _seed_summary(a3_rets, a3_seeds, baseline_v2_ret)
    results['A3_eth_ethpctchg_Bag30'] = {'swap': swap_a3, 'n_bags': 30, 'seeds': a3_summary}
    P(f"    => mean={a3_summary['mean']:+.1f}%, spread={a3_summary['spread']:.0f}pp, "
      f"beat_v2={a3_summary['beat_v2']}/10")

    # --- A4: D5 non-ETH + Bag30 ---
    P(f"\n  A4: D5 non-ETH (puell+rsi->momentum_accel, sopr+funding->sharpe_3y) + Bag30, 10 seeds")
    swap_a4 = {
        'puell_multiple': 'momentum_accel_7d',
        'rsi_14d': 'momentum_accel_7d',
        'sopr_ma7': 'sharpe_3y_artemis',
        'funding_rate': 'sharpe_3y_artemis',
    }
    X_a4, _ = build_ml_features_swap(df, returns, vols, n, swap_a4)
    a4_seeds = []
    for seed in SEEDS_10:
        P(f"    seed={seed}...", end="")
        r, allocs, strat_r, btc_r, alloc_a = run_strategy(
            daily_ret, returns, vols, df, dates, n,
            n_bags=30, X_all_override=X_a4, base_seed=seed,
            return_allocs=True)
        if r:
            a4_seeds.append(r)
            P(f" {r['total']*100:+.1f}%")
            if seed == 42:
                alloc_store['A4_D5_Bag30'] = {
                    'allocs': allocs, 'strat_ret': strat_r,
                    'btc_ret': btc_r, 'alloc_arr': alloc_a}
        else:
            P(" FAILED")

    a4_rets = [r['total']*100 for r in a4_seeds]
    a4_summary = _seed_summary(a4_rets, a4_seeds, baseline_v2_ret)
    results['A4_D5_Bag30'] = {'swap': swap_a4, 'n_bags': 30, 'seeds': a4_summary}
    P(f"    => mean={a4_summary['mean']:+.1f}%, spread={a4_summary['spread']:.0f}pp, "
      f"beat_v2={a4_summary['beat_v2']}/10")

    # --- A5: Meta-ensemble (average of A1+A2+A3 allocations), seed 42 ---
    P(f"\n  A5: Meta-ensemble (average A1+A2+A3 allocations), seed 42")
    if all(k in alloc_store for k in ['A1_D6_Bag30', 'A2_eth_plusdi_Bag30', 'A3_eth_ethpctchg_Bag30']):
        yb = get_year_boundaries(dates, n)
        ensemble_allocs = np.full(n, 0.5)
        for t in range(n):
            a1_val = alloc_store['A1_D6_Bag30']['allocs'][t]
            a2_val = alloc_store['A2_eth_plusdi_Bag30']['allocs'][t]
            a3_val = alloc_store['A3_eth_ethpctchg_Bag30']['allocs'][t]
            ensemble_allocs[t] = (a1_val + a2_val + a3_val) / 3.0

        all_s, all_b, all_a = [], [], []
        for yr in range(2022, 2027):
            if yr not in yb:
                continue
            s, b, a = backtest_allocations(daily_ret, ensemble_allocs,
                                           yb[yr]['start'], yb[yr]['end'])
            all_s.extend(s); all_b.extend(b); all_a.extend(a)

        r_ens = metrics(np.array(all_s), np.array(all_b), np.array(all_a))
        if r_ens:
            P(f"    Result: {r_ens['total']*100:+.1f}% | Sortino {r_ens['sortino']:.2f} | "
              f"MaxDD {r_ens['max_dd']*100:.1f}%")
            alloc_store['A5_ensemble'] = {
                'allocs': ensemble_allocs, 'strat_ret': np.array(all_s),
                'btc_ret': np.array(all_b), 'alloc_arr': np.array(all_a)}
        results['A5_ensemble'] = {'config': 'avg(A1,A2,A3) allocs', 'result': r_ens}
    else:
        P("    SKIPPED (missing component allocations)")
        results['A5_ensemble'] = {'config': 'avg(A1,A2,A3) allocs', 'result': None}

    # --- Also run F2 reference (top2+Bag30) for comparison ---
    P(f"\n  REF: F2 top2+Bag30 (puell+rsi->eth), seed 42")
    swap_f2 = {'puell_multiple': 'eth', 'rsi_14d': 'eth'}
    X_f2, _ = build_ml_features_swap(df, returns, vols, n, swap_f2)
    r_f2, allocs_f2, strat_f2, btc_f2, alloc_f2 = run_strategy(
        daily_ret, returns, vols, df, dates, n,
        n_bags=30, X_all_override=X_f2, base_seed=42,
        return_allocs=True)
    if r_f2:
        P(f"    F2 ref: {r_f2['total']*100:+.1f}%")
        alloc_store['F2_top2_Bag30'] = {
            'allocs': allocs_f2, 'strat_ret': strat_f2,
            'btc_ret': btc_f2, 'alloc_arr': alloc_f2}
    results['F2_ref'] = {'result': r_f2}

    # --- Summary ---
    P(f"\n  {'='*80}")
    P(f"  PART A SUMMARY")
    P(f"  {'='*80}")
    P(f"  {'Strategy':<30} {'Mean':>8} {'Spread':>8} {'BeatV2':>8} {'Sortino(42)':>12}")
    P(f"  {'-'*70}")
    for key in ['A1_D6_Bag30', 'A2_eth_plusdi_Bag30', 'A3_eth_ethpctchg_Bag30', 'A4_D5_Bag30']:
        info = results[key]['seeds']
        P(f"  {key:<30} {info['mean']:>+7.1f}% {info['spread']:>7.0f}pp "
          f"{info['beat_v2']:>5}/10 {info['sortinos_mean']:>11.2f}")
    if results['A5_ensemble']['result']:
        r5 = results['A5_ensemble']['result']
        P(f"  {'A5_ensemble':<30} {r5['total']*100:>+7.1f}% {'---':>8} "
          f"{'---':>8} {r5['sortino']:>11.2f}")

    return results, alloc_store


def _seed_summary(rets, seed_results, baseline_v2_ret):
    beat_v2 = sum(1 for p in rets if p > baseline_v2_ret * 100)
    beat_b7 = sum(1 for p in rets if p > 285)
    sortinos = [r['sortino'] for r in seed_results]
    max_dds = [r['max_dd']*100 for r in seed_results]
    return {
        'returns': [float(p) for p in rets],
        'mean': float(np.mean(rets)),
        'median': float(np.median(rets)),
        'spread': float(max(rets) - min(rets)),
        'min': float(min(rets)), 'max': float(max(rets)),
        'beat_v2': beat_v2, 'beat_b7': beat_b7,
        'sortinos': [float(s) for s in sortinos],
        'sortinos_mean': float(np.mean(sortinos)),
        'max_dds': [float(d) for d in max_dds],
        'max_dds_mean': float(np.mean(max_dds)),
    }


# ============================================================
# SECTION 8: PART B — OVERFITTING AUDIT
# ============================================================

def part_b_overfitting_audit(daily_ret, returns, vols, df, dates, n,
                             alloc_store, best_strat_key='A1_D6_Bag30'):
    P(f"\n{'#'*100}")
    P("PART B: OVERFITTING AUDIT")
    P("#" * 100)

    results = {}
    prices = df['price_usd'].values
    yb = get_year_boundaries(dates, n)

    # Get the best strategy's data
    best = alloc_store.get(best_strat_key)
    if best is None:
        best = alloc_store.get('F2_top2_Bag30')
        best_strat_key = 'F2_top2_Bag30'
    if best is None:
        P("  ERROR: No allocation data available for audit")
        return results

    strat_ret = best['strat_ret']
    btc_ret = best['btc_ret']
    alloc_arr = best['alloc_arr']

    # Build OOS rf array for inline backtests
    oos_start = yb[2022]['start'] if 2022 in yb else 0
    if RF_DAILY_ARR is not None:
        rf_oos = RF_DAILY_ARR[oos_start:oos_start + len(strat_ret)]
    else:
        rf_oos = np.full(len(strat_ret), RF_DAILY)

    P(f"  Auditing strategy: {best_strat_key}")
    P(f"  OOS days: {len(strat_ret)}")

    # ----- B1a: Allocation Shuffle (1000 permutations) -----
    P(f"\n  B1a: Allocation Shuffle Permutation Test (1000 perms)...")
    real_return = np.prod(1 + strat_ret) - 1
    rng = np.random.RandomState(42)
    n_perm = 1000
    block_size = 5
    n_oos = len(alloc_arr)
    perm_returns = []
    for _ in range(n_perm):
        # Block shuffle allocations
        n_blocks = n_oos // block_size
        block_indices = np.arange(n_blocks)
        rng.shuffle(block_indices)
        shuffled_allocs = np.zeros(n_oos)
        for bi, orig_bi in enumerate(block_indices):
            start = bi * block_size
            orig_start = orig_bi * block_size
            end = min(start + block_size, n_oos)
            orig_end = min(orig_start + block_size, n_oos)
            length = min(end - start, orig_end - orig_start)
            shuffled_allocs[start:start+length] = alloc_arr[orig_start:orig_start+length]
        # Remaining
        remainder = n_blocks * block_size
        if remainder < n_oos:
            shuffled_allocs[remainder:] = alloc_arr[remainder:]

        # Backtest with shuffled allocations
        perm_strat = []
        prev = 0.5
        for i in range(len(btc_ret)):
            a = shuffled_allocs[i] if i < len(shuffled_allocs) else 0.5
            tc = abs(a - prev) * COST * (1.5 if a < 0 else 1.0)
            sr = a * btc_ret[i] + (1 - abs(a)) * rf_oos[i] - tc
            perm_strat.append(sr)
            prev = a
        perm_total = np.prod(1 + np.array(perm_strat)) - 1
        perm_returns.append(perm_total)

    p_val_b1a = np.mean([pr >= real_return for pr in perm_returns])
    P(f"    Real return: {real_return*100:+.1f}%")
    P(f"    Shuffle mean: {np.mean(perm_returns)*100:+.1f}%")
    P(f"    p-value: {p_val_b1a:.4f} {'PASS' if p_val_b1a < 0.05 else 'FAIL'}")
    results['B1a_alloc_shuffle'] = {
        'real_return': float(real_return),
        'shuffle_mean': float(np.mean(perm_returns)),
        'shuffle_std': float(np.std(perm_returns)),
        'p_value': float(p_val_b1a),
        'n_perms': n_perm,
        'pass': p_val_b1a < 0.05,
    }

    # ----- B1b: Return Shuffle (100 retrains) -----
    P(f"\n  B1b: Return Shuffle Permutation Test (100 retrains)...")
    # Use best strategy's swap config to determine which features to build
    swap_d6 = {'puell_multiple': 'eth', 'rsi_14d': 'momentum_accel_7d'}
    X_best, _ = build_ml_features_swap(df, returns, vols, n, swap_d6)
    real_sortino = metrics(strat_ret, btc_ret, alloc_arr)['sortino']
    n_perm_b1b = 100
    block_size_b1b = 30
    perm_sortinos = []
    for perm_i in range(n_perm_b1b):
        if (perm_i + 1) % 20 == 0:
            P(f"    perm {perm_i+1}/{n_perm_b1b}...")
        rng_b = np.random.RandomState(perm_i * 17 + 3)
        # Block-shuffle daily returns
        shuffled_daily = daily_ret.copy()
        oos_start = yb[2022]['start']
        oos_data = shuffled_daily[oos_start:]
        n_oos_full = len(oos_data)
        n_blk = n_oos_full // block_size_b1b
        blk_idx = np.arange(n_blk)
        rng_b.shuffle(blk_idx)
        shuffled_oos = np.zeros(n_oos_full)
        for bi, orig_bi in enumerate(blk_idx):
            s1 = bi * block_size_b1b
            s2 = orig_bi * block_size_b1b
            ln = min(block_size_b1b, n_oos_full - s1, n_oos_full - s2)
            shuffled_oos[s1:s1+ln] = oos_data[s2:s2+ln]
        rem = n_blk * block_size_b1b
        if rem < n_oos_full:
            shuffled_oos[rem:] = oos_data[rem:]
        shuffled_daily[oos_start:] = shuffled_oos

        # Recompute prices and target from shuffled returns
        shuffled_prices = np.zeros(n)
        shuffled_prices[0] = prices[0]
        for i in range(1, n):
            shuffled_prices[i] = shuffled_prices[i-1] * (1 + shuffled_daily[i])
        shuffled_target = np.zeros(n)
        for i in range(n - 3):
            shuffled_target[i] = (shuffled_prices[i+3] - shuffled_prices[i]) / shuffled_prices[i]

        # Walk-forward with shuffled targets
        all_s, all_b, all_a = [], [], []
        full_a = np.full(n, 0.5)
        dow = pd.to_datetime(dates).dayofweek
        for test_year in range(2022, 2027):
            if test_year not in yb:
                continue
            te = yb[test_year]['start'] - 1
            ts_y = yb[test_year]['start']
            te_y = yb[test_year]['end']
            models = train_lgb_bagged(X_best, shuffled_target, te,
                                      horizon_gap=5, n_bags=30, base_seed=42)
            if models is None:
                continue
            prev_a = 0.5
            for t in range(ts_y, te_y + 1):
                a_ml = ml_predict(models, X_best, t)
                raw = a_ml
                if dow[t] != 4:
                    raw = prev_a
                full_a[t] = np.clip(raw, -0.25, 1.0)
                prev_a = full_a[t]
            s, b, a = backtest_allocations(shuffled_daily, full_a, ts_y, te_y)
            all_s.extend(s); all_b.extend(b); all_a.extend(a)

        m_perm = metrics(np.array(all_s), np.array(all_b), np.array(all_a))
        if m_perm:
            perm_sortinos.append(m_perm['sortino'])

    p_val_b1b = np.mean([ps >= real_sortino for ps in perm_sortinos]) if perm_sortinos else 1.0
    P(f"    Real Sortino: {real_sortino:.2f}")
    P(f"    Shuffle Sortinos: mean={np.mean(perm_sortinos):.2f}, "
      f"max={np.max(perm_sortinos):.2f}" if perm_sortinos else "    No valid perms")
    P(f"    p-value: {p_val_b1b:.4f} {'PASS' if p_val_b1b < 0.05 else 'FAIL'}")
    results['B1b_return_shuffle'] = {
        'real_sortino': float(real_sortino),
        'shuffle_mean': float(np.mean(perm_sortinos)) if perm_sortinos else None,
        'shuffle_std': float(np.std(perm_sortinos)) if perm_sortinos else None,
        'p_value': float(p_val_b1b),
        'n_perms': len(perm_sortinos),
        'pass': p_val_b1b < 0.05,
    }

    # ----- B2: Deflated Sharpe Ratio -----
    P(f"\n  B2: Deflated Sharpe Ratio (Bailey & Lopez de Prado, 2014)...")
    sr_obs = metrics(strat_ret, btc_ret, alloc_arr)['sharpe']
    T = len(strat_ret)
    gamma3 = float(scipy_stats.skew(strat_ret))
    gamma4 = float(scipy_stats.kurtosis(strat_ret, fisher=False))
    N = N_TRIALS_TOTAL

    # Expected max SR under null: E[max] ~ sqrt(2*ln(N)) (Euler approx for iid normals)
    sr_benchmark = np.sqrt(2 * np.log(N)) * (1 - 0.5772 / (2 * np.log(N)))
    # Annualize benchmark
    sr_benchmark_ann = sr_benchmark  # already in same units

    # Variance of SR estimator
    v_sr = (1 + 0.5 * gamma3 * sr_obs - (gamma4 - 3) / 4 * sr_obs**2) / T

    dsr = (sr_obs - sr_benchmark_ann) / (np.sqrt(v_sr) + 1e-10)
    dsr_pval = 1 - scipy_stats.norm.cdf(dsr)

    P(f"    SR_obs: {sr_obs:.3f}")
    P(f"    SR_benchmark (N={N}): {sr_benchmark_ann:.3f}")
    P(f"    Skewness: {gamma3:.3f}, Kurtosis: {gamma4:.3f}")
    P(f"    V[SR]: {v_sr:.6f}")
    P(f"    DSR: {dsr:.3f} (p={dsr_pval:.4f}) {'PASS' if dsr > 1.96 else 'FAIL'}")
    results['B2_deflated_sharpe'] = {
        'sr_obs': float(sr_obs), 'sr_benchmark': float(sr_benchmark_ann),
        'skewness': gamma3, 'kurtosis': gamma4,
        'v_sr': float(v_sr), 'dsr': float(dsr), 'dsr_pval': float(dsr_pval),
        'N_trials': N, 'T': T,
        'pass': dsr > 1.96,
    }

    # ----- B3: Alpha Decomposition (CAPM) -----
    P(f"\n  B3: Alpha Decomposition (CAPM regression)...")
    strats_for_capm = {}
    for key in list(alloc_store.keys()):
        strats_for_capm[key] = alloc_store[key]

    b3_results = {}
    for skey, sdata in strats_for_capm.items():
        sr = sdata['strat_ret']
        br = sdata['btc_ret']
        if len(sr) < 30 or len(br) < 30:
            continue
        # OLS: strat_ret = alpha + beta * btc_ret
        X_reg = np.column_stack([np.ones(len(br)), br])
        beta_hat = np.linalg.lstsq(X_reg, sr, rcond=None)[0]
        alpha_daily = beta_hat[0]
        beta = beta_hat[1]
        residuals = sr - X_reg @ beta_hat
        r_squared = 1 - np.var(residuals) / (np.var(sr) + 1e-10)
        # t-stat for alpha
        se = np.sqrt(np.var(residuals) / (len(sr) - 2) *
                     np.linalg.inv(X_reg.T @ X_reg)[0, 0])
        t_stat = alpha_daily / (se + 1e-10)
        alpha_annual = alpha_daily * 365

        P(f"    {skey}: alpha={alpha_annual*100:.2f}%/yr (t={t_stat:.2f}), "
          f"beta={beta:.3f}, R2={r_squared:.3f}")
        b3_results[skey] = {
            'alpha_daily': float(alpha_daily), 'alpha_annual': float(alpha_annual),
            't_stat': float(t_stat), 'beta': float(beta),
            'r_squared': float(r_squared),
            'pass': abs(t_stat) > 2.0 and alpha_daily > 0,
        }
    results['B3_capm_alpha'] = b3_results

    # ----- B4: Prediction Accuracy Analysis -----
    P(f"\n  B4: Prediction Accuracy Analysis...")
    if len(alloc_arr) == len(btc_ret) and len(alloc_arr) > 0:
        pred_dir = (alloc_arr > 0.5).astype(float)  # 1=bullish, 0=bearish
        actual_dir = (btc_ret > 0).astype(float)
        hit_rate = np.mean(pred_dir == actual_dir)
        # Conditional returns
        bullish_mask = alloc_arr > 0.5
        bearish_mask = alloc_arr <= 0.5
        mean_ret_bullish = np.mean(btc_ret[bullish_mask]) if bullish_mask.sum() > 0 else 0
        mean_ret_bearish = np.mean(btc_ret[bearish_mask]) if bearish_mask.sum() > 0 else 0

        # Per-year hit rates
        year_hits = {}
        oos_dates = dates[yb[2022]['start']:yb[2022]['start']+len(alloc_arr)]
        oos_years = pd.to_datetime(oos_dates).year.values
        for yr in range(2022, 2027):
            yr_mask = oos_years == yr
            if yr_mask.sum() > 0:
                yr_hit = np.mean(pred_dir[yr_mask] == actual_dir[yr_mask])
                year_hits[yr] = float(yr_hit)

        P(f"    Overall hit rate: {hit_rate:.4f} ({hit_rate*100:.1f}%) "
          f"{'PASS' if hit_rate > 0.52 else 'FAIL'}")
        P(f"    Mean BTC ret when bullish: {mean_ret_bullish*100:.4f}%")
        P(f"    Mean BTC ret when bearish: {mean_ret_bearish*100:.4f}%")
        P(f"    Per-year: {year_hits}")
        results['B4_prediction_accuracy'] = {
            'hit_rate': float(hit_rate), 'hit_rate_pct': float(hit_rate*100),
            'mean_ret_bullish': float(mean_ret_bullish),
            'mean_ret_bearish': float(mean_ret_bearish),
            'bullish_pct': float(bullish_mask.mean()),
            'year_hits': year_hits,
            'pass': hit_rate > 0.52,
        }
    else:
        results['B4_prediction_accuracy'] = {'pass': False, 'error': 'data mismatch'}

    # ----- B5: Feature Stability Across Time -----
    P(f"\n  B5: Feature Stability Across Time...")
    swap_d6 = {'puell_multiple': 'eth', 'rsi_14d': 'momentum_accel_7d'}
    X_best, feat_names = build_ml_features_swap(df, returns, vols, n, swap_d6)
    target_b5 = np.zeros(n)
    for i in range(n - 3):
        target_b5[i] = (prices[i+3] - prices[i]) / prices[i]

    fold_importances = {}
    for test_year in range(2022, 2027):
        if test_year not in yb:
            continue
        te = yb[test_year]['start'] - 1
        models = train_lgb_bagged(X_best, target_b5, te,
                                  horizon_gap=5, n_bags=5, base_seed=42)
        if models:
            # Average feature importance across bags
            imp = np.zeros(len(feat_names))
            for m in models:
                imp += m.feature_importance(importance_type='gain')
            imp /= len(models)
            # Rank (higher imp = rank 1)
            ranks = scipy_stats.rankdata(-imp)
            fold_importances[test_year] = ranks

    # Spearman correlations between consecutive folds
    years_sorted = sorted(fold_importances.keys())
    spearman_corrs = []
    for i in range(len(years_sorted) - 1):
        y1, y2 = years_sorted[i], years_sorted[i+1]
        corr, _ = scipy_stats.spearmanr(fold_importances[y1], fold_importances[y2])
        spearman_corrs.append(float(corr))
        P(f"    {y1}->{y2}: Spearman={corr:.3f}")

    mean_corr = np.mean(spearman_corrs) if spearman_corrs else 0
    P(f"    Mean Spearman: {mean_corr:.3f} {'PASS' if mean_corr > 0.60 else 'FAIL'}")
    results['B5_feature_stability'] = {
        'fold_years': years_sorted,
        'spearman_corrs': spearman_corrs,
        'mean_spearman': float(mean_corr),
        'pass': mean_corr > 0.60,
    }

    # ----- B6: In-Sample vs OOS Gap -----
    P(f"\n  B6: In-Sample vs OOS Gap (R2 and MAE)...")
    b6_gaps = {}
    for test_year in range(2022, 2027):
        if test_year not in yb:
            continue
        te = yb[test_year]['start'] - 1
        ts_y = yb[test_year]['start']
        te_y = yb[test_year]['end']

        models = train_lgb_bagged(X_best, target_b5, te,
                                  horizon_gap=5, n_bags=5, base_seed=42)
        if not models:
            continue

        # IS predictions
        train_idx = np.arange(60, te - 5 + 1)
        valid = ~np.any(np.isnan(X_best[train_idx]), axis=1)
        train_idx = train_idx[valid]
        if len(train_idx) < 100:
            continue
        X_tr = np.nan_to_num(X_best[train_idx], nan=0.0)
        y_tr = target_b5[train_idx]
        preds_is = np.mean([m.predict(X_tr) for m in models], axis=0)
        mae_is = np.mean(np.abs(preds_is - y_tr))
        ss_res_is = np.sum((preds_is - y_tr)**2)
        ss_tot_is = np.sum((y_tr - np.mean(y_tr))**2)
        r2_is = 1 - ss_res_is / (ss_tot_is + 1e-10)

        # OOS predictions
        test_idx = np.arange(ts_y, min(te_y + 1, n))
        valid_test = ~np.any(np.isnan(X_best[test_idx]), axis=1)
        test_idx = test_idx[valid_test]
        if len(test_idx) < 10:
            continue
        X_te = np.nan_to_num(X_best[test_idx], nan=0.0)
        y_te = target_b5[test_idx]
        preds_oos = np.mean([m.predict(X_te) for m in models], axis=0)
        mae_oos = np.mean(np.abs(preds_oos - y_te))
        ss_res_oos = np.sum((preds_oos - y_te)**2)
        ss_tot_oos = np.sum((y_te - np.mean(y_te))**2)
        r2_oos = 1 - ss_res_oos / (ss_tot_oos + 1e-10)

        gap_r2 = r2_is - r2_oos
        gap_mae = mae_oos - mae_is

        P(f"    {test_year}: R2_IS={r2_is:.4f} R2_OOS={r2_oos:.4f} gap={gap_r2:.4f} | "
          f"MAE_IS={mae_is:.5f} MAE_OOS={mae_oos:.5f} gap={gap_mae:.5f}")
        b6_gaps[test_year] = {
            'r2_is': float(r2_is), 'r2_oos': float(r2_oos), 'gap_r2': float(gap_r2),
            'mae_is': float(mae_is), 'mae_oos': float(mae_oos), 'gap_mae': float(gap_mae),
        }

    mean_gap = np.mean([v['gap_mae'] for v in b6_gaps.values()]) if b6_gaps else 999
    P(f"    Mean MAE gap: {mean_gap:.5f} {'PASS' if mean_gap < 0.20 else 'FAIL'}")
    results['B6_is_oos_gap'] = {
        'per_year': b6_gaps,
        'mean_gap_mae': float(mean_gap),
        'pass': mean_gap < 0.20,
    }

    # ----- B7: Walk-Forward with Feature Ranking PER-FOLD -----
    P(f"\n  B7: Per-Fold Feature Ranking (no lookahead)...")
    P(f"       CRITICAL TEST: Does strategy depend on knowing weak features in advance?")

    # For each fold, compute feature importance on data up to that fold
    # then identify the 4 weakest features and swap them
    all_features_full = list(DEFAULT_FEATURE_COLS)
    X_baseline, baseline_names = build_ml_features(df, returns, vols, n)
    target_b7 = target_b5.copy()

    feature_cols_per_fold = {}
    for test_year in range(2022, 2027):
        if test_year not in yb:
            continue
        te = yb[test_year]['start'] - 1
        # Train on data up to test_year - 1 to get feature ranking
        models_rank = train_lgb_bagged(X_baseline, target_b7, te,
                                       horizon_gap=5, n_bags=5, base_seed=42)
        if not models_rank:
            feature_cols_per_fold[test_year] = all_features_full
            continue

        # Get importance
        imp = np.zeros(len(baseline_names))
        for m in models_rank:
            fi = m.feature_importance(importance_type='gain')
            if len(fi) == len(baseline_names):
                imp += fi
        imp /= len(models_rank)

        # Find 4 weakest (lowest importance) from the 20 base features
        base_imp = {}
        for i, name in enumerate(baseline_names):
            if name in all_features_full:  # only rank base features
                base_imp[name] = imp[i]

        sorted_feats = sorted(base_imp.items(), key=lambda x: x[1])
        weak_4 = [f[0] for f in sorted_feats[:4]]

        P(f"    {test_year}: 4 weakest = {weak_4}")

        # Build swap dict: replace each weak with corresponding strong
        # Use same replacement strategy: puell->eth, rsi->momentum_accel_7d, etc.
        swap_map_options = {
            'puell_multiple': 'eth',
            'rsi_14d': 'momentum_accel_7d',
            'sopr_ma7': 'sharpe_3y_artemis',
            'funding_rate': 'sharpe_3y_artemis',
        }
        # For features not in our predefined swap map, just remove them
        fold_features = list(all_features_full)
        for weak in weak_4:
            if weak in fold_features:
                idx = fold_features.index(weak)
                if weak in swap_map_options:
                    fold_features[idx] = swap_map_options[weak]
                else:
                    # Replace with a reasonable alternative
                    fold_features[idx] = 'eth'  # default strong feature
        feature_cols_per_fold[test_year] = fold_features

    # Run walk-forward with per-fold features
    r_b7_perfold = run_strategy(
        daily_ret, returns, vols, df, dates, n,
        n_bags=30, base_seed=42, verbose=True,
        feature_cols_per_fold=feature_cols_per_fold)

    # Compare with global ranking result
    # Global = D6 swap with Bag30
    swap_d6 = {'puell_multiple': 'eth', 'rsi_14d': 'momentum_accel_7d'}
    r_b7_global = run_strategy(
        daily_ret, returns, vols, df, dates, n,
        n_bags=30, swap_dict=swap_d6, base_seed=42)

    if r_b7_perfold and r_b7_global:
        ratio = r_b7_perfold['total'] / (r_b7_global['total'] + 1e-10)
        P(f"    Per-fold: {r_b7_perfold['total']*100:+.1f}%")
        P(f"    Global:   {r_b7_global['total']*100:+.1f}%")
        P(f"    Ratio: {ratio:.2%} {'PASS' if ratio >= 0.80 else 'FAIL (OVERFITTING!)'}")
    else:
        ratio = 0
    results['B7_perfold_ranking'] = {
        'per_fold_return': float(r_b7_perfold['total']) if r_b7_perfold else None,
        'global_return': float(r_b7_global['total']) if r_b7_global else None,
        'ratio': float(ratio),
        'feature_cols_per_fold': {str(k): v for k, v in feature_cols_per_fold.items()},
        'pass': ratio >= 0.80,
    }

    # ----- B8: Multiple Testing Correction (Bonferroni) -----
    P(f"\n  B8: Multiple Testing Correction (Bonferroni)...")
    p_raw = results.get('B1a_alloc_shuffle', {}).get('p_value', 1.0)
    p_adjusted = min(p_raw * N_TRIALS_TOTAL, 1.0)
    P(f"    p_raw: {p_raw:.4f}")
    P(f"    N_tests: {N_TRIALS_TOTAL}")
    P(f"    p_adjusted: {p_adjusted:.4f} {'PASS' if p_adjusted < 0.05 else 'FAIL'}")
    results['B8_bonferroni'] = {
        'p_raw': float(p_raw), 'n_tests': N_TRIALS_TOTAL,
        'p_adjusted': float(p_adjusted),
        'pass': p_adjusted < 0.05,
    }

    # ----- B9: CPCV — Combinatorial Purged Cross-Validation -----
    P(f"\n  B9: CPCV (Combinatorial Purged CV, 6 blocks, C(6,3)=20 paths)...")
    from itertools import combinations

    oos_start_idx = yb[2022]['start']
    oos_end_idx = max(yb[yr]['end'] for yr in yb if yr >= 2022)
    oos_indices = np.arange(oos_start_idx, oos_end_idx + 1)
    n_oos_total = len(oos_indices)
    n_blocks = 6
    block_len = n_oos_total // n_blocks
    purge_gap = 7

    blocks = []
    for bi in range(n_blocks):
        s = oos_start_idx + bi * block_len
        e = s + block_len if bi < n_blocks - 1 else oos_end_idx + 1
        blocks.append((s, e))

    cpcv_sortinos = []
    combos = list(combinations(range(n_blocks), 3))
    for ci, train_blocks in enumerate(combos):
        test_blocks = [i for i in range(n_blocks) if i not in train_blocks]

        # Build train indices with purging
        train_idx = []
        for tb in train_blocks:
            s, e = blocks[tb]
            train_idx.extend(range(s, e))
        train_idx = np.array(train_idx)

        # Purge: remove indices near test block boundaries
        test_boundaries = set()
        for tb in test_blocks:
            s, e = blocks[tb]
            for j in range(max(0, s - purge_gap), min(n, s + purge_gap)):
                test_boundaries.add(j)
            for j in range(max(0, e - purge_gap), min(n, e + purge_gap)):
                test_boundaries.add(j)
        train_idx = np.array([i for i in train_idx if i not in test_boundaries])

        # Train model
        valid = ~np.any(np.isnan(X_best[train_idx]), axis=1)
        train_idx_clean = train_idx[valid]
        if len(train_idx_clean) < 100:
            continue
        X_tr = np.nan_to_num(X_best[train_idx_clean], nan=0.0)
        y_tr = target_b5[train_idx_clean]

        params = {'objective': 'regression', 'metric': 'mae',
                  'num_leaves': 31, 'learning_rate': 0.05,
                  'feature_fraction': 0.7, 'bagging_fraction': 0.8,
                  'bagging_freq': 5, 'verbose': -1, 'n_jobs': 1, 'seed': 42}
        dtrain = lgb.Dataset(X_tr, label=y_tr)
        model = lgb.train(params, dtrain, num_boost_round=200)

        # Predict on test blocks
        test_idx = []
        for tb in test_blocks:
            s, e = blocks[tb]
            test_idx.extend(range(s, min(e, n - 1)))
        test_idx = np.array(test_idx)

        day_of_week = pd.to_datetime(dates).dayofweek
        allocs_cpcv = np.full(n, 0.5)
        prev_a = 0.5
        for t in test_idx:
            x_t = np.nan_to_num(X_best[t:t+1], nan=0.0)
            pred = model.predict(x_t)[0]
            scaled = np.clip(pred / 0.05, -1.0, 1.0)
            a_ml = 0.5 + scaled * 0.5 if scaled > 0 else 0.5 + scaled * 0.75
            raw = a_ml
            if day_of_week[t] != 4:
                raw = prev_a
            allocs_cpcv[t] = np.clip(raw, -0.25, 1.0)
            prev_a = allocs_cpcv[t]

        # Backtest on test blocks
        all_s, all_b, all_a = [], [], []
        for tb in test_blocks:
            s, e = blocks[tb]
            sr, br, ar = backtest_allocations(daily_ret, allocs_cpcv, s, min(e, n-1))
            all_s.extend(sr); all_b.extend(br); all_a.extend(ar)

        m_cpcv = metrics(np.array(all_s), np.array(all_b), np.array(all_a))
        if m_cpcv:
            cpcv_sortinos.append(m_cpcv['sortino'])

    if cpcv_sortinos:
        p_sortino_pos = np.mean([s > 0 for s in cpcv_sortinos])
        mean_sortino = np.mean(cpcv_sortinos)
        P(f"    CPCV paths: {len(cpcv_sortinos)}/20")
        P(f"    Sortino mean: {mean_sortino:.3f}, P(>0): {p_sortino_pos:.2%}")
        P(f"    {'PASS' if p_sortino_pos > 0.75 and mean_sortino > 0.5 else 'FAIL'}")
    else:
        p_sortino_pos = 0
        mean_sortino = 0
    results['B9_cpcv'] = {
        'n_paths': len(cpcv_sortinos), 'sortinos': [float(s) for s in cpcv_sortinos],
        'mean_sortino': float(mean_sortino),
        'p_sortino_positive': float(p_sortino_pos),
        'pass': p_sortino_pos > 0.75 and mean_sortino > 0.5,
    }

    # ----- B10: Forward Performance Decay -----
    P(f"\n  B10: Forward Performance Decay (rolling 6-month Sortino)...")
    window_days = 180
    rolling_sortinos = []
    rolling_times = []
    for start_i in range(0, len(strat_ret) - window_days, 30):
        end_i = start_i + window_days
        window_s = strat_ret[start_i:end_i]
        ex = window_s - rf_oos[start_i:end_i]
        ds = ex[ex < 0]
        sortino_w = np.mean(ex) / (np.std(ds) + 1e-10) * np.sqrt(365) if len(ds) > 5 else 0
        rolling_sortinos.append(sortino_w)
        rolling_times.append(start_i)

    if len(rolling_sortinos) > 3:
        x_time = np.arange(len(rolling_sortinos))
        slope, intercept, r_val, p_val, se = scipy_stats.linregress(x_time, rolling_sortinos)
        # Mann-Kendall trend test
        mk_s = 0
        n_roll = len(rolling_sortinos)
        for i in range(n_roll - 1):
            for j in range(i + 1, n_roll):
                mk_s += np.sign(rolling_sortinos[j] - rolling_sortinos[i])
        var_s = n_roll * (n_roll - 1) * (2 * n_roll + 5) / 18
        if mk_s > 0:
            z_mk = (mk_s - 1) / np.sqrt(var_s)
        elif mk_s < 0:
            z_mk = (mk_s + 1) / np.sqrt(var_s)
        else:
            z_mk = 0
        p_mk = 2 * (1 - scipy_stats.norm.cdf(abs(z_mk)))

        # slope per month (each point is ~30 days)
        slope_per_month = slope

        P(f"    Slope: {slope_per_month:.4f}/month")
        P(f"    Mann-Kendall Z: {z_mk:.3f}, p={p_mk:.4f}")
        P(f"    {'PASS' if slope_per_month > -0.02 and p_mk > 0.10 else 'FAIL'}")
    else:
        slope_per_month = 0
        p_mk = 1.0
        z_mk = 0

    results['B10_forward_decay'] = {
        'rolling_sortinos': [float(s) for s in rolling_sortinos],
        'slope_per_month': float(slope_per_month),
        'mk_z': float(z_mk), 'mk_p': float(p_mk),
        'pass': slope_per_month > -0.02 and p_mk > 0.10,
    }

    # ----- B Summary -----
    P(f"\n  {'='*80}")
    P(f"  PART B SUMMARY")
    P(f"  {'='*80}")
    for key, val in results.items():
        passed = val.get('pass', 'N/A')
        P(f"    {key:<35} {'PASS' if passed else 'FAIL'}")

    return results


# ============================================================
# SECTION 9: PART C — LEVERAGE & RISK ANALYSIS
# ============================================================

def part_c_leverage_risk(daily_ret, returns, vols, df, dates, n, alloc_store,
                         part_a_results):
    P(f"\n{'#'*100}")
    P("PART C: LEVERAGE & RISK ANALYSIS")
    P("#" * 100)

    results = {}
    prices = df['price_usd'].values
    yb = get_year_boundaries(dates, n)

    # Use all stored strategies
    strategies = {}
    for key, data in alloc_store.items():
        strategies[key] = data

    # Build OOS rf array for decomposition
    oos_start = yb[2022]['start'] if 2022 in yb else 0
    first_key = next(iter(strategies))
    oos_len = len(strategies[first_key]['strat_ret'])
    if RF_DAILY_ARR is not None:
        rf_oos_c = RF_DAILY_ARR[oos_start:oos_start + oos_len]
    else:
        rf_oos_c = np.full(oos_len, RF_DAILY)

    # ----- C1: Return Decomposition -----
    P(f"\n  C1: Return Decomposition (BTC component + RF component + cost)...")
    c1_results = {}
    for skey, sdata in strategies.items():
        sr = sdata['strat_ret']
        br = sdata['btc_ret']
        aa = sdata['alloc_arr']

        rf_slice = rf_oos_c[:len(aa)]
        comp_btc = aa * br
        comp_rf = (1 - np.abs(aa)) * rf_slice
        prev_a = np.concatenate([[0.5], aa[:-1]])
        comp_cost = np.abs(aa - prev_a) * COST * np.where(aa < 0, 1.5, 1.0)

        total_ret = np.prod(1 + sr) - 1
        cum_btc = np.sum(comp_btc)
        cum_rf = np.sum(comp_rf)
        cum_cost = np.sum(comp_cost)
        alpha_residual = total_ret - cum_btc - cum_rf + cum_cost

        pct_btc = cum_btc / (total_ret + 1e-10) * 100
        pct_rf = cum_rf / (total_ret + 1e-10) * 100
        pct_cost = cum_cost / (total_ret + 1e-10) * 100

        P(f"    {skey}: BTC={pct_btc:.0f}%, RF={pct_rf:.0f}%, Cost={pct_cost:.0f}%")
        c1_results[skey] = {
            'total': float(total_ret), 'cum_btc': float(cum_btc),
            'cum_rf': float(cum_rf), 'cum_cost': float(cum_cost),
            'alpha_residual': float(alpha_residual),
            'pct_btc': float(pct_btc), 'pct_rf': float(pct_rf),
            'pct_cost': float(pct_cost),
        }
    results['C1_decomposition'] = c1_results

    # ----- C2: Effective Leverage -----
    P(f"\n  C2: Effective Leverage Analysis...")
    c2_results = {}
    for skey, sdata in strategies.items():
        aa = sdata['alloc_arr']
        rf_slice = rf_oos_c[:len(aa)]
        short_mask = aa < 0
        days_short = short_mask.sum()
        pct_short = short_mask.mean() * 100
        # RF "lost" in conservative model: when short, real RF = (1+|alloc|) but model uses (1-|alloc|)
        rf_lost = np.sum(np.abs(aa[short_mask]) * 2 * rf_slice[short_mask]) if days_short > 0 else 0
        # Effective leverage
        eff_lev = np.mean(np.abs(aa) + (1 - np.abs(aa)))  # always 1.0 in current model
        real_lev = np.mean(np.abs(aa) + np.where(aa < 0, 1 + np.abs(aa), 1 - np.abs(aa)))

        P(f"    {skey}: {pct_short:.1f}% short, RF lost={rf_lost*100:.2f}%, "
          f"real leverage={real_lev:.3f}")
        c2_results[skey] = {
            'days_short': int(days_short), 'pct_short': float(pct_short),
            'rf_lost': float(rf_lost), 'real_leverage': float(real_lev),
        }
    results['C2_leverage'] = c2_results

    # ----- C3: Allocation Distribution -----
    P(f"\n  C3: Allocation Distribution...")
    c3_results = {}
    for skey, sdata in strategies.items():
        aa = sdata['alloc_arr']
        bins = [(-0.25, 0), (0, 0.25), (0.25, 0.5), (0.5, 0.75), (0.75, 1.0)]
        bin_pcts = {}
        for lo, hi in bins:
            mask = (aa >= lo) & (aa < hi) if hi < 1.0 else (aa >= lo) & (aa <= hi)
            bin_pcts[f'[{lo:.2f},{hi:.2f}]'] = float(mask.mean() * 100)

        P(f"    {skey}: mean={np.mean(aa):.3f}, median={np.median(aa):.3f}, "
          f"std={np.std(aa):.3f}")
        c3_results[skey] = {
            'mean': float(np.mean(aa)), 'median': float(np.median(aa)),
            'std': float(np.std(aa)), 'min': float(np.min(aa)),
            'max': float(np.max(aa)), 'bins': bin_pcts,
        }
    results['C3_allocation_dist'] = c3_results

    # ----- C4: Year-by-Year Analysis -----
    P(f"\n  C4: Year-by-Year Drawdown Protection...")
    c4_results = {}
    for skey, sdata in strategies.items():
        sr = sdata['strat_ret']
        br = sdata['btc_ret']
        aa = sdata['alloc_arr']
        oos_start = yb[2022]['start']
        oos_dates = dates[oos_start:oos_start+len(sr)]
        oos_years = pd.to_datetime(oos_dates).year.values

        year_data = {}
        excess_positive_years = 0
        for yr in range(2022, 2027):
            yr_mask = oos_years == yr
            if yr_mask.sum() == 0:
                continue
            yr_s = sr[yr_mask]
            yr_b = br[yr_mask]
            yr_a = aa[yr_mask]
            yr_ret_s = np.prod(1 + yr_s) - 1
            yr_ret_b = np.prod(1 + yr_b) - 1
            yr_excess = yr_ret_s - yr_ret_b
            cum_yr = np.cumprod(1 + yr_s)
            pk_yr = np.maximum.accumulate(cum_yr)
            dd_yr = np.min((cum_yr - pk_yr) / (pk_yr + 1e-10))

            if yr_excess > 0:
                excess_positive_years += 1

            year_data[yr] = {
                'strat_return': float(yr_ret_s), 'btc_return': float(yr_ret_b),
                'excess': float(yr_excess), 'max_dd': float(dd_yr),
            }

        c4_results[skey] = {
            'years': year_data,
            'excess_positive_years': excess_positive_years,
            'pass': excess_positive_years >= 3,
        }
    results['C4_yearly'] = c4_results

    # Print C4 summary
    for skey in list(c4_results.keys())[:3]:
        P(f"    {skey}:")
        for yr, yd in c4_results[skey]['years'].items():
            P(f"      {yr}: strat={yd['strat_return']*100:+.1f}% btc={yd['btc_return']*100:+.1f}% "
              f"excess={yd['excess']*100:+.1f}% dd={yd['max_dd']*100:.1f}%")
        P(f"      Excess positive: {c4_results[skey]['excess_positive_years']}/5 "
          f"{'PASS' if c4_results[skey]['pass'] else 'FAIL'}")

    # ----- C5: Stress Test — Worst BTC Months -----
    P(f"\n  C5: Stress Test — 10 Worst BTC Months...")
    oos_start = yb[2022]['start']
    # Compute monthly BTC returns
    oos_dates_all = pd.to_datetime(dates[oos_start:])
    oos_daily_ret = daily_ret[oos_start:]
    monthly_data = pd.DataFrame({'date': oos_dates_all[:len(oos_daily_ret)],
                                  'btc_ret': oos_daily_ret})
    monthly_data['month'] = monthly_data['date'].dt.to_period('M')
    monthly_btc = monthly_data.groupby('month')['btc_ret'].apply(
        lambda x: np.prod(1 + x) - 1).sort_values()

    worst_10 = monthly_btc.head(10)
    P(f"    10 worst BTC months:")
    for month, ret in worst_10.items():
        P(f"      {month}: {ret*100:+.1f}%")

    c5_results = {}
    for skey, sdata in list(strategies.items())[:4]:
        sr = sdata['strat_ret']
        oos_sr_df = pd.DataFrame({
            'date': oos_dates_all[:len(sr)], 'strat_ret': sr})
        oos_sr_df['month'] = oos_sr_df['date'].dt.to_period('M')
        monthly_strat = oos_sr_df.groupby('month')['strat_ret'].apply(
            lambda x: np.prod(1 + x) - 1)

        protected = 0
        month_details = {}
        for month in worst_10.index:
            btc_m = worst_10[month]
            strat_m = monthly_strat.get(month, 0)
            if strat_m > btc_m:
                protected += 1
            month_details[str(month)] = {
                'btc': float(btc_m), 'strat': float(strat_m),
                'protected': strat_m > btc_m
            }

        P(f"    {skey}: protected {protected}/10 "
          f"{'PASS' if protected >= 7 else 'FAIL'}")
        c5_results[skey] = {
            'months': month_details, 'protected': protected,
            'pass': protected >= 7,
        }
    results['C5_stress_test'] = c5_results

    # ----- C6: Turnover & Cost -----
    P(f"\n  C6: Turnover & Cost Analysis...")
    c6_results = {}
    for skey, sdata in strategies.items():
        aa = sdata['alloc_arr']
        sr = sdata['strat_ret']
        prev_a = np.concatenate([[0.5], aa[:-1]])
        turnover = np.abs(aa - prev_a)
        avg_turnover = np.mean(turnover)
        total_cost = np.sum(turnover * COST * np.where(aa < 0, 1.5, 1.0))
        gross_return = np.prod(1 + sr) - 1 + total_cost  # approximate
        cost_pct = total_cost / (gross_return + 1e-10) * 100

        P(f"    {skey}: turnover={avg_turnover:.4f}, cost={total_cost*100:.2f}%, "
          f"cost/gross={cost_pct:.1f}% {'PASS' if cost_pct < 10 else 'FAIL'}")
        c6_results[skey] = {
            'avg_turnover': float(avg_turnover), 'total_cost': float(total_cost),
            'gross_return': float(gross_return), 'cost_pct': float(cost_pct),
            'pass': cost_pct < 10,
        }
    results['C6_turnover'] = c6_results

    return results


# ============================================================
# SECTION 10: PART D — ROBUSTNESS EXTENSIONS
# ============================================================

def part_d_robustness(daily_ret, returns, vols, df, dates, n):
    P(f"\n{'#'*100}")
    P("PART D: ROBUSTNESS EXTENSIONS")
    P("#" * 100)

    results = {}
    swap_d6 = {'puell_multiple': 'eth', 'rsi_14d': 'momentum_accel_7d'}

    # ----- D1: Rolling Window (3yr) vs Expanding -----
    P(f"\n  D1: Rolling Window (3yr) vs Expanding...")
    r_expanding = run_strategy(daily_ret, returns, vols, df, dates, n,
                               n_bags=30, swap_dict=swap_d6, base_seed=42)
    r_rolling = run_strategy(daily_ret, returns, vols, df, dates, n,
                             n_bags=30, swap_dict=swap_d6, base_seed=42,
                             rolling_window_years=3)
    if r_expanding and r_rolling:
        ratio = r_rolling['total'] / (r_expanding['total'] + 1e-10)
        P(f"    Expanding: {r_expanding['total']*100:+.1f}%")
        P(f"    Rolling 3yr: {r_rolling['total']*100:+.1f}%")
        P(f"    Ratio: {ratio:.2%} {'OK' if ratio >= 0.90 else 'Old data helps'}")
    results['D1_rolling_vs_expanding'] = {
        'expanding': r_expanding, 'rolling_3yr': r_rolling,
        'ratio': float(ratio) if r_expanding and r_rolling else None,
    }

    # ----- D2: LGB Hyperparameter Grid -----
    P(f"\n  D2: LGB Hyperparameter Grid (27 combos)...")
    X_d6, _ = build_ml_features_swap(df, returns, vols, n, swap_d6)
    grid_results = []
    num_leaves_opts = [15, 31, 63]
    lr_opts = [0.02, 0.05, 0.10]
    rounds_opts = [100, 200, 400]

    for nl in num_leaves_opts:
        for lr in lr_opts:
            for nr in rounds_opts:
                params = {
                    'objective': 'regression', 'metric': 'mae',
                    'num_leaves': nl, 'learning_rate': lr,
                    'feature_fraction': 0.7, 'bagging_fraction': 0.8,
                    'bagging_freq': 5, 'num_boost_round': nr,
                }
                r = run_strategy(daily_ret, returns, vols, df, dates, n,
                                 n_bags=30, X_all_override=X_d6, base_seed=42,
                                 lgb_params=params)
                ret = r['total']*100 if r else 0
                grid_results.append({
                    'num_leaves': nl, 'learning_rate': lr, 'num_boost_round': nr,
                    'return': float(ret), 'sortino': float(r['sortino']) if r else 0,
                    'max_dd': float(r['max_dd']*100) if r else 0,
                })
                P(f"    nl={nl} lr={lr} nr={nr}: {ret:+.1f}%")

    # Sort by return
    grid_sorted = sorted(grid_results, key=lambda x: x['return'], reverse=True)
    P(f"    Top 3:")
    for i, g in enumerate(grid_sorted[:3]):
        P(f"      {i+1}. nl={g['num_leaves']} lr={g['learning_rate']} "
          f"nr={g['num_boost_round']}: {g['return']:+.1f}%")
    default_ret = [g for g in grid_results
                   if g['num_leaves']==31 and g['learning_rate']==0.05 and g['num_boost_round']==200]
    default_rank = next((i+1 for i, g in enumerate(grid_sorted)
                         if g['num_leaves']==31 and g['learning_rate']==0.05
                         and g['num_boost_round']==200), -1)
    P(f"    Default (31/0.05/200) rank: {default_rank}/27")
    results['D2_lgb_grid'] = {
        'grid': grid_sorted, 'default_rank': default_rank,
    }

    # ----- D3: Prediction Scaling Sensitivity -----
    P(f"\n  D3: Prediction Scaling Sensitivity...")
    scale_divs = [0.03, 0.04, 0.05, 0.07, 0.10]
    d3_results = []
    for sd in scale_divs:
        r = run_strategy(daily_ret, returns, vols, df, dates, n,
                         n_bags=30, X_all_override=X_d6, base_seed=42,
                         scale_div=sd)
        ret = r['total']*100 if r else 0
        P(f"    scale_div={sd}: {ret:+.1f}%")
        d3_results.append({
            'scale_div': sd, 'return': float(ret),
            'sortino': float(r['sortino']) if r else 0,
            'max_dd': float(r['max_dd']*100) if r else 0,
        })
    results['D3_scaling'] = d3_results

    # ----- D4: Horizon Gap Sensitivity -----
    P(f"\n  D4: Horizon Gap Sensitivity...")
    # We need a custom version that overrides horizon_gap
    # For simplicity, we modify the target_horizon which affects gap via max(target_horizon, gap)
    # The plan says test gap=3,5,7,10. Current code uses gap=max(target_horizon,5).
    # With target_horizon=3, gap=5 is default. To get gap=3, we'd need to modify.
    # We'll test different target_horizons instead which changes the gap.
    gaps = [3, 5, 7, 10]
    d4_results = []
    for gap in gaps:
        # Hack: set target_horizon = gap so gap = max(gap, 5) when gap>=5,
        # or use gap directly for gap<5 by building custom
        r = run_strategy(daily_ret, returns, vols, df, dates, n,
                         n_bags=30, X_all_override=X_d6, base_seed=42,
                         target_horizon=gap)
        ret = r['total']*100 if r else 0
        P(f"    target_horizon={gap}: {ret:+.1f}%")
        d4_results.append({
            'target_horizon': gap, 'return': float(ret),
            'sortino': float(r['sortino']) if r else 0,
        })
    results['D4_horizon'] = d4_results

    # ----- D5: ret_5d with Feature Swaps -----
    P(f"\n  D5: ret_5d + top2 swap + Bag30...")
    r_5d = run_strategy(daily_ret, returns, vols, df, dates, n,
                        n_bags=30, X_all_override=X_d6, base_seed=42,
                        target_horizon=5)
    r_3d = run_strategy(daily_ret, returns, vols, df, dates, n,
                        n_bags=30, X_all_override=X_d6, base_seed=42,
                        target_horizon=3)
    if r_5d and r_3d:
        P(f"    ret_3d: {r_3d['total']*100:+.1f}%")
        P(f"    ret_5d: {r_5d['total']*100:+.1f}%")
        P(f"    {'ret_3d still better' if r_3d['total'] > r_5d['total'] else 'ret_5d wins!'}")
    results['D5_ret5d'] = {
        'ret_3d': r_3d, 'ret_5d': r_5d,
    }

    return results


# ============================================================
# SECTION 11: REPORT GENERATION
# ============================================================

def generate_report(all_results, docs_dir):
    docs_dir.mkdir(parents=True, exist_ok=True)
    report_path = docs_dir / 'PIPELINE_V8_AUDIT.md'

    part_a = all_results.get('part_a', {})
    part_b = all_results.get('part_b', {})
    part_c = all_results.get('part_c', {})
    part_d = all_results.get('part_d', {})

    lines = [
        "# Pipeline V8 Audit - Overfitting Audit + Missing Combinations",
        "",
        f"**Generated**: {datetime.now().strftime('%Y-%m-%d %H:%M')}",
        f"**Test Period**: 2022-2026 (walk-forward OOS)",
        f"**Total trials across V1-V7**: ~{N_TRIALS_TOTAL}",
        "",
        "---",
        "",
        "## Executive Summary",
        "",
    ]

    # Approval criteria scorecard
    criteria = [
        ("1. Return mean (10 seeds) > +350%", _check_a(part_a, 'A1_D6_Bag30', 'mean', 350)),
        ("2. Seed spread < 60pp", _check_a(part_a, 'A1_D6_Bag30', 'spread', 60, less_than=True)),
        ("3. Beat V2 10/10", _check_a(part_a, 'A1_D6_Bag30', 'beat_v2', 10, equals=True)),
        ("4. Permutation p (alloc) < 0.05", part_b.get('B1a_alloc_shuffle', {}).get('pass', False)),
        ("5. Permutation p (return) < 0.05", part_b.get('B1b_return_shuffle', {}).get('pass', False)),
        ("6. DSR > 1.96", part_b.get('B2_deflated_sharpe', {}).get('pass', False)),
        ("7. Alpha CAPM t > 2.0", _check_b3(part_b)),
        ("8. Hit rate > 52%", part_b.get('B4_prediction_accuracy', {}).get('pass', False)),
        ("9. Feature stability > 0.60", part_b.get('B5_feature_stability', {}).get('pass', False)),
        ("10. IS/OOS gap < 0.20", part_b.get('B6_is_oos_gap', {}).get('pass', False)),
        ("11. Per-fold >= 80%", part_b.get('B7_perfold_ranking', {}).get('pass', False)),
        ("12. CPCV P(S>0) > 75%", part_b.get('B9_cpcv', {}).get('pass', False)),
        ("13. Forward decay p > 0.10", part_b.get('B10_forward_decay', {}).get('pass', False)),
        ("14. Excess >= 3/5 years", _check_c4(part_c)),
        ("15. Stress protect >= 7/10", _check_c5(part_c)),
        ("16. Cost/gross < 10%", _check_c6(part_c)),
    ]

    n_pass = sum(1 for _, v in criteria if v)
    n_fail = sum(1 for _, v in criteria if not v)

    lines.append(f"**Scorecard: {n_pass} PASS / {n_fail} FAIL out of 16 criteria**")
    if n_fail >= 3:
        lines.append(f"\n**VERDICT: STRATEGY NOT APPROVED ({n_fail} failures >= 3 threshold)**")
    else:
        lines.append(f"\n**VERDICT: STRATEGY APPROVED ({n_fail} failures < 3 threshold)**")
    lines.append("")

    # B7 critical check
    b7_pass = part_b.get('B7_perfold_ranking', {}).get('pass', False)
    if not b7_pass:
        lines.append("**CRITICAL WARNING: B7 per-fold ranking FAILED. "
                     "Feature selection may rely on lookahead bias.**")
        lines.append("")

    # Scorecard table
    lines.extend([
        "### Approval Criteria Scorecard",
        "",
        "| # | Criterion | Result |",
        "|---|-----------|--------|",
    ])
    for desc, passed in criteria:
        lines.append(f"| {desc} | {'PASS' if passed else 'FAIL'} |")

    # Part A summary
    lines.extend(["", "---", "", "## Part A: Missing Combinations", ""])
    if part_a:
        lines.extend([
            "| Strategy | Mean | Spread | BeatV2 | Sortino |",
            "|----------|------|--------|--------|---------|",
        ])
        for key in ['A1_D6_Bag30', 'A2_eth_plusdi_Bag30', 'A3_eth_ethpctchg_Bag30', 'A4_D5_Bag30']:
            if key in part_a and 'seeds' in part_a[key]:
                s = part_a[key]['seeds']
                lines.append(f"| {key} | {s['mean']:+.1f}% | {s['spread']:.0f}pp | "
                           f"{s['beat_v2']}/10 | {s['sortinos_mean']:.2f} |")
        if 'A5_ensemble' in part_a and part_a['A5_ensemble'].get('result'):
            r5 = part_a['A5_ensemble']['result']
            lines.append(f"| A5_ensemble | {r5['total']*100:+.1f}% | - | - | {r5['sortino']:.2f} |")

    # Part B summary
    lines.extend(["", "---", "", "## Part B: Overfitting Audit", ""])
    for key in ['B1a_alloc_shuffle', 'B1b_return_shuffle', 'B2_deflated_sharpe',
                'B4_prediction_accuracy', 'B5_feature_stability', 'B6_is_oos_gap',
                'B7_perfold_ranking', 'B8_bonferroni', 'B9_cpcv', 'B10_forward_decay']:
        if key in part_b:
            val = part_b[key]
            passed = val.get('pass', False)
            lines.append(f"### {key}")
            if 'p_value' in val:
                lines.append(f"- p-value: {val['p_value']:.4f}")
            if 'dsr' in val:
                lines.append(f"- DSR: {val['dsr']:.3f}")
            if 'hit_rate_pct' in val:
                lines.append(f"- Hit rate: {val['hit_rate_pct']:.1f}%")
            if 'mean_spearman' in val:
                lines.append(f"- Mean Spearman: {val['mean_spearman']:.3f}")
            if 'ratio' in val:
                lines.append(f"- Ratio per-fold/global: {val['ratio']:.2%}")
            if 'mean_sortino' in val:
                lines.append(f"- Mean CPCV Sortino: {val['mean_sortino']:.3f}")
            if 'slope_per_month' in val:
                lines.append(f"- Slope: {val['slope_per_month']:.4f}/month")
            lines.append(f"- **{'PASS' if passed else 'FAIL'}**")
            lines.append("")

    # B3 CAPM detail
    if 'B3_capm_alpha' in part_b:
        lines.extend(["### B3: CAPM Alpha", "",
                      "| Strategy | Alpha/yr | t-stat | Beta | R2 |",
                      "|----------|----------|--------|------|----|"])
        for skey, v in part_b['B3_capm_alpha'].items():
            lines.append(f"| {skey} | {v['alpha_annual']*100:.2f}% | {v['t_stat']:.2f} | "
                        f"{v['beta']:.3f} | {v['r_squared']:.3f} |")
        lines.append("")

    # Part C summary
    lines.extend(["", "---", "", "## Part C: Leverage & Risk Analysis", ""])

    if 'C4_yearly' in part_c:
        lines.extend(["### C4: Year-by-Year Performance", ""])
        for skey in list(part_c['C4_yearly'].keys())[:3]:
            lines.append(f"**{skey}**")
            lines.extend([
                "| Year | Strat | BTC | Excess | MaxDD |",
                "|------|-------|-----|--------|-------|",
            ])
            for yr, yd in part_c['C4_yearly'][skey]['years'].items():
                lines.append(f"| {yr} | {yd['strat_return']*100:+.1f}% | "
                           f"{yd['btc_return']*100:+.1f}% | {yd['excess']*100:+.1f}% | "
                           f"{yd['max_dd']*100:.1f}% |")
            lines.append("")

    # Part D summary
    lines.extend(["", "---", "", "## Part D: Robustness Extensions", ""])
    if 'D2_lgb_grid' in part_d:
        lines.extend(["### D2: LGB Hyperparameter Grid (Top 5)", "",
                      "| Rank | Leaves | LR | Rounds | Return |",
                      "|------|--------|----|--------|--------|"])
        for i, g in enumerate(part_d['D2_lgb_grid']['grid'][:5]):
            lines.append(f"| {i+1} | {g['num_leaves']} | {g['learning_rate']} | "
                        f"{g['num_boost_round']} | {g['return']:+.1f}% |")
        lines.append(f"\nDefault rank: {part_d['D2_lgb_grid']['default_rank']}/27")
        lines.append("")

    if 'D3_scaling' in part_d:
        lines.extend(["### D3: Prediction Scaling Sensitivity", "",
                      "| Scale Div | Return | Sortino |",
                      "|-----------|--------|---------|"])
        for d in part_d['D3_scaling']:
            lines.append(f"| {d['scale_div']} | {d['return']:+.1f}% | {d['sortino']:.2f} |")
        lines.append("")

    lines.extend(["", "---", "",
                  f"*Report generated at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}*"])

    report_text = '\n'.join(lines)
    report_path.write_text(report_text, encoding='utf-8')
    P(f"  Report saved: {report_path}")
    return report_path


def _check_a(part_a, key, field, threshold, less_than=False, equals=False):
    if key not in part_a or 'seeds' not in part_a[key]:
        return False
    val = part_a[key]['seeds'].get(field, 0)
    if equals:
        return val >= threshold
    if less_than:
        return val < threshold
    return val > threshold


def _check_b3(part_b):
    b3 = part_b.get('B3_capm_alpha', {})
    for key, val in b3.items():
        if val.get('pass', False):
            return True
    return False


def _check_c4(part_c):
    c4 = part_c.get('C4_yearly', {})
    for key, val in c4.items():
        if val.get('pass', False):
            return True
    return False


def _check_c5(part_c):
    c5 = part_c.get('C5_stress_test', {})
    for key, val in c5.items():
        if val.get('pass', False):
            return True
    return False


def _check_c6(part_c):
    c6 = part_c.get('C6_turnover', {})
    for key, val in c6.items():
        if val.get('pass', False):
            return True
    return False


# ============================================================
# SECTION 12: MAIN
# ============================================================

def convert_numpy(obj):
    if isinstance(obj, (np.integer,)):
        return int(obj)
    elif isinstance(obj, (np.floating,)):
        return float(obj)
    elif isinstance(obj, np.ndarray):
        return obj.tolist()
    elif isinstance(obj, dict):
        return {str(k): convert_numpy(v) for k, v in obj.items()}
    elif isinstance(obj, (list, tuple)):
        return [convert_numpy(i) for i in obj]
    return obj


def main():
    P("=" * 100)
    P("PIPELINE V8 AUDIT - Overfitting Audit + Missing Combinations")
    P("=" * 100)
    P(f"  Start time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    P("\nLoading data...")
    prices, daily_ret, returns, vols, df = load_data()
    dates = df['date'].values
    n = len(prices)
    P(f"  {n} days | {len(df.columns)} columns | {dates[0]} to {dates[-1]}")

    # Build real CDI/Selic risk-free rate series
    global RF_DAILY_ARR
    try:
        from src.features.macro.cdi_rates import build_rf_daily
        RF_DAILY_ARR = build_rf_daily(dates, source='auto')
        rf_mean_annual = (np.prod(1 + RF_DAILY_ARR[-365:])  - 1) * 100
        P(f"  RF: Real CDI/Selic rates loaded ({RF_DAILY_ARR.shape[0]} days, "
          f"last-year ~{rf_mean_annual:.1f}%)")
    except Exception as e:
        P(f"  WARNING: Could not load real CDI rates ({e}), using flat 15%")
        RF_DAILY_ARR = np.full(n, RF_DAILY)

    full_output = {
        'timestamp': datetime.now().isoformat(),
        'method': 'pipeline_v8_audit',
        'test_period': '2022-2026',
        'n_trials_total': N_TRIALS_TOTAL,
    }

    # ========================================
    # PHASE 1: PART A — Missing Combinations
    # ========================================
    P(f"\n\n{'='*100}")
    P("PHASE 1: PART A")
    P("=" * 100)
    part_a_results, alloc_store = part_a_missing_combos(
        daily_ret, returns, vols, df, dates, n)
    full_output['part_a'] = part_a_results

    # Determine best strategy for audit
    best_key = 'A1_D6_Bag30'
    if best_key not in alloc_store:
        best_key = list(alloc_store.keys())[0] if alloc_store else None

    # ========================================
    # PHASE 2: PART B — Overfitting Audit
    # ========================================
    P(f"\n\n{'='*100}")
    P("PHASE 2: PART B")
    P("=" * 100)
    if best_key:
        part_b_results = part_b_overfitting_audit(
            daily_ret, returns, vols, df, dates, n,
            alloc_store, best_strat_key=best_key)
    else:
        part_b_results = {}
        P("  SKIPPED: No allocation data")
    full_output['part_b'] = part_b_results

    # CHECK B7 CRITICAL
    b7_pass = part_b_results.get('B7_perfold_ranking', {}).get('pass', True)
    if not b7_pass:
        P(f"\n  *** CRITICAL: B7 per-fold ranking FAILED ***")
        P(f"  *** Feature selection may rely on lookahead bias ***")
        P(f"  *** Continuing with remaining tests for completeness ***")

    # ========================================
    # PHASE 3: PART C — Leverage & Risk
    # ========================================
    P(f"\n\n{'='*100}")
    P("PHASE 3: PART C")
    P("=" * 100)
    part_c_results = part_c_leverage_risk(
        daily_ret, returns, vols, df, dates, n,
        alloc_store, part_a_results)
    full_output['part_c'] = part_c_results

    # ========================================
    # PHASE 4: PART D — Robustness
    # ========================================
    P(f"\n\n{'='*100}")
    P("PHASE 4: PART D")
    P("=" * 100)
    part_d_results = part_d_robustness(
        daily_ret, returns, vols, df, dates, n)
    full_output['part_d'] = part_d_results

    # ========================================
    # FINAL SCORECARD
    # ========================================
    P(f"\n\n{'#'*100}")
    P("FINAL SCORECARD")
    P("#" * 100)

    criteria = [
        ("1.  Return mean > +350%", _check_a(part_a_results, 'A1_D6_Bag30', 'mean', 350)),
        ("2.  Seed spread < 60pp", _check_a(part_a_results, 'A1_D6_Bag30', 'spread', 60, less_than=True)),
        ("3.  Beat V2 10/10", _check_a(part_a_results, 'A1_D6_Bag30', 'beat_v2', 10, equals=True)),
        ("4.  Perm p (alloc) < 0.05", part_b_results.get('B1a_alloc_shuffle', {}).get('pass', False)),
        ("5.  Perm p (return) < 0.05", part_b_results.get('B1b_return_shuffle', {}).get('pass', False)),
        ("6.  DSR > 1.96", part_b_results.get('B2_deflated_sharpe', {}).get('pass', False)),
        ("7.  Alpha CAPM t > 2.0", _check_b3(part_b_results)),
        ("8.  Hit rate > 52%", part_b_results.get('B4_prediction_accuracy', {}).get('pass', False)),
        ("9.  Feature stability > 0.60", part_b_results.get('B5_feature_stability', {}).get('pass', False)),
        ("10. IS/OOS gap < 0.20", part_b_results.get('B6_is_oos_gap', {}).get('pass', False)),
        ("11. Per-fold >= 80%", part_b_results.get('B7_perfold_ranking', {}).get('pass', False)),
        ("12. CPCV P(S>0) > 75%", part_b_results.get('B9_cpcv', {}).get('pass', False)),
        ("13. Forward decay p > 0.10", part_b_results.get('B10_forward_decay', {}).get('pass', False)),
        ("14. Excess >= 3/5 years", _check_c4(part_c_results)),
        ("15. Stress >= 7/10", _check_c5(part_c_results)),
        ("16. Cost/gross < 10%", _check_c6(part_c_results)),
    ]

    n_pass = 0
    for desc, passed in criteria:
        status = 'PASS' if passed else 'FAIL'
        P(f"  {desc:<35} {status}")
        if passed:
            n_pass += 1
    n_fail = len(criteria) - n_pass

    P(f"\n  TOTAL: {n_pass} PASS / {n_fail} FAIL")
    if n_fail >= 3:
        P(f"  VERDICT: STRATEGY NOT APPROVED ({n_fail} failures >= 3)")
    else:
        P(f"  VERDICT: STRATEGY APPROVED ({n_fail} failures < 3)")

    full_output['scorecard'] = {
        'criteria': [{desc: passed} for desc, passed in criteria],
        'n_pass': n_pass, 'n_fail': n_fail,
        'approved': n_fail < 3,
    }

    # ========================================
    # SAVE RESULTS
    # ========================================
    results_path = ROOT / 'outputs/results/pipeline_v8_audit.json'
    results_path.parent.mkdir(parents=True, exist_ok=True)
    full_output_clean = convert_numpy(full_output)
    results_path.write_text(json.dumps(full_output_clean, indent=2, default=str),
                            encoding='utf-8')
    P(f"\n  Results saved: {results_path}")

    # ========================================
    # GENERATE REPORT
    # ========================================
    P(f"\n  Generating report...")
    docs_dir = ROOT / 'docs'
    generate_report(full_output_clean, docs_dir)

    P(f"\n{'='*100}")
    P(f"V8 AUDIT COMPLETE")
    P(f"  End time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    P("=" * 100)


if __name__ == '__main__':
    main()
