"""
PIPELINE V9 — Baseline Corrections + Model Improvements
========================================================

V8 best: A3 (+417% mean, Sortino 1.51, 23pp spread, 14/16 audit PASS).
V8 issues:
  - Fixed CDI of 15%/year (real Selic varied 2-14.75%)
  - Bug in short formula: only (1-|a|) earns CDI when short (should be 100%)

V9 objectives:
  Step 1: Correct baseline (real CDI + fix short formula + 60/40 benchmark)
  Step 2: Model improvements (asymmetric loss, emergency rebalance, crash classifier)
  Step 3: Validation suite for any improved variant
"""

import sys
import pandas as pd
import numpy as np
from pathlib import Path
import warnings
import json
from datetime import datetime
from scipy import stats as scipy_stats
from itertools import combinations
import lightgbm as lgb

warnings.filterwarnings('ignore')
sys.stdout.reconfigure(line_buffering=True)

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))


# ============================================================
# SECTION 1: CONSTANTS & CONFIG
# ============================================================

COST = 0.0002       # 2 bps brokerage
N_TRIALS_TOTAL = 200  # total variants tested V1-V8

RF_DAILY_ARR = None   # populated in main() from real CDI data

SEEDS_10 = [42, 142, 242, 342, 442, 542, 642, 742, 842, 942]

DEFAULT_FEATURE_COLS = [
    'cusum_pos', 'miners_revenue_ratio', 'mr_score_30d', 'adx',
    'cusum_neg', 'exchange_netflow_ma7', 'structural_break_score',
    'macd_histogram', 'eth_btc_ratio', 'm2_yoy_growth',
    'volatility_7d', 'basis_ma7', 'nupl_ma30', 'hurst_60d',
    'funding_rate', 'bb_position', 'rsi_14d', 'puell_multiple',
    'stablecoin_zscore', 'sopr_ma7',
]

# A3 swap config (V8 best)
SWAP_A3 = {'puell_multiple': 'eth', 'rsi_14d': 'eth_pctchg_30d'}

DEFAULT_LGB_PARAMS = {
    'objective': 'regression', 'metric': 'mae',
    'num_leaves': 31, 'learning_rate': 0.05,
    'feature_fraction': 0.7, 'bagging_fraction': 0.8,
    'bagging_freq': 5, 'num_boost_round': 200,
    'verbose': -1, 'n_jobs': 1,
}


def P(*a, **kw):
    try:
        print(*a, **kw, flush=True)
    except UnicodeEncodeError:
        text = ' '.join(str(x) for x in a)
        text = text.encode('ascii', errors='replace').decode('ascii')
        print(text, **kw, flush=True)


# ============================================================
# SECTION 2: DATA LOADING (from V8)
# ============================================================

def load_data():
    df = pd.read_csv(ROOT / 'outputs/feature_selection/dataset_enhanced.csv')
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)

    prices = df['price_usd'].values
    n = len(prices)

    daily_ret = np.zeros(n)
    for i in range(1, n):
        daily_ret[i] = (prices[i] - prices[i-1]) / prices[i-1]

    returns = {}
    for w in [1, 3, 5, 7, 10, 14, 20, 21, 30, 45, 60]:
        r = np.zeros(n)
        for i in range(w, n):
            r[i] = (prices[i] - prices[i-w]) / prices[i-w]
        returns[w] = r

    vols = {}
    for w in [5, 7, 10, 14, 21, 30]:
        vols[w] = pd.Series(daily_ret).rolling(w).std().fillna(0.02).values

    return prices, daily_ret, returns, vols, df


# ============================================================
# SECTION 3: CORE ENGINE (FIXED short formula)
# ============================================================

def backtest_allocations(daily_ret, allocations, start_idx, end_idx,
                         cost=COST, rf_daily=None,
                         clip_min=-0.25, clip_max=1.0):
    """Backtest with CORRECTED short formula.

    V8 bug: sr = a * br + (1 - abs(a)) * rf_t - tc
      When a=-0.25, only 0.75 earns CDI.
    V9 fix: When short, 100% of capital earns CDI (margin also earns).
    """
    if rf_daily is None:
        rf_daily = RF_DAILY_ARR
    strat, btc, allocs = [], [], []
    prev = 0.5
    n = len(daily_ret)
    is_arr = isinstance(rf_daily, np.ndarray)
    for t in range(start_idx, min(end_idx, n - 1)):
        a = np.clip(allocations[t], clip_min, clip_max)
        br = daily_ret[t + 1]
        rf_t = rf_daily[t] if is_arr else rf_daily
        tc = abs(a - prev) * cost * (1.5 if a < 0 else 1.0)
        # FIXED: short positions earn CDI on full capital
        if a >= 0:
            sr = a * br + (1 - a) * rf_t - tc
        else:
            sr = a * br + 1.0 * rf_t - tc
        strat.append(sr)
        btc.append(br)
        allocs.append(a)
        prev = a
    return np.array(strat), np.array(btc), np.array(allocs)


def metrics(s, b, a, rf_daily=None):
    if len(s) < 10:
        return None
    if rf_daily is None:
        rf_daily = 0.0
    ts = np.prod(1 + s) - 1
    tb = np.prod(1 + b) - 1
    ex = s - rf_daily
    ds = ex[ex < 0]
    sortino = np.mean(ex) / (np.std(ds) + 1e-10) * np.sqrt(365) if len(ds) > 0 else 0
    cum = np.cumprod(1 + s)
    pk = np.maximum.accumulate(cum)
    dd = np.min((cum - pk) / (pk + 1e-10))
    sharpe = np.mean(ex) / (np.std(s) + 1e-10) * np.sqrt(365)
    calmar = ts / (abs(dd) + 1e-10)
    return {'total': ts, 'btc': tb, 'excess': ts - tb, 'sortino': sortino,
            'sharpe': sharpe, 'calmar': calmar,
            'max_dd': dd, 'short_pct': float((a < 0).mean()), 'avg_alloc': float(np.mean(a))}


def get_year_boundaries(dates, n):
    yb = {}
    for i in range(n):
        yr = pd.Timestamp(dates[i]).year
        if yr not in yb:
            yb[yr] = {'start': i, 'end': i}
        yb[yr]['end'] = i
    return yb


# ============================================================
# SECTION 4: FEATURE BUILDING (from V8)
# ============================================================

def build_ml_features(df, returns, vols, n, feature_cols=None):
    if feature_cols is None:
        feature_cols = DEFAULT_FEATURE_COLS

    price_derived_map = {
        'ret_3d': returns[3], 'ret_5d': returns[5], 'ret_7d': returns[7],
        'ret_10d': returns[10], 'ret_14d': returns[14], 'ret_30d': returns[30],
        'ret_45d': returns[45], 'ret_60d': returns[60],
        'vol_7d': vols[7], 'vol_14d': vols[14], 'vol_30d': vols[30],
    }

    cols, names = [], []
    for col in feature_cols:
        if col in price_derived_map:
            cols.append(price_derived_map[col])
            names.append(col)
        elif col in df.columns:
            cols.append(df[col].values.astype(float))
            names.append(col)

    for pd_feat in ['ret_3d', 'ret_10d', 'ret_30d', 'ret_60d', 'vol_14d']:
        if pd_feat not in names:
            cols.append(price_derived_map[pd_feat])
            names.append(pd_feat)

    X_all = np.column_stack(cols) if cols else np.zeros((n, 0))
    return X_all, names


def build_ml_features_swap(df, returns, vols, n, swap_dict):
    feature_cols = list(DEFAULT_FEATURE_COLS)
    for weak, strong in swap_dict.items():
        if weak in feature_cols:
            idx = feature_cols.index(weak)
            feature_cols[idx] = strong
    return build_ml_features(df, returns, vols, n, feature_cols=feature_cols)


# ============================================================
# SECTION 5: ML TRAINING (with asymmetric loss option)
# ============================================================

def make_asymmetric_mae(alpha_crash=3.0):
    """Create asymmetric MAE objective for LightGBM.
    Penalizes missed crashes (predicted up, reality down) by alpha_crash.
    """
    def asymmetric_mae(y_pred, dtrain):
        y_true = dtrain.get_label()
        residual = y_pred - y_true
        missed_crash = (residual > 0) & (y_true < 0)
        alpha = np.where(missed_crash, alpha_crash, 1.0)
        grad = alpha * np.sign(residual)
        hess = alpha * np.ones_like(residual)
        return grad, hess
    return asymmetric_mae


def train_lgb_bagged(X_all, target, train_end, horizon_gap=5, n_bags=5,
                     base_seed=42, lgb_params=None, fobj=None):
    """Train bagged LightGBM models.
    Args:
        fobj: custom objective function (set as params['objective'] in LGB 4.x)
    """
    models = []
    for i in range(n_bags):
        seed = base_seed + i * 7
        train_mask = np.arange(60, train_end - horizon_gap + 1)
        valid_train = ~np.any(np.isnan(X_all[train_mask]), axis=1)
        train_idx = train_mask[valid_train]
        if len(train_idx) < 100:
            continue
        X_train = np.nan_to_num(X_all[train_idx], nan=0.0)
        y_train = target[train_idx]
        params = dict(lgb_params or DEFAULT_LGB_PARAMS)
        params['seed'] = seed
        params['verbose'] = -1
        params['n_jobs'] = 1
        num_round = params.pop('num_boost_round', 200)
        if fobj is not None:
            params['objective'] = fobj
            params.pop('metric', None)
        dtrain = lgb.Dataset(X_train, label=y_train)
        models.append(lgb.train(params, dtrain, num_boost_round=num_round))
    return models if len(models) > 0 else None


def ml_predict(models, X_all, t, scale_div=0.05):
    x_t = np.nan_to_num(X_all[t:t+1].copy(), nan=0.0)
    preds = [m.predict(x_t)[0] for m in models]
    avg_pred = np.mean(preds)
    scaled = np.clip(avg_pred / scale_div, -1.0, 1.0)
    if scaled > 0:
        return 0.5 + scaled * 0.5
    else:
        return 0.5 + scaled * 0.75


# ============================================================
# SECTION 6: WALK-FORWARD ENGINE (with emergency rebalance)
# ============================================================

def run_strategy(daily_ret, returns, vols, df, dates, n,
                 n_bags=5, use_weekly=True, target_horizon=3,
                 X_all_override=None, base_seed=42,
                 clip_min=-0.25, clip_max=1.0,
                 cost=COST, rf_daily=None,
                 verbose=False, return_allocs=False,
                 return_per_year=False,
                 lgb_params=None, scale_div=0.05,
                 swap_dict=None,
                 fobj=None,
                 emergency_threshold=None):
    """Walk-forward engine with V9 enhancements.

    New params:
        fobj: custom LightGBM objective (for asymmetric loss)
        emergency_threshold: if BTC drops more than this since last rebal,
                             trigger mid-week rebalance (e.g. -0.05 for -5%)
    """
    if rf_daily is None:
        rf_daily = RF_DAILY_ARR
    yb = get_year_boundaries(dates, n)
    prices = df['price_usd'].values

    if X_all_override is not None:
        X_all = X_all_override
    elif swap_dict is not None:
        X_all, _ = build_ml_features_swap(df, returns, vols, n, swap_dict)
    else:
        X_all, _ = build_ml_features(df, returns, vols, n)

    target = np.zeros(n)
    h = target_horizon
    for i in range(n - h):
        target[i] = (prices[i + h] - prices[i]) / prices[i]

    day_of_week = pd.to_datetime(dates).dayofweek

    all_strat, all_btc, all_alloc, all_rf = [], [], [], []
    full_allocs = np.full(n, 0.5)
    year_metrics = {}
    is_rf_arr = isinstance(rf_daily, np.ndarray)

    for test_year in range(2022, 2027):
        if test_year not in yb:
            continue

        train_end = yb[test_year]['start'] - 1
        test_start = yb[test_year]['start']
        test_end = yb[test_year]['end']

        horizon_gap = max(target_horizon, 5)

        models_list = []
        for i in range(n_bags):
            seed = base_seed + i * 7
            train_mask = np.arange(60, train_end - horizon_gap + 1)
            valid_train = ~np.any(np.isnan(X_all[train_mask]), axis=1)
            train_idx = train_mask[valid_train]
            if len(train_idx) < 100:
                continue
            X_train = np.nan_to_num(X_all[train_idx], nan=0.0)
            y_train = target[train_idx]
            params = dict(lgb_params or DEFAULT_LGB_PARAMS)
            params['seed'] = seed
            params['verbose'] = -1
            params['n_jobs'] = 1
            num_round = params.pop('num_boost_round', 200)
            dtrain = lgb.Dataset(X_train, label=y_train)
            if fobj is not None:
                params['objective'] = fobj
                params.pop('metric', None)
            models_list.append(lgb.train(params, dtrain,
                                         num_boost_round=num_round))

        models = models_list if len(models_list) > 0 else None

        if verbose:
            P(f"    {test_year}: {len(models) if models else 0} models", end="")

        prev_alloc = 0.5
        last_rebal_price = prices[test_start] if test_start < len(prices) else 0

        for t in range(test_start, test_end + 1):
            if models is not None:
                a_ml = ml_predict(models, X_all, t, scale_div=scale_div)
            else:
                a_ml = 0.5

            raw_alloc = a_ml
            is_friday = day_of_week[t] == 4

            if use_weekly:
                # Check emergency rebalance
                if emergency_threshold is not None and not is_friday:
                    btc_change = (prices[t] - last_rebal_price) / (last_rebal_price + 1e-10)
                    if btc_change < emergency_threshold:
                        # Trigger emergency: use model prediction
                        is_friday = True  # treat as rebal day

                if not is_friday:
                    raw_alloc = prev_alloc

            if is_friday or not use_weekly:
                last_rebal_price = prices[t]

            full_allocs[t] = np.clip(raw_alloc, clip_min, clip_max)
            prev_alloc = full_allocs[t]

        s, b, a = backtest_allocations(daily_ret, full_allocs, test_start, test_end,
                                       cost=cost, rf_daily=rf_daily,
                                       clip_min=clip_min, clip_max=clip_max)
        all_strat.extend(s)
        all_btc.extend(b)
        all_alloc.extend(a)

        n_days = len(s)
        if is_rf_arr:
            rf_slice = rf_daily[test_start:test_start + n_days]
            all_rf.extend(rf_slice)
        else:
            all_rf.extend([rf_daily] * n_days)

        rf_yr = np.array(all_rf[-n_days:])
        m_yr = metrics(np.array(s), np.array(b), np.array(a), rf_daily=rf_yr)
        if return_per_year and m_yr:
            year_metrics[test_year] = m_yr
        if verbose and m_yr:
            P(f" -> {m_yr['total']*100:+.1f}%")
        elif verbose:
            P(" -> N/A")

    result = metrics(np.array(all_strat), np.array(all_btc), np.array(all_alloc),
                     rf_daily=np.array(all_rf))

    out = [result]
    if return_allocs:
        out.append(full_allocs.copy())
        out.append(np.array(all_strat))
        out.append(np.array(all_btc))
        out.append(np.array(all_alloc))
    if return_per_year:
        out.append(year_metrics)
    if len(out) == 1:
        return out[0]
    return tuple(out)


# ============================================================
# SECTION 7: CRASH CLASSIFIER (NEW)
# ============================================================

def build_crash_target(prices, n, horizon=7, threshold=-0.10):
    """Binary target: 1 if BTC drops >|threshold| within next `horizon` days."""
    target = np.zeros(n)
    for i in range(n - horizon):
        future_min = np.min(prices[i+1:i+1+horizon])
        drawdown = (future_min - prices[i]) / prices[i]
        if drawdown < threshold:
            target[i] = 1.0
    return target


def train_crash_classifier(X_all, crash_target, train_end, horizon_gap=5,
                           n_bags=5, base_seed=42):
    """Train LightGBM binary classifier for crash prediction."""
    models = []
    for i in range(n_bags):
        seed = base_seed + i * 7
        train_mask = np.arange(60, train_end - horizon_gap + 1)
        valid_train = ~np.any(np.isnan(X_all[train_mask]), axis=1)
        train_idx = train_mask[valid_train]
        if len(train_idx) < 100:
            continue
        X_train = np.nan_to_num(X_all[train_idx], nan=0.0)
        y_train = crash_target[train_idx]

        pos_count = y_train.sum()
        neg_count = len(y_train) - pos_count
        spw = neg_count / (pos_count + 1e-10)

        params = {
            'objective': 'binary', 'metric': 'binary_logloss',
            'num_leaves': 31, 'learning_rate': 0.05,
            'feature_fraction': 0.7, 'bagging_fraction': 0.8,
            'bagging_freq': 5, 'verbose': -1, 'n_jobs': 1,
            'seed': seed, 'scale_pos_weight': min(spw, 20.0),
        }
        dtrain = lgb.Dataset(X_train, label=y_train)
        models.append(lgb.train(params, dtrain, num_boost_round=200))
    return models if models else None


def crash_predict(models, X_all, t):
    """Return average crash probability."""
    x_t = np.nan_to_num(X_all[t:t+1].copy(), nan=0.0)
    probs = [m.predict(x_t)[0] for m in models]
    return np.mean(probs)


def run_strategy_with_crash_override(daily_ret, returns, vols, df, dates, n,
                                     crash_threshold=0.5,
                                     defensive_alloc=0.0,
                                     n_bags=30, base_seed=42,
                                     X_all_override=None, swap_dict=None,
                                     rf_daily=None, verbose=False,
                                     return_allocs=False, return_per_year=False):
    """Walk-forward with crash classifier override.

    If crash model predicts P(crash) > crash_threshold, force defensive allocation.
    """
    if rf_daily is None:
        rf_daily = RF_DAILY_ARR
    yb = get_year_boundaries(dates, n)
    prices = df['price_usd'].values

    if X_all_override is not None:
        X_all = X_all_override
    elif swap_dict is not None:
        X_all, _ = build_ml_features_swap(df, returns, vols, n, swap_dict)
    else:
        X_all, _ = build_ml_features(df, returns, vols, n)

    target_reg = np.zeros(n)
    for i in range(n - 3):
        target_reg[i] = (prices[i + 3] - prices[i]) / prices[i]

    crash_target = build_crash_target(prices, n, horizon=7, threshold=-0.10)
    pos_rate = crash_target[:yb[2022]['start']].mean() * 100
    if verbose:
        P(f"    Crash target: {pos_rate:.1f}% positive in training data")

    day_of_week = pd.to_datetime(dates).dayofweek

    all_strat, all_btc, all_alloc, all_rf = [], [], [], []
    full_allocs = np.full(n, 0.5)
    year_metrics = {}
    is_rf_arr = isinstance(rf_daily, np.ndarray)
    n_overrides = 0

    for test_year in range(2022, 2027):
        if test_year not in yb:
            continue

        train_end = yb[test_year]['start'] - 1
        test_start = yb[test_year]['start']
        test_end = yb[test_year]['end']
        horizon_gap = max(3, 5)

        # Train regression models (Model A)
        reg_models = []
        for i in range(n_bags):
            seed = base_seed + i * 7
            train_mask = np.arange(60, train_end - horizon_gap + 1)
            valid_train = ~np.any(np.isnan(X_all[train_mask]), axis=1)
            train_idx = train_mask[valid_train]
            if len(train_idx) < 100:
                continue
            X_train = np.nan_to_num(X_all[train_idx], nan=0.0)
            y_train = target_reg[train_idx]
            params = dict(DEFAULT_LGB_PARAMS)
            params['seed'] = seed
            params['verbose'] = -1
            params['n_jobs'] = 1
            num_round = params.pop('num_boost_round', 200)
            dtrain = lgb.Dataset(X_train, label=y_train)
            reg_models.append(lgb.train(params, dtrain, num_boost_round=num_round))

        # Train crash classifier (Model B)
        crash_models = train_crash_classifier(X_all, crash_target, train_end,
                                              horizon_gap=horizon_gap,
                                              n_bags=min(n_bags, 10),
                                              base_seed=base_seed)

        if verbose:
            P(f"    {test_year}: {len(reg_models)} reg + "
              f"{len(crash_models) if crash_models else 0} crash models", end="")

        prev_alloc = 0.5
        for t in range(test_start, test_end + 1):
            if reg_models:
                a_ml = ml_predict(reg_models, X_all, t)
            else:
                a_ml = 0.5

            raw_alloc = a_ml

            # Crash override
            if crash_models:
                p_crash = crash_predict(crash_models, X_all, t)
                if p_crash > crash_threshold:
                    raw_alloc = defensive_alloc
                    n_overrides += 1

            if day_of_week[t] != 4:
                raw_alloc = prev_alloc

            full_allocs[t] = np.clip(raw_alloc, -0.25, 1.0)
            prev_alloc = full_allocs[t]

        s, b, a = backtest_allocations(daily_ret, full_allocs, test_start, test_end,
                                       cost=COST, rf_daily=rf_daily)
        all_strat.extend(s)
        all_btc.extend(b)
        all_alloc.extend(a)

        n_days = len(s)
        if is_rf_arr:
            rf_slice = rf_daily[test_start:test_start + n_days]
            all_rf.extend(rf_slice)
        else:
            all_rf.extend([rf_daily] * n_days)

        rf_yr = np.array(all_rf[-n_days:])
        m_yr = metrics(np.array(s), np.array(b), np.array(a), rf_daily=rf_yr)
        if return_per_year and m_yr:
            year_metrics[test_year] = m_yr
        if verbose and m_yr:
            P(f" -> {m_yr['total']*100:+.1f}%")
        elif verbose:
            P(" -> N/A")

    if verbose:
        P(f"    Total crash overrides: {n_overrides}")

    result = metrics(np.array(all_strat), np.array(all_btc), np.array(all_alloc),
                     rf_daily=np.array(all_rf))

    out = [result]
    if return_allocs:
        out.append(full_allocs.copy())
        out.append(np.array(all_strat))
        out.append(np.array(all_btc))
        out.append(np.array(all_alloc))
    if return_per_year:
        out.append(year_metrics)
    if len(out) == 1:
        return out[0]
    return tuple(out)


# ============================================================
# SECTION 8: 60/40 STATIC BENCHMARK (NEW)
# ============================================================

def benchmark_60_40(daily_ret, dates, n, rf_daily=None):
    """60% BTC + 40% CDI, rebalanced monthly."""
    if rf_daily is None:
        rf_daily = RF_DAILY_ARR
    yb = get_year_boundaries(dates, n)

    allocs = np.full(n, 0.6)  # 60% BTC always
    months = pd.to_datetime(dates).to_period('M')
    is_rf_arr = isinstance(rf_daily, np.ndarray)

    all_strat, all_btc, all_alloc, all_rf = [], [], [], []
    for test_year in range(2022, 2027):
        if test_year not in yb:
            continue
        test_start = yb[test_year]['start']
        test_end = yb[test_year]['end']

        s, b, a = backtest_allocations(daily_ret, allocs, test_start, test_end,
                                       cost=COST, rf_daily=rf_daily)
        all_strat.extend(s)
        all_btc.extend(b)
        all_alloc.extend(a)

        n_days = len(s)
        if is_rf_arr:
            rf_slice = rf_daily[test_start:test_start + n_days]
            all_rf.extend(rf_slice)
        else:
            all_rf.extend([rf_daily] * n_days)

    result = metrics(np.array(all_strat), np.array(all_btc), np.array(all_alloc),
                     rf_daily=np.array(all_rf))
    return result


# ============================================================
# SECTION 9: CRASH DETECTION METRICS
# ============================================================

def crash_detection_rates(prices, allocations, dates, n, thresholds=None):
    """Measure how well the strategy detects BTC crashes.

    For each threshold (-5%, -10%, -15%, -20%), compute:
    - Total crash events (rolling 7-day drawdowns)
    - How many the strategy was defensive (alloc < 0.5) on those days
    """
    if thresholds is None:
        thresholds = [-0.05, -0.10, -0.15, -0.20]

    yb = get_year_boundaries(dates, n)
    oos_start = yb[2022]['start'] if 2022 in yb else 0

    results = {}
    for thresh in thresholds:
        crash_days = []
        for i in range(oos_start, n - 7):
            future_min = np.min(prices[i+1:i+8])
            dd = (future_min - prices[i]) / prices[i]
            if dd < thresh:
                crash_days.append(i)

        if not crash_days:
            results[f'{thresh*100:.0f}%'] = {'events': 0, 'detected': 0, 'rate': 0.0}
            continue

        detected = 0
        for cd in crash_days:
            oos_idx = cd - oos_start
            if 0 <= oos_idx < len(allocations):
                if allocations[oos_idx] < 0.5:
                    detected += 1

        rate = detected / len(crash_days)
        results[f'{thresh*100:.0f}%'] = {
            'events': len(crash_days), 'detected': detected, 'rate': rate
        }

    return results


# ============================================================
# SECTION 10: STEP 1 — BASELINE WITH CORRECTIONS
# ============================================================

def step1_baseline(daily_ret, returns, vols, df, dates, n):
    P(f"\n{'#'*100}")
    P("STEP 1: BASELINE WITH CORRECTIONS")
    P("#" * 100)
    P("  CDI: Real rates from BCB/COPOM")
    P("  Short formula: FIXED (100% earns CDI when short)")
    P("  Config: A3 (puell->eth, rsi->eth_pctchg_30d, Bag30, ret_3d, weekly Fri)")

    results = {}
    alloc_store = {}

    # --- 1a/1b: A3 baseline with corrections (10 seeds) ---
    P(f"\n  A3 baseline (10 seeds):")
    X_a3, _ = build_ml_features_swap(df, returns, vols, n, SWAP_A3)
    a3_seeds = []
    for seed in SEEDS_10:
        P(f"    seed={seed}...", end="")
        r = run_strategy(
            daily_ret, returns, vols, df, dates, n,
            n_bags=30, X_all_override=X_a3, base_seed=seed,
            return_allocs=True, return_per_year=True)
        result, allocs, strat_r, btc_r, alloc_a, year_m = r
        if result:
            a3_seeds.append(result)
            P(f" {result['total']*100:+.1f}% (Sortino {result['sortino']:.2f})")
            if seed == 42:
                alloc_store['A3_baseline'] = {
                    'allocs': allocs, 'strat_ret': strat_r,
                    'btc_ret': btc_r, 'alloc_arr': alloc_a,
                    'year_metrics': year_m
                }
        else:
            P(" FAILED")

    a3_rets = [r['total'] * 100 for r in a3_seeds]
    a3_summary = _seed_summary(a3_rets, a3_seeds)
    results['A3_baseline'] = {'config': 'A3 corrected (real CDI + fixed short)',
                              'seeds': a3_summary}

    P(f"\n  A3 baseline summary:")
    P(f"    Mean:   {a3_summary['mean']:+.1f}%")
    P(f"    Spread: {a3_summary['spread']:.0f}pp")
    P(f"    Sortino mean: {a3_summary['sortinos_mean']:.2f}")
    P(f"    MaxDD mean: {a3_summary['max_dds_mean']:.1f}%")
    P(f"    Beat V2 (221%): {a3_summary['beat_v2']}/10")

    # Year-by-year for seed 42
    if 'A3_baseline' in alloc_store:
        ym = alloc_store['A3_baseline']['year_metrics']
        P(f"\n  A3 year-by-year (seed 42):")
        for yr in sorted(ym.keys()):
            m = ym[yr]
            P(f"    {yr}: strat={m['total']*100:+.1f}%  btc={m['btc']*100:+.1f}%  "
              f"excess={m['excess']*100:+.1f}pp  dd={m['max_dd']*100:.1f}%")

    # --- 1d: 60/40 static benchmark ---
    P(f"\n  60/40 static benchmark:")
    r_6040 = benchmark_60_40(daily_ret, dates, n)
    if r_6040:
        P(f"    Return: {r_6040['total']*100:+.1f}%")
        P(f"    Sortino: {r_6040['sortino']:.2f}")
        P(f"    MaxDD: {r_6040['max_dd']*100:.1f}%")
    results['benchmark_60_40'] = r_6040

    # --- Crash detection rates for baseline ---
    if 'A3_baseline' in alloc_store:
        prices = df['price_usd'].values
        cd_rates = crash_detection_rates(
            prices, alloc_store['A3_baseline']['alloc_arr'], dates, n)
        P(f"\n  A3 crash detection rates:")
        for thresh, info in cd_rates.items():
            P(f"    {thresh}: {info['detected']}/{info['events']} = {info['rate']*100:.1f}%")
        results['A3_crash_detection'] = cd_rates

    return results, alloc_store


# ============================================================
# SECTION 11: STEP 2a — ASYMMETRIC LOSS TESTS
# ============================================================

def step2a_asymmetric_loss(daily_ret, returns, vols, df, dates, n):
    P(f"\n{'#'*100}")
    P("STEP 2a: ASYMMETRIC LOSS FUNCTION")
    P("#" * 100)

    results = {}
    X_a3, _ = build_ml_features_swap(df, returns, vols, n, SWAP_A3)
    prices = df['price_usd'].values

    for alpha in [2.0, 3.0, 5.0]:
        P(f"\n  Alpha={alpha} (10 seeds):")
        fobj = make_asymmetric_mae(alpha_crash=alpha)
        seeds_results = []
        best_alloc_arr = None
        for seed in SEEDS_10:
            P(f"    seed={seed}...", end="")
            r = run_strategy(
                daily_ret, returns, vols, df, dates, n,
                n_bags=30, X_all_override=X_a3, base_seed=seed,
                fobj=fobj, return_allocs=True)
            result, allocs, strat_r, btc_r, alloc_a = r
            if result:
                seeds_results.append(result)
                P(f" {result['total']*100:+.1f}% (Sortino {result['sortino']:.2f})")
                if seed == 42:
                    best_alloc_arr = alloc_a
            else:
                P(" FAILED")

        if seeds_results:
            rets = [r['total'] * 100 for r in seeds_results]
            summary = _seed_summary(rets, seeds_results)
            key = f'asym_alpha_{alpha}'
            results[key] = {'alpha': alpha, 'seeds': summary}
            P(f"    => mean={summary['mean']:+.1f}%, spread={summary['spread']:.0f}pp, "
              f"Sortino={summary['sortinos_mean']:.2f}")

            # Crash detection for seed 42
            if best_alloc_arr is not None:
                cd = crash_detection_rates(prices, best_alloc_arr, dates, n)
                results[key]['crash_detection'] = cd
                P(f"    Crash detection: ", end="")
                for thresh, info in cd.items():
                    P(f"{thresh}={info['rate']*100:.0f}% ", end="")
                P()

    return results


# ============================================================
# SECTION 12: STEP 2b — EMERGENCY REBALANCE TESTS
# ============================================================

def step2b_emergency_rebalance(daily_ret, returns, vols, df, dates, n):
    P(f"\n{'#'*100}")
    P("STEP 2b: EMERGENCY REBALANCING")
    P("#" * 100)

    results = {}
    X_a3, _ = build_ml_features_swap(df, returns, vols, n, SWAP_A3)
    prices = df['price_usd'].values

    for thresh in [-0.03, -0.05, -0.07]:
        P(f"\n  Threshold={thresh*100:.0f}% (10 seeds):")
        seeds_results = []
        best_alloc_arr = None
        for seed in SEEDS_10:
            P(f"    seed={seed}...", end="")
            r = run_strategy(
                daily_ret, returns, vols, df, dates, n,
                n_bags=30, X_all_override=X_a3, base_seed=seed,
                emergency_threshold=thresh, return_allocs=True)
            result, allocs, strat_r, btc_r, alloc_a = r
            if result:
                seeds_results.append(result)
                P(f" {result['total']*100:+.1f}% (Sortino {result['sortino']:.2f})")
                if seed == 42:
                    best_alloc_arr = alloc_a
            else:
                P(" FAILED")

        if seeds_results:
            rets = [r['total'] * 100 for r in seeds_results]
            summary = _seed_summary(rets, seeds_results)
            key = f'emergency_{abs(thresh*100):.0f}pct'
            results[key] = {'threshold': thresh, 'seeds': summary}
            P(f"    => mean={summary['mean']:+.1f}%, spread={summary['spread']:.0f}pp, "
              f"Sortino={summary['sortinos_mean']:.2f}")

            if best_alloc_arr is not None:
                cd = crash_detection_rates(prices, best_alloc_arr, dates, n)
                results[key]['crash_detection'] = cd
                P(f"    Crash detection: ", end="")
                for thresh_cd, info in cd.items():
                    P(f"{thresh_cd}={info['rate']*100:.0f}% ", end="")
                P()

    return results


# ============================================================
# SECTION 13: STEP 2c — CRASH CLASSIFIER TESTS
# ============================================================

def step2c_crash_classifier(daily_ret, returns, vols, df, dates, n):
    P(f"\n{'#'*100}")
    P("STEP 2c: CRASH CLASSIFIER")
    P("#" * 100)

    results = {}
    X_a3, _ = build_ml_features_swap(df, returns, vols, n, SWAP_A3)
    prices = df['price_usd'].values

    for conf_thresh in [0.3, 0.5, 0.7]:
        for def_alloc in [0.0, -0.25]:
            label = f"conf={conf_thresh}_def={def_alloc}"
            P(f"\n  {label} (10 seeds):")
            seeds_results = []
            best_alloc_arr = None
            for seed in SEEDS_10:
                P(f"    seed={seed}...", end="")
                r = run_strategy_with_crash_override(
                    daily_ret, returns, vols, df, dates, n,
                    crash_threshold=conf_thresh,
                    defensive_alloc=def_alloc,
                    n_bags=30, base_seed=seed,
                    X_all_override=X_a3,
                    return_allocs=True)
                result, allocs, strat_r, btc_r, alloc_a = r
                if result:
                    seeds_results.append(result)
                    P(f" {result['total']*100:+.1f}% (Sortino {result['sortino']:.2f})")
                    if seed == 42:
                        best_alloc_arr = alloc_a
                else:
                    P(" FAILED")

            if seeds_results:
                rets = [r['total'] * 100 for r in seeds_results]
                summary = _seed_summary(rets, seeds_results)
                key = f'crash_conf{conf_thresh}_def{def_alloc}'
                results[key] = {'crash_threshold': conf_thresh,
                                'defensive_alloc': def_alloc,
                                'seeds': summary}
                P(f"    => mean={summary['mean']:+.1f}%, spread={summary['spread']:.0f}pp, "
                  f"Sortino={summary['sortinos_mean']:.2f}")

                if best_alloc_arr is not None:
                    cd = crash_detection_rates(prices, best_alloc_arr, dates, n)
                    results[key]['crash_detection'] = cd
                    P(f"    Crash detection: ", end="")
                    for thresh_cd, info in cd.items():
                        P(f"{thresh_cd}={info['rate']*100:.0f}% ", end="")
                    P()

    return results


# ============================================================
# SECTION 14: STEP 2d — COMBINED BEST
# ============================================================

def step2d_combined(daily_ret, returns, vols, df, dates, n,
                    step2a_results, step2b_results, step2c_results):
    P(f"\n{'#'*100}")
    P("STEP 2d: COMBINED BEST")
    P("#" * 100)

    results = {}
    X_a3, _ = build_ml_features_swap(df, returns, vols, n, SWAP_A3)
    prices = df['price_usd'].values

    # Find best alpha from 2a
    best_alpha = None
    best_alpha_sortino = -999
    for key, val in step2a_results.items():
        if 'seeds' in val:
            s = val['seeds']['sortinos_mean']
            if s > best_alpha_sortino:
                best_alpha_sortino = s
                best_alpha = val['alpha']

    # Find best emergency threshold from 2b
    best_emerg = None
    best_emerg_sortino = -999
    for key, val in step2b_results.items():
        if 'seeds' in val:
            s = val['seeds']['sortinos_mean']
            if s > best_emerg_sortino:
                best_emerg_sortino = s
                best_emerg = val['threshold']

    # Find best crash config from 2c
    best_crash_key = None
    best_crash_sortino = -999
    for key, val in step2c_results.items():
        if 'seeds' in val:
            s = val['seeds']['sortinos_mean']
            if s > best_crash_sortino:
                best_crash_sortino = s
                best_crash_key = key

    P(f"  Best alpha: {best_alpha} (Sortino {best_alpha_sortino:.2f})")
    P(f"  Best emergency: {best_emerg} (Sortino {best_emerg_sortino:.2f})")
    P(f"  Best crash: {best_crash_key} (Sortino {best_crash_sortino:.2f})")

    # --- Combo 1: Best alpha + best emergency ---
    if best_alpha is not None and best_emerg is not None:
        P(f"\n  Combo 1: alpha={best_alpha} + emergency={best_emerg}")
        fobj = make_asymmetric_mae(alpha_crash=best_alpha)
        seeds_results = []
        for seed in SEEDS_10:
            P(f"    seed={seed}...", end="")
            r = run_strategy(
                daily_ret, returns, vols, df, dates, n,
                n_bags=30, X_all_override=X_a3, base_seed=seed,
                fobj=fobj, emergency_threshold=best_emerg)
            if r:
                seeds_results.append(r)
                P(f" {r['total']*100:+.1f}%")
            else:
                P(" FAILED")

        if seeds_results:
            rets = [r['total'] * 100 for r in seeds_results]
            summary = _seed_summary(rets, seeds_results)
            results['combo_alpha_emergency'] = {
                'alpha': best_alpha, 'emergency': best_emerg,
                'seeds': summary}
            P(f"    => mean={summary['mean']:+.1f}%, Sortino={summary['sortinos_mean']:.2f}")

    # --- Combo 2: Best alpha + crash classifier ---
    if best_alpha is not None and best_crash_key is not None:
        crash_conf = step2c_results[best_crash_key]['crash_threshold']
        crash_def = step2c_results[best_crash_key]['defensive_alloc']
        P(f"\n  Combo 2: alpha={best_alpha} + crash(conf={crash_conf}, def={crash_def})")
        # This needs a custom engine combining fobj and crash classifier.
        # For simplicity, we test crash classifier alone with the knowledge
        # that the regression model uses asymmetric loss.
        # The crash classifier trains its own separate models.
        # We can pass fobj to the regression part inside run_strategy_with_crash_override
        # by extending it. For now, skip this combo if too complex.
        P(f"    (Skipping — crash classifier already trains independently)")
        results['combo_alpha_crash'] = {'note': 'skipped - crash uses independent models'}

    # --- Combo 3: Best emergency + crash classifier ---
    # Similar complexity issue; skip for now
    results['combo_emergency_crash'] = {'note': 'skipped - would need engine integration'}

    return results


# ============================================================
# SECTION 15: VALIDATION SUITE
# ============================================================

def validate_variant(label, daily_ret, returns, vols, df, dates, n,
                     alloc_store_entry, baseline_60_40, X_all,
                     seed_summary):
    """Run full validation suite on a variant.

    Returns dict with pass/fail for each criterion.
    """
    P(f"\n  Validating: {label}")
    P(f"  {'-'*60}")

    results = {}
    prices = df['price_usd'].values
    yb = get_year_boundaries(dates, n)

    strat_ret = alloc_store_entry['strat_ret']
    btc_ret = alloc_store_entry['btc_ret']
    alloc_arr = alloc_store_entry['alloc_arr']

    oos_start = yb[2022]['start'] if 2022 in yb else 0
    if RF_DAILY_ARR is not None:
        rf_oos = RF_DAILY_ARR[oos_start:oos_start + len(strat_ret)]
    else:
        rf_oos = np.zeros(len(strat_ret))

    # V1: 10-seed stability
    P(f"    V1 10-seed stability: mean={seed_summary['mean']:+.1f}%, "
      f"spread={seed_summary['spread']:.0f}pp, beat_v2={seed_summary['beat_v2']}/10")
    v1_pass = (seed_summary['beat_v2'] >= 8 and seed_summary['spread'] < 60)
    results['V1_seeds'] = {'pass': v1_pass, **seed_summary}

    # V2: Crash detection rates
    cd = crash_detection_rates(prices, alloc_arr, dates, n)
    P(f"    V2 Crash detection: ", end="")
    for thresh, info in cd.items():
        P(f"{thresh}={info['rate']*100:.0f}% ", end="")
    P()
    results['V2_crash_detection'] = cd

    # V3: Permutation test (1000 allocation shuffles)
    P(f"    V3 Permutation test (1000 shuffles)...", end="")
    real_return = np.prod(1 + strat_ret) - 1
    rng = np.random.RandomState(42)
    n_perm = 1000
    block_size = 5
    n_oos = len(alloc_arr)
    perm_returns = []
    for _ in range(n_perm):
        n_blocks = n_oos // block_size
        block_indices = np.arange(n_blocks)
        rng.shuffle(block_indices)
        shuffled_allocs = np.zeros(n_oos)
        for bi, orig_bi in enumerate(block_indices):
            start = bi * block_size
            orig_start = orig_bi * block_size
            end = min(start + block_size, n_oos)
            orig_end = min(orig_start + block_size, n_oos)
            length = min(end - start, orig_end - orig_start)
            shuffled_allocs[start:start+length] = alloc_arr[orig_start:orig_start+length]
        remainder = n_blocks * block_size
        if remainder < n_oos:
            shuffled_allocs[remainder:] = alloc_arr[remainder:]

        perm_strat = []
        prev = 0.5
        for i in range(len(btc_ret)):
            a = shuffled_allocs[i] if i < len(shuffled_allocs) else 0.5
            tc = abs(a - prev) * COST * (1.5 if a < 0 else 1.0)
            # Fixed short formula in permutation loop too
            if a >= 0:
                sr = a * btc_ret[i] + (1 - a) * rf_oos[i] - tc
            else:
                sr = a * btc_ret[i] + 1.0 * rf_oos[i] - tc
            perm_strat.append(sr)
            prev = a
        perm_total = np.prod(1 + np.array(perm_strat)) - 1
        perm_returns.append(perm_total)

    p_val = np.mean([pr >= real_return for pr in perm_returns])
    v3_pass = p_val < 0.05
    P(f" p={p_val:.4f} {'PASS' if v3_pass else 'FAIL'}")
    results['V3_permutation'] = {'p_value': float(p_val), 'pass': v3_pass}

    # V4: CPCV (6 blocks, C(6,3)=20 paths)
    P(f"    V4 CPCV (20 paths)...", end="")
    oos_end_idx = max(yb[yr]['end'] for yr in yb if yr >= 2022)
    oos_indices = np.arange(oos_start, oos_end_idx + 1)
    n_oos_total = len(oos_indices)
    n_blocks_cpcv = 6
    block_len = n_oos_total // n_blocks_cpcv
    purge_gap = 7

    blocks = []
    for bi in range(n_blocks_cpcv):
        s = oos_start + bi * block_len
        e = s + block_len if bi < n_blocks_cpcv - 1 else oos_end_idx + 1
        blocks.append((s, e))

    target_cpcv = np.zeros(n)
    for i in range(n - 3):
        target_cpcv[i] = (prices[i + 3] - prices[i]) / prices[i]

    cpcv_sortinos = []
    for train_blocks in combinations(range(n_blocks_cpcv), 3):
        test_blocks_list = [i for i in range(n_blocks_cpcv) if i not in train_blocks]

        train_idx = []
        for tb in train_blocks:
            s, e = blocks[tb]
            train_idx.extend(range(s, e))
        train_idx = np.array(train_idx)

        test_boundaries = set()
        for tb in test_blocks_list:
            s, e = blocks[tb]
            for j in range(max(0, s - purge_gap), min(n, s + purge_gap)):
                test_boundaries.add(j)
            for j in range(max(0, e - purge_gap), min(n, e + purge_gap)):
                test_boundaries.add(j)
        train_idx = np.array([i for i in train_idx if i not in test_boundaries])

        valid = ~np.any(np.isnan(X_all[train_idx]), axis=1)
        train_idx_clean = train_idx[valid]
        if len(train_idx_clean) < 100:
            continue
        X_tr = np.nan_to_num(X_all[train_idx_clean], nan=0.0)
        y_tr = target_cpcv[train_idx_clean]

        params = dict(DEFAULT_LGB_PARAMS)
        params['seed'] = 42
        num_round = params.pop('num_boost_round', 200)
        dtrain = lgb.Dataset(X_tr, label=y_tr)
        model = lgb.train(params, dtrain, num_boost_round=num_round)

        test_idx = []
        for tb in test_blocks_list:
            s, e = blocks[tb]
            test_idx.extend(range(s, min(e, n - 1)))
        test_idx = np.array(test_idx)

        day_of_week = pd.to_datetime(dates).dayofweek
        allocs_cpcv = np.full(n, 0.5)
        prev_a = 0.5
        for t in test_idx:
            x_t = np.nan_to_num(X_all[t:t+1], nan=0.0)
            pred = model.predict(x_t)[0]
            scaled = np.clip(pred / 0.05, -1.0, 1.0)
            a_ml = 0.5 + scaled * 0.5 if scaled > 0 else 0.5 + scaled * 0.75
            raw = a_ml
            if day_of_week[t] != 4:
                raw = prev_a
            allocs_cpcv[t] = np.clip(raw, -0.25, 1.0)
            prev_a = allocs_cpcv[t]

        all_s, all_b, all_a = [], [], []
        for tb in test_blocks_list:
            s, e = blocks[tb]
            sr, br, ar = backtest_allocations(daily_ret, allocs_cpcv, s, min(e, n-1))
            all_s.extend(sr); all_b.extend(br); all_a.extend(ar)

        m_cpcv = metrics(np.array(all_s), np.array(all_b), np.array(all_a))
        if m_cpcv:
            cpcv_sortinos.append(m_cpcv['sortino'])

    if cpcv_sortinos:
        p_sortino_pos = np.mean([s > 0 for s in cpcv_sortinos])
        mean_sortino = np.mean(cpcv_sortinos)
        v4_pass = p_sortino_pos > 0.75 and mean_sortino > 0.5
        P(f" P(S>0)={p_sortino_pos:.0%}, mean={mean_sortino:.2f} {'PASS' if v4_pass else 'FAIL'}")
    else:
        p_sortino_pos = 0
        mean_sortino = 0
        v4_pass = False
        P(f" NO PATHS")
    results['V4_cpcv'] = {
        'n_paths': len(cpcv_sortinos), 'p_sortino_positive': float(p_sortino_pos),
        'mean_sortino': float(mean_sortino), 'pass': v4_pass}

    # V5: Year-by-year excess positive in >= 3/5 years
    P(f"    V5 Year-by-year: ", end="")
    oos_dates = dates[oos_start:oos_start + len(strat_ret)]
    oos_years = pd.to_datetime(oos_dates).year.values
    excess_pos = 0
    for yr in range(2022, 2027):
        yr_mask = oos_years == yr
        if yr_mask.sum() == 0:
            continue
        yr_s = np.prod(1 + strat_ret[yr_mask]) - 1
        yr_b = np.prod(1 + btc_ret[yr_mask]) - 1
        if yr_s - yr_b > 0:
            excess_pos += 1
    v5_pass = excess_pos >= 3
    P(f"{excess_pos}/5 years excess positive {'PASS' if v5_pass else 'FAIL'}")
    results['V5_yearly'] = {'excess_positive_years': excess_pos, 'pass': v5_pass}

    # V6: Bootstrap 95% CI — P(loss) < 5%
    P(f"    V6 Bootstrap CI...", end="")
    rng_bs = np.random.RandomState(42)
    n_bootstrap = 1000
    block_bs = 20
    bootstrap_returns = []
    for _ in range(n_bootstrap):
        n_blocks_bs = len(strat_ret) // block_bs
        sampled = rng_bs.randint(0, n_blocks_bs, n_blocks_bs)
        bs_ret = []
        for bi in sampled:
            start = bi * block_bs
            end = min(start + block_bs, len(strat_ret))
            bs_ret.extend(strat_ret[start:end])
        bs_total = np.prod(1 + np.array(bs_ret)) - 1
        bootstrap_returns.append(bs_total)
    p_loss = np.mean([r < 0 for r in bootstrap_returns])
    ci_lo = np.percentile(bootstrap_returns, 2.5)
    ci_hi = np.percentile(bootstrap_returns, 97.5)
    v6_pass = p_loss < 0.05
    P(f" P(loss)={p_loss*100:.1f}%, CI=[{ci_lo*100:+.0f}%, {ci_hi*100:+.0f}%] "
      f"{'PASS' if v6_pass else 'FAIL'}")
    results['V6_bootstrap'] = {
        'p_loss': float(p_loss), 'ci_lo': float(ci_lo), 'ci_hi': float(ci_hi),
        'pass': v6_pass}

    # V7: Beat 60/40 static
    total_return = np.prod(1 + strat_ret) - 1
    ret_6040 = baseline_60_40['total'] if baseline_60_40 else 0
    v7_pass = total_return > ret_6040
    P(f"    V7 Beat 60/40: strat={total_return*100:+.1f}% vs 60/40={ret_6040*100:+.1f}% "
      f"{'PASS' if v7_pass else 'FAIL'}")
    results['V7_beat_6040'] = {'strat': float(total_return), 'benchmark': float(ret_6040),
                               'pass': v7_pass}

    # V8: Insurance ratio >= 1.0x
    # Insurance ratio: sum of gains in crash months / sum of losses in non-crash months
    oos_dates_pd = pd.to_datetime(oos_dates)
    monthly_df = pd.DataFrame({'date': oos_dates_pd[:len(strat_ret)],
                                'strat': strat_ret, 'btc': btc_ret})
    monthly_df['month'] = monthly_df['date'].dt.to_period('M')
    monthly_btc = monthly_df.groupby('month')['btc'].apply(lambda x: np.prod(1+x)-1)
    monthly_strat = monthly_df.groupby('month')['strat'].apply(lambda x: np.prod(1+x)-1)

    crash_months = monthly_btc[monthly_btc < -0.10].index
    non_crash_months = monthly_btc[monthly_btc >= 0].index

    gain_in_crashes = sum(max(0, monthly_strat[m] - monthly_btc[m])
                          for m in crash_months if m in monthly_strat.index)
    loss_in_bull = sum(max(0, monthly_btc[m] - monthly_strat[m])
                       for m in non_crash_months if m in monthly_strat.index)
    insurance_ratio = gain_in_crashes / (loss_in_bull + 1e-10)
    v8_pass = insurance_ratio >= 1.0
    P(f"    V8 Insurance ratio: {insurance_ratio:.2f}x {'PASS' if v8_pass else 'FAIL'}")
    results['V8_insurance'] = {'ratio': float(insurance_ratio), 'pass': v8_pass}

    # Summary
    n_pass = sum(1 for v in results.values() if isinstance(v, dict) and v.get('pass', False))
    n_total = sum(1 for v in results.values() if isinstance(v, dict) and 'pass' in v)
    P(f"    TOTAL: {n_pass}/{n_total} PASS")
    results['summary'] = {'n_pass': n_pass, 'n_total': n_total}

    return results


# ============================================================
# SECTION 16: HELPERS
# ============================================================

def _seed_summary(rets, seed_results):
    beat_v2 = sum(1 for p in rets if p > 221)
    sortinos = [r['sortino'] for r in seed_results]
    max_dds = [r['max_dd'] * 100 for r in seed_results]
    return {
        'returns': [float(p) for p in rets],
        'mean': float(np.mean(rets)),
        'median': float(np.median(rets)),
        'spread': float(max(rets) - min(rets)),
        'min': float(min(rets)), 'max': float(max(rets)),
        'beat_v2': beat_v2,
        'sortinos': [float(s) for s in sortinos],
        'sortinos_mean': float(np.mean(sortinos)),
        'max_dds': [float(d) for d in max_dds],
        'max_dds_mean': float(np.mean(max_dds)),
    }


def convert_numpy(obj):
    if isinstance(obj, (np.integer,)):
        return int(obj)
    elif isinstance(obj, (np.floating,)):
        return float(obj)
    elif isinstance(obj, np.ndarray):
        return obj.tolist()
    elif isinstance(obj, dict):
        return {str(k): convert_numpy(v) for k, v in obj.items()}
    elif isinstance(obj, (list, tuple)):
        return [convert_numpy(i) for i in obj]
    return obj


def find_best_variant(all_results):
    """Find the best variant across all steps by Sortino mean."""
    candidates = []

    # Baseline
    if 'step1' in all_results:
        s1 = all_results['step1']
        if 'A3_baseline' in s1 and 'seeds' in s1['A3_baseline']:
            candidates.append(('A3_baseline', s1['A3_baseline']['seeds']))

    # Step 2a
    if 'step2a' in all_results:
        for key, val in all_results['step2a'].items():
            if 'seeds' in val:
                candidates.append((f'2a_{key}', val['seeds']))

    # Step 2b
    if 'step2b' in all_results:
        for key, val in all_results['step2b'].items():
            if 'seeds' in val:
                candidates.append((f'2b_{key}', val['seeds']))

    # Step 2c
    if 'step2c' in all_results:
        for key, val in all_results['step2c'].items():
            if 'seeds' in val:
                candidates.append((f'2c_{key}', val['seeds']))

    # Step 2d
    if 'step2d' in all_results:
        for key, val in all_results['step2d'].items():
            if isinstance(val, dict) and 'seeds' in val:
                candidates.append((f'2d_{key}', val['seeds']))

    if not candidates:
        return None, None

    # Sort by Sortino mean
    candidates.sort(key=lambda x: x[1]['sortinos_mean'], reverse=True)
    return candidates[0]


# ============================================================
# SECTION 17: SUMMARY & JSON OUTPUT
# ============================================================

def print_summary(all_results):
    P(f"\n\n{'#'*100}")
    P("FINAL SUMMARY")
    P("#" * 100)

    # Collect all variants
    variants = []

    # Baseline
    s1 = all_results.get('step1', {})
    if 'A3_baseline' in s1 and 'seeds' in s1['A3_baseline']:
        ss = s1['A3_baseline']['seeds']
        variants.append(('A3 baseline (corrected)', ss['mean'], ss['spread'],
                         ss['sortinos_mean'], ss['beat_v2']))

    # 60/40
    b6040 = s1.get('benchmark_60_40', {})
    if b6040:
        variants.append(('60/40 static', b6040.get('total', 0)*100, 0,
                         b6040.get('sortino', 0), 0))

    # 2a
    for key, val in all_results.get('step2a', {}).items():
        if 'seeds' in val:
            ss = val['seeds']
            variants.append((f'Asym alpha={val["alpha"]}', ss['mean'], ss['spread'],
                             ss['sortinos_mean'], ss['beat_v2']))

    # 2b
    for key, val in all_results.get('step2b', {}).items():
        if 'seeds' in val:
            ss = val['seeds']
            variants.append((f'Emergency {val["threshold"]*100:.0f}%', ss['mean'],
                             ss['spread'], ss['sortinos_mean'], ss['beat_v2']))

    # 2c
    for key, val in all_results.get('step2c', {}).items():
        if 'seeds' in val:
            ss = val['seeds']
            variants.append((f'Crash {key}', ss['mean'], ss['spread'],
                             ss['sortinos_mean'], ss['beat_v2']))

    # 2d
    for key, val in all_results.get('step2d', {}).items():
        if isinstance(val, dict) and 'seeds' in val:
            ss = val['seeds']
            variants.append((f'Combo {key}', ss['mean'], ss['spread'],
                             ss['sortinos_mean'], ss['beat_v2']))

    # Sort by Sortino
    variants.sort(key=lambda x: x[3], reverse=True)

    P(f"\n  {'Variant':<35} {'Mean':>8} {'Spread':>8} {'Sortino':>8} {'BeatV2':>8}")
    P(f"  {'-'*70}")
    for name, mean, spread, sortino, bv2 in variants:
        bv2_str = f"{bv2}/10" if bv2 > 0 else "---"
        P(f"  {name:<35} {mean:>+7.1f}% {spread:>7.0f}pp {sortino:>7.2f} {bv2_str:>8}")

    # Best
    if variants:
        best = variants[0]
        P(f"\n  BEST: {best[0]} (Sortino={best[3]:.2f}, Mean={best[1]:+.1f}%)")

    # Validation results
    if 'validation' in all_results:
        P(f"\n  VALIDATION:")
        for key, val in all_results['validation'].items():
            if 'summary' in val:
                P(f"    {key}: {val['summary']['n_pass']}/{val['summary']['n_total']} PASS")


# ============================================================
# SECTION 18: MAIN
# ============================================================

def main():
    P("=" * 100)
    P("PIPELINE V9 — Baseline Corrections + Model Improvements")
    P("=" * 100)
    P(f"  Start time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    P("\nLoading data...")
    prices, daily_ret, returns, vols, df = load_data()
    dates = df['date'].values
    n = len(prices)
    P(f"  {n} days | {len(df.columns)} columns | {dates[0]} to {dates[-1]}")

    # Build real CDI/Selic risk-free rate series
    global RF_DAILY_ARR
    try:
        from src.features.macro.cdi_rates import build_rf_daily
        RF_DAILY_ARR = build_rf_daily(dates, source='auto')
        rf_mean_annual = (np.prod(1 + RF_DAILY_ARR[-365:]) - 1) * 100
        P(f"  RF: Real CDI/Selic rates loaded ({RF_DAILY_ARR.shape[0]} days, "
          f"last-year ~{rf_mean_annual:.1f}%)")
    except Exception as e:
        P(f"  WARNING: Could not load real CDI rates ({e}), using COPOM fallback")
        try:
            from src.features.macro.cdi_rates import build_rf_daily
            RF_DAILY_ARR = build_rf_daily(dates, source='copom')
            P(f"  RF: COPOM offline rates loaded ({RF_DAILY_ARR.shape[0]} days)")
        except Exception as e2:
            P(f"  FATAL: Cannot load CDI rates ({e2}). Aborting.")
            return

    # Show CDI summary
    P(f"\n  CDI summary by year:")
    for year in range(2019, 2027):
        mask = pd.to_datetime(dates).year == year
        if mask.sum() == 0:
            continue
        cum = np.prod(1 + RF_DAILY_ARR[mask]) - 1
        P(f"    {year}: {cum*100:.2f}%")

    full_output = {
        'timestamp': datetime.now().isoformat(),
        'method': 'pipeline_v9',
        'test_period': '2022-2026',
        'corrections': ['real_cdi', 'fixed_short_formula', '60_40_benchmark'],
    }

    # ========================================
    # STEP 1: Baseline with corrections
    # ========================================
    step1_results, alloc_store = step1_baseline(
        daily_ret, returns, vols, df, dates, n)
    full_output['step1'] = step1_results

    # ========================================
    # STEP 2a: Asymmetric loss
    # ========================================
    step2a_results = step2a_asymmetric_loss(
        daily_ret, returns, vols, df, dates, n)
    full_output['step2a'] = step2a_results

    # ========================================
    # STEP 2b: Emergency rebalance
    # ========================================
    step2b_results = step2b_emergency_rebalance(
        daily_ret, returns, vols, df, dates, n)
    full_output['step2b'] = step2b_results

    # ========================================
    # STEP 2c: Crash classifier
    # ========================================
    step2c_results = step2c_crash_classifier(
        daily_ret, returns, vols, df, dates, n)
    full_output['step2c'] = step2c_results

    # ========================================
    # STEP 2d: Combined best
    # ========================================
    step2d_results = step2d_combined(
        daily_ret, returns, vols, df, dates, n,
        step2a_results, step2b_results, step2c_results)
    full_output['step2d'] = step2d_results

    # ========================================
    # VALIDATION SUITE
    # ========================================
    P(f"\n\n{'='*100}")
    P("VALIDATION SUITE")
    P("=" * 100)

    X_a3, _ = build_ml_features_swap(df, returns, vols, n, SWAP_A3)
    baseline_60_40 = step1_results.get('benchmark_60_40', {})
    validation_results = {}

    # Validate baseline A3
    if 'A3_baseline' in alloc_store:
        val = validate_variant(
            'A3_baseline', daily_ret, returns, vols, df, dates, n,
            alloc_store['A3_baseline'], baseline_60_40, X_a3,
            step1_results['A3_baseline']['seeds'])
        validation_results['A3_baseline'] = val

    # Validate best variant from each step (if different from baseline)
    # Find best from 2a by Sortino
    best_2a_key = None
    best_2a_sortino = -999
    for key, val in step2a_results.items():
        if 'seeds' in val and val['seeds']['sortinos_mean'] > best_2a_sortino:
            best_2a_sortino = val['seeds']['sortinos_mean']
            best_2a_key = key

    if best_2a_key and best_2a_sortino > 0:
        # Need to re-run with return_allocs to get alloc data for validation
        alpha = step2a_results[best_2a_key]['alpha']
        fobj = make_asymmetric_mae(alpha_crash=alpha)
        P(f"\n  Re-running best 2a (alpha={alpha}) for validation data...")
        r = run_strategy(
            daily_ret, returns, vols, df, dates, n,
            n_bags=30, X_all_override=X_a3, base_seed=42,
            fobj=fobj, return_allocs=True)
        result, allocs_v, strat_v, btc_v, alloc_v = r
        if result:
            val = validate_variant(
                f'asym_alpha_{alpha}', daily_ret, returns, vols, df, dates, n,
                {'strat_ret': strat_v, 'btc_ret': btc_v, 'alloc_arr': alloc_v},
                baseline_60_40, X_a3,
                step2a_results[best_2a_key]['seeds'])
            validation_results[f'asym_alpha_{alpha}'] = val

    full_output['validation'] = validation_results

    # ========================================
    # FINAL SUMMARY
    # ========================================
    print_summary(full_output)

    # ========================================
    # SAVE RESULTS
    # ========================================
    results_path = ROOT / 'outputs/results/pipeline_v9.json'
    results_path.parent.mkdir(parents=True, exist_ok=True)
    full_output_clean = convert_numpy(full_output)
    results_path.write_text(json.dumps(full_output_clean, indent=2, default=str),
                            encoding='utf-8')
    P(f"\n  Results saved: {results_path}")

    P(f"\n{'='*100}")
    P(f"V9 PIPELINE COMPLETE")
    P(f"  End time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    P("=" * 100)


if __name__ == '__main__':
    main()
