"""
PIPELINE V14 — Re-optimization on Updated Data (Mar 2026)
==========================================================

V13 achieved +1313% / S=3.22 on Jan 31 data.
CoinMetrics revised exchange flows (corr=0.75), breaking exchange_netflow_ma7.
Updated data (to Mar 3) with old config gives +912% / S=2.39.
Removing exchange_netflow_ma7 recovers to +1028% / S=2.49.

This pipeline re-optimizes everything on the new data (~10h target).

Tracks:
  A: Feature Re-selection — drop bad, screen 30 replacements, confirm top 5 (3h)
  B: Allocation & K Re-sweep — 7 K values + 4 formulas + 5 thresholds (2h)
  C: Model Architecture — 7 hybrid ratios + 3 pure XGB + 3 pure LGB (2.5h)
  D: Risk Management — adaptive K + regularization sweep (1.5h)
  E: Training Strategy — retrain freq + sample weighting + rolling window (1.5h)
  F: Final Assembly — best combo from A-E, conservative + aggressive (0.5h)

Total: ~11h max
"""

import sys
import gc
import pandas as pd
import numpy as np
from pathlib import Path
import warnings
import json
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
import lightgbm as lgb
import xgboost as xgb

warnings.filterwarnings('ignore')
sys.stdout.reconfigure(line_buffering=True)

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

from scripts.optimization.pipeline_v9 import (
    load_data, build_ml_features,
    backtest_allocations, metrics, get_year_boundaries,
    SEEDS_10, COST, DEFAULT_LGB_PARAMS,
    P, _seed_summary, convert_numpy,
)
from scripts.optimization.pipeline_v10_mega import (
    C2_BASE, TOP_ADD, MODELS, _compute_allocation,
)
from scripts.optimization.pipeline_v11_xgb import DEFAULT_XGB_PARAMS
from scripts.optimization.pipeline_v12_hybrid import N_WORKERS
from scripts.optimization.pipeline_v13_definitive import run_v13

RF_DAILY_ARR = None
RESULTS_PATH = ROOT / 'outputs/results/pipeline_v14_reoptimize.json'


def _save(R):
    RESULTS_PATH.parent.mkdir(parents=True, exist_ok=True)
    RESULTS_PATH.write_text(json.dumps(convert_numpy(R), indent=2, default=str), encoding='utf-8')
    P(f"  [SAVE] {RESULTS_PATH.name}")


def _seeds(daily_ret, returns, vols, df, dates, n, label, **kw):
    results = []
    for seed in SEEDS_10:
        P(f"    seed={seed}...", end="")
        r = run_v13(daily_ret, returns, vols, df, dates, n, base_seed=seed, **kw)
        if r:
            results.append(r)
            P(f" {r['total']*100:+.1f}% S={r['sortino']:.2f}")
        else:
            P(" FAILED")
        gc.collect()
    if not results:
        return None
    rets = [r['total']*100 for r in results]
    s = _seed_summary(rets, results)
    P(f"    {label}: mean={s['mean']:+.1f}%, S={s['sortinos_mean']:.2f}, "
      f"spread={s['spread']:.0f}pp, MaxDD={s['max_dds_mean']:.1f}%")
    return s


def _1seed(daily_ret, returns, vols, df, dates, n, label, **kw):
    P(f"    {label}...", end="")
    r = run_v13(daily_ret, returns, vols, df, dates, n, base_seed=42, **kw)
    if r:
        P(f" {r['total']*100:+.1f}% S={r['sortino']:.2f}")
        gc.collect()
        return {'return': float(r['total']*100), 'sortino': float(r['sortino']),
                'max_dd': float(r['max_dd']*100)}
    P(" FAILED")
    gc.collect()
    return None


# ============================================================
# TRACK A: FEATURE RE-SELECTION (~3h)
# ============================================================

def track_a(daily_ret, returns, vols, df, dates, n):
    P(f"\n{'#'*100}")
    P("TRACK A: FEATURE RE-SELECTION")
    P("#" * 100)

    base_37 = list(MODELS['37feat'])
    # Clean base: remove exchange_netflow_ma7 (broken by CoinMetrics revision)
    base_clean = [f for f in base_37 if f != 'exchange_netflow_ma7'] + ['basis_pct']
    P(f"  Clean base: {len(base_clean)} feats (dropped exchange_netflow_ma7, added basis_pct)")

    kw = dict(n_bags_lgb=15, n_bags_xgb=30,
              lgb_params={'min_data_in_leaf': 12},
              alloc_formula='linear_direct', alloc_params={'K': 30},
              retrain_freq='semi', rebal_day=4, rebal_threshold=0.0)
    results = {}

    # A1: Baseline
    P(f"\n  --- A1: Clean baseline ---")
    s = _seeds(daily_ret, returns, vols, df, dates, n, label='clean_base',
               feature_cols=base_clean, **kw)
    if s: results['clean_base'] = s

    # A2: Also test keeping exchange_netflow_ma7 (confirm it hurts)
    P(f"\n  --- A2: With exchange_netflow_ma7 (confirm it hurts) ---")
    s = _seeds(daily_ret, returns, vols, df, dates, n, label='with_enf',
               feature_cols=base_37 + ['basis_pct'], **kw)
    if s: results['with_enf'] = s

    # A3: Screen 30 replacement candidates (1 seed each)
    P(f"\n  === A3: Screen replacements (1 seed) ===")
    candidates = [
        # V13 Phase 2 top confirmed (re-test on new data)
        'rsi_14d', 'btc_sp500_corr_30d', 'days_since_ath', 'fg_extreme_signal',
        'extreme_fear', 'dxy_pctchg_30d', 'fear_greed_zscore', 'momentum_consensus',
        'funding_rate', 'vix_zscore',
        # Other V13 candidates
        'max_drawdown_90d', 'return_lag_1', 'nvt_ratio', 'puell_multiple',
        'hash_rate_pctchg_30d', 'sopr_below_1', 'sth_sopr_ma7', 'funding_rate_ma7',
        'oi_change_7d', 'futures_dominance', 'mempool_congestion',
        # Never tested before
        'realized_price', 'stock_to_flow', 's2f_zscore',
        'difficulty_ribbon', 'parkinson_vol_14d',
        'candle_body_ratio', 'volume_per_trade', 'trade_count_zscore',
        'spot_taker_buy_ratio',
    ]
    available = [f for f in candidates if f in df.columns and f not in base_clean]
    P(f"  {len(available)} candidates available")

    base_1s = run_v13(daily_ret, returns, vols, df, dates, n, feature_cols=base_clean,
                      base_seed=42, **kw)
    base_s = base_1s['sortino'] if base_1s else 0
    P(f"  Baseline 1-seed: {base_1s['total']*100:+.1f}% S={base_s:.2f}")

    screen = {}
    for feat in available:
        feats = base_clean + [feat]
        r = _1seed(daily_ret, returns, vols, df, dates, n, label=f'+{feat}',
                   feature_cols=feats, **kw)
        if r:
            r['diff'] = r['sortino'] - base_s
            screen[feat] = r

    ranked = sorted(screen.items(), key=lambda x: x[1]['sortino'], reverse=True)
    P(f"\n  Screen ranking:")
    for feat, r in ranked:
        P(f"    +{feat:<30} {r['return']:+.1f}% S={r['sortino']:.2f} ({r['diff']:+.3f})")
    results['screen_1seed'] = screen

    # A4: Confirm top 5 (10 seeds)
    top_5 = [f for f, _ in ranked[:5]]
    P(f"\n  === A4: Confirm top 5 (10 seeds) ===")
    confirmed = {}
    for feat in top_5:
        feats = base_clean + [feat]
        P(f"\n  +{feat}:")
        s = _seeds(daily_ret, returns, vols, df, dates, n, label=f'+{feat}',
                   feature_cols=feats, **kw)
        if s: confirmed[feat] = s
    results['confirmed'] = confirmed

    # A5: Incremental additions (top 1, 2, 3)
    winners = sorted(confirmed.items(), key=lambda x: x[1]['sortinos_mean'], reverse=True)
    P(f"\n  === A5: Incremental additions ===")
    for n_add in [1, 2, 3]:
        if n_add > len(winners): break
        add = [w[0] for w in winners[:n_add]]
        feats = base_clean + add
        P(f"\n  base + {add}:")
        s = _seeds(daily_ret, returns, vols, df, dates, n, label=f'base+{n_add}',
                   feature_cols=feats, **kw)
        if s: results[f'base+{n_add}'] = s

    return results, base_clean, winners


# ============================================================
# TRACK B: ALLOCATION & K RE-SWEEP (~2h)
# ============================================================

def track_b(daily_ret, returns, vols, df, dates, n, best_feats):
    P(f"\n{'#'*100}")
    P("TRACK B: ALLOCATION & K RE-SWEEP")
    P("#" * 100)

    results = {}
    kw = dict(feature_cols=best_feats, n_bags_lgb=15, n_bags_xgb=30,
              lgb_params={'min_data_in_leaf': 12},
              retrain_freq='semi', rebal_day=4, rebal_threshold=0.0)

    # B1: K sweep
    for K in [20, 22, 25, 27, 30, 33, 35]:
        P(f"\n  --- K={K} ---")
        s = _seeds(daily_ret, returns, vols, df, dates, n, label=f'K={K}',
                   alloc_formula='linear_direct', alloc_params={'K': K}, **kw)
        if s: results[f'K={K}'] = s

    # B2: Alternative formulas
    for label, formula, params in [('sigmoid_K30', 'sigmoid', {'K': 30}),
                                    ('sigmoid_K40', 'sigmoid', {'K': 40}),
                                    ('sigmoid_K50', 'sigmoid', {'K': 50}),
                                    ('conservative', 'conservative', {})]:
        P(f"\n  --- {label} ---")
        s = _seeds(daily_ret, returns, vols, df, dates, n, label=label,
                   alloc_formula=formula, alloc_params=params, **kw)
        if s: results[label] = s

    # B3: Conditional rebalance thresholds with best K
    best_K = 30
    best_s = 0
    for k, s in results.items():
        if k.startswith('K=') and s.get('sortinos_mean', 0) > best_s:
            best_s = s['sortinos_mean']
            best_K = int(k.split('=')[1])

    for thresh in [0.005, 0.01, 0.015, 0.02]:
        P(f"\n  --- K={best_K} thresh={thresh} ---")
        s = _seeds(daily_ret, returns, vols, df, dates, n, label=f'K{best_K}_t{thresh}',
                   alloc_formula='linear_direct', alloc_params={'K': best_K},
                   rebal_threshold=thresh,
                   feature_cols=best_feats, n_bags_lgb=15, n_bags_xgb=30,
                   lgb_params={'min_data_in_leaf': 12},
                   retrain_freq='semi', rebal_day=4)
        if s: results[f'K{best_K}_t{thresh}'] = s

    return results, best_K


# ============================================================
# TRACK C: MODEL ARCHITECTURE (~2.5h)
# ============================================================

def track_c(daily_ret, returns, vols, df, dates, n, best_feats, best_K):
    P(f"\n{'#'*100}")
    P(f"TRACK C: MODEL ARCHITECTURE (K={best_K})")
    P("#" * 100)

    results = {}
    kw = dict(feature_cols=best_feats, lgb_params={'min_data_in_leaf': 12},
              alloc_formula='linear_direct', alloc_params={'K': best_K},
              retrain_freq='semi', rebal_day=4, rebal_threshold=0.0)

    # C1: Hybrid ratios
    for label, nl, nx in [('15+30', 15, 30), ('15+40', 15, 40), ('15+50', 15, 50),
                           ('20+30', 20, 30), ('20+40', 20, 40),
                           ('10+40', 10, 40), ('10+50', 10, 50)]:
        P(f"\n  --- Hybrid {label} ---")
        s = _seeds(daily_ret, returns, vols, df, dates, n, label=f'h_{label}',
                   n_bags_lgb=nl, n_bags_xgb=nx, **kw)
        if s: results[f'h_{label}'] = s

    # C2: Pure XGB
    for nb in [30, 45, 60]:
        P(f"\n  --- Pure XGB Bag{nb} ---")
        s = _seeds(daily_ret, returns, vols, df, dates, n, label=f'xgb_{nb}',
                   n_bags_lgb=0, n_bags_xgb=nb, **kw)
        if s: results[f'xgb_{nb}'] = s

    # C3: Pure LGB
    for nb in [30, 45, 60]:
        P(f"\n  --- Pure LGB Bag{nb} ---")
        s = _seeds(daily_ret, returns, vols, df, dates, n, label=f'lgb_{nb}',
                   n_bags_lgb=nb, n_bags_xgb=0, **kw)
        if s: results[f'lgb_{nb}'] = s

    return results


# ============================================================
# TRACK D: RISK MANAGEMENT (~1.5h)
# ============================================================

def track_d(daily_ret, returns, vols, df, dates, n, best_feats, best_K, best_ratio):
    P(f"\n{'#'*100}")
    P(f"TRACK D: RISK MANAGEMENT (K={best_K}, {best_ratio[0]}+{best_ratio[1]})")
    P("#" * 100)

    nl, nx = best_ratio
    results = {}
    kw = dict(feature_cols=best_feats, n_bags_lgb=nl, n_bags_xgb=nx,
              alloc_formula='linear_direct', alloc_params={'K': best_K},
              retrain_freq='semi', rebal_day=4, rebal_threshold=0.0)

    # D1: Adaptive K
    for high_K, low_K in [(best_K-5, best_K+5), (best_K-8, best_K+3), (best_K-10, best_K)]:
        label = f'adaptive_{high_K}_{best_K}_{low_K}'
        P(f"\n  --- {label} ---")
        s = _seeds(daily_ret, returns, vols, df, dates, n, label=label,
                   adaptive_K={'high_vol_K': high_K, 'mid_vol_K': best_K, 'low_vol_K': low_K},
                   lgb_params={'min_data_in_leaf': 12}, **kw)
        if s: results[label] = s

    # D2: Regularization (min_data_in_leaf)
    for mdl in [8, 12, 20, 30, 50]:
        P(f"\n  --- min_data_in_leaf={mdl} ---")
        s = _seeds(daily_ret, returns, vols, df, dates, n, label=f'mdl={mdl}',
                   lgb_params={'min_data_in_leaf': mdl},
                   feature_cols=best_feats, n_bags_lgb=nl, n_bags_xgb=nx,
                   alloc_formula='linear_direct', alloc_params={'K': best_K},
                   retrain_freq='semi', rebal_day=4, rebal_threshold=0.0)
        if s: results[f'mdl={mdl}'] = s

    return results


# ============================================================
# TRACK E: TRAINING STRATEGY (~1.5h)
# ============================================================

def track_e(daily_ret, returns, vols, df, dates, n, best_feats, best_K, best_ratio, best_mdl):
    P(f"\n{'#'*100}")
    P(f"TRACK E: TRAINING STRATEGY (K={best_K})")
    P("#" * 100)

    nl, nx = best_ratio
    results = {}
    kw = dict(feature_cols=best_feats, n_bags_lgb=nl, n_bags_xgb=nx,
              lgb_params={'min_data_in_leaf': best_mdl},
              alloc_formula='linear_direct', alloc_params={'K': best_K},
              rebal_day=4, rebal_threshold=0.0)

    # E1: Retrain frequency
    for freq in ['annual', 'semi', 'quarterly']:
        P(f"\n  --- retrain={freq} ---")
        s = _seeds(daily_ret, returns, vols, df, dates, n, label=freq,
                   retrain_freq=freq, **kw)
        if s: results[f'retrain_{freq}'] = s

    # E2: Sample weighting
    for hl in [None, 365.0, 730.0]:
        label = f'weight_{hl}' if hl else 'weight_none'
        P(f"\n  --- {label} ---")
        s = _seeds(daily_ret, returns, vols, df, dates, n, label=label,
                   retrain_freq='semi', sample_weight_halflife=hl, **kw)
        if s: results[label] = s

    # E3: Rolling window
    for window in [None, 1460]:
        label = f'window_{window}' if window else 'expanding'
        P(f"\n  --- {label} ---")
        s = _seeds(daily_ret, returns, vols, df, dates, n, label=label,
                   retrain_freq='semi', rolling_window_days=window, **kw)
        if s: results[label] = s

    return results


# ============================================================
# TRACK F: FINAL ASSEMBLY (~0.5h)
# ============================================================

def track_f(daily_ret, returns, vols, df, dates, n, d):
    P(f"\n{'#'*100}")
    P("TRACK F: FINAL ASSEMBLY")
    P("#" * 100)
    P(f"  Config: K={d['K']}, {d['n_lgb']}+{d['n_xgb']}, mdl={d['mdl']}, "
      f"retrain={d['retrain']}, feats={d['n_features']}")

    results = {}
    kw = dict(feature_cols=d['features'], n_bags_lgb=d['n_lgb'], n_bags_xgb=d['n_xgb'],
              lgb_params={'min_data_in_leaf': d['mdl']},
              alloc_formula='linear_direct', alloc_params={'K': d['K']},
              retrain_freq=d['retrain'], rebal_day=4,
              sample_weight_halflife=d.get('weight'),
              rolling_window_days=d.get('window'))

    # F1: Conservative (always rebal)
    P(f"\n  --- F1: Conservative (always rebal) ---")
    s = _seeds(daily_ret, returns, vols, df, dates, n, label='FINAL_conservative',
               rebal_threshold=0.0, **kw)
    if s: results['final_conservative'] = s

    # F2: Aggressive (conditional rebal)
    P(f"\n  --- F2: Aggressive (thresh=0.01) ---")
    s = _seeds(daily_ret, returns, vols, df, dates, n, label='FINAL_aggressive',
               rebal_threshold=0.01, **kw)
    if s: results['final_aggressive'] = s

    # F3: Mid (thresh=0.005)
    P(f"\n  --- F3: Mid (thresh=0.005) ---")
    s = _seeds(daily_ret, returns, vols, df, dates, n, label='FINAL_mid',
               rebal_threshold=0.005, **kw)
    if s: results['final_mid'] = s

    return results


# ============================================================
# MAIN
# ============================================================

def main():
    P("=" * 100)
    P("PIPELINE V14 — RE-OPTIMIZATION ON UPDATED DATA (Mar 2026)")
    P("=" * 100)
    start = datetime.now()
    P(f"  Start: {start.strftime('%Y-%m-%d %H:%M:%S')}")

    P("\nLoading data...")
    prices, daily_ret, returns, vols, df = load_data()
    dates = df['date'].values
    n = len(prices)
    P(f"  {n} days | {dates[0]} to {dates[-1]}")

    global RF_DAILY_ARR
    import scripts.optimization.pipeline_v9 as v9m
    import scripts.optimization.pipeline_v10_mega as v10m
    import scripts.optimization.pipeline_v11_xgb as v11m
    import scripts.optimization.pipeline_v12_hybrid as v12m
    import scripts.optimization.pipeline_v13_definitive as v13m
    try:
        from src.features.macro.cdi_rates import build_rf_daily
        RF_DAILY_ARR = build_rf_daily(dates, source='auto')
    except Exception:
        from src.features.macro.cdi_rates import build_rf_daily
        RF_DAILY_ARR = build_rf_daily(dates, source='copom')
    v9m.RF_DAILY_ARR = RF_DAILY_ARR
    v10m.RF_DAILY_ARR = RF_DAILY_ARR
    v11m.RF_DAILY_ARR = RF_DAILY_ARR
    v12m.RF_DAILY_ARR = RF_DAILY_ARR
    v13m.RF_DAILY_ARR = RF_DAILY_ARR
    P(f"  CDI loaded | {n} days")

    R = {'timestamp': start.isoformat(), 'method': 'pipeline_v14'}

    # ========================================
    # TRACK A: Feature Re-selection (~3h)
    # ========================================
    P(f"\n  Track A... ({datetime.now().strftime('%H:%M')})")
    ta, base_clean, winners = track_a(daily_ret, returns, vols, df, dates, n)
    R['track_a'] = ta
    _save(R)

    # Pick best features
    best_feats = list(base_clean)
    if winners:
        base_s = ta.get('clean_base', {}).get('sortinos_mean', 0)
        # Check if adding top feature improves
        top_feat, top_data = winners[0]
        if top_data['sortinos_mean'] > base_s:
            best_feats = base_clean + [top_feat]
        # Check +2
        if 'base+2' in ta and ta['base+2'].get('sortinos_mean', 0) > top_data['sortinos_mean']:
            best_feats = base_clean + [w[0] for w in winners[:2]]
    P(f"\n  DECISION features: {len(best_feats)} feats")
    R['decisions'] = {'features': best_feats, 'n_features': len(best_feats)}
    _save(R)

    # ========================================
    # TRACK B: Allocation & K (~2h)
    # ========================================
    P(f"\n  Track B... ({datetime.now().strftime('%H:%M')})")
    tb, best_K = track_b(daily_ret, returns, vols, df, dates, n, best_feats)
    R['track_b'] = tb
    R['decisions']['K'] = best_K
    _save(R)

    # ========================================
    # TRACK C: Model Architecture (~2.5h)
    # ========================================
    P(f"\n  Track C... ({datetime.now().strftime('%H:%M')})")
    tc = track_c(daily_ret, returns, vols, df, dates, n, best_feats, best_K)
    R['track_c'] = tc
    _save(R)

    # Find best model
    best_ratio = (15, 30)
    best_ratio_s = 0
    for k, s in tc.items():
        if s.get('sortinos_mean', 0) > best_ratio_s:
            best_ratio_s = s['sortinos_mean']
            if k.startswith('h_'):
                parts = k.replace('h_', '').split('+')
                best_ratio = (int(parts[0]), int(parts[1]))
            elif k.startswith('xgb_'):
                best_ratio = (0, int(k.split('_')[1]))
            elif k.startswith('lgb_'):
                best_ratio = (int(k.split('_')[1]), 0)
    P(f"\n  DECISION model: {best_ratio[0]}+{best_ratio[1]} (S={best_ratio_s:.2f})")
    R['decisions']['n_lgb'] = best_ratio[0]
    R['decisions']['n_xgb'] = best_ratio[1]
    _save(R)

    # ========================================
    # TRACK D: Risk Management (~1.5h)
    # ========================================
    P(f"\n  Track D... ({datetime.now().strftime('%H:%M')})")
    td = track_d(daily_ret, returns, vols, df, dates, n, best_feats, best_K, best_ratio)
    R['track_d'] = td
    _save(R)

    best_mdl = 12
    best_mdl_s = 0
    for k, s in td.items():
        if k.startswith('mdl=') and s.get('sortinos_mean', 0) > best_mdl_s:
            best_mdl_s = s['sortinos_mean']
            best_mdl = int(k.split('=')[1])
    R['decisions']['mdl'] = best_mdl

    # ========================================
    # TRACK E: Training Strategy (~1.5h)
    # ========================================
    P(f"\n  Track E... ({datetime.now().strftime('%H:%M')})")
    te = track_e(daily_ret, returns, vols, df, dates, n, best_feats, best_K, best_ratio, best_mdl)
    R['track_e'] = te
    _save(R)

    best_retrain = 'semi'
    best_retrain_s = 0
    for k, s in te.items():
        if k.startswith('retrain_') and s.get('sortinos_mean', 0) > best_retrain_s:
            best_retrain_s = s['sortinos_mean']
            best_retrain = k.replace('retrain_', '')
    R['decisions']['retrain'] = best_retrain

    best_weight = None
    best_w_s = 0
    for k, s in te.items():
        if k.startswith('weight_') and s.get('sortinos_mean', 0) > best_w_s:
            best_w_s = s['sortinos_mean']
            w = k.replace('weight_', '')
            best_weight = float(w) if w not in ('None', 'none') else None
    R['decisions']['weight'] = best_weight

    best_window = None
    best_win_s = 0
    for k, s in te.items():
        if ('window_' in k or k == 'expanding') and s.get('sortinos_mean', 0) > best_win_s:
            best_win_s = s['sortinos_mean']
            best_window = None if k == 'expanding' else int(k.split('_')[1])
    R['decisions']['window'] = best_window
    _save(R)

    # ========================================
    # TRACK F: Final Assembly (~0.5h)
    # ========================================
    P(f"\n  Track F... ({datetime.now().strftime('%H:%M')})")
    tf = track_f(daily_ret, returns, vols, df, dates, n, R['decisions'])
    R['track_f'] = tf
    _save(R)

    # ========================================
    # FINAL SUMMARY
    # ========================================
    elapsed = (datetime.now() - start).total_seconds() / 3600
    R['elapsed_hours'] = float(elapsed)

    P(f"\n\n{'='*100}")
    P("V14 RE-OPTIMIZATION SUMMARY")
    P("=" * 100)
    P(f"  Elapsed: {elapsed:.1f}h")
    P(f"\n  DECISIONS:")
    for k, v in R['decisions'].items():
        if k == 'features':
            P(f"    {k}: {len(v)} features")
        else:
            P(f"    {k}: {v}")

    # Full ranking
    all_v = []
    for track in ['track_a', 'track_b', 'track_c', 'track_d', 'track_e', 'track_f']:
        data = R.get(track, {})
        t_letter = track[-1].upper()
        for k, s in data.items():
            if isinstance(s, dict) and 'sortinos_mean' in s:
                all_v.append((f'[{t_letter}] {k}', s['mean'], s['spread'],
                              s['sortinos_mean'], s['max_dds_mean']))

    all_v.sort(key=lambda x: x[3], reverse=True)
    P(f"\n  {'Rk':<4} {'Config':<55} {'Mean':>8} {'Spread':>8} {'Sortino':>8} {'MaxDD':>8}")
    P(f"  {'-'*95}")
    for i, (name, mean, spread, sortino, mdd) in enumerate(all_v[:30], 1):
        P(f"  {i:<4} {name:<55} {mean:>+7.1f}% {spread:>7.0f}pp {sortino:>7.2f} {mdd:>7.1f}%")

    _save(R)
    P(f"\n{'='*100}")
    P(f"V14 COMPLETE | {elapsed:.1f}h | {RESULTS_PATH}")
    P("=" * 100)


if __name__ == '__main__':
    main()
