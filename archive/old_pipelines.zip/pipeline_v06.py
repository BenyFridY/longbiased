"""
PIPELINE V6 COMPREHENSIVE - Feature Optimization + Stability Improvements
==========================================================================

V5 proved ML weight is the biggest lever (monotonic: more ML = more return).
Current best: B7 Pure ML + ret_3d at +289% mean (10 seeds) but 89pp spread.

Critical finding from feature_ranking.csv: 4 of the current 25 features rank
very poorly (positions 95-259) while 5 unused features rank in top 15.

V6 tests:
  Part A: Feature Optimization (~30 tests)
    A1: SHAP Importance on B7 model
    A2: Individual swap tests (4 weak x 5 strong = 20 tests)
    A3: Best combo tests (up to 10, conditional on A2)

  Part B: V6 Tier 1 Ideas (~40 tests)
    B1: Larger bags for stability (Bag10/20/30 x 10 seeds)
    B2: Weighted ensemble of allocations (8 schemes)
    B3: Wider short range (6 tests)
    B4: Regime-conditional ML weight (4 tests)

  Part C: Combine Best + Full Robustness (conditional)
    C1: Best Features x Best V6 Idea
    C2: 10-seed stability
    C3: Bootstrap 95% CI
    C4: Cost sensitivity
    C5: Year-by-year breakdown

All walk-forward OOS (2022-2026), no look-ahead.
"""

import sys
import pandas as pd
import numpy as np
from pathlib import Path
import warnings
import json
from datetime import datetime
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import lightgbm as lgb

warnings.filterwarnings('ignore')
sys.stdout.reconfigure(line_buffering=True)

ROOT = Path(__file__).parent.parent.parent
COST = 0.0002       # 2 bps
RF_ANNUAL = 0.15
RF_DAILY = (1 + RF_ANNUAL)**(1/365) - 1

P = lambda *a, **kw: print(*a, **kw, flush=True)


# ============================================================
# SECTION 1: CONSTANTS & DATA LOADING
# ============================================================

DEFAULT_FEATURE_COLS = [
    'cusum_pos', 'miners_revenue_ratio', 'mr_score_30d', 'adx',
    'cusum_neg', 'exchange_netflow_ma7', 'structural_break_score',
    'macd_histogram', 'eth_btc_ratio', 'm2_yoy_growth',
    'volatility_7d', 'basis_ma7', 'nupl_ma30', 'hurst_60d',
    'funding_rate', 'bb_position', 'rsi_14d', 'puell_multiple',
    'stablecoin_zscore', 'sopr_ma7',
]

# Weak features (current 25, low rank)
WEAK_FEATURES = ['funding_rate', 'puell_multiple', 'sopr_ma7', 'rsi_14d']

# Strong unused features (top 15 in ranking)
STRONG_FEATURES = ['sharpe_3y_artemis', 'eth', 'acceleration',
                   'active_developers', 'momentum_accel_7d']


def load_data():
    df = pd.read_csv(ROOT / 'outputs/feature_selection/dataset_enhanced.csv')
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)

    prices = df['price_usd'].values
    n = len(prices)

    daily_ret = np.zeros(n)
    for i in range(1, n):
        daily_ret[i] = (prices[i] - prices[i-1]) / prices[i-1]

    returns = {}
    for w in [1, 3, 5, 7, 10, 14, 20, 21, 30, 45, 60]:
        r = np.zeros(n)
        for i in range(w, n):
            r[i] = (prices[i] - prices[i-w]) / prices[i-w]
        returns[w] = r

    vols = {}
    for w in [5, 7, 10, 14, 21, 30]:
        vols[w] = pd.Series(daily_ret).rolling(w).std().fillna(0.02).values

    return prices, daily_ret, returns, vols, df


# ============================================================
# SECTION 2: CORE ENGINE
# ============================================================

def backtest_allocations(daily_ret, allocations, start_idx, end_idx,
                         cost=COST, rf_daily=RF_DAILY,
                         clip_min=-0.25, clip_max=1.0):
    strat, btc, allocs = [], [], []
    prev = 0.5
    n = len(daily_ret)
    for t in range(start_idx, min(end_idx, n - 1)):
        a = np.clip(allocations[t], clip_min, clip_max)
        br = daily_ret[t + 1]
        tc = abs(a - prev) * cost * (1.5 if a < 0 else 1.0)
        sr = a * br + (1 - abs(a)) * rf_daily - tc
        strat.append(sr)
        btc.append(br)
        allocs.append(a)
        prev = a
    return np.array(strat), np.array(btc), np.array(allocs)


def metrics(s, b, a, rf_daily=RF_DAILY):
    if len(s) < 10:
        return None
    ts = np.prod(1 + s) - 1
    tb = np.prod(1 + b) - 1
    ex = s - rf_daily
    ds = ex[ex < 0]
    sortino = np.mean(ex) / (np.std(ds) + 1e-10) * np.sqrt(365) if len(ds) > 0 else 0
    cum = np.cumprod(1 + s)
    pk = np.maximum.accumulate(cum)
    dd = np.min((cum - pk) / (pk + 1e-10))
    return {'total': ts, 'btc': tb, 'excess': ts - tb, 'sortino': sortino,
            'max_dd': dd, 'short_pct': float((a < 0).mean()), 'avg_alloc': float(np.mean(a))}


def metrics_by_year(daily_ret, full_allocs, dates, n, cost=COST, rf_daily=RF_DAILY,
                    clip_min=-0.25, clip_max=1.0):
    yb = get_year_boundaries(dates, n)
    year_metrics = {}
    for yr in range(2022, 2027):
        if yr not in yb:
            continue
        s, b, a = backtest_allocations(daily_ret, full_allocs,
                                       yb[yr]['start'], yb[yr]['end'],
                                       cost=cost, rf_daily=rf_daily,
                                       clip_min=clip_min, clip_max=clip_max)
        m = metrics(s, b, a, rf_daily=rf_daily)
        if m:
            year_metrics[yr] = m
    return year_metrics


def get_year_boundaries(dates, n):
    yb = {}
    for i in range(n):
        yr = pd.Timestamp(dates[i]).year
        if yr not in yb:
            yb[yr] = {'start': i, 'end': i}
        yb[yr]['end'] = i
    return yb


def bootstrap_ci(daily_returns, n_bootstrap=1000, ci=0.95):
    n = len(daily_returns)
    if n < 30:
        return None
    rng = np.random.RandomState(42)
    total_returns = []
    for _ in range(n_bootstrap):
        idx = rng.choice(n, size=n, replace=True)
        resampled = daily_returns[idx]
        total = np.prod(1 + resampled) - 1
        total_returns.append(total)
    alpha = (1 - ci) / 2
    lo, hi = alpha * 100, (1 - alpha) * 100
    return {
        'return_mean': float(np.mean(total_returns)),
        'return_lo': float(np.percentile(total_returns, lo)),
        'return_hi': float(np.percentile(total_returns, hi)),
        'return_std': float(np.std(total_returns)),
        'excess_above_zero_pct': float(np.mean([r > 0 for r in total_returns]) * 100),
    }


# ============================================================
# SECTION 3: FEATURE BUILDING
# ============================================================

def build_ml_features(df, returns, vols, n, feature_cols=None):
    """Build features from column list. Always appends 5 price-derived features."""
    if feature_cols is None:
        feature_cols = DEFAULT_FEATURE_COLS

    price_derived_map = {
        'ret_3d': returns[3], 'ret_5d': returns[5], 'ret_7d': returns[7],
        'ret_10d': returns[10], 'ret_14d': returns[14], 'ret_30d': returns[30],
        'ret_45d': returns[45], 'ret_60d': returns[60],
        'vol_7d': vols[7], 'vol_14d': vols[14], 'vol_30d': vols[30],
    }

    cols, names = [], []
    for col in feature_cols:
        if col in price_derived_map:
            cols.append(price_derived_map[col])
            names.append(col)
        elif col in df.columns:
            cols.append(df[col].values.astype(float))
            names.append(col)

    # Always add base price-derived
    for pd_feat in ['ret_3d', 'ret_10d', 'ret_30d', 'ret_60d', 'vol_14d']:
        if pd_feat not in names:
            cols.append(price_derived_map[pd_feat])
            names.append(pd_feat)

    X_all = np.column_stack(cols) if cols else np.zeros((n, 0))
    return X_all, names


def build_ml_features_swap(df, returns, vols, n, swap_dict):
    """Build features with specific swaps applied.

    swap_dict: {weak_feature: strong_feature} — remove weak, add strong.
    Feature count stays at 25.
    """
    feature_cols = list(DEFAULT_FEATURE_COLS)
    for weak, strong in swap_dict.items():
        if weak in feature_cols:
            idx = feature_cols.index(weak)
            feature_cols[idx] = strong
    return build_ml_features(df, returns, vols, n, feature_cols=feature_cols)


# ============================================================
# SECTION 4: ML TRAINING
# ============================================================

def train_lgb_bagged(X_all, target, train_end, horizon_gap=5, n_bags=5, base_seed=42):
    models = []
    for i in range(n_bags):
        seed = base_seed + i * 7
        train_mask = np.arange(60, train_end - horizon_gap + 1)
        valid_train = ~np.any(np.isnan(X_all[train_mask]), axis=1)
        train_idx = train_mask[valid_train]
        if len(train_idx) < 100:
            continue
        X_train = np.nan_to_num(X_all[train_idx], nan=0.0)
        y_train = target[train_idx]
        params = {
            'objective': 'regression', 'metric': 'mae',
            'num_leaves': 31, 'learning_rate': 0.05,
            'feature_fraction': 0.7, 'bagging_fraction': 0.8,
            'bagging_freq': 5, 'verbose': -1, 'n_jobs': 1, 'seed': seed,
        }
        dtrain = lgb.Dataset(X_train, label=y_train)
        models.append(lgb.train(params, dtrain, num_boost_round=200))
    return models if len(models) > 0 else None


def ml_predict(models, X_all, t):
    x_t = np.nan_to_num(X_all[t:t+1].copy(), nan=0.0)
    preds = [m.predict(x_t)[0] for m in models]
    avg_pred = np.mean(preds)
    scaled = np.clip(avg_pred / 0.05, -1.0, 1.0)
    if scaled > 0:
        return 0.5 + scaled * 0.5
    else:
        return 0.5 + scaled * 0.75


# ============================================================
# SECTION 5: MOMENTUM STRATEGY
# ============================================================

def strategy_fn(slow_ret, fast_ret, vol, p):
    bear_s, bear_f, bull_s = p[0], p[1], p[2]
    a_min, a_max, a_mid = p[3], p[4], p[5]
    sl_bear, sl_bull = p[6], p[7]
    v_thresh, v_damp = p[8], p[9]

    if slow_ret < bear_s and fast_ret < bear_f:
        base = a_min
    elif slow_ret < bear_s * 0.5 and fast_ret < bear_f * 0.5:
        t = np.clip(slow_ret / (bear_s + 1e-10), 0, 2)
        base = a_mid + (a_min - a_mid) * min(t * sl_bear, 1.0)
    elif slow_ret < 0 and fast_ret < bear_f * 0.5:
        t = np.clip(slow_ret / (bear_s * 0.5 + 1e-10), 0, 1)
        base = a_mid * (1 - t * 0.5)
    elif slow_ret > bull_s:
        base = a_max
    elif slow_ret > 0:
        t = np.clip(slow_ret / (bull_s + 1e-10), 0, 1)
        base = a_mid + (a_max - a_mid) * (t ** (1.0 / max(sl_bull, 0.1)))
    else:
        base = a_mid

    if vol > v_thresh:
        excess = (vol - v_thresh) / (v_thresh + 1e-10)
        damp = min(v_damp * excess, 0.5)
        if base > 0:
            base *= (1 - damp)
        else:
            base *= (1 + damp * 0.5)

    return np.clip(base, -0.25, 1.0)


def optimize_params(daily_ret, slow_sig, fast_sig, vol_sig, start_idx, end_idx,
                    n_trials=2000, cost=COST, rf_daily=RF_DAILY, alloc_min_range=(-0.25, -0.05)):
    ranges = {
        'bear_slow': (-0.15, -0.04), 'bear_fast': (-0.06, -0.01),
        'bull': (0.05, 0.30), 'alloc_min': alloc_min_range,
        'alloc_max': (0.80, 1.0), 'alloc_mid': (0.25, 0.65),
        'slope_bear': (0.3, 2.5), 'slope_bull': (0.3, 2.5),
        'vol_thresh': (0.015, 0.05), 'vol_damp': (0.05, 0.55),
    }

    best_score, best_params = -999, None
    n = len(daily_ret)

    for _ in range(n_trials):
        p = [np.random.uniform(*ranges[k]) for k in
             ['bear_slow', 'bear_fast', 'bull', 'alloc_min', 'alloc_max',
              'alloc_mid', 'slope_bear', 'slope_bull', 'vol_thresh', 'vol_damp']]

        allocs = np.full(n, 0.5)
        for t in range(max(start_idx, 60), end_idx + 1):
            allocs[t] = strategy_fn(slow_sig[t], fast_sig[t], vol_sig[t], p)

        s, b, a = backtest_allocations(daily_ret, allocs, max(start_idx, 60), end_idx,
                                       cost=cost, rf_daily=rf_daily)
        m = metrics(s, b, a, rf_daily=rf_daily)
        if m is None:
            continue

        score = m['total'] * 2 + m['sortino'] * 0.3 + m['excess'] * 0.5 + m['max_dd'] * 0.3
        if score > best_score:
            best_score = score
            best_params = p[:]

    return best_params


# ============================================================
# SECTION 6: B7 PURE ML ENGINE
# ============================================================

def run_b7(daily_ret, returns, vols, df, dates, n,
           n_bags=5, use_weekly=True, target_horizon=3,
           X_all_override=None, feature_names_override=None,
           base_seed=42, vol_switch=False,
           clip_min=-0.25, clip_max=1.0,
           cost=COST, rf_daily=RF_DAILY,
           label="B7", verbose=True,
           return_allocs=False):
    """Run B7 Pure ML walk-forward.

    Returns: result dict (or (result, full_allocs, strat_rets) if return_allocs=True)
    """
    yb = get_year_boundaries(dates, n)
    prices = df['price_usd'].values

    if X_all_override is not None:
        X_all = X_all_override
    else:
        X_all, _ = build_ml_features(df, returns, vols, n)

    # Build target
    target = np.zeros(n)
    h = target_horizon
    for i in range(n - h):
        target[i] = (prices[i + h] - prices[i]) / prices[i]

    day_of_week = pd.to_datetime(dates).dayofweek

    all_strat, all_btc, all_alloc = [], [], []
    full_allocs = np.full(n, 0.5)

    for test_year in range(2022, 2027):
        if test_year not in yb:
            continue
        train_end = yb[test_year]['start'] - 1
        test_start = yb[test_year]['start']
        test_end = yb[test_year]['end']

        horizon_gap = max(target_horizon, 5)
        models = train_lgb_bagged(X_all, target, train_end,
                                  horizon_gap=horizon_gap, n_bags=n_bags,
                                  base_seed=base_seed)

        if verbose:
            P(f"    {test_year}: {len(models) if models else 0} models", end="")

        prev_alloc = 0.5
        for t in range(test_start, test_end + 1):
            if models is not None:
                a_ml = ml_predict(models, X_all, t)
            else:
                a_ml = 0.5

            # Vol switch
            if vol_switch:
                vol_now = vols[14][t] * np.sqrt(365)
                vol_60d = vols[30][t] * np.sqrt(365) if t > 30 else vol_now
                if vol_now > vol_60d * 1.3:
                    a_ml = a_ml * 0.85 + 0.5 * 0.15
                elif vol_now < vol_60d * 0.7:
                    a_ml = a_ml * 1.1

            raw_alloc = a_ml  # 100% ML

            # Rebalance logic
            if use_weekly and day_of_week[t] != 4:
                raw_alloc = prev_alloc

            full_allocs[t] = np.clip(raw_alloc, clip_min, clip_max)
            prev_alloc = full_allocs[t]

        s, b, a = backtest_allocations(daily_ret, full_allocs, test_start, test_end,
                                       cost=cost, rf_daily=rf_daily,
                                       clip_min=clip_min, clip_max=clip_max)
        all_strat.extend(s)
        all_btc.extend(b)
        all_alloc.extend(a)

        m_yr = metrics(np.array(s), np.array(b), np.array(a), rf_daily=rf_daily)
        if verbose and m_yr:
            P(f" -> {m_yr['total']*100:+.1f}%")
        elif verbose:
            P(" -> N/A")

    result = metrics(np.array(all_strat), np.array(all_btc), np.array(all_alloc),
                     rf_daily=rf_daily)

    if return_allocs:
        return result, full_allocs.copy(), np.array(all_strat)
    return result


# ============================================================
# SECTION 7: HYBRID ENGINE (ML + Momentum)
# ============================================================

def walk_forward_hybrid(daily_ret, returns, vols, df, dates, n,
                        ml_weight=0.5, n_bags=5, use_weekly=True,
                        target_horizon=5, base_seed=42,
                        X_all_override=None,
                        clip_min=-0.25, clip_max=1.0,
                        alloc_min_range=(-0.25, -0.05),
                        vol_switch=False,
                        cost=COST, rf_daily=RF_DAILY,
                        label="Hybrid", verbose=True,
                        return_allocs=False):
    """Walk-forward Hybrid with configurable ML weight and clip bounds."""
    yb = get_year_boundaries(dates, n)
    prices = df['price_usd'].values
    slow_sig, fast_sig, vol_sig = returns[60], returns[3], vols[14]

    if X_all_override is not None:
        X_all = X_all_override
    else:
        X_all, _ = build_ml_features(df, returns, vols, n)

    # Build target
    target = np.zeros(n)
    h = target_horizon
    for i in range(n - h):
        target[i] = (prices[i + h] - prices[i]) / prices[i]

    day_of_week = pd.to_datetime(dates).dayofweek

    all_strat, all_btc, all_alloc = [], [], []
    full_allocs = np.full(n, 0.5)

    for test_year in range(2022, 2027):
        if test_year not in yb:
            continue
        train_end = yb[test_year]['start'] - 1
        test_start = yb[test_year]['start']
        test_end = yb[test_year]['end']

        np.random.seed(42 + test_year)
        mom_params = optimize_params(daily_ret, slow_sig, fast_sig, vol_sig,
                                     60, train_end, 2000,
                                     cost=cost, rf_daily=rf_daily,
                                     alloc_min_range=alloc_min_range)
        if mom_params is None:
            continue

        horizon_gap = max(target_horizon, 5)
        models = train_lgb_bagged(X_all, target, train_end,
                                  horizon_gap=horizon_gap, n_bags=n_bags,
                                  base_seed=base_seed)

        if verbose:
            P(f"    {test_year}: {len(models) if models else 0} models", end="")

        prev_alloc = 0.5
        for t in range(test_start, test_end + 1):
            a_mom = strategy_fn(slow_sig[t], fast_sig[t], vol_sig[t], mom_params)

            if models is not None:
                a_ml = ml_predict(models, X_all, t)
            else:
                a_ml = a_mom

            # Vol switch
            ml_w = ml_weight
            if vol_switch:
                vol_now = vols[14][t] * np.sqrt(365)
                vol_60d = vols[30][t] * np.sqrt(365) if t > 30 else vol_now
                if vol_now > vol_60d * 1.3:
                    ml_w = max(ml_weight - 0.15, 0.2)
                elif vol_now < vol_60d * 0.7:
                    ml_w = min(ml_weight + 0.15, 0.95)

            raw_alloc = ml_w * a_ml + (1.0 - ml_w) * a_mom

            if use_weekly and day_of_week[t] != 4:
                raw_alloc = prev_alloc

            full_allocs[t] = np.clip(raw_alloc, clip_min, clip_max)
            prev_alloc = full_allocs[t]

        s, b, a = backtest_allocations(daily_ret, full_allocs, test_start, test_end,
                                       cost=cost, rf_daily=rf_daily,
                                       clip_min=clip_min, clip_max=clip_max)
        all_strat.extend(s)
        all_btc.extend(b)
        all_alloc.extend(a)

        m_yr = metrics(np.array(s), np.array(b), np.array(a), rf_daily=rf_daily)
        if verbose and m_yr:
            P(f" -> {m_yr['total']*100:+.1f}%")
        elif verbose:
            P(" -> N/A")

    result = metrics(np.array(all_strat), np.array(all_btc), np.array(all_alloc),
                     rf_daily=rf_daily)

    if return_allocs:
        return result, full_allocs.copy(), np.array(all_strat)
    return result


# ============================================================
# SECTION 8: PART A — FEATURE OPTIMIZATION
# ============================================================

def part_a1_shap(daily_ret, returns, vols, df, dates, n):
    """A1: SHAP importance on B7 model trained on 2019-2021, evaluated on 2022-2026."""
    P(f"\n{'='*100}")
    P("PART A1: SHAP IMPORTANCE ON B7 MODEL")
    P("=" * 100)

    try:
        import shap
    except ImportError:
        P("  WARNING: shap not installed. pip install shap. Falling back to LGB feature importance.")
        return part_a1_fallback(daily_ret, returns, vols, df, dates, n)

    prices = df['price_usd'].values
    X_all, feat_names = build_ml_features(df, returns, vols, n)

    # Build ret_3d target
    target = np.zeros(n)
    for i in range(n - 3):
        target[i] = (prices[i + 3] - prices[i]) / prices[i]

    # Train on 2019-2021 (all data before 2022)
    yb = get_year_boundaries(dates, n)
    train_end = yb[2022]['start'] - 1

    models = train_lgb_bagged(X_all, target, train_end, horizon_gap=5,
                              n_bags=5, base_seed=42)
    if not models:
        P("  ERROR: No models trained")
        return None

    # Get OOS data (2022-2026)
    test_start = yb[2022]['start']
    X_test = np.nan_to_num(X_all[test_start:], nan=0.0)

    # Compute SHAP on first model (representative)
    P("  Computing SHAP values (this may take a minute)...")
    explainer = shap.TreeExplainer(models[0])
    # Use subsample for speed
    sample_size = min(500, len(X_test))
    rng = np.random.RandomState(42)
    sample_idx = rng.choice(len(X_test), size=sample_size, replace=False)
    shap_values = explainer.shap_values(X_test[sample_idx])

    # Mean absolute SHAP
    mean_abs_shap = np.mean(np.abs(shap_values), axis=0)

    # Build ranking
    shap_ranking = sorted(zip(feat_names, mean_abs_shap),
                          key=lambda x: x[1], reverse=True)

    P(f"\n  SHAP Feature Ranking (B7 model, OOS 2022-2026):")
    P(f"  {'Rank':<6} {'Feature':<30} {'Mean|SHAP|':>12} {'In Weak4?':>10}")
    P(f"  {'-'*65}")
    for rank, (feat, shap_val) in enumerate(shap_ranking, 1):
        is_weak = '*WEAK*' if feat in WEAK_FEATURES else ''
        P(f"  {rank:<6} {feat:<30} {shap_val:>12.6f} {is_weak:>10}")

    # Load feature_ranking.csv for comparison
    try:
        rank_df = pd.read_csv(ROOT / 'outputs/feature_selection/feature_ranking.csv')
        ranking_map = dict(zip(rank_df['feature'], rank_df['rank']))
        P(f"\n  SHAP vs feature_ranking.csv correlation:")
        shap_ranks = list(range(1, len(shap_ranking) + 1))
        csv_ranks = [ranking_map.get(f, 999) for f, _ in shap_ranking]
        from scipy.stats import spearmanr
        corr, pval = spearmanr(shap_ranks, csv_ranks)
        P(f"    Spearman r = {corr:.3f}, p = {pval:.4f}")
    except Exception as e:
        P(f"  Could not compare with ranking CSV: {e}")

    # Identify bottom 4 by SHAP
    bottom4_shap = [f for f, _ in shap_ranking[-4:]] if len(shap_ranking) >= 4 else []
    P(f"\n  Bottom 4 by SHAP: {bottom4_shap}")
    P(f"  Bottom 4 by ranking CSV: {WEAK_FEATURES}")

    result = {
        'shap_ranking': [(f, float(v)) for f, v in shap_ranking],
        'bottom4_shap': bottom4_shap,
        'bottom4_csv': WEAK_FEATURES,
    }
    return result


def part_a1_fallback(daily_ret, returns, vols, df, dates, n):
    """Fallback: use LGB built-in feature importance instead of SHAP."""
    P("  Using LightGBM feature importance (split-based) as fallback...")

    prices = df['price_usd'].values
    X_all, feat_names = build_ml_features(df, returns, vols, n)

    target = np.zeros(n)
    for i in range(n - 3):
        target[i] = (prices[i + 3] - prices[i]) / prices[i]

    yb = get_year_boundaries(dates, n)
    train_end = yb[2022]['start'] - 1

    models = train_lgb_bagged(X_all, target, train_end, horizon_gap=5,
                              n_bags=5, base_seed=42)
    if not models:
        P("  ERROR: No models trained")
        return None

    # Average importance across bags
    importances = np.zeros(len(feat_names))
    for m in models:
        imp = m.feature_importance(importance_type='gain')
        importances += imp / len(models)

    ranking = sorted(zip(feat_names, importances), key=lambda x: x[1], reverse=True)

    P(f"\n  LGB Feature Importance Ranking (gain, averaged over {len(models)} bags):")
    P(f"  {'Rank':<6} {'Feature':<30} {'Importance':>12} {'In Weak4?':>10}")
    P(f"  {'-'*65}")
    for rank, (feat, imp) in enumerate(ranking, 1):
        is_weak = '*WEAK*' if feat in WEAK_FEATURES else ''
        P(f"  {rank:<6} {feat:<30} {imp:>12.2f} {is_weak:>10}")

    bottom4 = [f for f, _ in ranking[-4:]] if len(ranking) >= 4 else []
    P(f"\n  Bottom 4 by LGB importance: {bottom4}")

    return {
        'lgb_ranking': [(f, float(v)) for f, v in ranking],
        'bottom4_lgb': bottom4,
        'bottom4_csv': WEAK_FEATURES,
    }


def part_a2_swaps(daily_ret, returns, vols, df, dates, n, baseline_result):
    """A2: Individual swap tests (4 weak x 5 strong = 20 tests)."""
    P(f"\n{'='*100}")
    P("PART A2: INDIVIDUAL FEATURE SWAP TESTS (20 tests)")
    P("=" * 100)
    P(f"  Baseline B7 ret_3d: {baseline_result['total']*100:+.1f}%")
    P(f"  Weak features to remove: {WEAK_FEATURES}")
    P(f"  Strong features to add: {STRONG_FEATURES}")
    P(f"  Config: B7 100/0 + ret_3d + Bag5 + Weekly\n")

    results = {}
    for weak in WEAK_FEATURES:
        for strong in STRONG_FEATURES:
            swap = {weak: strong}
            label = f"swap_{weak}_with_{strong}"
            P(f"  {label}...", end="")

            X_swap, names_swap = build_ml_features_swap(df, returns, vols, n, swap)
            r = run_b7(daily_ret, returns, vols, df, dates, n,
                       n_bags=5, use_weekly=True, target_horizon=3,
                       X_all_override=X_swap, base_seed=42,
                       label=label, verbose=False)

            if r:
                delta = (r['total'] - baseline_result['total']) * 100
                verdict = 'BETTER' if delta > 5 else ('similar' if delta > -5 else 'worse')
                P(f" {r['total']*100:+.1f}% ({delta:+.1f}pp) [{verdict}]")
                results[label] = {
                    'weak': weak, 'strong': strong,
                    'result': r, 'delta_pp': float(delta),
                    'n_features': len(names_swap),
                }
            else:
                P(" FAILED")

    # Summary
    P(f"\n  SWAP RESULTS SUMMARY:")
    P(f"  {'Swap':<45} {'Return':>10} {'Delta':>8} {'Verdict':>10}")
    P(f"  {'-'*80}")
    sorted_swaps = sorted(results.items(), key=lambda x: x[1]['delta_pp'], reverse=True)
    for name, info in sorted_swaps:
        r = info['result']
        delta = info['delta_pp']
        verdict = 'BETTER' if delta > 5 else ('similar' if delta > -5 else 'worse')
        P(f"  {name:<45} {r['total']*100:>+9.1f}% {delta:>+7.1f}pp {verdict:>10}")

    winners = [(k, v) for k, v in sorted_swaps if v['delta_pp'] > 5]
    P(f"\n  Winners (>+5pp): {len(winners)}/{len(results)}")
    for name, info in winners:
        P(f"    {name}: {info['delta_pp']:+.1f}pp")

    return results


def part_a3_combos(daily_ret, returns, vols, df, dates, n,
                   swap_results, baseline_result):
    """A3: Multi-swap combo tests. Only runs if A2 found improvements."""
    P(f"\n{'='*100}")
    P("PART A3: MULTI-SWAP COMBO TESTS")
    P("=" * 100)

    # Find best individual swaps
    winning_swaps = sorted(
        [(k, v) for k, v in swap_results.items() if v['delta_pp'] > 0],
        key=lambda x: x[1]['delta_pp'], reverse=True
    )

    if not winning_swaps:
        P("  No winning swaps from A2 — skipping combos.")
        return {}

    # Group by weak feature — pick best strong replacement for each weak
    best_per_weak = {}
    for name, info in winning_swaps:
        weak = info['weak']
        if weak not in best_per_weak or info['delta_pp'] > best_per_weak[weak]['delta_pp']:
            best_per_weak[weak] = info

    P(f"  Best swap per weak feature:")
    for weak, info in best_per_weak.items():
        P(f"    {weak} -> {info['strong']}: {info['delta_pp']:+.1f}pp")

    # Build combos
    combos = []
    best_list = sorted(best_per_weak.items(), key=lambda x: x[1]['delta_pp'], reverse=True)

    # Top 2 combo
    if len(best_list) >= 2:
        swap_dict = {bl[0]: bl[1]['strong'] for bl in best_list[:2]}
        combos.append(('top2_combo', swap_dict))

    # Top 3 combo
    if len(best_list) >= 3:
        swap_dict = {bl[0]: bl[1]['strong'] for bl in best_list[:3]}
        combos.append(('top3_combo', swap_dict))

    # All 4 combo
    if len(best_list) >= 4:
        swap_dict = {bl[0]: bl[1]['strong'] for bl in best_list[:4]}
        combos.append(('all4_combo', swap_dict))

    # Conservative: bottom 2 weak only
    if len(best_list) >= 2:
        bottom2 = best_list[-2:]
        swap_dict = {bl[0]: bl[1]['strong'] for bl in bottom2}
        combos.append(('conservative_bottom2', swap_dict))

    results = {}
    for combo_name, swap_dict in combos:
        P(f"\n  {combo_name}: {swap_dict}")

        # Test at B7 (100/0)
        X_swap, names_swap = build_ml_features_swap(df, returns, vols, n, swap_dict)
        P(f"    B7 (100/0)...", end="")
        r_b7 = run_b7(daily_ret, returns, vols, df, dates, n,
                       n_bags=5, use_weekly=True, target_horizon=3,
                       X_all_override=X_swap, base_seed=42,
                       verbose=False)
        if r_b7:
            delta = (r_b7['total'] - baseline_result['total']) * 100
            P(f" {r_b7['total']*100:+.1f}% ({delta:+.1f}pp)")
        else:
            P(" FAILED")
            r_b7 = None

        # Test at B4 (60/40)
        P(f"    B4 (60/40)...", end="")
        r_b4 = walk_forward_hybrid(daily_ret, returns, vols, df, dates, n,
                                   ml_weight=0.6, n_bags=5, use_weekly=True,
                                   target_horizon=3, X_all_override=X_swap,
                                   base_seed=42, verbose=False)
        if r_b4:
            P(f" {r_b4['total']*100:+.1f}%")
        else:
            P(" FAILED")
            r_b4 = None

        results[combo_name] = {
            'swap_dict': {k: v for k, v in swap_dict.items()},
            'b7_result': r_b7,
            'b4_result': r_b4,
            'n_features': len(names_swap),
        }

    return results


# ============================================================
# SECTION 9: PART B — V6 TIER 1 IDEAS
# ============================================================

def part_b1_bags(daily_ret, returns, vols, df, dates, n, baseline_result):
    """B1: Larger bags for stability (10 seeds each at Bag10/20/30)."""
    P(f"\n{'='*100}")
    P("PART B1: LARGER BAGS FOR STABILITY")
    P("=" * 100)
    P(f"  Baseline B7 ret_3d Bag5 mean: {baseline_result['total']*100:+.1f}%")
    P(f"  Goal: Reduce spread to <50pp while keeping mean >+280%\n")

    results = {}

    for n_bags_val in [10, 20, 30]:
        P(f"  --- B7 + Bag{n_bags_val} (10 seeds) ---")
        seed_results = []
        for trial in range(10):
            base_seed = 42 + trial * 100
            P(f"    Seed {trial} (base={base_seed})...", end="")
            r = run_b7(daily_ret, returns, vols, df, dates, n,
                       n_bags=n_bags_val, use_weekly=True, target_horizon=3,
                       base_seed=base_seed, verbose=False)
            if r:
                seed_results.append(r)
                P(f" {r['total']*100:+.1f}%")
            else:
                P(" FAILED")

        if seed_results:
            pcts = [r['total'] * 100 for r in seed_results]
            spread = max(pcts) - min(pcts)
            mean_ret = np.mean(pcts)
            verdict = 'STABLE' if spread < 30 else ('MODERATE' if spread < 60 else 'UNSTABLE')
            P(f"    Bag{n_bags_val}: mean={mean_ret:+.1f}%, spread={spread:.0f}pp -> {verdict}")

            results[f'Bag{n_bags_val}'] = {
                'n_bags': n_bags_val,
                'returns': [float(p) for p in pcts],
                'mean': float(mean_ret),
                'spread': float(spread),
                'verdict': verdict,
                'sortinos': [float(r['sortino']) for r in seed_results],
                'max_dds': [float(r['max_dd'] * 100) for r in seed_results],
            }

    return results


def part_b2_ensemble(daily_ret, returns, vols, df, dates, n):
    """B2: Weighted ensemble of allocations from B4/B5/B6/B7."""
    P(f"\n{'='*100}")
    P("PART B2: WEIGHTED ENSEMBLE OF ALLOCATIONS")
    P("=" * 100)
    P("  Running B4, B5, B6, B7 to get allocation arrays...\n")

    # Get allocation arrays from each ML weight config
    configs = [
        ('B4_60', 0.6),
        ('B5_70', 0.7),
        ('B6_80', 0.8),
        ('B7_100', 1.0),
    ]

    alloc_arrays = {}
    config_results = {}
    for name, ml_w in configs:
        P(f"  Running {name} (ml_weight={ml_w})...")
        if ml_w >= 1.0:
            r, allocs, strat = run_b7(daily_ret, returns, vols, df, dates, n,
                                      n_bags=5, use_weekly=True, target_horizon=3,
                                      base_seed=42, verbose=False, return_allocs=True)
        else:
            r, allocs, strat = walk_forward_hybrid(
                daily_ret, returns, vols, df, dates, n,
                ml_weight=ml_w, n_bags=5, use_weekly=True, target_horizon=3,
                base_seed=42, verbose=False, return_allocs=True)
        alloc_arrays[name] = allocs
        config_results[name] = r
        if r:
            P(f"    {name}: {r['total']*100:+.1f}%")

    # Weight schemes
    weight_schemes = {
        'equal': {'B4_60': 0.25, 'B5_70': 0.25, 'B6_80': 0.25, 'B7_100': 0.25},
        'favor_B7': {'B4_60': 0.10, 'B5_70': 0.10, 'B6_80': 0.20, 'B7_100': 0.60},
        'favor_B6': {'B4_60': 0.10, 'B5_70': 0.20, 'B6_80': 0.50, 'B7_100': 0.20},
        'B5_B6_only': {'B4_60': 0.00, 'B5_70': 0.50, 'B6_80': 0.50, 'B7_100': 0.00},
        'B4_B7_extremes': {'B4_60': 0.50, 'B5_70': 0.00, 'B6_80': 0.00, 'B7_100': 0.50},
    }

    # Inverse-variance weighting (from single-seed results)
    if all(config_results.get(k) for k in alloc_arrays):
        alloc_stds = {}
        for name, allocs in alloc_arrays.items():
            alloc_stds[name] = max(np.std(allocs[allocs != 0.5]), 0.01)
        inv_vars = {k: 1.0 / (v**2) for k, v in alloc_stds.items()}
        total_inv = sum(inv_vars.values())
        weight_schemes['inverse_variance'] = {k: v / total_inv for k, v in inv_vars.items()}

    # Sharpe-weighted
    if all(config_results.get(k) for k in alloc_arrays):
        sortinos = {k: max(config_results[k]['sortino'], 0.01) for k in alloc_arrays}
        total_s = sum(sortinos.values())
        weight_schemes['sharpe_weighted'] = {k: v / total_s for k, v in sortinos.items()}

    # Bootstrap-optimal: favor highest return configs
    if all(config_results.get(k) for k in alloc_arrays):
        returns_map = {k: max(config_results[k]['total'], 0.01) for k in alloc_arrays}
        total_r = sum(returns_map.values())
        weight_schemes['bootstrap_optimal'] = {k: v / total_r for k, v in returns_map.items()}

    P(f"\n  Testing {len(weight_schemes)} ensemble weight schemes...\n")
    yb = get_year_boundaries(dates, n)

    ensemble_results = {}
    for scheme_name, weights in weight_schemes.items():
        P(f"  {scheme_name}: {weights}")

        # Create blended allocation
        blended = np.full(n, 0.5)
        for name, w in weights.items():
            if name in alloc_arrays and w > 0:
                blended += w * (alloc_arrays[name] - 0.5)
        # blended now has 0.5 + weighted sum of deviations

        # Backtest the blended allocation
        all_s, all_b, all_a = [], [], []
        for yr in range(2022, 2027):
            if yr not in yb:
                continue
            s, b, a = backtest_allocations(daily_ret, blended,
                                           yb[yr]['start'], yb[yr]['end'])
            all_s.extend(s)
            all_b.extend(b)
            all_a.extend(a)

        r = metrics(np.array(all_s), np.array(all_b), np.array(all_a))
        if r:
            P(f"    -> {r['total']*100:+.1f}% | Sortino {r['sortino']:.2f} | MaxDD {r['max_dd']*100:.1f}%")
        ensemble_results[scheme_name] = {'weights': weights, 'result': r}

    return ensemble_results


def part_b3_shorts(daily_ret, returns, vols, df, dates, n, baseline_b7, baseline_v2):
    """B3: Wider short range tests."""
    P(f"\n{'='*100}")
    P("PART B3: WIDER SHORT RANGE")
    P("=" * 100)
    P(f"  Current clip: [-0.25, 1.0]")
    P(f"  Testing: [-0.50, 1.0], [-0.75, 1.0], [-1.0, 1.0]")
    P(f"  At both V2 (50/50) and B7 (100/0)\n")

    clip_tests = [
        (-0.50, 1.0),
        (-0.75, 1.0),
        (-1.0, 1.0),
    ]

    results = {}
    for clip_min, clip_max in clip_tests:
        # B7 (100/0)
        label = f"B7_clip[{clip_min},{clip_max}]"
        P(f"  {label}...", end="")
        r = run_b7(daily_ret, returns, vols, df, dates, n,
                   n_bags=5, use_weekly=True, target_horizon=3,
                   base_seed=42, clip_min=clip_min, clip_max=clip_max,
                   verbose=False)
        if r:
            P(f" {r['total']*100:+.1f}% (MaxDD {r['max_dd']*100:.1f}%)")
        else:
            P(" FAILED")
        results[label] = r

        # V2 (50/50) with wider alloc_min range for momentum too
        label_v2 = f"V2_clip[{clip_min},{clip_max}]"
        P(f"  {label_v2}...", end="")
        r_v2 = walk_forward_hybrid(
            daily_ret, returns, vols, df, dates, n,
            ml_weight=0.5, n_bags=5, use_weekly=True, target_horizon=5,
            base_seed=42, clip_min=clip_min, clip_max=clip_max,
            alloc_min_range=(clip_min, -0.05),
            verbose=False)
        if r_v2:
            P(f" {r_v2['total']*100:+.1f}% (MaxDD {r_v2['max_dd']*100:.1f}%)")
        else:
            P(" FAILED")
        results[label_v2] = r_v2

    return results


def part_b4_regime(daily_ret, returns, vols, df, dates, n, baseline_b7):
    """B4: Regime-conditional ML weight (switch between B4 and B7 by vol)."""
    P(f"\n{'='*100}")
    P("PART B4: REGIME-CONDITIONAL ML WEIGHT")
    P("=" * 100)
    P(f"  Dynamically switch between B4 (60/40) and B7 (100/0) based on volatility")
    P(f"  Indicators: vol ratio, hurst, kpss, cusum\n")

    yb = get_year_boundaries(dates, n)
    prices = df['price_usd'].values
    X_all, feat_names = build_ml_features(df, returns, vols, n)

    target_3d = np.zeros(n)
    for i in range(n - 3):
        target_3d[i] = (prices[i + 3] - prices[i]) / prices[i]

    slow_sig, fast_sig, vol_sig = returns[60], returns[3], vols[14]
    day_of_week = pd.to_datetime(dates).dayofweek

    # Regime indicators
    vol_14d_ann = vols[14] * np.sqrt(365)
    vol_60d_ann = vols[30] * np.sqrt(365)
    vol_ratio = np.where(vol_60d_ann > 0.01, vol_14d_ann / vol_60d_ann, 1.0)

    hurst_col = df['hurst_60d'].values if 'hurst_60d' in df.columns else np.full(n, 0.5)
    kpss_col = df['kpss_stat_30d'].values if 'kpss_stat_30d' in df.columns else np.full(n, 0.5)
    cusum_col = df['cusum_pos'].values if 'cusum_pos' in df.columns else np.full(n, 0.0)

    # Define regimes: 4 variants
    regime_tests = {
        'vol_ratio': lambda t: 1.0 if vol_ratio[t] > 1.2 else (0.6 if vol_ratio[t] < 0.8 else 0.8),
        'hurst': lambda t: 1.0 if hurst_col[t] > 0.55 else (0.6 if hurst_col[t] < 0.45 else 0.8),
        'kpss': lambda t: 0.6 if kpss_col[t] > 0.5 else 1.0,
        'combined': lambda t: (1.0 if (vol_ratio[t] < 0.9 and hurst_col[t] > 0.5) else
                               (0.6 if (vol_ratio[t] > 1.3 or hurst_col[t] < 0.4) else 0.8)),
    }

    results = {}
    for regime_name, ml_weight_fn in regime_tests.items():
        label = f"regime_{regime_name}"
        P(f"  {label}...", end="")

        all_strat, all_btc, all_alloc = [], [], []
        full_allocs = np.full(n, 0.5)

        for test_year in range(2022, 2027):
            if test_year not in yb:
                continue
            train_end = yb[test_year]['start'] - 1
            test_start = yb[test_year]['start']
            test_end = yb[test_year]['end']

            np.random.seed(42 + test_year)
            mom_params = optimize_params(daily_ret, slow_sig, fast_sig, vol_sig,
                                         60, train_end, 2000)
            if mom_params is None:
                continue

            models = train_lgb_bagged(X_all, target_3d, train_end,
                                      horizon_gap=5, n_bags=5, base_seed=42)

            prev_alloc = 0.5
            for t in range(test_start, test_end + 1):
                a_mom = strategy_fn(slow_sig[t], fast_sig[t], vol_sig[t], mom_params)

                if models is not None:
                    a_ml = ml_predict(models, X_all, t)
                else:
                    a_ml = a_mom

                ml_w = ml_weight_fn(t)
                raw_alloc = ml_w * a_ml + (1.0 - ml_w) * a_mom

                if day_of_week[t] != 4:
                    raw_alloc = prev_alloc

                full_allocs[t] = np.clip(raw_alloc, -0.25, 1.0)
                prev_alloc = full_allocs[t]

            s, b, a = backtest_allocations(daily_ret, full_allocs, test_start, test_end)
            all_strat.extend(s)
            all_btc.extend(b)
            all_alloc.extend(a)

        r = metrics(np.array(all_strat), np.array(all_btc), np.array(all_alloc))
        if r:
            P(f" {r['total']*100:+.1f}% | Sortino {r['sortino']:.2f} | MaxDD {r['max_dd']*100:.1f}%")
        else:
            P(" FAILED")
        results[label] = r

    return results


# ============================================================
# SECTION 10: PART C — COMBINE BEST + ROBUSTNESS
# ============================================================

def part_c_robustness(daily_ret, returns, vols, df, dates, n,
                      winner_config, winner_label, all_results):
    """Part C: Full robustness on best winner from A+B.

    winner_config: dict with keys to reconstruct the winner strategy.
    """
    P(f"\n{'='*100}")
    P(f"PART C: FULL ROBUSTNESS ON WINNER: {winner_label}")
    P("=" * 100)

    results = {}

    # C2: 10-seed stability
    P(f"\n  C2: 10-SEED STABILITY")
    P(f"  {'-'*60}")
    seed_results = []
    for trial in range(10):
        base_seed = 42 + trial * 100
        P(f"    Seed {trial} (base={base_seed})...", end="")
        r = _run_winner(daily_ret, returns, vols, df, dates, n,
                        winner_config, base_seed=base_seed, verbose=False)
        if r:
            seed_results.append(r)
            P(f" {r['total']*100:+.1f}%")
        else:
            P(" FAILED")

    if seed_results:
        pcts = [r['total'] * 100 for r in seed_results]
        spread = max(pcts) - min(pcts)
        mean_ret = np.mean(pcts)
        verdict = 'STABLE' if spread < 30 else ('MODERATE' if spread < 60 else 'UNSTABLE')
        P(f"    Mean: {mean_ret:+.1f}%, Spread: {spread:.0f}pp -> {verdict}")
        P(f"    Beat V2 (+219%): {sum(1 for p in pcts if p > 219)}/10")
        results['seed_stability'] = {
            'returns': [float(p) for p in pcts],
            'mean': float(mean_ret), 'spread': float(spread),
            'verdict': verdict,
        }

    # C3: Bootstrap 95% CI
    P(f"\n  C3: BOOTSTRAP 95% CI")
    P(f"  {'-'*60}")
    # Run winner once to get strat returns
    r_main, allocs_main, strat_rets = _run_winner(
        daily_ret, returns, vols, df, dates, n,
        winner_config, base_seed=42, verbose=False, return_allocs=True)
    if len(strat_rets) > 30:
        bs = bootstrap_ci(strat_rets, n_bootstrap=1000)
        P(f"    Return 95% CI: [{bs['return_lo']*100:+.0f}%, {bs['return_hi']*100:+.0f}%]")
        P(f"    P(return > 0): {bs['excess_above_zero_pct']:.1f}%")
        results['bootstrap'] = bs

    # C4: Cost sensitivity
    P(f"\n  C4: COST SENSITIVITY")
    P(f"  {'-'*60}")
    yb = get_year_boundaries(dates, n)
    cost_results = {}
    for cost_bps in [1, 2, 5, 10, 15, 20]:
        cost_val = cost_bps / 10000.0
        all_s, all_b, all_a = [], [], []
        for yr in range(2022, 2027):
            if yr not in yb:
                continue
            clip_min = winner_config.get('clip_min', -0.25)
            clip_max = winner_config.get('clip_max', 1.0)
            s, b, a = backtest_allocations(daily_ret, allocs_main,
                                           yb[yr]['start'], yb[yr]['end'],
                                           cost=cost_val,
                                           clip_min=clip_min, clip_max=clip_max)
            all_s.extend(s)
            all_b.extend(b)
            all_a.extend(a)
        r_cost = metrics(np.array(all_s), np.array(all_b), np.array(all_a))
        if r_cost:
            P(f"    {cost_bps:3d} bps: {r_cost['total']*100:+.1f}%")
            cost_results[f'{cost_bps}bps'] = r_cost
    results['cost_sensitivity'] = cost_results

    # C5: Year-by-year
    P(f"\n  C5: YEAR-BY-YEAR BREAKDOWN")
    P(f"  {'-'*60}")
    year_m = metrics_by_year(daily_ret, allocs_main, dates, n)
    for yr, m in sorted(year_m.items()):
        P(f"    {yr}: {m['total']*100:+.1f}% | BTC {m['btc']*100:+.1f}% | "
          f"Excess {m['excess']*100:+.1f}%")
    results['year_by_year'] = {str(yr): m for yr, m in year_m.items()}

    # Check positive excess in ≥3 of 5 years
    positive_excess_years = sum(1 for m in year_m.values() if m['excess'] > 0)
    P(f"    Positive excess in {positive_excess_years}/5 years")
    results['positive_excess_years'] = positive_excess_years

    return results


def _run_winner(daily_ret, returns, vols, df, dates, n,
                config, base_seed=42, verbose=False, return_allocs=False):
    """Run the winner config with given seed."""
    swap_dict = config.get('swap_dict', None)
    X_override = None
    if swap_dict:
        X_override, _ = build_ml_features_swap(df, returns, vols, n, swap_dict)

    ml_weight = config.get('ml_weight', 1.0)
    n_bags = config.get('n_bags', 5)
    target_horizon = config.get('target_horizon', 3)
    clip_min = config.get('clip_min', -0.25)
    clip_max = config.get('clip_max', 1.0)
    vol_switch = config.get('vol_switch', False)

    if ml_weight >= 1.0:
        return run_b7(daily_ret, returns, vols, df, dates, n,
                      n_bags=n_bags, use_weekly=True,
                      target_horizon=target_horizon,
                      X_all_override=X_override, base_seed=base_seed,
                      vol_switch=vol_switch,
                      clip_min=clip_min, clip_max=clip_max,
                      verbose=verbose, return_allocs=return_allocs)
    else:
        return walk_forward_hybrid(
            daily_ret, returns, vols, df, dates, n,
            ml_weight=ml_weight, n_bags=n_bags, use_weekly=True,
            target_horizon=target_horizon,
            X_all_override=X_override, base_seed=base_seed,
            vol_switch=vol_switch,
            clip_min=clip_min, clip_max=clip_max,
            verbose=verbose, return_allocs=return_allocs)


# ============================================================
# SECTION 11: CHARTS
# ============================================================

def generate_charts(all_results, part_a2_results, part_b1_results,
                    part_b2_results, chart_dir):
    chart_dir.mkdir(parents=True, exist_ok=True)

    # --- Chart 1: A2 Feature Swap Results ---
    if part_a2_results:
        fig, ax = plt.subplots(1, 1, figsize=(16, 8))
        names = []
        deltas = []
        colors = []
        for name, info in sorted(part_a2_results.items(),
                                  key=lambda x: x[1]['delta_pp'], reverse=True):
            short_name = name.replace('swap_', '').replace('_with_', ' -> ')
            names.append(short_name)
            deltas.append(info['delta_pp'])
            colors.append('#2ecc71' if info['delta_pp'] > 5 else
                         ('#f39c12' if info['delta_pp'] > -5 else '#e74c3c'))

        x = np.arange(len(names))
        ax.barh(x, deltas, color=colors, alpha=0.85, edgecolor='black', linewidth=0.5)
        ax.set_yticks(x)
        ax.set_yticklabels(names, fontsize=7)
        ax.axvline(x=0, color='black', lw=1)
        ax.axvline(x=5, color='green', lw=1, ls='--', label='+5pp threshold')
        ax.axvline(x=-5, color='red', lw=1, ls='--', label='-5pp threshold')
        ax.set_xlabel('Delta vs Baseline (pp)')
        ax.set_title('V6 Part A2: Feature Swap Results (vs B7 ret_3d Baseline)',
                     fontsize=13, fontweight='bold')
        ax.legend()
        ax.grid(True, alpha=0.3, axis='x')
        plt.tight_layout()
        plt.savefig(chart_dir / 'v6_feature_swaps.png', dpi=150, bbox_inches='tight')
        plt.close()
        P(f"  Chart saved: {chart_dir / 'v6_feature_swaps.png'}")

    # --- Chart 2: B1 Bag Stability ---
    if part_b1_results:
        fig, ax = plt.subplots(1, 1, figsize=(12, 6))
        bag_names = []
        means = []
        spreads = []
        all_pts = []
        for bag_label, info in sorted(part_b1_results.items()):
            bag_names.append(bag_label)
            means.append(info['mean'])
            spreads.append(info['spread'])
            all_pts.append(info['returns'])

        x = np.arange(len(bag_names))
        # Box-like: show mean + individual points
        for i, pts in enumerate(all_pts):
            ax.scatter([i] * len(pts), pts, alpha=0.5, s=40, zorder=3)
            ax.barh(i, means[i], height=0.3, alpha=0.3, color='steelblue')

        ax.set_yticks(x)
        ax.set_yticklabels(bag_names, fontsize=10)
        ax.set_xlabel('Total Return (%)')
        ax.set_title('V6 Part B1: Bag Size vs Stability (10 seeds each)',
                     fontsize=13, fontweight='bold')
        for i in range(len(bag_names)):
            ax.text(means[i] + 2, i, f'mean={means[i]:.0f}%, spread={spreads[i]:.0f}pp',
                    fontsize=9, va='center')
        ax.grid(True, alpha=0.3, axis='x')
        plt.tight_layout()
        plt.savefig(chart_dir / 'v6_bag_stability.png', dpi=150, bbox_inches='tight')
        plt.close()
        P(f"  Chart saved: {chart_dir / 'v6_bag_stability.png'}")

    # --- Chart 3: B2 Ensemble Weights ---
    if part_b2_results:
        fig, ax = plt.subplots(1, 1, figsize=(14, 6))
        names = []
        rets = []
        sortinos = []
        for scheme, info in part_b2_results.items():
            if info.get('result'):
                names.append(scheme)
                rets.append(info['result']['total'] * 100)
                sortinos.append(info['result']['sortino'])

        x = np.arange(len(names))
        bars = ax.bar(x, rets, color='steelblue', alpha=0.7, edgecolor='black', linewidth=0.5)
        for v, bar in zip(rets, bars):
            ax.text(bar.get_x() + bar.get_width()/2, v + 3,
                    f'{v:+.0f}%', ha='center', fontsize=9, fontweight='bold')
        ax.set_xticks(x)
        ax.set_xticklabels(names, fontsize=8, rotation=30, ha='right')
        ax.set_ylabel('Total Return %')
        ax.set_title('V6 Part B2: Ensemble Weight Schemes', fontsize=13, fontweight='bold')
        ax.grid(True, alpha=0.3, axis='y')
        plt.tight_layout()
        plt.savefig(chart_dir / 'v6_ensemble_weights.png', dpi=150, bbox_inches='tight')
        plt.close()
        P(f"  Chart saved: {chart_dir / 'v6_ensemble_weights.png'}")

    # --- Chart 4: Final Comparison ---
    if all_results:
        fig, ax = plt.subplots(1, 1, figsize=(16, 8))
        names = []
        rets = []
        colors = []
        cmap = plt.cm.Set2
        for i, (name, r) in enumerate(all_results.items()):
            if r is None:
                continue
            names.append(name)
            rets.append(r['total'] * 100)
            if 'Baseline' in name or 'V2' in name:
                colors.append('#4A90D9')
            elif 'Winner' in name or 'Best' in name:
                colors.append('#E74C3C')
            elif 'BTC' in name:
                colors.append('#F7931A')
            else:
                colors.append(cmap(i / max(len(all_results), 1)))

        x = np.arange(len(names))
        bars = ax.bar(x, rets, color=colors, alpha=0.85, edgecolor='black', linewidth=0.5)
        for v, bar in zip(rets, bars):
            ax.text(bar.get_x() + bar.get_width()/2, v + 3,
                    f'{v:+.0f}%', ha='center', fontsize=8, fontweight='bold')
        ax.set_xticks(x)
        ax.set_xticklabels(names, fontsize=7, rotation=35, ha='right')
        ax.set_ylabel('Total Return %')
        ax.set_title('V6 Final Comparison: All Winners vs Baselines (OOS 2022-2026)',
                     fontsize=13, fontweight='bold')
        ax.grid(True, alpha=0.3, axis='y')
        plt.tight_layout()
        plt.savefig(chart_dir / 'v6_final_comparison.png', dpi=150, bbox_inches='tight')
        plt.close()
        P(f"  Chart saved: {chart_dir / 'v6_final_comparison.png'}")


# ============================================================
# SECTION 12: MAIN
# ============================================================

def main():
    P("=" * 100)
    P("PIPELINE V6 COMPREHENSIVE - Feature Optimization + Stability Improvements")
    P("=" * 100)
    P(f"  Start time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    P("\nLoading data...")
    prices, daily_ret, returns, vols, df = load_data()
    dates = df['date'].values
    n = len(prices)
    P(f"  {n} days | {len(df.columns)} columns | {dates[0]} to {dates[-1]}")

    all_results = {}
    full_output = {
        'timestamp': datetime.now().isoformat(),
        'method': 'pipeline_v6_comprehensive',
        'test_period': '2022-2026',
    }

    # =========================================================
    # BASELINES
    # =========================================================
    P(f"\n{'='*100}")
    P("BASELINES")
    P("=" * 100)

    # BTC Buy & Hold
    yb = get_year_boundaries(dates, n)
    bh_s, bh_b, bh_a = [], [], []
    for yr in range(2022, 2027):
        if yr not in yb:
            continue
        allocs_bh = np.full(n, 1.0)
        s, b, a = backtest_allocations(daily_ret, allocs_bh, yb[yr]['start'], yb[yr]['end'])
        bh_s.extend(s); bh_b.extend(b); bh_a.extend(a)
    bh_result = metrics(np.array(bh_s), np.array(bh_b), np.array(bh_a))
    all_results['BTC Buy & Hold'] = bh_result
    P(f"  BTC Buy & Hold: {bh_result['total']*100:+.1f}%")

    # V2 Baseline (50/50 + Bag5 + Weekly + ret_5d)
    P(f"\n  V2 Baseline (50/50)...")
    r_v2 = walk_forward_hybrid(daily_ret, returns, vols, df, dates, n,
                               ml_weight=0.5, n_bags=5, use_weekly=True,
                               target_horizon=5, base_seed=42, verbose=False)
    all_results['V2 Baseline (50/50)'] = r_v2
    if r_v2:
        P(f"  V2 Baseline: {r_v2['total']*100:+.1f}% | Sortino {r_v2['sortino']:.2f}")

    # B4 Baseline (60/40 + ret_3d)
    P(f"  B4 Baseline (60/40)...")
    r_b4 = walk_forward_hybrid(daily_ret, returns, vols, df, dates, n,
                               ml_weight=0.6, n_bags=5, use_weekly=True,
                               target_horizon=3, base_seed=42, verbose=False)
    all_results['B4 Baseline (60/40)'] = r_b4
    if r_b4:
        P(f"  B4 Baseline: {r_b4['total']*100:+.1f}% | Sortino {r_b4['sortino']:.2f}")

    # B7 Baseline (100/0 + ret_3d)
    P(f"  B7 Baseline (100/0 + ret_3d)...")
    r_b7 = run_b7(daily_ret, returns, vols, df, dates, n,
                   n_bags=5, use_weekly=True, target_horizon=3,
                   base_seed=42, verbose=False)
    all_results['B7 Baseline (100/0 ret_3d)'] = r_b7
    if r_b7:
        P(f"  B7 Baseline: {r_b7['total']*100:+.1f}% | Sortino {r_b7['sortino']:.2f}")

    # =========================================================
    # PART A: FEATURE OPTIMIZATION
    # =========================================================
    P(f"\n\n{'#'*100}")
    P("PART A: FEATURE OPTIMIZATION")
    P("#" * 100)

    # A1: SHAP
    a1_results = part_a1_shap(daily_ret, returns, vols, df, dates, n)
    full_output['part_a1_shap'] = a1_results

    # A2: Individual swaps
    a2_results = part_a2_swaps(daily_ret, returns, vols, df, dates, n, r_b7)
    full_output['part_a2_swaps'] = {
        k: {'weak': v['weak'], 'strong': v['strong'],
            'delta_pp': v['delta_pp'], 'n_features': v['n_features'],
            'result': v['result']}
        for k, v in a2_results.items()
    }

    # A3: Combos (conditional)
    a3_results = {}
    winning_swaps = [k for k, v in a2_results.items() if v['delta_pp'] > 5]
    if winning_swaps:
        P(f"\n  A2 found {len(winning_swaps)} winning swaps -> running A3 combos")
        a3_results = part_a3_combos(daily_ret, returns, vols, df, dates, n,
                                    a2_results, r_b7)
    else:
        any_positive = [k for k, v in a2_results.items() if v['delta_pp'] > 0]
        if any_positive:
            P(f"\n  A2 found {len(any_positive)} positive swaps (none >+5pp) -> running A3 anyway")
            a3_results = part_a3_combos(daily_ret, returns, vols, df, dates, n,
                                        a2_results, r_b7)
        else:
            P(f"\n  A2 found NO positive swaps -> skipping A3")

    full_output['part_a3_combos'] = {}
    for k, v in a3_results.items():
        full_output['part_a3_combos'][k] = {
            'swap_dict': v['swap_dict'],
            'b7_result': v['b7_result'],
            'b4_result': v['b4_result'],
            'n_features': v['n_features'],
        }

    # Best from A
    best_a_label = None
    best_a_config = None
    best_a_return = r_b7['total'] if r_b7 else 0

    for k, v in a3_results.items():
        if v['b7_result'] and v['b7_result']['total'] > best_a_return:
            best_a_return = v['b7_result']['total']
            best_a_label = f"A3_{k}"
            best_a_config = {
                'swap_dict': v['swap_dict'],
                'ml_weight': 1.0,
                'n_bags': 5,
                'target_horizon': 3,
            }

    # Also check individual swaps
    for k, v in a2_results.items():
        if v['result'] and v['result']['total'] > best_a_return:
            best_a_return = v['result']['total']
            best_a_label = f"A2_{k}"
            best_a_config = {
                'swap_dict': {v['weak']: v['strong']},
                'ml_weight': 1.0,
                'n_bags': 5,
                'target_horizon': 3,
            }

    if best_a_label:
        P(f"\n  Best from Part A: {best_a_label} ({best_a_return*100:+.1f}%)")
        all_results[f'A Best: {best_a_label}'] = (
            a3_results.get(best_a_label.replace('A3_', ''), {}).get('b7_result') or
            a2_results.get(best_a_label.replace('A2_', ''), {}).get('result')
        )
    else:
        P(f"\n  Part A: No improvement over B7 baseline")

    # =========================================================
    # PART B: V6 TIER 1 IDEAS
    # =========================================================
    P(f"\n\n{'#'*100}")
    P("PART B: V6 TIER 1 IDEAS")
    P("#" * 100)

    # B1: Larger bags
    b1_results = part_b1_bags(daily_ret, returns, vols, df, dates, n, r_b7)
    full_output['part_b1_bags'] = b1_results

    # B2: Ensemble
    b2_results = part_b2_ensemble(daily_ret, returns, vols, df, dates, n)
    full_output['part_b2_ensemble'] = {}
    for k, v in b2_results.items():
        full_output['part_b2_ensemble'][k] = {
            'weights': v['weights'],
            'result': v['result'],
        }

    # B3: Wider shorts
    b3_results = part_b3_shorts(daily_ret, returns, vols, df, dates, n, r_b7, r_v2)
    full_output['part_b3_shorts'] = {k: v for k, v in b3_results.items()}

    # B4: Regime
    b4_results = part_b4_regime(daily_ret, returns, vols, df, dates, n, r_b7)
    full_output['part_b4_regime'] = b4_results

    # Best from B
    best_b_label = None
    best_b_config = None
    best_b_return = r_b7['total'] if r_b7 else 0

    # Check B1 (compare by mean of 10 seeds)
    for bag_label, info in b1_results.items():
        if info['mean'] / 100 > best_b_return and info['spread'] < 60:
            # Only count if spread is reasonable
            n_bags_val = info['n_bags']
            best_b_return = info['mean'] / 100
            best_b_label = f"B1_{bag_label}"
            best_b_config = {
                'ml_weight': 1.0,
                'n_bags': n_bags_val,
                'target_horizon': 3,
            }

    # Check B2
    for scheme, info in b2_results.items():
        if info.get('result') and info['result']['total'] > best_b_return:
            best_b_return = info['result']['total']
            best_b_label = f"B2_{scheme}"
            best_b_config = {'ensemble': scheme, 'weights': info['weights']}

    # Check B3
    for label, r in b3_results.items():
        if r and r['total'] > best_b_return:
            best_b_return = r['total']
            best_b_label = f"B3_{label}"
            clip_min = float(label.split('[')[1].split(',')[0])
            is_b7 = 'B7' in label
            best_b_config = {
                'ml_weight': 1.0 if is_b7 else 0.5,
                'n_bags': 5,
                'target_horizon': 3 if is_b7 else 5,
                'clip_min': clip_min,
            }

    # Check B4
    for label, r in b4_results.items():
        if r and r['total'] > best_b_return:
            best_b_return = r['total']
            best_b_label = f"B4_{label}"
            best_b_config = {
                'ml_weight': 0.8,  # dynamic, approximate
                'n_bags': 5,
                'target_horizon': 3,
                'vol_switch': True,
            }

    if best_b_label:
        P(f"\n  Best from Part B: {best_b_label} ({best_b_return*100:+.1f}%)")
        # Add to all_results
        if 'B2' in best_b_label:
            all_results[f'B Best: {best_b_label}'] = b2_results.get(
                best_b_label.replace('B2_', ''), {}).get('result')
        elif 'B3' in best_b_label:
            all_results[f'B Best: {best_b_label}'] = b3_results.get(
                best_b_label.replace('B3_', ''))
        elif 'B4' in best_b_label:
            all_results[f'B Best: {best_b_label}'] = b4_results.get(
                best_b_label.replace('B4_', ''))
    else:
        P(f"\n  Part B: No improvement over B7 baseline")

    # =========================================================
    # PART C: COMBINE BEST + ROBUSTNESS
    # =========================================================
    P(f"\n\n{'#'*100}")
    P("PART C: COMBINE BEST + FULL ROBUSTNESS")
    P("#" * 100)

    # Determine overall winner
    winner_label = "B7 Baseline"
    winner_config = {'ml_weight': 1.0, 'n_bags': 5, 'target_horizon': 3}
    winner_return = r_b7['total'] if r_b7 else 0

    if best_a_config and best_a_return > winner_return:
        winner_label = best_a_label
        winner_config = best_a_config
        winner_return = best_a_return

    if best_b_config and best_b_return > winner_return and 'ensemble' not in (best_b_config or {}):
        winner_label = best_b_label
        winner_config = best_b_config
        winner_return = best_b_return

    # C1: Try combining best A + best B features (if both found improvements)
    c1_results = {}
    if best_a_config and best_b_config and 'ensemble' not in (best_b_config or {}):
        P(f"\n  C1: COMBINING BEST A ({best_a_label}) + BEST B ({best_b_label})")
        combined_config = dict(winner_config)
        if best_a_config.get('swap_dict'):
            combined_config['swap_dict'] = best_a_config['swap_dict']
        if best_b_config.get('n_bags') and best_b_config['n_bags'] > combined_config.get('n_bags', 5):
            combined_config['n_bags'] = best_b_config['n_bags']
        if best_b_config.get('clip_min'):
            combined_config['clip_min'] = best_b_config['clip_min']
        if best_b_config.get('vol_switch'):
            combined_config['vol_switch'] = True

        P(f"    Combined config: {combined_config}")
        r_combined = _run_winner(daily_ret, returns, vols, df, dates, n,
                                 combined_config, base_seed=42, verbose=True)
        if r_combined:
            P(f"    Combined: {r_combined['total']*100:+.1f}%")
            c1_results['combined'] = r_combined
            all_results['C1 Combined A+B'] = r_combined

            if r_combined['total'] > winner_return:
                winner_label = "C1_combined"
                winner_config = combined_config
                winner_return = r_combined['total']

    full_output['part_c1_combined'] = c1_results

    P(f"\n  OVERALL WINNER: {winner_label} ({winner_return*100:+.1f}%)")
    P(f"  Config: {winner_config}")

    # C2-C5: Full robustness on winner
    if 'ensemble' not in str(winner_config):
        c_results = part_c_robustness(daily_ret, returns, vols, df, dates, n,
                                      winner_config, winner_label, all_results)
        full_output['part_c_robustness'] = c_results
    else:
        P("  Skipping C2-C5 for ensemble winner (not a single config)")
        full_output['part_c_robustness'] = {'note': 'skipped for ensemble'}

    # =========================================================
    # FINAL COMPARISON TABLE
    # =========================================================
    P(f"\n\n{'='*100}")
    P("FINAL COMPARISON TABLE")
    P("=" * 100)

    P(f"\n  {'Strategy':<40} {'Return':>10} {'Sortino':>8} {'MaxDD':>8}")
    P(f"  {'-'*70}")
    for name, r in all_results.items():
        if r is None:
            continue
        P(f"  {name:<40} {r['total']*100:>+9.1f}% {r['sortino']:>+7.2f} {r['max_dd']*100:>7.1f}%")

    # =========================================================
    # SAVE RESULTS
    # =========================================================
    out_dir = ROOT / 'outputs/results'
    out_dir.mkdir(parents=True, exist_ok=True)

    # Serialize results
    def serialize(obj):
        if isinstance(obj, (np.floating, np.integer)):
            return float(obj)
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        if isinstance(obj, dict):
            return {k: serialize(v) for k, v in obj.items()}
        if isinstance(obj, list):
            return [serialize(v) for v in obj]
        return obj

    full_output['all_results'] = serialize(all_results)
    full_output['winner'] = {
        'label': winner_label,
        'config': serialize(winner_config),
        'return': float(winner_return),
    }

    with open(out_dir / 'pipeline_v6_comprehensive.json', 'w') as f:
        json.dump(serialize(full_output), f, indent=2, default=str)
    P(f"\n  Results saved: {out_dir / 'pipeline_v6_comprehensive.json'}")

    # =========================================================
    # CHARTS
    # =========================================================
    P("\n  Generating charts...")
    chart_dir = ROOT / 'outputs/results/charts'
    generate_charts(all_results, a2_results, b1_results, b2_results, chart_dir)

    # =========================================================
    # GENERATE REPORT
    # =========================================================
    generate_report(all_results, full_output, winner_label, winner_config,
                    a2_results, a3_results, b1_results, b2_results,
                    b3_results, b4_results, r_b7, r_v2, r_b4)

    # =========================================================
    # VERDICT
    # =========================================================
    P(f"\n{'='*100}")
    P("VERDICT")
    P("=" * 100)

    P(f"\n  B7 Baseline (seed 42): {r_b7['total']*100:+.1f}%" if r_b7 else "  B7: N/A")
    P(f"  V6 Winner: {winner_label} ({winner_return*100:+.1f}%)")
    improvement = (winner_return - (r_b7['total'] if r_b7 else 0)) * 100
    P(f"  Improvement over B7: {improvement:+.1f}pp")

    if 'part_c_robustness' in full_output and isinstance(full_output['part_c_robustness'], dict):
        rob = full_output['part_c_robustness']
        if 'seed_stability' in rob:
            P(f"  Seed stability: {rob['seed_stability']['verdict']} "
              f"(spread={rob['seed_stability']['spread']:.0f}pp)")
        if 'bootstrap' in rob:
            bs = rob['bootstrap']
            P(f"  Bootstrap 95% CI: [{bs['return_lo']*100:+.0f}%, {bs['return_hi']*100:+.0f}%]")
            P(f"  P(return > 0): {bs['excess_above_zero_pct']:.1f}%")
        if 'cost_sensitivity' in rob:
            r10 = rob['cost_sensitivity'].get('10bps')
            if r10:
                P(f"  Still profitable at 10 bps: {r10['total']*100:+.1f}%")

    P(f"\n  End time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    P(f"\n{'='*100}")
    P("PIPELINE V6 COMPREHENSIVE COMPLETE")
    P("=" * 100)


def generate_report(all_results, full_output, winner_label, winner_config,
                    a2_results, a3_results, b1_results, b2_results,
                    b3_results, b4_results, r_b7, r_v2, r_b4):
    """Generate markdown report."""
    report_path = ROOT / 'docs/PIPELINE_V6_COMPREHENSIVE.md'
    report_path.parent.mkdir(parents=True, exist_ok=True)

    lines = []
    lines.append("# Pipeline V6 Comprehensive — Feature Optimization + Stability")
    lines.append(f"\n**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append(f"**Test Period:** 2022-2026 OOS (walk-forward)")
    lines.append(f"**Cost Model:** 2 bps (1.5x for shorts)")

    # Baselines
    lines.append("\n## Baselines")
    lines.append("\n| Strategy | Return | Sortino | MaxDD |")
    lines.append("|----------|--------|---------|-------|")
    for name in ['BTC Buy & Hold', 'V2 Baseline (50/50)', 'B4 Baseline (60/40)',
                 'B7 Baseline (100/0 ret_3d)']:
        r = all_results.get(name)
        if r:
            lines.append(f"| {name} | {r['total']*100:+.1f}% | {r['sortino']:.2f} | {r['max_dd']*100:.1f}% |")

    # Part A
    lines.append("\n## Part A: Feature Optimization")

    if a2_results:
        lines.append("\n### A2: Individual Swaps")
        lines.append("\n| Swap | Return | Delta | Verdict |")
        lines.append("|------|--------|-------|---------|")
        for name, info in sorted(a2_results.items(), key=lambda x: x[1]['delta_pp'], reverse=True):
            r = info['result']
            delta = info['delta_pp']
            verdict = 'BETTER' if delta > 5 else ('similar' if delta > -5 else 'worse')
            lines.append(f"| {name} | {r['total']*100:+.1f}% | {delta:+.1f}pp | {verdict} |")

    if a3_results:
        lines.append("\n### A3: Combo Swaps")
        lines.append("\n| Combo | B7 Return | B4 Return |")
        lines.append("|-------|-----------|-----------|")
        for name, info in a3_results.items():
            b7_r = info['b7_result']
            b4_r = info['b4_result']
            b7_str = f"{b7_r['total']*100:+.1f}%" if b7_r else "N/A"
            b4_str = f"{b4_r['total']*100:+.1f}%" if b4_r else "N/A"
            lines.append(f"| {name} | {b7_str} | {b4_str} |")

    # Part B
    lines.append("\n## Part B: V6 Tier 1 Ideas")

    if b1_results:
        lines.append("\n### B1: Bag Size Stability")
        lines.append("\n| Bags | Mean Return | Spread | Verdict |")
        lines.append("|------|------------|--------|---------|")
        for label, info in sorted(b1_results.items()):
            lines.append(f"| {label} | {info['mean']:+.1f}% | {info['spread']:.0f}pp | {info['verdict']} |")

    if b2_results:
        lines.append("\n### B2: Ensemble Weights")
        lines.append("\n| Scheme | Return | Sortino | MaxDD |")
        lines.append("|--------|--------|---------|-------|")
        for scheme, info in b2_results.items():
            r = info.get('result')
            if r:
                lines.append(f"| {scheme} | {r['total']*100:+.1f}% | {r['sortino']:.2f} | {r['max_dd']*100:.1f}% |")

    if b3_results:
        lines.append("\n### B3: Wider Short Range")
        lines.append("\n| Config | Return | MaxDD |")
        lines.append("|--------|--------|-------|")
        for label, r in b3_results.items():
            if r:
                lines.append(f"| {label} | {r['total']*100:+.1f}% | {r['max_dd']*100:.1f}% |")

    if b4_results:
        lines.append("\n### B4: Regime-Conditional ML Weight")
        lines.append("\n| Regime | Return | Sortino | MaxDD |")
        lines.append("|--------|--------|---------|-------|")
        for label, r in b4_results.items():
            if r:
                lines.append(f"| {label} | {r['total']*100:+.1f}% | {r['sortino']:.2f} | {r['max_dd']*100:.1f}% |")

    # Winner
    lines.append(f"\n## Winner")
    lines.append(f"\n**{winner_label}**")
    lines.append(f"- Config: `{winner_config}`")

    rob = full_output.get('part_c_robustness', {})
    if isinstance(rob, dict):
        if 'seed_stability' in rob:
            ss = rob['seed_stability']
            lines.append(f"- Seed stability: {ss['verdict']} (mean={ss['mean']:+.1f}%, spread={ss['spread']:.0f}pp)")
        if 'bootstrap' in rob:
            bs = rob['bootstrap']
            lines.append(f"- Bootstrap 95% CI: [{bs['return_lo']*100:+.0f}%, {bs['return_hi']*100:+.0f}%]")
            lines.append(f"- P(return > 0): {bs['excess_above_zero_pct']:.1f}%")
        if 'year_by_year' in rob:
            lines.append("\n### Year-by-Year")
            lines.append("\n| Year | Return | BTC | Excess |")
            lines.append("|------|--------|-----|--------|")
            for yr, m in sorted(rob['year_by_year'].items()):
                lines.append(f"| {yr} | {m['total']*100:+.1f}% | {m['btc']*100:+.1f}% | {m['excess']*100:+.1f}% |")

    with open(report_path, 'w') as f:
        f.write('\n'.join(lines))
    P(f"  Report saved: {report_path}")


if __name__ == '__main__':
    main()
