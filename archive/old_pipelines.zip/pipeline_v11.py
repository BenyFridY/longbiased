"""
PIPELINE V11 — XGBoost + Ensemble + Tuning Experiments
======================================================

V10 best: 37feat + min_data_in_leaf=12 + linear_direct K=25 + Bag50
  -> +802%, Sortino 2.74, Spread 50pp, MaxDD -14.1% (10 seeds)

V11 goals: Test XGBoost as alternative/complement to LightGBM,
optimize bag count, fine-tune K, explore prediction smoothing,
and sweep target horizons.

A V11 config must beat current best on at least 2 of 3:
  - Sortino >= 2.74
  - Spread <= 50pp
  - Return >= +800%

Phases:
  A: XGBoost drop-in comparison (10 seeds x 2 models)
  B: Hybrid LGB + XGB ensemble (10 seeds x 2 configs)
  C: Bag count optimization (10 seeds x 4 counts)
  D: K fine-tuning (10 seeds x 7 values)
  E: Prediction smoothing (10 seeds x 4 configs)
  F: Target horizon sweep (10 seeds x 3 horizons)

Estimated total: ~15h
"""

import sys
import gc
import pandas as pd
import numpy as np
from pathlib import Path
import warnings
import json
from datetime import datetime
import lightgbm as lgb
import xgboost as xgb

warnings.filterwarnings('ignore')
sys.stdout.reconfigure(line_buffering=True)

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

from archive.old_pipelines.pipeline_v09 import (
    load_data, build_ml_features,
    backtest_allocations, metrics, get_year_boundaries,
    SEEDS_10, COST, DEFAULT_LGB_PARAMS,
    P, _seed_summary, convert_numpy,
)

from archive.old_pipelines.pipeline_v10 import (
    C2_BASE, TOP_ADD, MODELS, _compute_allocation,
)

RF_DAILY_ARR = None

# ============================================================
# XGBOOST DEFAULT PARAMS (mapped from LGB defaults)
# ============================================================

DEFAULT_XGB_PARAMS = {
    'max_leaves': 31,
    'grow_policy': 'lossguide',
    'tree_method': 'hist',
    'colsample_bytree': 0.7,
    'subsample': 0.8,
    'learning_rate': 0.05,
    'min_child_weight': 12,
    'n_estimators': 200,
    'objective': 'reg:squarederror',
    'verbosity': 0,
    'nthread': 1,
}

# V10 best configs per feature set
V10_BEST = {
    'features': '37feat',
    'n_bags': 50,
    'K': 25,
    'lgb_override': {'min_data_in_leaf': 12},
    'alloc_formula': 'linear_direct',
    'return_pct': 802,
    'sortino': 2.74,
    'spread': 50,
}

V10_CONFIGS = {
    '37feat': {'K': 25, 'return_pct': 802, 'sortino': 2.74, 'spread': 50, 'max_dd': -14.1},
    '32feat': {'K': 20, 'return_pct': 711, 'sortino': 2.62, 'spread': 55, 'max_dd': -12.4},
    '30feat': {'K': 25, 'return_pct': 800, 'sortino': 2.56, 'spread': 76, 'max_dd': -15.4},
}

RESULTS_PATH = ROOT / 'outputs/results/pipeline_v11.json'


# ============================================================
# V11 CORE ENGINE
# ============================================================

def run_strategy_v11(daily_ret, returns, vols, df, dates, n,
                     feature_cols, n_bags_lgb=50, n_bags_xgb=0,
                     base_seed=42, lgb_params=None, xgb_params=None,
                     alloc_formula='linear_direct', alloc_params=None,
                     scale_div=0.05, target_horizon=3,
                     prediction_ema=1.0,
                     model_type='lgb',
                     verbose=False):
    """Walk-forward engine with V11 enhancements.

    Args:
        feature_cols: list of feature column names
        n_bags_lgb: number of LightGBM bagged models
        n_bags_xgb: number of XGBoost bagged models
        lgb_params: LightGBM params dict (merged with defaults)
        xgb_params: XGBoost params dict (merged with defaults)
        alloc_formula: allocation formula name
        alloc_params: dict with formula-specific params
        scale_div: prediction scaling divisor
        target_horizon: days ahead for return target (default 3)
        prediction_ema: EMA alpha for prediction smoothing (1.0 = no smoothing)
        model_type: 'lgb', 'xgb', or 'hybrid'
    """
    if alloc_params is None:
        alloc_params = {}

    prices = df['price_usd'].values
    yb = get_year_boundaries(dates, n)

    X_all, names = build_ml_features(df, returns, vols, n, feature_cols=feature_cols)

    h = target_horizon
    target = np.zeros(n)
    for i in range(n - h):
        target[i] = (prices[i + h] - prices[i]) / prices[i]

    day_of_week = pd.to_datetime(dates).dayofweek

    all_strat, all_btc, all_alloc, all_rf = [], [], [], []
    full_allocs = np.full(n, 0.5)
    is_rf_arr = isinstance(RF_DAILY_ARR, np.ndarray)

    lgb_params_base = dict(DEFAULT_LGB_PARAMS)
    if lgb_params:
        lgb_params_base.update(lgb_params)

    xgb_params_base = dict(DEFAULT_XGB_PARAMS)
    if xgb_params:
        xgb_params_base.update(xgb_params)

    for test_year in range(2022, 2027):
        if test_year not in yb:
            continue

        train_end = yb[test_year]['start'] - 1
        test_start = yb[test_year]['start']
        test_end = yb[test_year]['end']
        horizon_gap = max(h, 5)

        # Prepare training data
        train_mask = np.arange(60, train_end - horizon_gap + 1)
        valid_train = ~np.any(np.isnan(X_all[train_mask]), axis=1)
        train_idx = train_mask[valid_train]
        if len(train_idx) < 100:
            continue
        X_train = np.nan_to_num(X_all[train_idx], nan=0.0)
        y_train = target[train_idx]

        models_lgb = []
        models_xgb = []

        # Train LightGBM models
        n_lgb = n_bags_lgb if model_type in ('lgb', 'hybrid') else 0
        for i in range(n_lgb):
            seed = base_seed + i * 7
            params = dict(lgb_params_base)
            params['seed'] = seed
            params['verbose'] = -1
            params['n_jobs'] = 1
            num_round = params.pop('num_boost_round', 200)
            dtrain = lgb.Dataset(X_train, label=y_train)
            models_lgb.append(lgb.train(params, dtrain, num_boost_round=num_round))

        # Train XGBoost models
        n_xgb = n_bags_xgb if model_type in ('xgb', 'hybrid') else 0
        if model_type == 'xgb':
            n_xgb = n_bags_lgb  # use n_bags_lgb as total when pure XGB
        for i in range(n_xgb):
            seed = base_seed + i * 7
            params = dict(xgb_params_base)
            params['random_state'] = seed
            n_est = params.pop('n_estimators', 200)
            model = xgb.XGBRegressor(n_estimators=n_est, **params)
            model.fit(X_train, y_train)
            models_xgb.append(model)

        all_models_count = len(models_lgb) + len(models_xgb)
        if all_models_count == 0:
            continue

        if verbose:
            P(f"    {test_year}: {len(models_lgb)} LGB + {len(models_xgb)} XGB models")

        prev_alloc = 0.5
        smoothed_pred = None

        for t in range(test_start, test_end + 1):
            # Predict from all models
            x_t = np.nan_to_num(X_all[t:t+1].copy(), nan=0.0)
            preds = []
            for m in models_lgb:
                preds.append(m.predict(x_t)[0])
            for m in models_xgb:
                preds.append(m.predict(x_t)[0])
            avg_pred = np.mean(preds)

            # EMA smoothing
            if smoothed_pred is None:
                smoothed_pred = avg_pred
            else:
                smoothed_pred = prediction_ema * avg_pred + (1 - prediction_ema) * smoothed_pred

            # Allocation
            raw_alloc = _compute_allocation(smoothed_pred, scale_div, alloc_formula, alloc_params)

            is_friday = day_of_week[t] == 4
            if not is_friday:
                raw_alloc = prev_alloc

            full_allocs[t] = np.clip(raw_alloc, -0.25, 1.0)
            prev_alloc = full_allocs[t]

        s, b, a = backtest_allocations(daily_ret, full_allocs, test_start, test_end,
                                       cost=COST, rf_daily=RF_DAILY_ARR)
        all_strat.extend(s)
        all_btc.extend(b)
        all_alloc.extend(a)

        n_days = len(s)
        if is_rf_arr:
            rf_slice = RF_DAILY_ARR[test_start:test_start + n_days]
            all_rf.extend(rf_slice)
        else:
            all_rf.extend([0.0] * n_days)

    result = metrics(np.array(all_strat), np.array(all_btc), np.array(all_alloc),
                     rf_daily=np.array(all_rf))
    return result


# ============================================================
# SAVE HELPER
# ============================================================

def _save(all_results):
    """Save results incrementally."""
    RESULTS_PATH.parent.mkdir(parents=True, exist_ok=True)
    output_clean = convert_numpy(all_results)
    RESULTS_PATH.write_text(json.dumps(output_clean, indent=2, default=str),
                            encoding='utf-8')
    P(f"  [SAVE] {RESULTS_PATH.name}")


def _run_seeds(daily_ret, returns, vols, df, dates, n, label, **kwargs):
    """Run 10 seeds and return summary dict. Returns None if all fail."""
    seed_results = []
    for seed in SEEDS_10:
        P(f"    seed={seed}...", end="")
        r = run_strategy_v11(daily_ret, returns, vols, df, dates, n,
                             base_seed=seed, **kwargs)
        if r:
            seed_results.append(r)
            P(f" {r['total']*100:+.1f}% S={r['sortino']:.2f}")
        else:
            P(" FAILED")
        gc.collect()

    if not seed_results:
        return None

    rets = [r['total'] * 100 for r in seed_results]
    summary = _seed_summary(rets, seed_results)
    P(f"    {label}: mean={summary['mean']:+.1f}%, "
      f"Sortino={summary['sortinos_mean']:.2f}, "
      f"spread={summary['spread']:.0f}pp, "
      f"MaxDD={summary['max_dds_mean']:.1f}%")
    return summary


def _beats_v10(summary):
    """Check if summary beats V10 on at least 2 of 3 criteria."""
    if summary is None:
        return False, 0
    wins = 0
    if summary['sortinos_mean'] >= V10_BEST['sortino']:
        wins += 1
    if summary['spread'] <= V10_BEST['spread']:
        wins += 1
    if summary['mean'] >= V10_BEST['return_pct']:
        wins += 1
    return wins >= 2, wins


# ============================================================
# PHASE A: XGBOOST DROP-IN COMPARISON
# ============================================================

def phase_a(daily_ret, returns, vols, df, dates, n):
    P(f"\n{'#'*100}")
    P("PHASE A: XGBOOST DROP-IN COMPARISON (10 seeds x 3 models)")
    P("#" * 100)
    P("  Using V10-best K per feature set: 37f→K=25, 32f→K=20, 30f→K=25")

    results = {}

    for model_name in ['30feat', '32feat', '37feat']:
        feature_cols = MODELS[model_name]
        best_K = V10_CONFIGS[model_name]['K']

        # LGB baseline (V10 config) — reproduce V10 numbers
        P(f"\n  --- {model_name} LGB baseline (Bag50, K={best_K}) ---")
        lgb_summary = _run_seeds(
            daily_ret, returns, vols, df, dates, n,
            label=f'{model_name}_lgb',
            feature_cols=feature_cols,
            n_bags_lgb=50, n_bags_xgb=0,
            model_type='lgb',
            lgb_params={'min_data_in_leaf': 12},
            alloc_formula='linear_direct',
            alloc_params={'K': best_K})

        if lgb_summary:
            results[f'{model_name}_lgb_K{best_K}'] = lgb_summary

        # XGB comparison — same K, same bags, same features
        P(f"\n  --- {model_name} XGB (Bag50, K={best_K}) ---")
        xgb_summary = _run_seeds(
            daily_ret, returns, vols, df, dates, n,
            label=f'{model_name}_xgb',
            feature_cols=feature_cols,
            n_bags_lgb=50, n_bags_xgb=0,
            model_type='xgb',
            alloc_formula='linear_direct',
            alloc_params={'K': best_K})

        if xgb_summary:
            results[f'{model_name}_xgb_K{best_K}'] = xgb_summary

        gc.collect()

    # Compare
    P(f"\n  PHASE A COMPARISON:")
    P(f"  {'Config':<30} {'Mean':>8} {'Spread':>8} {'Sortino':>8} {'MaxDD':>8} {'V10 ref':>10}")
    P(f"  {'-'*75}")
    for key, s in results.items():
        beats, wins = _beats_v10(s)
        flag = " *** BEATS V10" if beats else ""
        P(f"  {key:<30} {s['mean']:>+7.1f}% {s['spread']:>7.0f}pp "
          f"{s['sortinos_mean']:>7.2f} {s['max_dds_mean']:>7.1f}%{flag}")

    return results


# ============================================================
# PHASE B: HYBRID LGB + XGB ENSEMBLE
# ============================================================

def phase_b(daily_ret, returns, vols, df, dates, n, phase_a_results):
    P(f"\n{'#'*100}")
    P("PHASE B: HYBRID LGB + XGB ENSEMBLE (10 seeds x 4 configs)")
    P("#" * 100)

    # Check if XGBoost was reasonable in Phase A
    xgb_keys = [k for k in phase_a_results if 'xgb' in k]
    any_xgb_ok = any(phase_a_results[k].get('sortinos_mean', 0) >= 1.0
                     for k in xgb_keys if isinstance(phase_a_results[k], dict))
    if not any_xgb_ok:
        P("  All XGBoost Sortinos < 1.0 — skipping hybrid (XGB not competitive)")
        return {'skipped': True, 'reason': 'XGB Sortino too low'}

    results = {}

    # 37feat hybrids (V10-best K=25)
    P(f"\n  --- 37feat Hybrid Bag25+25 (K=25) ---")
    h50_37 = _run_seeds(
        daily_ret, returns, vols, df, dates, n,
        label='37f_hybrid_25_25',
        feature_cols=MODELS['37feat'],
        n_bags_lgb=25, n_bags_xgb=25,
        model_type='hybrid',
        lgb_params={'min_data_in_leaf': 12},
        alloc_formula='linear_direct',
        alloc_params={'K': 25})
    if h50_37:
        results['37f_hybrid_25_25'] = h50_37

    P(f"\n  --- 37feat Hybrid Bag15+15 (K=25) ---")
    h30_37 = _run_seeds(
        daily_ret, returns, vols, df, dates, n,
        label='37f_hybrid_15_15',
        feature_cols=MODELS['37feat'],
        n_bags_lgb=15, n_bags_xgb=15,
        model_type='hybrid',
        lgb_params={'min_data_in_leaf': 12},
        alloc_formula='linear_direct',
        alloc_params={'K': 25})
    if h30_37:
        results['37f_hybrid_15_15'] = h30_37

    # 32feat hybrids (V10-best K=20)
    P(f"\n  --- 32feat Hybrid Bag25+25 (K=20) ---")
    h50_32 = _run_seeds(
        daily_ret, returns, vols, df, dates, n,
        label='32f_hybrid_25_25',
        feature_cols=MODELS['32feat'],
        n_bags_lgb=25, n_bags_xgb=25,
        model_type='hybrid',
        lgb_params={'min_data_in_leaf': 12},
        alloc_formula='linear_direct',
        alloc_params={'K': 20})
    if h50_32:
        results['32f_hybrid_25_25'] = h50_32

    P(f"\n  --- 32feat Hybrid Bag15+15 (K=20) ---")
    h30_32 = _run_seeds(
        daily_ret, returns, vols, df, dates, n,
        label='32f_hybrid_15_15',
        feature_cols=MODELS['32feat'],
        n_bags_lgb=15, n_bags_xgb=15,
        model_type='hybrid',
        lgb_params={'min_data_in_leaf': 12},
        alloc_formula='linear_direct',
        alloc_params={'K': 20})
    if h30_32:
        results['32f_hybrid_15_15'] = h30_32

    # Compare
    P(f"\n  PHASE B COMPARISON:")
    P(f"  {'Config':<30} {'Mean':>8} {'Spread':>8} {'Sortino':>8} {'MaxDD':>8}")
    P(f"  {'-'*65}")
    for key, s in results.items():
        beats, wins = _beats_v10(s)
        flag = " *** BEATS V10" if beats else ""
        P(f"  {key:<30} {s['mean']:>+7.1f}% {s['spread']:>7.0f}pp "
          f"{s['sortinos_mean']:>7.2f} {s['max_dds_mean']:>7.1f}%{flag}")

    return results


# ============================================================
# PHASE C: BAG COUNT OPTIMIZATION
# ============================================================

def phase_c(daily_ret, returns, vols, df, dates, n):
    P(f"\n{'#'*100}")
    P("PHASE C: BAG COUNT OPTIMIZATION (10 seeds x 8 configs)")
    P("#" * 100)

    results = {}

    # 37feat bag counts (K=25)
    for n_bags in [60, 70, 80, 100]:
        P(f"\n  --- 37feat Bag{n_bags} (K=25) ---")
        summary = _run_seeds(
            daily_ret, returns, vols, df, dates, n,
            label=f'37f_bag{n_bags}',
            feature_cols=MODELS['37feat'],
            n_bags_lgb=n_bags, n_bags_xgb=0,
            model_type='lgb',
            lgb_params={'min_data_in_leaf': 12},
            alloc_formula='linear_direct',
            alloc_params={'K': 25})

        if summary:
            results[f'37f_bag{n_bags}'] = summary
        gc.collect()

    # 32feat bag counts (K=20)
    for n_bags in [60, 70, 80, 100]:
        P(f"\n  --- 32feat Bag{n_bags} (K=20) ---")
        summary = _run_seeds(
            daily_ret, returns, vols, df, dates, n,
            label=f'32f_bag{n_bags}',
            feature_cols=MODELS['32feat'],
            n_bags_lgb=n_bags, n_bags_xgb=0,
            model_type='lgb',
            lgb_params={'min_data_in_leaf': 12},
            alloc_formula='linear_direct',
            alloc_params={'K': 20})

        if summary:
            results[f'32f_bag{n_bags}'] = summary
        gc.collect()

    # Compare
    P(f"\n  PHASE C COMPARISON (refs: 37f Bag50 +802% S=2.74 50pp | 32f Bag50 +711% S=2.62 55pp):")
    P(f"  {'Config':<30} {'Mean':>8} {'Spread':>8} {'Sortino':>8} {'MaxDD':>8}")
    P(f"  {'-'*65}")
    for key, s in sorted(results.items(), key=lambda x: x[1]['sortinos_mean'], reverse=True):
        beats, wins = _beats_v10(s)
        flag = " *** BEATS V10" if beats else ""
        P(f"  {key:<30} {s['mean']:>+7.1f}% {s['spread']:>7.0f}pp "
          f"{s['sortinos_mean']:>7.2f} {s['max_dds_mean']:>7.1f}%{flag}")

    return results


# ============================================================
# PHASE D: K FINE-TUNING
# ============================================================

def phase_d(daily_ret, returns, vols, df, dates, n):
    P(f"\n{'#'*100}")
    P("PHASE D: K FINE-TUNING (10 seeds x 14 configs)")
    P("#" * 100)

    results = {}

    # 37feat K sweep (V10 best K=25)
    P(f"\n  === 37feat K sweep (Bag50, V10 best K=25) ===")
    for K in [18, 20, 22, 23, 25, 27, 30]:
        P(f"\n  --- 37feat Bag50 K={K} ---")
        summary = _run_seeds(
            daily_ret, returns, vols, df, dates, n,
            label=f'37f_K={K}',
            feature_cols=MODELS['37feat'],
            n_bags_lgb=50, n_bags_xgb=0,
            model_type='lgb',
            lgb_params={'min_data_in_leaf': 12},
            alloc_formula='linear_direct',
            alloc_params={'K': K})
        if summary:
            results[f'37f_K={K}'] = summary

    # 32feat K sweep (V10 best K=20)
    P(f"\n  === 32feat K sweep (Bag50, V10 best K=20) ===")
    for K in [15, 17, 18, 20, 22, 23, 25]:
        P(f"\n  --- 32feat Bag50 K={K} ---")
        summary = _run_seeds(
            daily_ret, returns, vols, df, dates, n,
            label=f'32f_K={K}',
            feature_cols=MODELS['32feat'],
            n_bags_lgb=50, n_bags_xgb=0,
            model_type='lgb',
            lgb_params={'min_data_in_leaf': 12},
            alloc_formula='linear_direct',
            alloc_params={'K': K})
        if summary:
            results[f'32f_K={K}'] = summary

    # Compare
    P(f"\n  PHASE D COMPARISON:")
    P(f"  {'Config':<30} {'Mean':>8} {'Spread':>8} {'Sortino':>8} {'MaxDD':>8}")
    P(f"  {'-'*65}")
    for key, s in sorted(results.items(), key=lambda x: x[1]['sortinos_mean'], reverse=True):
        beats, wins = _beats_v10(s)
        flag = " *** BEATS V10" if beats else ""
        P(f"  {key:<30} {s['mean']:>+7.1f}% {s['spread']:>7.0f}pp "
          f"{s['sortinos_mean']:>7.2f} {s['max_dds_mean']:>7.1f}%{flag}")

    return results


# ============================================================
# PHASE E: PREDICTION SMOOTHING
# ============================================================

def phase_e(daily_ret, returns, vols, df, dates, n):
    P(f"\n{'#'*100}")
    P("PHASE E: PREDICTION SMOOTHING (10 seeds x 8 configs)")
    P("#" * 100)

    results = {}

    # 37feat smoothing (K=25)
    P(f"\n  === 37feat EMA smoothing (Bag50, K=25) ===")
    for alpha in [0.3, 0.5, 0.7, 1.0]:
        label = f'alpha={alpha}' if alpha < 1.0 else 'no_smooth'
        P(f"\n  --- 37feat Bag50 K=25 EMA {label} ---")
        summary = _run_seeds(
            daily_ret, returns, vols, df, dates, n,
            label=f'37f_{label}',
            feature_cols=MODELS['37feat'],
            n_bags_lgb=50, n_bags_xgb=0,
            model_type='lgb',
            lgb_params={'min_data_in_leaf': 12},
            alloc_formula='linear_direct',
            alloc_params={'K': 25},
            prediction_ema=alpha)
        if summary:
            results[f'37f_{label}'] = summary

    # 32feat smoothing (K=20)
    P(f"\n  === 32feat EMA smoothing (Bag50, K=20) ===")
    for alpha in [0.3, 0.5, 0.7, 1.0]:
        label = f'alpha={alpha}' if alpha < 1.0 else 'no_smooth'
        P(f"\n  --- 32feat Bag50 K=20 EMA {label} ---")
        summary = _run_seeds(
            daily_ret, returns, vols, df, dates, n,
            label=f'32f_{label}',
            feature_cols=MODELS['32feat'],
            n_bags_lgb=50, n_bags_xgb=0,
            model_type='lgb',
            lgb_params={'min_data_in_leaf': 12},
            alloc_formula='linear_direct',
            alloc_params={'K': 20},
            prediction_ema=alpha)
        if summary:
            results[f'32f_{label}'] = summary

    # Compare
    P(f"\n  PHASE E COMPARISON:")
    P(f"  {'Config':<30} {'Mean':>8} {'Spread':>8} {'Sortino':>8} {'MaxDD':>8}")
    P(f"  {'-'*65}")
    for key, s in results.items():
        beats, wins = _beats_v10(s)
        flag = " *** BEATS V10" if beats else ""
        P(f"  {key:<30} {s['mean']:>+7.1f}% {s['spread']:>7.0f}pp "
          f"{s['sortinos_mean']:>7.2f} {s['max_dds_mean']:>7.1f}%{flag}")

    return results


# ============================================================
# PHASE F: TARGET HORIZON SWEEP
# ============================================================

def phase_f(daily_ret, returns, vols, df, dates, n):
    P(f"\n{'#'*100}")
    P("PHASE F: TARGET HORIZON SWEEP (10 seeds x 6 configs)")
    P("#" * 100)

    results = {}

    # 37feat horizons (K=25)
    P(f"\n  === 37feat horizon sweep (Bag50, K=25) ===")
    for horizon in [2, 4, 5]:
        P(f"\n  --- 37feat Bag50 K=25 ret_{horizon}d ---")
        summary = _run_seeds(
            daily_ret, returns, vols, df, dates, n,
            label=f'37f_ret_{horizon}d',
            feature_cols=MODELS['37feat'],
            n_bags_lgb=50, n_bags_xgb=0,
            model_type='lgb',
            lgb_params={'min_data_in_leaf': 12},
            alloc_formula='linear_direct',
            alloc_params={'K': 25},
            target_horizon=horizon)
        if summary:
            results[f'37f_ret_{horizon}d'] = summary

    # 32feat horizons (K=20)
    P(f"\n  === 32feat horizon sweep (Bag50, K=20) ===")
    for horizon in [2, 4, 5]:
        P(f"\n  --- 32feat Bag50 K=20 ret_{horizon}d ---")
        summary = _run_seeds(
            daily_ret, returns, vols, df, dates, n,
            label=f'32f_ret_{horizon}d',
            feature_cols=MODELS['32feat'],
            n_bags_lgb=50, n_bags_xgb=0,
            model_type='lgb',
            lgb_params={'min_data_in_leaf': 12},
            alloc_formula='linear_direct',
            alloc_params={'K': 20},
            target_horizon=horizon)
        if summary:
            results[f'32f_ret_{horizon}d'] = summary

    # Compare
    P(f"\n  PHASE F COMPARISON (baselines: 37f ret_3d +802% S=2.74 | 32f ret_3d +711% S=2.62):")
    P(f"  {'Config':<30} {'Mean':>8} {'Spread':>8} {'Sortino':>8} {'MaxDD':>8}")
    P(f"  {'-'*65}")
    for key, s in results.items():
        beats, wins = _beats_v10(s)
        flag = " *** BEATS V10" if beats else ""
        P(f"  {key:<30} {s['mean']:>+7.1f}% {s['spread']:>7.0f}pp "
          f"{s['sortinos_mean']:>7.2f} {s['max_dds_mean']:>7.1f}%{flag}")

    return results


# ============================================================
# FINAL SUMMARY
# ============================================================

def print_final_summary(all_results):
    P(f"\n\n{'#'*100}")
    P("V11 FINAL SUMMARY — ALL CONFIGS RANKED BY SORTINO")
    P("#" * 100)

    # Collect all configs with their summaries
    variants = []

    # Reference: V10 best
    variants.append(('V10_BEST (reference)', V10_BEST['return_pct'],
                     V10_BEST['spread'], V10_BEST['sortino'], -14.1))

    phase_map = {
        'phase_a': 'A',
        'phase_b': 'B',
        'phase_c': 'C',
        'phase_d': 'D',
        'phase_e': 'E',
        'phase_f': 'F',
    }

    for phase_key, phase_label in phase_map.items():
        phase_data = all_results.get(phase_key, {})
        if isinstance(phase_data, dict) and not phase_data.get('skipped'):
            for config_key, summary in phase_data.items():
                if isinstance(summary, dict) and 'sortinos_mean' in summary:
                    name = f"[{phase_label}] {config_key}"
                    variants.append((name, summary['mean'], summary['spread'],
                                     summary['sortinos_mean'], summary['max_dds_mean']))

    # Sort by Sortino
    variants.sort(key=lambda x: x[3], reverse=True)

    P(f"\n  {'Rank':<5} {'Config':<40} {'Mean':>8} {'Spread':>8} {'Sortino':>8} {'MaxDD':>8} {'Beats V10':>10}")
    P(f"  {'-'*90}")
    for i, (name, mean, spread, sortino, mdd) in enumerate(variants, 1):
        if 'reference' in name:
            beats_str = "REFERENCE"
        else:
            wins = 0
            if sortino >= V10_BEST['sortino']:
                wins += 1
            if spread <= V10_BEST['spread']:
                wins += 1
            if mean >= V10_BEST['return_pct']:
                wins += 1
            beats_str = f"{wins}/3" + (" ***" if wins >= 2 else "")
        P(f"  {i:<5} {name:<40} {mean:>+7.1f}% {spread:>7.0f}pp "
          f"{sortino:>7.2f} {mdd:>7.1f}% {beats_str:>10}")

    # Count configs that beat V10
    n_beats = sum(1 for name, mean, spread, sortino, mdd in variants
                  if 'reference' not in name
                  and sum([sortino >= V10_BEST['sortino'],
                          spread <= V10_BEST['spread'],
                          mean >= V10_BEST['return_pct']]) >= 2)

    P(f"\n  CONFIGS THAT BEAT V10: {n_beats}")

    if n_beats == 0:
        P("  CONCLUSION: No V11 config beats V10 on 2/3 criteria.")
        P("  Pipeline is DONE -- focus shifts to production.")
    else:
        # Find the absolute best
        best = None
        best_sortino = -999
        for name, mean, spread, sortino, mdd in variants:
            if 'reference' in name:
                continue
            wins = sum([sortino >= V10_BEST['sortino'],
                       spread <= V10_BEST['spread'],
                       mean >= V10_BEST['return_pct']])
            if wins >= 2 and sortino > best_sortino:
                best_sortino = sortino
                best = (name, mean, spread, sortino, mdd)

        if best:
            P(f"\n  NEW BEST: {best[0]}")
            P(f"    Mean: {best[1]:+.1f}%, Sortino: {best[3]:.2f}, "
              f"Spread: {best[2]:.0f}pp, MaxDD: {best[4]:.1f}%")


# ============================================================
# MAIN
# ============================================================

def main():
    P("=" * 100)
    P("PIPELINE V11 — XGBoost + Ensemble + Tuning Experiments")
    P(f"  V10 reference: +{V10_BEST['return_pct']}%, "
      f"Sortino {V10_BEST['sortino']}, "
      f"Spread {V10_BEST['spread']}pp")
    P("=" * 100)
    start_time = datetime.now()
    P(f"  Start time: {start_time.strftime('%Y-%m-%d %H:%M:%S')}")

    P("\nLoading data...")
    prices, daily_ret, returns, vols, df = load_data()
    dates = df['date'].values
    n = len(prices)
    P(f"  {n} days | {dates[0]} to {dates[-1]}")

    # Build real CDI
    global RF_DAILY_ARR
    import archive.old_pipelines.pipeline_v09 as v9_module
    import archive.old_pipelines.pipeline_v10 as v10_module
    try:
        from src.features.macro.cdi_rates import build_rf_daily
        RF_DAILY_ARR = build_rf_daily(dates, source='auto')
        v9_module.RF_DAILY_ARR = RF_DAILY_ARR
        v10_module.RF_DAILY_ARR = RF_DAILY_ARR
        rf_mean_annual = (np.prod(1 + RF_DAILY_ARR[-365:]) - 1) * 100
        P(f"  RF: Real CDI loaded ({RF_DAILY_ARR.shape[0]} days, "
          f"last-year ~{rf_mean_annual:.1f}%)")
    except Exception:
        from src.features.macro.cdi_rates import build_rf_daily
        RF_DAILY_ARR = build_rf_daily(dates, source='copom')
        v9_module.RF_DAILY_ARR = RF_DAILY_ARR
        v10_module.RF_DAILY_ARR = RF_DAILY_ARR
        P(f"  RF: COPOM fallback loaded")

    # Validate features
    for model_name, feat_list in MODELS.items():
        valid = [f for f in feat_list if f in df.columns or f in
                 ['ret_3d','ret_5d','ret_7d','ret_10d','ret_14d','ret_30d',
                  'ret_45d','ret_60d','vol_7d','vol_14d','vol_30d']]
        P(f"  {model_name}: {len(valid)}/{len(feat_list)} features available")

    # Check XGBoost version
    P(f"  XGBoost version: {xgb.__version__}")
    P(f"  LightGBM version: {lgb.__version__}")

    all_results = {
        'timestamp': start_time.isoformat(),
        'method': 'pipeline_v11',
        'test_period': '2022-2026',
        'v10_reference': V10_BEST,
        'models': {k: v for k, v in MODELS.items()},
    }

    # ========================================
    # PHASE A: XGBoost drop-in comparison
    # ========================================
    P(f"\n  Starting Phase A... ({datetime.now().strftime('%H:%M:%S')})")
    phase_a_results = phase_a(daily_ret, returns, vols, df, dates, n)
    all_results['phase_a'] = phase_a_results
    _save(all_results)

    # ========================================
    # PHASE B: Hybrid LGB + XGB ensemble
    # ========================================
    P(f"\n  Starting Phase B... ({datetime.now().strftime('%H:%M:%S')})")
    phase_b_results = phase_b(daily_ret, returns, vols, df, dates, n, phase_a_results)
    all_results['phase_b'] = phase_b_results
    _save(all_results)

    # ========================================
    # PHASE C: Bag count optimization
    # ========================================
    P(f"\n  Starting Phase C... ({datetime.now().strftime('%H:%M:%S')})")
    phase_c_results = phase_c(daily_ret, returns, vols, df, dates, n)
    all_results['phase_c'] = phase_c_results
    _save(all_results)

    # ========================================
    # PHASE D: K fine-tuning
    # ========================================
    P(f"\n  Starting Phase D... ({datetime.now().strftime('%H:%M:%S')})")
    phase_d_results = phase_d(daily_ret, returns, vols, df, dates, n)
    all_results['phase_d'] = phase_d_results
    _save(all_results)

    # ========================================
    # PHASE E: Prediction smoothing
    # ========================================
    P(f"\n  Starting Phase E... ({datetime.now().strftime('%H:%M:%S')})")
    phase_e_results = phase_e(daily_ret, returns, vols, df, dates, n)
    all_results['phase_e'] = phase_e_results
    _save(all_results)

    # ========================================
    # PHASE F: Target horizon sweep
    # ========================================
    P(f"\n  Starting Phase F... ({datetime.now().strftime('%H:%M:%S')})")
    phase_f_results = phase_f(daily_ret, returns, vols, df, dates, n)
    all_results['phase_f'] = phase_f_results
    _save(all_results)

    # ========================================
    # FINAL SUMMARY
    # ========================================
    print_final_summary(all_results)

    elapsed = (datetime.now() - start_time).total_seconds() / 3600
    all_results['elapsed_hours'] = float(elapsed)
    _save(all_results)

    P(f"\n{'='*100}")
    P(f"V11 PIPELINE COMPLETE")
    P(f"  End time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    P(f"  Elapsed: {elapsed:.1f}h")
    P(f"  Results: {RESULTS_PATH}")
    P("=" * 100)


if __name__ == '__main__':
    main()
