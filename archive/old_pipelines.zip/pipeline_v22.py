"""
Pipeline V22 — CORRECTED METRICS
BTC Allocation Strategy using XGBoost

Changes vs V21:
  1. Sortino fix: Sortino & Price (1994) standard formula
     DD = sqrt( (1/N) * Σ min(excess_i, 0)² ) — uses ALL days, not just negatives
  2. Reports Sortino (both formulas) + Sharpe
  3. Model/training/allocations IDENTICAL to V21
  4. Early stopping tested and discarded (stops at 10-20 trees, underfits badly)

Usage:
    python scripts/optimization/pipeline_v22.py              # 10 seeds (default)
    python scripts/optimization/pipeline_v22.py --seeds 1    # Quick single-seed
"""
import sys, gc, json, argparse, numpy as np, pandas as pd
from pathlib import Path
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
import warnings; warnings.filterwarnings('ignore')
sys.stdout.reconfigure(line_buffering=True)

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

from archive.old_pipelines.pipeline_v09 import (
    load_data, build_ml_features, backtest_allocations,
    COST, P, convert_numpy,
)
from archive.old_pipelines.pipeline_v10 import MODELS
from archive.old_pipelines.pipeline_v13 import _get_retrain_periods, _train_one_xgb


# ═══════════════════════════════════════════════════════════════════════
# CONFIGURATION — IDENTICAL TO V21
# ═══════════════════════════════════════════════════════════════════════

XGB_PARAMS = {
    'max_leaves': 31,
    'grow_policy': 'lossguide',
    'tree_method': 'hist',
    'colsample_bytree': 0.5,
    'subsample': 0.8,
    'learning_rate': 0.05,
    'min_child_weight': 12,
    'n_estimators': 200,
    'objective': 'reg:squarederror',
    'verbosity': 0,
    'nthread': 1,
}

K_REGIME = {'BULL': 50, 'MILD': 30, 'BEAR': 15}
ALLOC_MIN = -0.25
ALLOC_MAX = 1.0
BAGS = 80
HORIZON = 3
RETRAIN = 'semi'
REBAL_DOW = [4]
EMERGENCY_THRESHOLD = 0.08
WORKERS = 16

BASE_FEATURES = [f for f in MODELS['37feat'] if f != 'exchange_netflow_ma7'] + ['basis_pct']
EXTRA_FEATURES = [
    'fed_balance_sheet', 'futures_trade_count',
    'vol_x_regime_duration', 'velocity', 'hash_rate_pctchg_30d',
]


# ═══════════════════════════════════════════════════════════════════════
# V22 FIX: CORRECTED METRICS (Sortino & Price 1994)
# ═══════════════════════════════════════════════════════════════════════

def metrics_v22(s, b, a, rf_daily=None):
    """Sortino & Price (1994) standard + Sharpe.

    Downside deviation = sqrt( (1/N) * Σ min(excess_i, 0)² )
    Uses ALL observations. Positive excess returns contribute zero.
    """
    if len(s) < 10:
        return None
    if rf_daily is None:
        rf_daily = 0.0

    ts = np.prod(1 + s) - 1
    tb = np.prod(1 + b) - 1
    ex = s - rf_daily

    # CORRECT Sortino (Sortino & Price 1994)
    downside = np.minimum(ex, 0.0)
    dd_std = np.sqrt(np.mean(downside ** 2))
    sortino = np.mean(ex) / (dd_std + 1e-10) * np.sqrt(365)

    # V21 formula (for comparison)
    ds = ex[ex < 0]
    sortino_v21 = np.mean(ex) / (np.std(ds) + 1e-10) * np.sqrt(365) if len(ds) > 0 else 0

    # Sharpe
    sharpe = np.mean(ex) / (np.std(s) + 1e-10) * np.sqrt(365)

    # Max drawdown
    cum = np.cumprod(1 + s)
    pk = np.maximum.accumulate(cum)
    max_dd = np.min((cum - pk) / (pk + 1e-10))

    calmar = ts / (abs(max_dd) + 1e-10)

    return {
        'total': ts, 'btc': tb, 'excess': ts - tb,
        'sortino': sortino, 'sortino_v21': sortino_v21, 'sharpe': sharpe,
        'calmar': calmar, 'max_dd': max_dd,
        'short_pct': float((a < 0).mean()), 'avg_alloc': float(np.mean(a)),
    }


# ═══════════════════════════════════════════════════════════════════════
# FUNCTIONS — IDENTICAL TO V21
# ═══════════════════════════════════════════════════════════════════════

def get_regime(t, prices, sma50, sma200):
    if np.isnan(sma50[t]) or np.isnan(sma200[t]):
        return 'MILD'
    if prices[t] > sma50[t] and sma50[t] > sma200[t]:
        return 'BULL'
    elif prices[t] > sma200[t]:
        return 'MILD'
    return 'BEAR'


def compute_allocation(prediction, regime):
    K = K_REGIME[regime]
    return np.clip(prediction * K, ALLOC_MIN, ALLOC_MAX)


def run_single_seed(seed, X_all, target, prices, daily_ret, dates, periods,
                    dow, sma50, sma200, rf_daily, n):
    full_allocs = np.full(n, 0.0)
    prev_alloc = 0.0
    a_s, a_b, a_a, a_r = [], [], [], []

    for te, ts, tend in periods:
        gap = max(HORIZON, 5)
        tm = np.arange(60, te - gap + 1)
        valid = ~np.any(np.isnan(X_all[tm]), axis=1)
        idx = tm[valid]
        if len(idx) < 100:
            continue

        Xt = np.nan_to_num(X_all[idx], nan=0.0)
        yt = target[idx]

        bag_seeds = [seed + i * 7 for i in range(BAGS)]
        with ThreadPoolExecutor(max_workers=WORKERS) as ex:
            models = list(ex.map(_train_one_xgb,
                [(s, Xt, yt, XGB_PARAMS) for s in bag_seeds]))

        for t in range(ts, tend + 1):
            is_rebal = dow[t] in REBAL_DOW
            is_emerg = t > 0 and abs(daily_ret[t]) > EMERGENCY_THRESHOLD
            if not is_rebal and not is_emerg:
                full_allocs[t] = prev_alloc
                continue

            x_t = np.nan_to_num(X_all[t:t + 1].copy(), nan=0.0)
            prediction = float(np.mean([m.predict(x_t)[0] for m in models]))
            regime = get_regime(t, prices, sma50, sma200)
            full_allocs[t] = compute_allocation(prediction, regime)
            prev_alloc = full_allocs[t]

        s, b, a = backtest_allocations(daily_ret, full_allocs, ts, tend,
                                       cost=COST, rf_daily=rf_daily)
        a_s.extend(s)
        a_b.extend(b)
        a_a.extend(a)
        a_r.extend(rf_daily[ts:ts + len(s)])

        del models
        gc.collect()

    return metrics_v22(np.array(a_s), np.array(a_b), np.array(a_a),
                       rf_daily=np.array(a_r))


# ═══════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(description='Pipeline V22 — Corrected Metrics')
    parser.add_argument('--seeds', type=int, default=10, help='Number of seeds (default: 10)')
    args = parser.parse_args()

    num_seeds = args.seeds
    seeds = [42 + i * 100 for i in range(num_seeds)]

    P("=" * 80)
    P("PIPELINE V22 — CORRECTED METRICS (Sortino & Price 1994)")
    P("=" * 80)
    P(f"  XGBoost Bag{BAGS} | colsample={XGB_PARAMS['colsample_bytree']} | "
      f"lr={XGB_PARAMS['learning_rate']} | n_est={XGB_PARAMS['n_estimators']}")
    P(f"  Horizon: {HORIZON}d | Retrain: {RETRAIN}-annual | "
      f"Rebalance: Friday + emergency {EMERGENCY_THRESHOLD*100:.0f}%")
    P(f"  K: BULL={K_REGIME['BULL']}, MILD={K_REGIME['MILD']}, BEAR={K_REGIME['BEAR']}")
    P(f"  Seeds: {num_seeds}")
    P(f"  Sortino: sqrt( (1/N) * Σ min(excess_i, 0)² ) — all days, not just negatives")
    P("")

    start = datetime.now()

    P("Loading data...")
    prices, daily_ret, returns, vols, df = load_data()
    dates = df['date'].values
    n = len(prices)
    P(f"  {n} days | {dates[0]} to {dates[-1]}")

    try:
        from src.features.macro.cdi_rates import build_rf_daily
        rf_daily = build_rf_daily(dates, source='auto')
    except Exception:
        from src.features.macro.cdi_rates import build_rf_daily
        rf_daily = build_rf_daily(dates, source='copom')

    import archive.old_pipelines.pipeline_v09 as v9m
    import archive.old_pipelines.pipeline_v13 as v13m
    v9m.RF_DAILY_ARR = rf_daily
    v13m.RF_DAILY_ARR = rf_daily

    fc = BASE_FEATURES + [f for f in EXTRA_FEATURES if f not in BASE_FEATURES]
    fc = [f for f in fc if f in df.columns]
    P(f"  {len(fc)} features")

    X_all, _ = build_ml_features(df, returns, vols, n, feature_cols=fc)

    target = np.zeros(n)
    for i in range(n - HORIZON):
        target[i] = (prices[i + HORIZON] - prices[i]) / prices[i]

    dow = pd.to_datetime(dates).dayofweek
    periods = _get_retrain_periods(dates, n, RETRAIN)
    sma50 = pd.Series(prices).rolling(50).mean().values
    sma200 = pd.Series(prices).rolling(200).mean().values

    P("")
    P("Running backtest...")
    all_metrics = []

    for si, seed in enumerate(seeds):
        P(f"  Seed {seed} ({si+1}/{num_seeds})...")
        m = run_single_seed(seed, X_all, target, prices, daily_ret, dates,
                           periods, dow, sma50, sma200, rf_daily, n)
        all_metrics.append(m)
        P(f"    Sortino={m['sortino']:.2f} (V21={m['sortino_v21']:.2f})  "
          f"Sharpe={m['sharpe']:.2f}  Return={m['total']*100:+.0f}%  "
          f"MaxDD={m['max_dd']*100:.1f}%")

    elapsed = (datetime.now() - start).total_seconds() / 60

    sortinos = [m['sortino'] for m in all_metrics]
    sortinos_v21 = [m['sortino_v21'] for m in all_metrics]
    sharpes = [m['sharpe'] for m in all_metrics]
    rets = [m['total'] * 100 for m in all_metrics]
    dds = [m['max_dd'] * 100 for m in all_metrics]

    P("")
    P("=" * 80)
    P(f"RESULTS — V22 — {num_seeds} seeds ({elapsed:.0f} min)")
    P("=" * 80)
    P("")
    P(f"  Sortino (V22 correct):  {np.mean(sortinos):.2f} +/- {np.std(sortinos):.2f}")
    P(f"  Sortino (V21 formula):  {np.mean(sortinos_v21):.2f} +/- {np.std(sortinos_v21):.2f}")
    P(f"  Sharpe:                 {np.mean(sharpes):.2f} +/- {np.std(sharpes):.2f}")
    P(f"  Return:   {np.mean(rets):+.0f}% +/- {np.std(rets):.0f}%")
    P(f"            min={np.min(rets):+.0f}%  median={np.median(rets):+.0f}%  "
      f"max={np.max(rets):+.0f}%")
    P(f"  MaxDD:    {np.mean(dds):.1f}% +/- {np.std(dds):.1f}%")
    P(f"  Elapsed:  {elapsed:.1f} min")

    output = {
        'pipeline': 'V22',
        'timestamp': datetime.now().isoformat(),
        'elapsed_min': elapsed,
        'n_seeds': num_seeds,
        'changes_vs_v21': [
            'Sortino: Sortino & Price (1994) — sqrt(1/N * Σ min(ex,0)²), all days',
            'V21 used std(negatives_only) which inflates by centering on mean of negatives',
            'Added Sharpe ratio',
            'Early stopping tested (patience 10-50) and discarded — underfits at 10-20 trees',
            'Model/training/allocations IDENTICAL to V21',
        ],
        'params': {
            'xgb': {k: v for k, v in XGB_PARAMS.items()
                    if k not in ['objective', 'verbosity', 'nthread', 'tree_method']},
            'bags': BAGS,
            'horizon': HORIZON,
            'retrain': RETRAIN,
            'rebal_dow': REBAL_DOW,
            'emergency_threshold': EMERGENCY_THRESHOLD,
            'K_regime': K_REGIME,
            'alloc_range': [ALLOC_MIN, ALLOC_MAX],
            'n_features': len(fc),
            'features': fc,
        },
        'results': {
            'sortino_avg': float(np.mean(sortinos)),
            'sortino_std': float(np.std(sortinos)),
            'sortino_v21_avg': float(np.mean(sortinos_v21)),
            'sortino_v21_std': float(np.std(sortinos_v21)),
            'sharpe_avg': float(np.mean(sharpes)),
            'sharpe_std': float(np.std(sharpes)),
            'return_avg': float(np.mean(rets)),
            'return_std': float(np.std(rets)),
            'max_dd_avg': float(np.mean(dds)),
            'max_dd_std': float(np.std(dds)),
        },
        'seed_results': [
            {
                'seed': seeds[i],
                'sortino': float(sortinos[i]),
                'sortino_v21': float(sortinos_v21[i]),
                'sharpe': float(sharpes[i]),
                'return_pct': float(rets[i]),
                'max_dd_pct': float(dds[i]),
            }
            for i in range(num_seeds)
        ],
    }

    out_path = ROOT / 'outputs' / 'results' / 'pipeline_v22_sortino_audit.json'
    with open(out_path, 'w') as f:
        json.dump(output, f, indent=2, default=convert_numpy)
    P(f"\n  Saved: {out_path}")


if __name__ == '__main__':
    main()
