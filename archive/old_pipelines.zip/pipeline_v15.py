"""
PIPELINE V15 — Genuinely New Approaches
=========================================

V13/V14 re-optimize the same heuristic (LGB+XGB regression → linear allocation).
V15 tests fundamentally DIFFERENT approaches never tried:

  Track 1: Multi-Timeframe Signals — combine 3d + 7d + 14d targets (2h)
  Track 2: Stacking Meta-Learner — LGB predicts on XGB predictions (1.5h)
  Track 3: Regime-Aware Models — different K/allocation per market regime (2h)
  Track 4: Ensemble Weighting — weight models by recent accuracy, not equal (1.5h)
  Track 5: Classification Target — predict direction instead of magnitude (2h)
  Track 6: Best Combo — assemble winners from Tracks 1-5 (1h)

Uses N_WORKERS=8 (separate from V14 running on other 8 cores).
Total: ~10h
"""

import sys
import gc
import pandas as pd
import numpy as np
from pathlib import Path
import warnings
import json
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
import lightgbm as lgb
import xgboost as xgb

warnings.filterwarnings('ignore')
sys.stdout.reconfigure(line_buffering=True)

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

from scripts.optimization.pipeline_v9 import (
    load_data, build_ml_features,
    backtest_allocations, metrics, get_year_boundaries,
    SEEDS_10, COST, DEFAULT_LGB_PARAMS,
    P, _seed_summary, convert_numpy,
)
from scripts.optimization.pipeline_v10_mega import (
    MODELS, _compute_allocation,
)
from scripts.optimization.pipeline_v11_xgb import DEFAULT_XGB_PARAMS
from scripts.optimization.pipeline_v13_definitive import (
    _get_retrain_periods, _train_one_lgb, _train_one_xgb,
)

RF_DAILY_ARR = None
RESULTS_PATH = ROOT / 'outputs/results/pipeline_v15_new_approaches.json'
V15_WORKERS = 8  # use only 8 cores (other 8 for V14)


def _save(R):
    RESULTS_PATH.parent.mkdir(parents=True, exist_ok=True)
    RESULTS_PATH.write_text(json.dumps(convert_numpy(R), indent=2, default=str), encoding='utf-8')
    P(f"  [SAVE] {RESULTS_PATH.name}")


# ============================================================
# CLEAN FEATURE SET (from V14 diagnostic)
# ============================================================

def get_clean_feats():
    """37feat - exchange_netflow_ma7 + basis_pct"""
    return [f for f in MODELS['37feat'] if f != 'exchange_netflow_ma7'] + ['basis_pct']


# ============================================================
# ENGINE: MULTI-TIMEFRAME
# ============================================================

def run_multi_timeframe(daily_ret, returns, vols, df, dates, n,
                        feature_cols, n_bags_lgb=15, n_bags_xgb=30,
                        base_seed=42, alloc_params=None, retrain_freq='semi',
                        horizons=(3, 7, 14), horizon_weights=(0.5, 0.3, 0.2)):
    """Train separate models for each horizon, blend predictions."""
    if alloc_params is None:
        alloc_params = {'K': 30}

    prices = df['price_usd'].values
    X_all, _ = build_ml_features(df, returns, vols, n, feature_cols=feature_cols)
    day_of_week = pd.to_datetime(dates).dayofweek

    lgb_p = dict(DEFAULT_LGB_PARAMS)
    lgb_p['min_data_in_leaf'] = 12
    xgb_p = dict(DEFAULT_XGB_PARAMS)

    # Build targets for each horizon
    targets = {}
    for h in horizons:
        t = np.zeros(n)
        for i in range(n - h):
            t[i] = (prices[i + h] - prices[i]) / prices[i]
        targets[h] = t

    periods = _get_retrain_periods(dates, n, retrain_freq)
    full_allocs = np.full(n, 0.5)
    is_rf_arr = isinstance(RF_DAILY_ARR, np.ndarray)
    all_strat, all_btc, all_alloc, all_rf = [], [], [], []

    for train_end, test_start, test_end in periods:
        gap = 5
        train_mask = np.arange(60, train_end - gap + 1)

        # Train models for each horizon
        all_models = {}
        for h in horizons:
            valid = ~np.any(np.isnan(X_all[train_mask]), axis=1)
            idx = train_mask[valid]
            if len(idx) < 100:
                continue
            Xt = np.nan_to_num(X_all[idx], nan=0.0)
            yt = targets[h][idx]

            n_lgb = n_bags_lgb // len(horizons) + (1 if n_bags_lgb % len(horizons) > 0 else 0)
            n_xgb = n_bags_xgb // len(horizons) + (1 if n_bags_xgb % len(horizons) > 0 else 0)

            models_h = []
            seeds_l = [base_seed + h * 100 + i * 7 for i in range(n_lgb)]
            args = [(s, Xt, yt, lgb_p) for s in seeds_l]
            with ThreadPoolExecutor(max_workers=V15_WORKERS) as ex:
                models_h.extend(list(ex.map(_train_one_lgb, args)))

            seeds_x = [base_seed + h * 100 + i * 7 for i in range(n_xgb)]
            args = [(s, Xt, yt, xgb_p) for s in seeds_x]
            with ThreadPoolExecutor(max_workers=V15_WORKERS) as ex:
                models_h.extend(list(ex.map(_train_one_xgb, args)))

            all_models[h] = models_h

        if not any(all_models.values()):
            continue

        prev_alloc = 0.5
        for t in range(test_start, test_end + 1):
            x_t = np.nan_to_num(X_all[t:t + 1].copy(), nan=0.0)

            # Blend predictions across horizons
            blended_pred = 0.0
            total_weight = 0.0
            for h, w in zip(horizons, horizon_weights):
                if h not in all_models or not all_models[h]:
                    continue
                preds = []
                for m in all_models[h]:
                    preds.append(m.predict(x_t)[0])
                # Normalize by horizon (longer horizons have larger predictions)
                blended_pred += w * np.mean(preds) / (h / 3.0)
                total_weight += w

            if total_weight > 0:
                blended_pred /= total_weight

            raw = _compute_allocation(blended_pred, 0.05, 'linear_direct', alloc_params)
            if day_of_week[t] != 4:
                raw = prev_alloc
            full_allocs[t] = np.clip(raw, -0.25, 1.0)
            prev_alloc = full_allocs[t]

        s, b, a = backtest_allocations(daily_ret, full_allocs, test_start, test_end,
                                       cost=COST, rf_daily=RF_DAILY_ARR)
        all_strat.extend(s); all_btc.extend(b); all_alloc.extend(a)
        nd = len(s)
        if is_rf_arr:
            all_rf.extend(RF_DAILY_ARR[test_start:test_start + nd])
        else:
            all_rf.extend([0.0] * nd)

    return metrics(np.array(all_strat), np.array(all_btc), np.array(all_alloc),
                   rf_daily=np.array(all_rf))


# ============================================================
# ENGINE: STACKING META-LEARNER
# ============================================================

def run_stacking(daily_ret, returns, vols, df, dates, n,
                 feature_cols, n_bags_lgb=15, n_bags_xgb=30,
                 base_seed=42, alloc_params=None, retrain_freq='semi',
                 meta_model='lgb'):
    """Two-level stacking: base models predict, meta-learner combines.
    Level 1: LGB and XGB predict independently.
    Level 2: Meta-model takes both predictions + raw features → final prediction.
    Uses time-series safe CV: train meta on first half of train, validate on second half.
    """
    if alloc_params is None:
        alloc_params = {'K': 30}

    prices = df['price_usd'].values
    X_all, _ = build_ml_features(df, returns, vols, n, feature_cols=feature_cols)
    day_of_week = pd.to_datetime(dates).dayofweek

    target = np.zeros(n)
    for i in range(n - 3):
        target[i] = (prices[i + 3] - prices[i]) / prices[i]

    lgb_p = dict(DEFAULT_LGB_PARAMS)
    lgb_p['min_data_in_leaf'] = 12
    xgb_p = dict(DEFAULT_XGB_PARAMS)

    periods = _get_retrain_periods(dates, n, retrain_freq)
    full_allocs = np.full(n, 0.5)
    is_rf_arr = isinstance(RF_DAILY_ARR, np.ndarray)
    all_strat, all_btc, all_alloc, all_rf = [], [], [], []

    for train_end, test_start, test_end in periods:
        gap = 5
        train_mask = np.arange(60, train_end - gap + 1)
        valid = ~np.any(np.isnan(X_all[train_mask]), axis=1)
        idx = train_mask[valid]
        if len(idx) < 200:
            continue

        Xt = np.nan_to_num(X_all[idx], nan=0.0)
        yt = target[idx]

        # Split train into base_train (first 70%) and meta_train (last 30%)
        split = int(len(idx) * 0.7)
        base_idx = idx[:split]
        meta_idx = idx[split:]

        Xt_base = np.nan_to_num(X_all[base_idx], nan=0.0)
        yt_base = target[base_idx]
        Xt_meta = np.nan_to_num(X_all[meta_idx], nan=0.0)
        yt_meta = target[meta_idx]

        # Level 1: Train base models on base_train
        seeds_l = [base_seed + i * 7 for i in range(n_bags_lgb)]
        args = [(s, Xt_base, yt_base, lgb_p) for s in seeds_l]
        with ThreadPoolExecutor(max_workers=V15_WORKERS) as ex:
            models_lgb = list(ex.map(_train_one_lgb, args))

        seeds_x = [base_seed + i * 7 for i in range(n_bags_xgb)]
        args = [(s, Xt_base, yt_base, xgb_p) for s in seeds_x]
        with ThreadPoolExecutor(max_workers=V15_WORKERS) as ex:
            models_xgb = list(ex.map(_train_one_xgb, args))

        # Get base predictions on meta_train
        lgb_preds_meta = np.mean([m.predict(Xt_meta) for m in models_lgb], axis=0)
        xgb_preds_meta = np.mean([m.predict(Xt_meta) for m in models_xgb], axis=0)

        # Meta features: base predictions + top 5 raw features
        meta_X = np.column_stack([lgb_preds_meta, xgb_preds_meta,
                                  Xt_meta[:, :5]])

        # Level 2: Train meta-model
        meta_params = {'objective': 'regression', 'metric': 'mae',
                       'num_leaves': 15, 'learning_rate': 0.03,
                       'feature_fraction': 0.8, 'bagging_fraction': 0.8,
                       'bagging_freq': 5, 'verbose': -1, 'n_jobs': 1,
                       'seed': base_seed, 'min_data_in_leaf': 20}
        nr = 100
        meta_ds = lgb.Dataset(meta_X, label=yt_meta)
        meta_model_trained = lgb.train(meta_params, meta_ds, num_boost_round=nr)

        # Now retrain base models on FULL training data
        seeds_l = [base_seed + i * 7 for i in range(n_bags_lgb)]
        args = [(s, Xt, yt, lgb_p) for s in seeds_l]
        with ThreadPoolExecutor(max_workers=V15_WORKERS) as ex:
            models_lgb_full = list(ex.map(_train_one_lgb, args))

        seeds_x = [base_seed + i * 7 for i in range(n_bags_xgb)]
        args = [(s, Xt, yt, xgb_p) for s in seeds_x]
        with ThreadPoolExecutor(max_workers=V15_WORKERS) as ex:
            models_xgb_full = list(ex.map(_train_one_xgb, args))

        prev_alloc = 0.5
        for t in range(test_start, test_end + 1):
            x_t = np.nan_to_num(X_all[t:t + 1].copy(), nan=0.0)

            lgb_pred = np.mean([m.predict(x_t)[0] for m in models_lgb_full])
            xgb_pred = np.mean([m.predict(x_t)[0] for m in models_xgb_full])
            meta_x = np.array([[lgb_pred, xgb_pred] + list(x_t[0, :5])])
            final_pred = meta_model_trained.predict(meta_x)[0]

            raw = _compute_allocation(final_pred, 0.05, 'linear_direct', alloc_params)
            if day_of_week[t] != 4:
                raw = prev_alloc
            full_allocs[t] = np.clip(raw, -0.25, 1.0)
            prev_alloc = full_allocs[t]

        s, b, a = backtest_allocations(daily_ret, full_allocs, test_start, test_end,
                                       cost=COST, rf_daily=RF_DAILY_ARR)
        all_strat.extend(s); all_btc.extend(b); all_alloc.extend(a)
        nd = len(s)
        if is_rf_arr:
            all_rf.extend(RF_DAILY_ARR[test_start:test_start + nd])
        else:
            all_rf.extend([0.0] * nd)

    return metrics(np.array(all_strat), np.array(all_btc), np.array(all_alloc),
                   rf_daily=np.array(all_rf))


# ============================================================
# ENGINE: REGIME-AWARE ALLOCATION
# ============================================================

def run_regime_aware(daily_ret, returns, vols, df, dates, n,
                     feature_cols, n_bags_lgb=15, n_bags_xgb=30,
                     base_seed=42, retrain_freq='semi',
                     K_bull=35, K_neutral=25, K_bear=15):
    """Different K based on detected market regime (trend + volatility)."""
    prices = df['price_usd'].values
    X_all, _ = build_ml_features(df, returns, vols, n, feature_cols=feature_cols)
    day_of_week = pd.to_datetime(dates).dayofweek

    target = np.zeros(n)
    for i in range(n - 3):
        target[i] = (prices[i + 3] - prices[i]) / prices[i]

    # Pre-compute regime indicators
    sma_50 = pd.Series(prices).rolling(50).mean().values
    sma_200 = pd.Series(prices).rolling(200).mean().values
    vol_30 = pd.Series(daily_ret).rolling(30).std().values
    vol_median = np.nanmedian(vol_30)

    lgb_p = dict(DEFAULT_LGB_PARAMS)
    lgb_p['min_data_in_leaf'] = 12
    xgb_p = dict(DEFAULT_XGB_PARAMS)

    periods = _get_retrain_periods(dates, n, retrain_freq)
    full_allocs = np.full(n, 0.5)
    is_rf_arr = isinstance(RF_DAILY_ARR, np.ndarray)
    all_strat, all_btc, all_alloc, all_rf = [], [], [], []

    for train_end, test_start, test_end in periods:
        gap = 5
        train_mask = np.arange(60, train_end - gap + 1)
        valid = ~np.any(np.isnan(X_all[train_mask]), axis=1)
        idx = train_mask[valid]
        if len(idx) < 100:
            continue

        Xt = np.nan_to_num(X_all[idx], nan=0.0)
        yt = target[idx]

        seeds_l = [base_seed + i * 7 for i in range(n_bags_lgb)]
        args = [(s, Xt, yt, lgb_p) for s in seeds_l]
        with ThreadPoolExecutor(max_workers=V15_WORKERS) as ex:
            models_lgb = list(ex.map(_train_one_lgb, args))

        seeds_x = [base_seed + i * 7 for i in range(n_bags_xgb)]
        args = [(s, Xt, yt, xgb_p) for s in seeds_x]
        with ThreadPoolExecutor(max_workers=V15_WORKERS) as ex:
            models_xgb = list(ex.map(_train_one_xgb, args))

        prev_alloc = 0.5
        for t in range(test_start, test_end + 1):
            x_t = np.nan_to_num(X_all[t:t + 1].copy(), nan=0.0)
            preds = []
            for m in models_lgb:
                preds.append(m.predict(x_t)[0])
            for m in models_xgb:
                preds.append(m.predict(x_t)[0])
            avg_pred = np.mean(preds)

            # Detect regime
            if t >= 200 and not np.isnan(sma_50[t]) and not np.isnan(sma_200[t]):
                price_above_sma200 = prices[t] > sma_200[t]
                sma50_above_sma200 = sma_50[t] > sma_200[t]
                high_vol = vol_30[t] > vol_median * 1.5 if not np.isnan(vol_30[t]) else False

                if sma50_above_sma200 and price_above_sma200 and not high_vol:
                    K = K_bull
                elif not sma50_above_sma200 or high_vol:
                    K = K_bear
                else:
                    K = K_neutral
            else:
                K = K_neutral

            raw = _compute_allocation(avg_pred, 0.05, 'linear_direct', {'K': K})
            if day_of_week[t] != 4:
                raw = prev_alloc
            full_allocs[t] = np.clip(raw, -0.25, 1.0)
            prev_alloc = full_allocs[t]

        s, b, a = backtest_allocations(daily_ret, full_allocs, test_start, test_end,
                                       cost=COST, rf_daily=RF_DAILY_ARR)
        all_strat.extend(s); all_btc.extend(b); all_alloc.extend(a)
        nd = len(s)
        if is_rf_arr:
            all_rf.extend(RF_DAILY_ARR[test_start:test_start + nd])
        else:
            all_rf.extend([0.0] * nd)

    return metrics(np.array(all_strat), np.array(all_btc), np.array(all_alloc),
                   rf_daily=np.array(all_rf))


# ============================================================
# ENGINE: WEIGHTED ENSEMBLE (by recent performance)
# ============================================================

def run_weighted_ensemble(daily_ret, returns, vols, df, dates, n,
                          feature_cols, n_bags_lgb=15, n_bags_xgb=30,
                          base_seed=42, alloc_params=None, retrain_freq='semi',
                          method='trimmed_mean', trim_pct=0.1):
    """Ensemble with non-equal weighting: trimmed mean, median, or ranked."""
    if alloc_params is None:
        alloc_params = {'K': 30}

    prices = df['price_usd'].values
    X_all, _ = build_ml_features(df, returns, vols, n, feature_cols=feature_cols)
    day_of_week = pd.to_datetime(dates).dayofweek

    target = np.zeros(n)
    for i in range(n - 3):
        target[i] = (prices[i + 3] - prices[i]) / prices[i]

    lgb_p = dict(DEFAULT_LGB_PARAMS)
    lgb_p['min_data_in_leaf'] = 12
    xgb_p = dict(DEFAULT_XGB_PARAMS)

    periods = _get_retrain_periods(dates, n, retrain_freq)
    full_allocs = np.full(n, 0.5)
    is_rf_arr = isinstance(RF_DAILY_ARR, np.ndarray)
    all_strat, all_btc, all_alloc, all_rf = [], [], [], []

    for train_end, test_start, test_end in periods:
        gap = 5
        train_mask = np.arange(60, train_end - gap + 1)
        valid = ~np.any(np.isnan(X_all[train_mask]), axis=1)
        idx = train_mask[valid]
        if len(idx) < 100:
            continue

        Xt = np.nan_to_num(X_all[idx], nan=0.0)
        yt = target[idx]

        seeds_l = [base_seed + i * 7 for i in range(n_bags_lgb)]
        args = [(s, Xt, yt, lgb_p) for s in seeds_l]
        with ThreadPoolExecutor(max_workers=V15_WORKERS) as ex:
            models_lgb = list(ex.map(_train_one_lgb, args))

        seeds_x = [base_seed + i * 7 for i in range(n_bags_xgb)]
        args = [(s, Xt, yt, xgb_p) for s in seeds_x]
        with ThreadPoolExecutor(max_workers=V15_WORKERS) as ex:
            models_xgb = list(ex.map(_train_one_xgb, args))

        all_models = models_lgb + models_xgb

        prev_alloc = 0.5
        for t in range(test_start, test_end + 1):
            x_t = np.nan_to_num(X_all[t:t + 1].copy(), nan=0.0)
            preds = [m.predict(x_t)[0] for m in all_models]

            if method == 'median':
                avg_pred = np.median(preds)
            elif method == 'trimmed_mean':
                sorted_p = sorted(preds)
                trim_n = max(1, int(len(sorted_p) * trim_pct))
                avg_pred = np.mean(sorted_p[trim_n:-trim_n]) if trim_n < len(sorted_p)//2 else np.mean(preds)
            else:
                avg_pred = np.mean(preds)

            raw = _compute_allocation(avg_pred, 0.05, 'linear_direct', alloc_params)
            if day_of_week[t] != 4:
                raw = prev_alloc
            full_allocs[t] = np.clip(raw, -0.25, 1.0)
            prev_alloc = full_allocs[t]

        s, b, a = backtest_allocations(daily_ret, full_allocs, test_start, test_end,
                                       cost=COST, rf_daily=RF_DAILY_ARR)
        all_strat.extend(s); all_btc.extend(b); all_alloc.extend(a)
        nd = len(s)
        if is_rf_arr:
            all_rf.extend(RF_DAILY_ARR[test_start:test_start + nd])
        else:
            all_rf.extend([0.0] * nd)

    return metrics(np.array(all_strat), np.array(all_btc), np.array(all_alloc),
                   rf_daily=np.array(all_rf))


# ============================================================
# ENGINE: CLASSIFICATION TARGET
# ============================================================

def run_classification(daily_ret, returns, vols, df, dates, n,
                       feature_cols, n_bags_lgb=15, n_bags_xgb=30,
                       base_seed=42, alloc_params=None, retrain_freq='semi',
                       threshold=0.0):
    """Binary classification: predict UP/DOWN, then use probability for allocation.
    threshold: if > 0, only predict UP if return > threshold (filter noise).
    """
    if alloc_params is None:
        alloc_params = {'K': 30}

    prices = df['price_usd'].values
    X_all, _ = build_ml_features(df, returns, vols, n, feature_cols=feature_cols)
    day_of_week = pd.to_datetime(dates).dayofweek

    # Binary target: 1 if 3-day return > threshold
    target_cls = np.zeros(n)
    for i in range(n - 3):
        ret_3d = (prices[i + 3] - prices[i]) / prices[i]
        target_cls[i] = 1.0 if ret_3d > threshold else 0.0

    lgb_cls_params = {
        'objective': 'binary', 'metric': 'binary_logloss',
        'num_leaves': 31, 'learning_rate': 0.05,
        'feature_fraction': 0.7, 'bagging_fraction': 0.8,
        'bagging_freq': 5, 'verbose': -1, 'n_jobs': 1,
        'min_data_in_leaf': 12,
    }

    xgb_cls_params = dict(DEFAULT_XGB_PARAMS)
    xgb_cls_params['objective'] = 'binary:logistic'
    xgb_cls_params['eval_metric'] = 'logloss'

    periods = _get_retrain_periods(dates, n, retrain_freq)
    full_allocs = np.full(n, 0.5)
    is_rf_arr = isinstance(RF_DAILY_ARR, np.ndarray)
    all_strat, all_btc, all_alloc, all_rf = [], [], [], []

    for train_end, test_start, test_end in periods:
        gap = 5
        train_mask = np.arange(60, train_end - gap + 1)
        valid = ~np.any(np.isnan(X_all[train_mask]), axis=1)
        idx = train_mask[valid]
        if len(idx) < 100:
            continue

        Xt = np.nan_to_num(X_all[idx], nan=0.0)
        yt = target_cls[idx]

        # LGB classifiers
        models_lgb = []
        for i in range(n_bags_lgb):
            seed = base_seed + i * 7
            p = dict(lgb_cls_params)
            p['seed'] = seed
            nr = 200
            ds = lgb.Dataset(Xt, label=yt)
            models_lgb.append(lgb.train(p, ds, num_boost_round=nr))

        # XGB classifiers
        models_xgb = []
        for i in range(n_bags_xgb):
            seed = base_seed + i * 7
            p = dict(xgb_cls_params)
            p['random_state'] = seed
            ne = p.pop('n_estimators', 200)
            m = xgb.XGBClassifier(n_estimators=ne, use_label_encoder=False, **p)
            m.fit(Xt, yt)
            models_xgb.append(m)

        prev_alloc = 0.5
        for t in range(test_start, test_end + 1):
            x_t = np.nan_to_num(X_all[t:t + 1].copy(), nan=0.0)

            # Get probability of UP
            probs = []
            for m in models_lgb:
                probs.append(m.predict(x_t)[0])  # LGB binary returns probability
            for m in models_xgb:
                probs.append(m.predict_proba(x_t)[0, 1])

            prob_up = np.mean(probs)

            # Map probability to allocation: 0.5 → neutral, 1.0 → full long, 0.0 → short
            K = alloc_params.get('K', 30)
            # Scale: prob=0.5 → alloc=0.375 (neutral), prob=1.0 → alloc=1.0, prob=0.0 → alloc=-0.25
            alloc = -0.25 + 1.25 * prob_up  # linear mapping [0,1] → [-0.25, 1.0]

            if day_of_week[t] != 4:
                alloc = prev_alloc
            full_allocs[t] = np.clip(alloc, -0.25, 1.0)
            prev_alloc = full_allocs[t]

        s, b, a = backtest_allocations(daily_ret, full_allocs, test_start, test_end,
                                       cost=COST, rf_daily=RF_DAILY_ARR)
        all_strat.extend(s); all_btc.extend(b); all_alloc.extend(a)
        nd = len(s)
        if is_rf_arr:
            all_rf.extend(RF_DAILY_ARR[test_start:test_start + nd])
        else:
            all_rf.extend([0.0] * nd)

    return metrics(np.array(all_strat), np.array(all_btc), np.array(all_alloc),
                   rf_daily=np.array(all_rf))


# ============================================================
# HELPER: run 10 seeds with any engine
# ============================================================

def _seeds_engine(engine_fn, daily_ret, returns, vols, df, dates, n, label, **kw):
    results = []
    for seed in SEEDS_10:
        P(f"    seed={seed}...", end="")
        r = engine_fn(daily_ret, returns, vols, df, dates, n, base_seed=seed, **kw)
        if r:
            results.append(r)
            P(f" {r['total']*100:+.1f}% S={r['sortino']:.2f}")
        else:
            P(" FAILED")
        gc.collect()
    if not results:
        return None
    rets = [r['total']*100 for r in results]
    s = _seed_summary(rets, results)
    P(f"    {label}: mean={s['mean']:+.1f}%, S={s['sortinos_mean']:.2f}, "
      f"spread={s['spread']:.0f}pp, MaxDD={s['max_dds_mean']:.1f}%")
    return s


# ============================================================
# MAIN
# ============================================================

def main():
    P("=" * 100)
    P("PIPELINE V15 — GENUINELY NEW APPROACHES")
    P("=" * 100)
    start = datetime.now()
    P(f"  Start: {start.strftime('%Y-%m-%d %H:%M:%S')}")
    P(f"  Using {V15_WORKERS} cores (parallel with V14 on other 8)")

    P("\nLoading data...")
    prices, daily_ret, returns, vols, df = load_data()
    dates = df['date'].values
    n = len(prices)
    P(f"  {n} days | {dates[0]} to {dates[-1]}")

    global RF_DAILY_ARR
    import scripts.optimization.pipeline_v9 as v9m
    import scripts.optimization.pipeline_v10_mega as v10m
    import scripts.optimization.pipeline_v11_xgb as v11m
    import scripts.optimization.pipeline_v12_hybrid as v12m
    import scripts.optimization.pipeline_v13_definitive as v13m
    try:
        from src.features.macro.cdi_rates import build_rf_daily
        RF_DAILY_ARR = build_rf_daily(dates, source='auto')
    except Exception:
        from src.features.macro.cdi_rates import build_rf_daily
        RF_DAILY_ARR = build_rf_daily(dates, source='copom')
    v9m.RF_DAILY_ARR = RF_DAILY_ARR
    v10m.RF_DAILY_ARR = RF_DAILY_ARR
    v11m.RF_DAILY_ARR = RF_DAILY_ARR
    v12m.RF_DAILY_ARR = RF_DAILY_ARR
    v13m.RF_DAILY_ARR = RF_DAILY_ARR

    fc = get_clean_feats()
    P(f"  Features: {len(fc)} (clean, no exchange_netflow_ma7)")

    R = {'timestamp': start.isoformat(), 'method': 'pipeline_v15_new_approaches'}

    # ========================================
    # BASELINE (V13 config on new data)
    # ========================================
    from scripts.optimization.pipeline_v13_definitive import run_v13
    P(f"\n{'#'*100}")
    P("BASELINE: V13 config on new data (for comparison)")
    P("#" * 100)
    baseline = _seeds_engine(
        run_v13, daily_ret, returns, vols, df, dates, n, label='baseline',
        feature_cols=fc, n_bags_lgb=15, n_bags_xgb=30,
        lgb_params={'min_data_in_leaf': 12},
        alloc_formula='linear_direct', alloc_params={'K': 30},
        retrain_freq='semi', rebal_day=4, rebal_threshold=0.0)
    if baseline:
        R['baseline'] = baseline
        P(f"\n  Baseline: {baseline['mean']:+.1f}%, S={baseline['sortinos_mean']:.2f}")
    _save(R)

    # ========================================
    # TRACK 1: Multi-Timeframe Signals (~2h)
    # ========================================
    P(f"\n{'#'*100}")
    P(f"TRACK 1: MULTI-TIMEFRAME SIGNALS ({datetime.now().strftime('%H:%M')})")
    P("#" * 100)

    t1_results = {}
    configs = [
        ('3d+7d', (3, 7), (0.6, 0.4)),
        ('3d+7d+14d', (3, 7, 14), (0.5, 0.3, 0.2)),
        ('3d+14d', (3, 14), (0.7, 0.3)),
        ('3d+5d+10d', (3, 5, 10), (0.5, 0.3, 0.2)),
        ('equal_3_7_14', (3, 7, 14), (0.33, 0.34, 0.33)),
    ]
    for label, horizons, weights in configs:
        P(f"\n  --- {label} ---")
        s = _seeds_engine(run_multi_timeframe, daily_ret, returns, vols, df, dates, n,
                          label=label, feature_cols=fc, n_bags_lgb=15, n_bags_xgb=30,
                          alloc_params={'K': 30}, retrain_freq='semi',
                          horizons=horizons, horizon_weights=weights)
        if s: t1_results[label] = s
    R['track_1_multitf'] = t1_results
    _save(R)

    # ========================================
    # TRACK 2: Stacking Meta-Learner (~1.5h)
    # ========================================
    P(f"\n{'#'*100}")
    P(f"TRACK 2: STACKING META-LEARNER ({datetime.now().strftime('%H:%M')})")
    P("#" * 100)

    t2_results = {}
    for K in [25, 30, 35]:
        P(f"\n  --- Stacking K={K} ---")
        s = _seeds_engine(run_stacking, daily_ret, returns, vols, df, dates, n,
                          label=f'stack_K{K}', feature_cols=fc,
                          n_bags_lgb=15, n_bags_xgb=30,
                          alloc_params={'K': K}, retrain_freq='semi')
        if s: t2_results[f'stack_K{K}'] = s
    R['track_2_stacking'] = t2_results
    _save(R)

    # ========================================
    # TRACK 3: Regime-Aware Models (~2h)
    # ========================================
    P(f"\n{'#'*100}")
    P(f"TRACK 3: REGIME-AWARE ALLOCATION ({datetime.now().strftime('%H:%M')})")
    P("#" * 100)

    t3_results = {}
    configs = [
        ('bear15_neut25_bull35', 15, 25, 35),
        ('bear10_neut25_bull40', 10, 25, 40),
        ('bear20_neut30_bull35', 20, 30, 35),
        ('bear15_neut30_bull40', 15, 30, 40),
        ('bear10_neut20_bull35', 10, 20, 35),
        ('bear5_neut25_bull45', 5, 25, 45),
    ]
    for label, K_bear, K_neut, K_bull in configs:
        P(f"\n  --- {label} ---")
        s = _seeds_engine(run_regime_aware, daily_ret, returns, vols, df, dates, n,
                          label=label, feature_cols=fc, n_bags_lgb=15, n_bags_xgb=30,
                          retrain_freq='semi', K_bull=K_bull, K_neutral=K_neut, K_bear=K_bear)
        if s: t3_results[label] = s
    R['track_3_regime'] = t3_results
    _save(R)

    # ========================================
    # TRACK 4: Ensemble Weighting (~1.5h)
    # ========================================
    P(f"\n{'#'*100}")
    P(f"TRACK 4: ENSEMBLE WEIGHTING ({datetime.now().strftime('%H:%M')})")
    P("#" * 100)

    t4_results = {}
    configs = [
        ('mean', 'mean', 0),
        ('median', 'median', 0),
        ('trimmed_10pct', 'trimmed_mean', 0.1),
        ('trimmed_20pct', 'trimmed_mean', 0.2),
    ]
    for label, method, trim in configs:
        P(f"\n  --- {label} ---")
        s = _seeds_engine(run_weighted_ensemble, daily_ret, returns, vols, df, dates, n,
                          label=label, feature_cols=fc, n_bags_lgb=15, n_bags_xgb=30,
                          alloc_params={'K': 30}, retrain_freq='semi',
                          method=method, trim_pct=trim)
        if s: t4_results[label] = s
    R['track_4_weighting'] = t4_results
    _save(R)

    # ========================================
    # TRACK 5: Classification Target (~2h)
    # ========================================
    P(f"\n{'#'*100}")
    P(f"TRACK 5: CLASSIFICATION TARGET ({datetime.now().strftime('%H:%M')})")
    P("#" * 100)

    t5_results = {}
    configs = [
        ('cls_thresh0', 0.0),
        ('cls_thresh0.005', 0.005),
        ('cls_thresh0.01', 0.01),
        ('cls_thresh0.02', 0.02),
    ]
    for label, thresh in configs:
        P(f"\n  --- {label} ---")
        s = _seeds_engine(run_classification, daily_ret, returns, vols, df, dates, n,
                          label=label, feature_cols=fc, n_bags_lgb=10, n_bags_xgb=20,
                          alloc_params={'K': 30}, retrain_freq='semi',
                          threshold=thresh)
        if s: t5_results[label] = s
    R['track_5_classification'] = t5_results
    _save(R)

    # ========================================
    # TRACK 6: Best Combo (~1h)
    # ========================================
    P(f"\n{'#'*100}")
    P(f"TRACK 6: BEST COMBOS ({datetime.now().strftime('%H:%M')})")
    P("#" * 100)

    # Find best from each track
    track_bests = {}
    for track_name, track_data in [('T1', t1_results), ('T2', t2_results),
                                    ('T3', t3_results), ('T4', t4_results),
                                    ('T5', t5_results)]:
        if track_data:
            best_k = max(track_data.keys(), key=lambda k: track_data[k].get('sortinos_mean', 0))
            track_bests[track_name] = (best_k, track_data[best_k])
            P(f"  Best {track_name}: {best_k} (S={track_data[best_k]['sortinos_mean']:.2f})")

    t6_results = {}

    # Test best regime config with stacking
    if 'T3' in track_bests:
        best_regime = track_bests['T3'][0]
        parts = best_regime.split('_')
        K_bear = int(parts[0].replace('bear', ''))
        K_neut = int(parts[1].replace('neut', ''))
        K_bull = int(parts[2].replace('bull', ''))

        # Re-run best regime with more bags
        P(f"\n  --- Best regime + more bags (20+40) ---")
        s = _seeds_engine(run_regime_aware, daily_ret, returns, vols, df, dates, n,
                          label='regime_20+40', feature_cols=fc, n_bags_lgb=20, n_bags_xgb=40,
                          retrain_freq='semi', K_bull=K_bull, K_neutral=K_neut, K_bear=K_bear)
        if s: t6_results['regime_more_bags'] = s

    # Test best ensemble method with regime
    if 'T4' in track_bests:
        best_ens = track_bests['T4'][0]
        method = 'trimmed_mean' if 'trimmed' in best_ens else best_ens
        trim = 0.1 if '10' in best_ens else (0.2 if '20' in best_ens else 0)
        P(f"\n  --- Best ensemble ({best_ens}) + more bags ---")
        s = _seeds_engine(run_weighted_ensemble, daily_ret, returns, vols, df, dates, n,
                          label='ens_more_bags', feature_cols=fc, n_bags_lgb=20, n_bags_xgb=40,
                          alloc_params={'K': 30}, retrain_freq='semi',
                          method=method, trim_pct=trim)
        if s: t6_results['ens_more_bags'] = s

    R['track_6_combos'] = t6_results
    _save(R)

    # ========================================
    # FINAL SUMMARY
    # ========================================
    elapsed = (datetime.now() - start).total_seconds() / 3600
    R['elapsed_hours'] = float(elapsed)

    P(f"\n\n{'='*100}")
    P("V15 NEW APPROACHES SUMMARY")
    P("=" * 100)
    P(f"  Elapsed: {elapsed:.1f}h")

    all_v = []
    if baseline:
        all_v.append(('BASELINE (V13 config)', baseline['mean'], baseline['spread'],
                       baseline['sortinos_mean'], baseline['max_dds_mean']))

    for track in ['track_1_multitf', 'track_2_stacking', 'track_3_regime',
                   'track_4_weighting', 'track_5_classification', 'track_6_combos']:
        data = R.get(track, {})
        t_num = track.split('_')[1]
        for k, s in data.items():
            if isinstance(s, dict) and 'sortinos_mean' in s:
                all_v.append((f'[T{t_num}] {k}', s['mean'], s['spread'],
                              s['sortinos_mean'], s['max_dds_mean']))

    all_v.sort(key=lambda x: x[3], reverse=True)
    P(f"\n  {'Rk':<4} {'Config':<55} {'Mean':>8} {'Spread':>8} {'Sortino':>8} {'MaxDD':>8}")
    P(f"  {'-'*95}")
    for i, (name, mean, spread, sortino, mdd) in enumerate(all_v[:25], 1):
        P(f"  {i:<4} {name:<55} {mean:>+7.1f}% {spread:>7.0f}pp {sortino:>7.2f} {mdd:>7.1f}%")

    # Verdict
    if all_v and baseline:
        best = all_v[0]
        if best[3] > baseline['sortinos_mean']:
            P(f"\n  WINNER: {best[0]} beats baseline by +{best[3]-baseline['sortinos_mean']:.2f} Sortino")
        else:
            P(f"\n  VERDICT: Baseline still best. New approaches didn't improve.")

    _save(R)
    P(f"\n{'='*100}")
    P(f"V15 COMPLETE | {elapsed:.1f}h | {RESULTS_PATH}")
    P("=" * 100)


if __name__ == '__main__':
    main()
