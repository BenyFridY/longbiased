"""
PIPELINE V10 — Mega-Experiment: Hyperparameters + Allocation + Emergency Rebal + Accuracy
==========================================================================================

Top 3 V9 models (baselines):
  30-feat: +609%, Sortino 2.37, 50pp spread, -13.7% MaxDD (C2 + TOP_ADD[:5])
  32-feat: +595%, Sortino 2.40, 29pp spread, -13.3% MaxDD (C2 + TOP_ADD[:7])
  37-feat: +582%, Sortino 2.48, 41pp spread, -16.0% MaxDD (C2 + TOP_ADD[:12])

All use: C2 swaps, Bag30, ret_3d, weekly Friday, real CDI, fixed short formula.
All use DEFAULT LightGBM hyperparams (never optimized).

Phases:
  A: Hyperparameter sweep (1 seed, ~50 min)
  B: Allocation formula experiments (1 seed, ~15 min)
  C: Emergency rebalancing bidirectional (1 seed, ~10 min)
  D: Accuracy analysis (10 seeds, ~18 min)
  E: Top combos (10 seeds, ~5h)
  F: Fine grid around best (10 seeds, ~2h)
  G: Final: best hyperparams x best allocation x emergency rebal (10 seeds, ~30 min)

Total estimated: ~10-12 hours
"""

import sys
import pandas as pd
import numpy as np
from pathlib import Path
import warnings
import json
from datetime import datetime
from scipy import stats as scipy_stats
import lightgbm as lgb

warnings.filterwarnings('ignore')
sys.stdout.reconfigure(line_buffering=True)

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

from archive.old_pipelines.pipeline_v09 import (
    load_data, build_ml_features,
    backtest_allocations, metrics, get_year_boundaries,
    SEEDS_10, COST, DEFAULT_LGB_PARAMS,
    P, _seed_summary, convert_numpy,
)

RF_DAILY_ARR = None

# ============================================================
# FEATURE CONFIGS FOR TOP 3 MODELS
# ============================================================

C2_BASE = [
    'cusum_pos', 'miners_revenue_ratio', 'mr_score_30d', 'adx',
    'cusum_neg', 'exchange_netflow_ma7', 'structural_break_score',
    'macd_histogram', 'eth_btc_ratio', 'm2_yoy_growth',
    'volatility_7d', 'basis_ma7', 'nupl_ma30', 'hurst_60d',
    'eth', 'bb_position', 'eth_pctchg_30d',
    'price_percentile_1y', 'stablecoin_zscore', 'btc_gold_corr_30d',
]

TOP_ADD = [
    'stablecoin_supply_change_30d', 'copper_return_30d', 'ou_theta_60d',
    'fractal_dimension_30d', 'kpss_stat_30d', 'open_interest',
    'half_life_60d', 'sortino_30d', 'obv_trend', 'volume_sma20_ratio',
    'aroon_down_30d', 'trend_strength',
]

MODELS = {
    '30feat': list(dict.fromkeys(C2_BASE + TOP_ADD[:5])),
    '32feat': list(dict.fromkeys(C2_BASE + TOP_ADD[:7])),
    '37feat': list(dict.fromkeys(C2_BASE + TOP_ADD[:12])),
}


# ============================================================
# CORE ENGINE (adapted from V9 with custom allocation + bidir emergency)
# ============================================================

def run_strategy_v10(daily_ret, returns, vols, df, dates, n,
                     feature_cols, n_bags=30, base_seed=42,
                     lgb_params=None, scale_div=0.05,
                     alloc_formula='default',
                     alloc_params=None,
                     emergency_threshold=None,
                     emergency_direction='both',
                     return_predictions=False,
                     verbose=False):
    """Walk-forward engine with V10 enhancements.

    Args:
        feature_cols: list of feature column names
        lgb_params: LightGBM params dict (merged with defaults)
        scale_div: prediction scaling divisor
        alloc_formula: 'default', 'symmetric', 'conservative', 'aggressive',
                       'sigmoid', 'linear_direct'
        alloc_params: dict with formula-specific params (e.g. K for sigmoid)
        emergency_threshold: float, trigger rebal if |BTC move| > threshold
        emergency_direction: 'both', 'down_only', 'up_only'
        return_predictions: if True, also return (pred_t, actual_t) pairs
    """
    if alloc_params is None:
        alloc_params = {}

    prices = df['price_usd'].values
    yb = get_year_boundaries(dates, n)

    X_all, names = build_ml_features(df, returns, vols, n, feature_cols=feature_cols)

    target = np.zeros(n)
    for i in range(n - 3):
        target[i] = (prices[i + 3] - prices[i]) / prices[i]

    day_of_week = pd.to_datetime(dates).dayofweek

    all_strat, all_btc, all_alloc, all_rf = [], [], [], []
    full_allocs = np.full(n, 0.5)
    predictions = []  # (pred, actual, date_idx) for accuracy analysis
    is_rf_arr = isinstance(RF_DAILY_ARR, np.ndarray)

    params_base = dict(DEFAULT_LGB_PARAMS)
    if lgb_params:
        params_base.update(lgb_params)

    for test_year in range(2022, 2027):
        if test_year not in yb:
            continue

        train_end = yb[test_year]['start'] - 1
        test_start = yb[test_year]['start']
        test_end = yb[test_year]['end']
        horizon_gap = max(3, 5)

        models_list = []
        for i in range(n_bags):
            seed = base_seed + i * 7
            train_mask = np.arange(60, train_end - horizon_gap + 1)
            valid_train = ~np.any(np.isnan(X_all[train_mask]), axis=1)
            train_idx = train_mask[valid_train]
            if len(train_idx) < 100:
                continue
            X_train = np.nan_to_num(X_all[train_idx], nan=0.0)
            y_train = target[train_idx]
            params = dict(params_base)
            params['seed'] = seed
            params['verbose'] = -1
            params['n_jobs'] = 1
            num_round = params.pop('num_boost_round', 200)
            dtrain = lgb.Dataset(X_train, label=y_train)
            models_list.append(lgb.train(params, dtrain, num_boost_round=num_round))

        if not models_list:
            continue

        prev_alloc = 0.5
        last_rebal_price = prices[test_start] if test_start < len(prices) else 0

        for t in range(test_start, test_end + 1):
            # Predict
            x_t = np.nan_to_num(X_all[t:t+1].copy(), nan=0.0)
            preds = [m.predict(x_t)[0] for m in models_list]
            avg_pred = np.mean(preds)

            # Allocation formula
            raw_alloc = _compute_allocation(avg_pred, scale_div, alloc_formula, alloc_params)

            is_friday = day_of_week[t] == 4

            # Emergency rebalance check
            if emergency_threshold is not None and not is_friday:
                btc_change = (prices[t] - last_rebal_price) / (last_rebal_price + 1e-10)
                trigger = False
                if emergency_direction == 'both':
                    trigger = abs(btc_change) > emergency_threshold
                elif emergency_direction == 'down_only':
                    trigger = btc_change < -emergency_threshold
                elif emergency_direction == 'up_only':
                    trigger = btc_change > emergency_threshold
                if trigger:
                    is_friday = True  # treat as rebal day

            if not is_friday:
                raw_alloc = prev_alloc
            else:
                last_rebal_price = prices[t]
                # Track predictions on rebal days
                if return_predictions and t + 3 < n:
                    actual_3d = (prices[t + 3] - prices[t]) / prices[t]
                    predictions.append((float(avg_pred), float(actual_3d), int(t)))

            full_allocs[t] = np.clip(raw_alloc, -0.25, 1.0)
            prev_alloc = full_allocs[t]

        s, b, a = backtest_allocations(daily_ret, full_allocs, test_start, test_end,
                                       cost=COST, rf_daily=RF_DAILY_ARR)
        all_strat.extend(s)
        all_btc.extend(b)
        all_alloc.extend(a)

        n_days = len(s)
        if is_rf_arr:
            rf_slice = RF_DAILY_ARR[test_start:test_start + n_days]
            all_rf.extend(rf_slice)
        else:
            all_rf.extend([0.0] * n_days)

    result = metrics(np.array(all_strat), np.array(all_btc), np.array(all_alloc),
                     rf_daily=np.array(all_rf))

    if return_predictions:
        return result, predictions
    return result


def _compute_allocation(avg_pred, scale_div, formula, params):
    """Compute allocation from raw prediction using specified formula."""
    scaled = np.clip(avg_pred / scale_div, -1.0, 1.0)

    if formula == 'default':
        if scaled > 0:
            return 0.5 + scaled * 0.5
        else:
            return 0.5 + scaled * 0.75

    elif formula == 'symmetric':
        return 0.375 + scaled * 0.625

    elif formula == 'conservative':
        if scaled > 0:
            return 0.5 + scaled * 0.375
        else:
            return 0.5 + scaled * 0.50

    elif formula == 'aggressive':
        return 0.5 + scaled * 0.5

    elif formula == 'sigmoid':
        K = params.get('K', 30)
        return -0.25 + 1.25 / (1 + np.exp(-avg_pred * K))

    elif formula == 'linear_direct':
        K = params.get('K', 10)
        return np.clip(avg_pred * K + 0.375, -0.25, 1.0)

    else:
        # fallback to default
        if scaled > 0:
            return 0.5 + scaled * 0.5
        else:
            return 0.5 + scaled * 0.75


# ============================================================
# SAVE HELPER
# ============================================================

RESULTS_PATH = ROOT / 'outputs/results/pipeline_v10.json'


def _save(all_results):
    """Save results incrementally."""
    RESULTS_PATH.parent.mkdir(parents=True, exist_ok=True)
    output_clean = convert_numpy(all_results)
    RESULTS_PATH.write_text(json.dumps(output_clean, indent=2, default=str),
                            encoding='utf-8')
    P(f"  [SAVE] {RESULTS_PATH.name}")


# ============================================================
# PHASE A: HYPERPARAMETER SWEEP (1 seed, model 32-feat)
# ============================================================

def phase_a(daily_ret, returns, vols, df, dates, n):
    P(f"\n{'#'*100}")
    P("PHASE A: HYPERPARAMETER SWEEP (1 seed, 32-feat)")
    P("#" * 100)

    feature_cols = MODELS['32feat']
    seed = 42

    # First, run baseline
    P(f"\n  Baseline (default params)...")
    baseline = run_strategy_v10(
        daily_ret, returns, vols, df, dates, n,
        feature_cols=feature_cols, base_seed=seed)
    if baseline:
        P(f"    => {baseline['total']*100:+.1f}%, Sortino={baseline['sortino']:.2f}, "
          f"MaxDD={baseline['max_dd']*100:.1f}%")
    else:
        P("    FAILED")
        return {}

    baseline_ret = baseline['total'] * 100
    baseline_sortino = baseline['sortino']

    sweeps = {
        'num_leaves':       [8, 15, 31, 47, 63, 95, 127],
        'learning_rate':    [0.01, 0.02, 0.03, 0.05, 0.08, 0.10, 0.15, 0.20],
        'num_boost_round':  [50, 100, 150, 200, 300, 400, 600, 800, 1000],
        'feature_fraction': [0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0],
        'bagging_fraction': [0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0],
        'min_data_in_leaf': [5, 10, 15, 20, 30, 50, 100],
        'lambda_l1':        [0, 0.001, 0.01, 0.1, 1.0, 5.0, 10.0],
        'lambda_l2':        [0, 0.001, 0.01, 0.1, 1.0, 5.0, 10.0],
        'max_depth':        [-1, 3, 5, 6, 8, 10, 15, 20],
        'bagging_freq':     [1, 2, 3, 5, 7, 10],
    }

    results = {
        'baseline': {
            'return': float(baseline_ret),
            'sortino': float(baseline_sortino),
            'max_dd': float(baseline['max_dd'] * 100),
        },
        'sweeps': {},
    }

    all_runs = []  # (param, value, return, sortino, max_dd)

    for param_name, values in sweeps.items():
        P(f"\n  --- {param_name} ---")
        param_results = []

        for val in values:
            lgb_override = {param_name: val}
            P(f"    {param_name}={val}...", end="")
            r = run_strategy_v10(
                daily_ret, returns, vols, df, dates, n,
                feature_cols=feature_cols, base_seed=seed,
                lgb_params=lgb_override)
            if r:
                ret = r['total'] * 100
                diff = ret - baseline_ret
                P(f" {ret:+.1f}% ({diff:+.1f}pp), Sortino={r['sortino']:.2f}")
                entry = {
                    'value': val, 'return': float(ret),
                    'sortino': float(r['sortino']),
                    'max_dd': float(r['max_dd'] * 100),
                    'diff_return': float(diff),
                    'diff_sortino': float(r['sortino'] - baseline_sortino),
                }
                param_results.append(entry)
                all_runs.append((param_name, val, ret, r['sortino'], r['max_dd'] * 100))
            else:
                P(" FAILED")

        results['sweeps'][param_name] = param_results

        # Best for this param
        if param_results:
            best = max(param_results, key=lambda x: x['sortino'])
            P(f"    BEST: {param_name}={best['value']} "
              f"(Sortino={best['sortino']:.2f}, {best['diff_sortino']:+.2f} vs default)")

    # Global ranking by Sortino
    all_runs.sort(key=lambda x: x[3], reverse=True)
    P(f"\n  TOP 20 RUNS (by Sortino):")
    P(f"  {'Param':<20} {'Value':>8} {'Return':>8} {'Sortino':>8} {'MaxDD':>8}")
    P(f"  {'-'*56}")
    for param, val, ret, sortino, mdd in all_runs[:20]:
        P(f"  {param:<20} {str(val):>8} {ret:>+7.1f}% {sortino:>7.2f} {mdd:>7.1f}%")

    # Extract best value per param (if it improved vs default)
    best_per_param = {}
    for param_name, param_results in results['sweeps'].items():
        if not param_results:
            continue
        best = max(param_results, key=lambda x: x['sortino'])
        if best['diff_sortino'] > 0:
            best_per_param[param_name] = best['value']

    results['best_per_param'] = {k: v for k, v in best_per_param.items()}
    P(f"\n  Params that improved (Sortino): {best_per_param}")

    return results


# ============================================================
# PHASE B: ALLOCATION FORMULA (1 seed, 32-feat)
# ============================================================

def phase_b(daily_ret, returns, vols, df, dates, n):
    P(f"\n{'#'*100}")
    P("PHASE B: ALLOCATION FORMULA (1 seed, 32-feat)")
    P("#" * 100)

    feature_cols = MODELS['32feat']
    seed = 42
    results = {}

    # B1: Vary scale_div
    P(f"\n  B1: Vary scale_div")
    scale_results = []
    for sd in [0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.07, 0.08, 0.10, 0.15, 0.20]:
        P(f"    scale_div={sd}...", end="")
        r = run_strategy_v10(
            daily_ret, returns, vols, df, dates, n,
            feature_cols=feature_cols, base_seed=seed,
            scale_div=sd)
        if r:
            P(f" {r['total']*100:+.1f}%, Sortino={r['sortino']:.2f}")
            scale_results.append({
                'scale_div': sd, 'return': float(r['total'] * 100),
                'sortino': float(r['sortino']), 'max_dd': float(r['max_dd'] * 100),
            })
        else:
            P(" FAILED")
    results['scale_div'] = scale_results

    if scale_results:
        best_sd = max(scale_results, key=lambda x: x['sortino'])
        P(f"    BEST scale_div: {best_sd['scale_div']} (Sortino={best_sd['sortino']:.2f})")

    # B2: Alternative formulas
    P(f"\n  B2: Alternative formulas")
    formula_results = []

    formulas = [
        ('default', 'default', {}),
        ('symmetric', 'symmetric', {}),
        ('conservative', 'conservative', {}),
        ('aggressive', 'aggressive', {}),
        ('sigmoid_K20', 'sigmoid', {'K': 20}),
        ('sigmoid_K30', 'sigmoid', {'K': 30}),
        ('sigmoid_K50', 'sigmoid', {'K': 50}),
        ('sigmoid_K80', 'sigmoid', {'K': 80}),
        ('linear_K5', 'linear_direct', {'K': 5}),
        ('linear_K10', 'linear_direct', {'K': 10}),
        ('linear_K15', 'linear_direct', {'K': 15}),
        ('linear_K20', 'linear_direct', {'K': 20}),
        ('linear_K25', 'linear_direct', {'K': 25}),
    ]

    for label, formula, params in formulas:
        P(f"    {label}...", end="")
        r = run_strategy_v10(
            daily_ret, returns, vols, df, dates, n,
            feature_cols=feature_cols, base_seed=seed,
            alloc_formula=formula, alloc_params=params)
        if r:
            P(f" {r['total']*100:+.1f}%, Sortino={r['sortino']:.2f}")
            formula_results.append({
                'label': label, 'formula': formula, 'params': params,
                'return': float(r['total'] * 100),
                'sortino': float(r['sortino']), 'max_dd': float(r['max_dd'] * 100),
            })
        else:
            P(" FAILED")

    results['formulas'] = formula_results

    if formula_results:
        best_f = max(formula_results, key=lambda x: x['sortino'])
        P(f"    BEST formula: {best_f['label']} (Sortino={best_f['sortino']:.2f})")
        results['best_formula'] = best_f

    return results


# ============================================================
# PHASE C: EMERGENCY REBALANCING BIDIRECTIONAL (1 seed, 32-feat)
# ============================================================

def phase_c(daily_ret, returns, vols, df, dates, n):
    P(f"\n{'#'*100}")
    P("PHASE C: EMERGENCY REBALANCING BIDIRECTIONAL (1 seed, 32-feat)")
    P("#" * 100)

    feature_cols = MODELS['32feat']
    seed = 42
    results = {}

    configs = [
        ('bidir_3pct', 0.03, 'both'),
        ('bidir_5pct', 0.05, 'both'),
        ('bidir_7pct', 0.07, 'both'),
        ('bidir_10pct', 0.10, 'both'),
        ('down_3pct', 0.03, 'down_only'),
        ('down_5pct', 0.05, 'down_only'),
        ('down_7pct', 0.07, 'down_only'),
        ('down_10pct', 0.10, 'down_only'),
        ('up_3pct', 0.03, 'up_only'),
        ('up_5pct', 0.05, 'up_only'),
        ('up_7pct', 0.07, 'up_only'),
        ('up_10pct', 0.10, 'up_only'),
    ]

    # Baseline (no emergency)
    P(f"\n  Baseline (no emergency rebal)...")
    r_base = run_strategy_v10(
        daily_ret, returns, vols, df, dates, n,
        feature_cols=feature_cols, base_seed=seed)
    if r_base:
        P(f"    => {r_base['total']*100:+.1f}%, Sortino={r_base['sortino']:.2f}")
        results['baseline'] = {
            'return': float(r_base['total'] * 100),
            'sortino': float(r_base['sortino']),
            'max_dd': float(r_base['max_dd'] * 100),
        }

    emergency_results = []
    for label, thresh, direction in configs:
        P(f"    {label}...", end="")
        r = run_strategy_v10(
            daily_ret, returns, vols, df, dates, n,
            feature_cols=feature_cols, base_seed=seed,
            emergency_threshold=thresh, emergency_direction=direction)
        if r:
            diff = r['sortino'] - (r_base['sortino'] if r_base else 0)
            P(f" {r['total']*100:+.1f}%, Sortino={r['sortino']:.2f} ({diff:+.2f})")
            emergency_results.append({
                'label': label, 'threshold': thresh, 'direction': direction,
                'return': float(r['total'] * 100),
                'sortino': float(r['sortino']), 'max_dd': float(r['max_dd'] * 100),
                'diff_sortino': float(diff),
            })
        else:
            P(" FAILED")

    results['emergency'] = emergency_results

    if emergency_results:
        best_e = max(emergency_results, key=lambda x: x['sortino'])
        P(f"\n  BEST emergency: {best_e['label']} (Sortino={best_e['sortino']:.2f})")
        results['best_emergency'] = best_e

    return results


# ============================================================
# PHASE D: ACCURACY ANALYSIS (10 seeds, 3 models)
# ============================================================

def phase_d(daily_ret, returns, vols, df, dates, n):
    P(f"\n{'#'*100}")
    P("PHASE D: ACCURACY ANALYSIS (10 seeds, 3 models)")
    P("#" * 100)

    prices = df['price_usd'].values
    results = {}

    for model_name, feature_cols in MODELS.items():
        P(f"\n  --- Model: {model_name} ---")
        model_results = []

        for seed in SEEDS_10:
            P(f"    seed={seed}...", end="")
            r, preds = run_strategy_v10(
                daily_ret, returns, vols, df, dates, n,
                feature_cols=feature_cols, base_seed=seed,
                return_predictions=True)
            if r and preds:
                # Compute accuracy metrics
                pred_arr = np.array([p[0] for p in preds])
                actual_arr = np.array([p[1] for p in preds])
                date_idxs = np.array([p[2] for p in preds])

                # Directional accuracy
                dir_correct = np.sign(pred_arr) == np.sign(actual_arr)
                dir_acc = float(np.mean(dir_correct))

                # Weighted accuracy (weight by |actual|)
                weights = np.abs(actual_arr)
                w_sum = weights.sum()
                weighted_acc = float(np.sum(dir_correct * weights) / (w_sum + 1e-10))

                # Correlation
                corr = float(np.corrcoef(pred_arr, actual_arr)[0, 1])

                # Per-year accuracy
                year_acc = {}
                date_years = pd.to_datetime(dates[date_idxs]).year
                for yr in range(2022, 2027):
                    yr_mask = date_years == yr
                    if yr_mask.sum() > 0:
                        yr_dir = dir_correct[yr_mask]
                        year_acc[str(yr)] = float(np.mean(yr_dir))

                P(f" {r['total']*100:+.1f}%, acc={dir_acc:.1%}, "
                  f"w_acc={weighted_acc:.1%}, corr={corr:.3f}")

                model_results.append({
                    'seed': seed,
                    'return': float(r['total'] * 100),
                    'sortino': float(r['sortino']),
                    'dir_accuracy': dir_acc,
                    'weighted_accuracy': weighted_acc,
                    'correlation': corr,
                    'n_predictions': len(preds),
                    'year_accuracy': year_acc,
                })
            else:
                P(" FAILED")

        if model_results:
            # Summary
            accs = [m['dir_accuracy'] for m in model_results]
            w_accs = [m['weighted_accuracy'] for m in model_results]
            corrs = [m['correlation'] for m in model_results]
            sortinos = [m['sortino'] for m in model_results]
            rets = [m['return'] for m in model_results]

            summary = {
                'mean_accuracy': float(np.mean(accs)),
                'mean_weighted_accuracy': float(np.mean(w_accs)),
                'mean_correlation': float(np.mean(corrs)),
                'mean_sortino': float(np.mean(sortinos)),
                'mean_return': float(np.mean(rets)),
                'acc_sortino_corr': float(np.corrcoef(accs, sortinos)[0, 1])
                    if len(accs) > 2 else 0.0,
            }

            P(f"\n    Summary {model_name}:")
            P(f"      Dir accuracy: {summary['mean_accuracy']:.1%}")
            P(f"      Weighted acc: {summary['mean_weighted_accuracy']:.1%}")
            P(f"      Correlation:  {summary['mean_correlation']:.3f}")
            P(f"      Acc-Sortino corr: {summary['acc_sortino_corr']:.3f}")

            results[model_name] = {
                'seeds': model_results,
                'summary': summary,
            }

    return results


# ============================================================
# PHASE E: TOP COMBOS (10 seeds, 3 models)
# ============================================================

def phase_e(daily_ret, returns, vols, df, dates, n, phase_a_results, phase_b_results):
    P(f"\n{'#'*100}")
    P("PHASE E: TOP COMBOS (10 seeds, 3 models)")
    P("#" * 100)

    best_per_param = phase_a_results.get('best_per_param', {})
    if not best_per_param:
        P("  No improved params from Phase A, skipping.")
        return {}

    P(f"  Improved params: {best_per_param}")

    # Sort params by their Sortino improvement (from Phase A sweeps)
    param_ranking = []
    for param_name, best_val in best_per_param.items():
        sweep_data = phase_a_results.get('sweeps', {}).get(param_name, [])
        for entry in sweep_data:
            if entry['value'] == best_val:
                param_ranking.append((param_name, best_val, entry['diff_sortino']))
                break

    param_ranking.sort(key=lambda x: x[2], reverse=True)
    P(f"  Ranked by Sortino improvement:")
    for p, v, d in param_ranking:
        P(f"    {p}={v} ({d:+.3f})")

    results = {}

    # Build incremental combos
    combos = []
    current_params = {}

    for i, (param_name, best_val, _) in enumerate(param_ranking):
        current_params[param_name] = best_val
        combo_label = f"combo_{i+1}_{'_'.join(current_params.keys())}"
        combos.append((combo_label, dict(current_params)))

    # Also test each param alone
    for param_name, best_val, _ in param_ranking:
        label = f"single_{param_name}_{best_val}"
        combos.append((label, {param_name: best_val}))

    # Also try best allocation formula from Phase B
    best_formula = phase_b_results.get('best_formula', {})
    best_sd_list = phase_b_results.get('scale_div', [])
    best_sd = None
    if best_sd_list:
        best_sd_entry = max(best_sd_list, key=lambda x: x['sortino'])
        best_sd = best_sd_entry['scale_div']

    P(f"\n  Total combos to test: {len(combos)}")
    P(f"  Best allocation: formula={best_formula.get('label', 'default')}, scale_div={best_sd}")

    combo_results = {}

    for model_name, feature_cols in MODELS.items():
        P(f"\n  === Model: {model_name} ===")

        # Baseline for this model (10 seeds)
        P(f"  Baseline (10 seeds):")
        base_seeds = []
        for seed in SEEDS_10:
            P(f"    seed={seed}...", end="")
            r = run_strategy_v10(
                daily_ret, returns, vols, df, dates, n,
                feature_cols=feature_cols, base_seed=seed)
            if r:
                base_seeds.append(r)
                P(f" {r['total']*100:+.1f}%")
            else:
                P(" FAILED")

        if base_seeds:
            rets = [r['total'] * 100 for r in base_seeds]
            base_summary = _seed_summary(rets, base_seeds)
            P(f"    Baseline: mean={base_summary['mean']:+.1f}%, "
              f"Sortino={base_summary['sortinos_mean']:.2f}, "
              f"spread={base_summary['spread']:.0f}pp")
            combo_results[f'{model_name}_baseline'] = base_summary

        # Test each combo
        for combo_label, lgb_override in combos:
            P(f"\n  {combo_label} ({model_name}):")
            seeds_results = []
            for seed in SEEDS_10:
                P(f"    seed={seed}...", end="")
                r = run_strategy_v10(
                    daily_ret, returns, vols, df, dates, n,
                    feature_cols=feature_cols, base_seed=seed,
                    lgb_params=lgb_override)
                if r:
                    seeds_results.append(r)
                    P(f" {r['total']*100:+.1f}%")
                else:
                    P(" FAILED")

            if seeds_results:
                rets = [r['total'] * 100 for r in seeds_results]
                summary = _seed_summary(rets, seeds_results)
                key = f'{model_name}_{combo_label}'
                combo_results[key] = {
                    'params': lgb_override,
                    'seeds': summary,
                }
                diff = summary['sortinos_mean'] - (base_summary['sortinos_mean']
                       if base_seeds else 0)
                P(f"    => mean={summary['mean']:+.1f}%, "
                  f"Sortino={summary['sortinos_mean']:.2f} ({diff:+.2f}), "
                  f"spread={summary['spread']:.0f}pp")

    # Find best combo overall
    best_combo = None
    best_combo_sortino = -999
    for key, val in combo_results.items():
        if 'baseline' in key:
            continue
        s = val.get('seeds', val) if isinstance(val, dict) else val
        sortino = s.get('sortinos_mean', s.get('sortinos_mean', -999))
        if sortino > best_combo_sortino:
            best_combo_sortino = sortino
            best_combo = key

    if best_combo:
        P(f"\n  BEST COMBO: {best_combo} (Sortino={best_combo_sortino:.2f})")

    results['combos'] = combo_results
    results['best_combo'] = best_combo
    results['best_combo_sortino'] = float(best_combo_sortino) if best_combo else 0

    return results


# ============================================================
# PHASE F: FINE GRID AROUND BEST (10 seeds)
# ============================================================

def phase_f(daily_ret, returns, vols, df, dates, n, phase_a_results, phase_e_results):
    P(f"\n{'#'*100}")
    P("PHASE F: FINE GRID AROUND BEST COMBOS (10 seeds)")
    P("#" * 100)

    best_per_param = phase_a_results.get('best_per_param', {})
    if not best_per_param:
        P("  No improved params, skipping.")
        return {}

    sweeps = phase_a_results.get('sweeps', {})
    results = {}

    # For each improved param, find fine grid (values between neighbors)
    fine_grid_params = {}
    sweep_values = {
        'num_leaves':       [8, 15, 31, 47, 63, 95, 127],
        'learning_rate':    [0.01, 0.02, 0.03, 0.05, 0.08, 0.10, 0.15, 0.20],
        'num_boost_round':  [50, 100, 150, 200, 300, 400, 600, 800, 1000],
        'feature_fraction': [0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0],
        'bagging_fraction': [0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0],
        'min_data_in_leaf': [5, 10, 15, 20, 30, 50, 100],
        'lambda_l1':        [0, 0.001, 0.01, 0.1, 1.0, 5.0, 10.0],
        'lambda_l2':        [0, 0.001, 0.01, 0.1, 1.0, 5.0, 10.0],
        'max_depth':        [-1, 3, 5, 6, 8, 10, 15, 20],
        'bagging_freq':     [1, 2, 3, 5, 7, 10],
    }

    for param_name, best_val in best_per_param.items():
        vals = sweep_values.get(param_name, [])
        if best_val not in vals:
            continue
        idx = vals.index(best_val)

        # Generate fine values between neighbors
        fine_vals = []
        if idx > 0:
            lo = vals[idx - 1]
            mid_lo = (lo + best_val) / 2
            if param_name in ['num_leaves', 'num_boost_round', 'min_data_in_leaf', 'bagging_freq']:
                mid_lo = int(round(mid_lo))
            fine_vals.append(mid_lo)
        if idx < len(vals) - 1:
            hi = vals[idx + 1]
            mid_hi = (best_val + hi) / 2
            if param_name in ['num_leaves', 'num_boost_round', 'min_data_in_leaf', 'bagging_freq']:
                mid_hi = int(round(mid_hi))
            fine_vals.append(mid_hi)

        if fine_vals:
            fine_grid_params[param_name] = fine_vals

    P(f"  Fine grid params: {fine_grid_params}")

    # Build the best combo from Phase E as the base params
    best_combo_key = phase_e_results.get('best_combo', '')
    combos = phase_e_results.get('combos', {})
    base_lgb_params = {}
    if best_combo_key and best_combo_key in combos:
        val = combos[best_combo_key]
        if isinstance(val, dict) and 'params' in val:
            base_lgb_params = dict(val['params'])

    if not base_lgb_params:
        base_lgb_params = {k: v for k, v in best_per_param.items()}

    P(f"  Base params for fine grid: {base_lgb_params}")

    # Determine best model from Phase E
    best_model = '32feat'
    for key in combos:
        if 'baseline' not in key and best_combo_key and key == best_combo_key:
            for mn in ['30feat', '32feat', '37feat']:
                if mn in key:
                    best_model = mn
                    break

    feature_cols = MODELS[best_model]
    P(f"  Using model: {best_model}")

    fine_results = []

    # Test each fine grid param variation (vary one at a time from base)
    for param_name, fine_vals in fine_grid_params.items():
        for fv in fine_vals:
            params = dict(base_lgb_params)
            params[param_name] = fv
            label = f"fine_{param_name}={fv}"
            P(f"\n  {label}:")

            seeds_results = []
            for seed in SEEDS_10:
                P(f"    seed={seed}...", end="")
                r = run_strategy_v10(
                    daily_ret, returns, vols, df, dates, n,
                    feature_cols=feature_cols, base_seed=seed,
                    lgb_params=params)
                if r:
                    seeds_results.append(r)
                    P(f" {r['total']*100:+.1f}%")
                else:
                    P(" FAILED")

            if seeds_results:
                rets = [r['total'] * 100 for r in seeds_results]
                summary = _seed_summary(rets, seeds_results)
                fine_results.append({
                    'label': label, 'params': {k: v for k, v in params.items()},
                    'varied_param': param_name, 'varied_value': fv,
                    'seeds': summary,
                })
                P(f"    => mean={summary['mean']:+.1f}%, "
                  f"Sortino={summary['sortinos_mean']:.2f}, "
                  f"spread={summary['spread']:.0f}pp")

    results['fine_results'] = fine_results
    results['base_params'] = base_lgb_params
    results['model'] = best_model

    if fine_results:
        best_fine = max(fine_results, key=lambda x: x['seeds']['sortinos_mean'])
        P(f"\n  BEST FINE: {best_fine['label']} "
          f"(Sortino={best_fine['seeds']['sortinos_mean']:.2f})")
        results['best_fine'] = best_fine

    return results


# ============================================================
# PHASE G: FINAL COMBINATION (10 seeds)
# ============================================================

def phase_g(daily_ret, returns, vols, df, dates, n,
            phase_a_results, phase_b_results, phase_c_results,
            phase_e_results, phase_f_results):
    P(f"\n{'#'*100}")
    P("PHASE G: FINAL COMBINATION (10 seeds, all models)")
    P("#" * 100)

    results = {}

    # Get best hyperparams
    best_lgb_params = {}

    # From Phase F (fine grid) if available
    best_fine = phase_f_results.get('best_fine', {})
    if best_fine and 'params' in best_fine:
        best_lgb_params = dict(best_fine['params'])
    else:
        # Fall back to Phase A best_per_param
        best_per_param = phase_a_results.get('best_per_param', {})
        best_lgb_params = dict(best_per_param)

    # Get best allocation formula
    best_formula_entry = phase_b_results.get('best_formula', {})
    best_formula = best_formula_entry.get('formula', 'default')
    best_formula_params = best_formula_entry.get('params', {})

    # Get best scale_div
    best_sd = 0.05
    sd_list = phase_b_results.get('scale_div', [])
    if sd_list:
        best_sd_entry = max(sd_list, key=lambda x: x['sortino'])
        best_sd = best_sd_entry['scale_div']

    # Get best emergency rebal
    best_emerg = phase_c_results.get('best_emergency', {})
    emerg_thresh = best_emerg.get('threshold', None)
    emerg_dir = best_emerg.get('direction', 'both')
    # Only use emergency if it actually improved
    emerg_improved = best_emerg.get('diff_sortino', 0) > 0

    P(f"  Best hyperparams: {best_lgb_params}")
    P(f"  Best formula: {best_formula} (params={best_formula_params})")
    P(f"  Best scale_div: {best_sd}")
    P(f"  Best emergency: thresh={emerg_thresh}, dir={emerg_dir}, improved={emerg_improved}")

    # Test combinations
    configs = []

    # 1. Best hyperparams only
    configs.append(('best_hyper', best_lgb_params, 'default', {}, 0.05, None, 'both'))

    # 2. Best hyperparams + best scale_div
    configs.append(('best_hyper+sd', best_lgb_params, 'default', {}, best_sd, None, 'both'))

    # 3. Best hyperparams + best formula
    configs.append(('best_hyper+formula', best_lgb_params, best_formula,
                    best_formula_params, 0.05, None, 'both'))

    # 4. Best hyperparams + best formula + best scale_div
    configs.append(('best_hyper+formula+sd', best_lgb_params, best_formula,
                    best_formula_params, best_sd, None, 'both'))

    # 5. With emergency rebal (if it improved)
    if emerg_improved and emerg_thresh:
        configs.append(('best_all+emergency', best_lgb_params, best_formula,
                        best_formula_params, best_sd, emerg_thresh, emerg_dir))

    # 6. Default hyperparams + best allocation (to isolate effects)
    configs.append(('default_hyper+best_alloc', {}, best_formula,
                    best_formula_params, best_sd, None, 'both'))

    P(f"\n  Configs to test: {len(configs)}")

    final_results = {}

    for model_name, feature_cols in MODELS.items():
        P(f"\n  === Model: {model_name} ===")

        for cfg_label, lgb_p, formula, formula_p, sd, et, ed in configs:
            P(f"\n  {cfg_label} ({model_name}):")
            seeds_results = []
            for seed in SEEDS_10:
                P(f"    seed={seed}...", end="")
                r = run_strategy_v10(
                    daily_ret, returns, vols, df, dates, n,
                    feature_cols=feature_cols, base_seed=seed,
                    lgb_params=lgb_p if lgb_p else None,
                    scale_div=sd,
                    alloc_formula=formula,
                    alloc_params=formula_p,
                    emergency_threshold=et,
                    emergency_direction=ed)
                if r:
                    seeds_results.append(r)
                    P(f" {r['total']*100:+.1f}%")
                else:
                    P(" FAILED")

            if seeds_results:
                rets = [r['total'] * 100 for r in seeds_results]
                summary = _seed_summary(rets, seeds_results)
                key = f'{model_name}_{cfg_label}'
                final_results[key] = {
                    'model': model_name,
                    'config': cfg_label,
                    'lgb_params': lgb_p,
                    'formula': formula,
                    'formula_params': formula_p,
                    'scale_div': sd,
                    'emergency_threshold': et,
                    'emergency_direction': ed,
                    'seeds': summary,
                }
                P(f"    => mean={summary['mean']:+.1f}%, "
                  f"Sortino={summary['sortinos_mean']:.2f}, "
                  f"spread={summary['spread']:.0f}pp, "
                  f"beat_v2={summary['beat_v2']}/10")

    results['final'] = final_results
    return results


# ============================================================
# FINAL SUMMARY
# ============================================================

def print_final_summary(all_results):
    P(f"\n\n{'#'*100}")
    P("V10 MEGA-EXPERIMENT FINAL SUMMARY")
    P("#" * 100)

    # Collect all entries with seed summaries
    variants = []

    # Phase E combos
    for key, val in all_results.get('phase_e', {}).get('combos', {}).items():
        if isinstance(val, dict):
            s = val.get('seeds', val)
            if 'sortinos_mean' in s:
                variants.append((key, s['mean'], s['spread'], s['sortinos_mean'],
                                s['max_dds_mean'], s['beat_v2']))

    # Phase G finals
    for key, val in all_results.get('phase_g', {}).get('final', {}).items():
        if isinstance(val, dict) and 'seeds' in val:
            s = val['seeds']
            variants.append((key, s['mean'], s['spread'], s['sortinos_mean'],
                            s['max_dds_mean'], s['beat_v2']))

    # Sort by Sortino
    variants.sort(key=lambda x: x[3], reverse=True)

    P(f"\n  {'Config':<50} {'Mean':>8} {'Spread':>8} {'Sortino':>8} {'MaxDD':>8} {'BeatV2':>8}")
    P(f"  {'-'*92}")
    for name, mean, spread, sortino, mdd, bv2 in variants[:30]:
        P(f"  {name:<50} {mean:>+7.1f}% {spread:>7.0f}pp {sortino:>7.2f} {mdd:>7.1f}% {bv2:>5}/10")

    # Accuracy summary from Phase D
    phase_d_data = all_results.get('phase_d', {})
    if phase_d_data:
        P(f"\n  ACCURACY SUMMARY:")
        P(f"  {'Model':<12} {'Dir Acc':>8} {'Wt Acc':>8} {'Corr':>8} {'Acc-Sort corr':>14}")
        P(f"  {'-'*52}")
        for model, data in phase_d_data.items():
            s = data.get('summary', {})
            P(f"  {model:<12} {s.get('mean_accuracy',0):.1%}   "
              f"{s.get('mean_weighted_accuracy',0):.1%}   "
              f"{s.get('mean_correlation',0):.3f}   "
              f"{s.get('acc_sortino_corr',0):.3f}")

    if variants:
        best = variants[0]
        P(f"\n  BEST OVERALL: {best[0]}")
        P(f"    Mean: {best[1]:+.1f}%, Sortino: {best[3]:.2f}, "
          f"Spread: {best[2]:.0f}pp, MaxDD: {best[4]:.1f}%")


# ============================================================
# MAIN
# ============================================================

def main():
    P("=" * 100)
    P("PIPELINE V10 - MEGA-EXPERIMENT")
    P("  Hyperparameters + Allocation + Emergency Rebal + Accuracy")
    P("=" * 100)
    start_time = datetime.now()
    P(f"  Start time: {start_time.strftime('%Y-%m-%d %H:%M:%S')}")

    P("\nLoading data...")
    prices, daily_ret, returns, vols, df = load_data()
    dates = df['date'].values
    n = len(prices)
    P(f"  {n} days | {dates[0]} to {dates[-1]}")

    # Build real CDI
    global RF_DAILY_ARR
    import archive.old_pipelines.pipeline_v09 as v9_module
    try:
        from src.features.macro.cdi_rates import build_rf_daily
        RF_DAILY_ARR = build_rf_daily(dates, source='auto')
        v9_module.RF_DAILY_ARR = RF_DAILY_ARR
        rf_mean_annual = (np.prod(1 + RF_DAILY_ARR[-365:]) - 1) * 100
        P(f"  RF: Real CDI loaded ({RF_DAILY_ARR.shape[0]} days, "
          f"last-year ~{rf_mean_annual:.1f}%)")
    except Exception:
        from src.features.macro.cdi_rates import build_rf_daily
        RF_DAILY_ARR = build_rf_daily(dates, source='copom')
        v9_module.RF_DAILY_ARR = RF_DAILY_ARR
        P(f"  RF: COPOM fallback loaded")

    # Validate feature availability
    for model_name, feat_list in MODELS.items():
        valid = [f for f in feat_list if f in df.columns or f in
                 ['ret_3d','ret_5d','ret_7d','ret_10d','ret_14d','ret_30d',
                  'ret_45d','ret_60d','vol_7d','vol_14d','vol_30d']]
        P(f"  {model_name}: {len(valid)}/{len(feat_list)} features available")

    all_results = {
        'timestamp': start_time.isoformat(),
        'method': 'pipeline_v10',
        'test_period': '2022-2026',
        'models': {k: v for k, v in MODELS.items()},
    }

    # ========================================
    # PHASE A: Hyperparameter sweep
    # ========================================
    P(f"\n  Starting Phase A... ({datetime.now().strftime('%H:%M:%S')})")
    phase_a_results = phase_a(daily_ret, returns, vols, df, dates, n)
    all_results['phase_a'] = phase_a_results
    _save(all_results)

    # ========================================
    # PHASE B: Allocation formula
    # ========================================
    P(f"\n  Starting Phase B... ({datetime.now().strftime('%H:%M:%S')})")
    phase_b_results = phase_b(daily_ret, returns, vols, df, dates, n)
    all_results['phase_b'] = phase_b_results
    _save(all_results)

    # ========================================
    # PHASE C: Emergency rebalancing
    # ========================================
    P(f"\n  Starting Phase C... ({datetime.now().strftime('%H:%M:%S')})")
    phase_c_results = phase_c(daily_ret, returns, vols, df, dates, n)
    all_results['phase_c'] = phase_c_results
    _save(all_results)

    # ========================================
    # PHASE D: Accuracy analysis
    # ========================================
    P(f"\n  Starting Phase D... ({datetime.now().strftime('%H:%M:%S')})")
    phase_d_results = phase_d(daily_ret, returns, vols, df, dates, n)
    all_results['phase_d'] = phase_d_results
    _save(all_results)

    # ========================================
    # PHASE E: Top combos
    # ========================================
    P(f"\n  Starting Phase E... ({datetime.now().strftime('%H:%M:%S')})")
    phase_e_results = phase_e(daily_ret, returns, vols, df, dates, n,
                              phase_a_results, phase_b_results)
    all_results['phase_e'] = phase_e_results
    _save(all_results)

    # ========================================
    # PHASE F: Fine grid
    # ========================================
    P(f"\n  Starting Phase F... ({datetime.now().strftime('%H:%M:%S')})")
    phase_f_results = phase_f(daily_ret, returns, vols, df, dates, n,
                              phase_a_results, phase_e_results)
    all_results['phase_f'] = phase_f_results
    _save(all_results)

    # ========================================
    # PHASE G: Final combination
    # ========================================
    P(f"\n  Starting Phase G... ({datetime.now().strftime('%H:%M:%S')})")
    phase_g_results = phase_g(daily_ret, returns, vols, df, dates, n,
                              phase_a_results, phase_b_results, phase_c_results,
                              phase_e_results, phase_f_results)
    all_results['phase_g'] = phase_g_results
    _save(all_results)

    # ========================================
    # FINAL SUMMARY
    # ========================================
    print_final_summary(all_results)

    elapsed = (datetime.now() - start_time).total_seconds() / 3600
    all_results['elapsed_hours'] = float(elapsed)
    _save(all_results)

    P(f"\n{'='*100}")
    P(f"V10 MEGA-EXPERIMENT COMPLETE")
    P(f"  End time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    P(f"  Elapsed: {elapsed:.1f}h")
    P(f"  Results: {RESULTS_PATH}")
    P("=" * 100)


if __name__ == '__main__':
    main()
