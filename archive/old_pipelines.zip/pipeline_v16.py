"""
PIPELINE V16 — All 10 Experiments (Full 16-core parallel)
==========================================================

Group A: Same XGB60 predictions, different sizing (train once, test 20+ strategies)
  - Exp 4: Target Volatility (risk parity)
  - Exp 5: Kelly Criterion
  - Exp 6: Centered + Trend Filter
  - Exp 7: Drawdown Budget
  - Exp 9: Prediction Z-Score
  - Exp 10: Bayesian Shrinkage
  + combinations of above

Group B: Different model targets (need separate training)
  - Exp 1: Risk-Adjusted Target (return / vol)
  - Exp 2: Two-Model Pipeline (classifier + regressor)
  - Exp 8: Multi-Horizon Veto (3d + 7d + 14d vote)

Using all 16 logical cores.
Estimated: ~8-10h
"""

import sys
import gc
import numpy as np
import pandas as pd
from pathlib import Path
import warnings
import json
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
import lightgbm as lgb
import xgboost as xgb

warnings.filterwarnings('ignore')
sys.stdout.reconfigure(line_buffering=True)

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

from scripts.optimization.pipeline_v9 import (
    load_data, build_ml_features, backtest_allocations,
    metrics, get_year_boundaries,
    SEEDS_10, COST, DEFAULT_LGB_PARAMS,
    P, _seed_summary, convert_numpy,
)
from scripts.optimization.pipeline_v10_mega import MODELS
from scripts.optimization.pipeline_v11_xgb import DEFAULT_XGB_PARAMS
from scripts.optimization.pipeline_v13_definitive import (
    _get_retrain_periods, _train_one_xgb, _train_one_lgb,
)

RF_DAILY_ARR = None
RESULTS_PATH = ROOT / 'outputs/results/pipeline_v16_experiments.json'
WORKERS = 16  # all cores


def _save(R):
    RESULTS_PATH.parent.mkdir(parents=True, exist_ok=True)
    RESULTS_PATH.write_text(json.dumps(convert_numpy(R), indent=2, default=str), encoding='utf-8')
    P(f"  [SAVE] {RESULTS_PATH.name}")


def get_clean_feats():
    return [f for f in MODELS['37feat'] if f != 'exchange_netflow_ma7'] + ['basis_pct']


# ============================================================
# SHARED: Pre-compute indicators needed by all strategies
# ============================================================

def precompute_indicators(prices, daily_ret, dates, n):
    sma_20 = pd.Series(prices).rolling(20).mean().values
    sma_50 = pd.Series(prices).rolling(50).mean().values
    sma_200 = pd.Series(prices).rolling(200).mean().values
    vol_7 = pd.Series(daily_ret).rolling(7).std().fillna(0.02).values
    vol_30 = pd.Series(daily_ret).rolling(30).std().fillna(0.02).values
    yb = get_year_boundaries(dates, n)
    oos_start = yb[2022]['start'] if 2022 in yb else 0
    vol_median = np.nanmedian(vol_30[:oos_start])
    return dict(sma_20=sma_20, sma_50=sma_50, sma_200=sma_200,
                vol_7=vol_7, vol_30=vol_30, vol_median=vol_median)


# ============================================================
# GROUP A: Train XGB60 once, test many sizing strategies
# ============================================================

def train_xgb60(daily_ret, returns, vols, df, dates, n,
                feature_cols, base_seed=42, target_array=None):
    """Train XGB60 and return predictions + std for every OOS day."""
    prices = df['price_usd'].values
    X_all, feat_names = build_ml_features(df, returns, vols, n, feature_cols=feature_cols)

    if target_array is None:
        target_array = np.zeros(n)
        for i in range(n - 3):
            target_array[i] = (prices[i + 3] - prices[i]) / prices[i]

    xgb_p = dict(DEFAULT_XGB_PARAMS)
    periods = _get_retrain_periods(dates, n, 'semi')

    pred_mean = np.full(n, np.nan)
    pred_std = np.full(n, np.nan)
    pred_all = np.full((n, 60), np.nan)  # individual model predictions

    for train_end, test_start, test_end in periods:
        train_mask = np.arange(60, train_end - 5 + 1)
        valid = ~np.any(np.isnan(X_all[train_mask]), axis=1)
        idx = train_mask[valid]
        if len(idx) < 100:
            continue

        Xt = np.nan_to_num(X_all[idx], nan=0.0)
        yt = target_array[idx]
        seeds = [base_seed + i * 7 for i in range(60)]
        args = [(s, Xt, yt, xgb_p) for s in seeds]
        with ThreadPoolExecutor(max_workers=WORKERS) as ex:
            models = list(ex.map(_train_one_xgb, args))

        for t in range(test_start, test_end + 1):
            x_t = np.nan_to_num(X_all[t:t + 1].copy(), nan=0.0)
            preds = [m.predict(x_t)[0] for m in models]
            pred_mean[t] = np.mean(preds)
            pred_std[t] = np.std(preds)
            pred_all[t, :len(preds)] = preds

    return pred_mean, pred_std, pred_all


def backtest_strategy(daily_ret, dates, n, prices, indicators,
                      pred_mean, pred_std, alloc_fn, rebal_day=4):
    """Fast backtest: apply allocation function to pre-computed predictions."""
    day_of_week = pd.to_datetime(dates).dayofweek
    periods = _get_retrain_periods(dates, n, 'semi')
    full_allocs = np.full(n, 0.0)
    is_rf_arr = isinstance(RF_DAILY_ARR, np.ndarray)
    all_strat, all_btc, all_alloc, all_rf = [], [], [], []

    running_equity = 1.0
    peak_equity = 1.0
    prev_alloc = 0.0
    # Rolling prediction stats
    pred_history = []

    for train_end, test_start, test_end in periods:
        for t in range(test_start, test_end + 1):
            if np.isnan(pred_mean[t]):
                raw = prev_alloc
            elif day_of_week[t] == rebal_day:
                dd = (running_equity - peak_equity) / (peak_equity + 1e-10)
                pred_history.append(pred_mean[t])

                # Rolling pred stats (last 20 rebalances)
                recent = pred_history[-20:]
                pred_rolling_mean = np.mean(recent) if len(recent) >= 5 else 0
                pred_rolling_std = np.std(recent) if len(recent) >= 5 else 0.01

                ctx = dict(
                    pred=pred_mean[t], pred_std=pred_std[t],
                    price=prices[t],
                    sma_20=indicators['sma_20'][t],
                    sma_50=indicators['sma_50'][t],
                    sma_200=indicators['sma_200'][t],
                    vol_7=indicators['vol_7'][t],
                    vol_30=indicators['vol_30'][t],
                    vol_median=indicators['vol_median'],
                    drawdown=dd,
                    pred_rolling_mean=pred_rolling_mean,
                    pred_rolling_std=pred_rolling_std,
                    running_equity=running_equity,
                )
                raw = alloc_fn(ctx)
            else:
                raw = prev_alloc

            full_allocs[t] = np.clip(raw, -0.25, 1.0)
            prev_alloc = full_allocs[t]

        s, b, a = backtest_allocations(daily_ret, full_allocs, test_start, test_end,
                                       cost=COST, rf_daily=RF_DAILY_ARR)
        all_strat.extend(s)
        all_btc.extend(b)
        all_alloc.extend(a)
        for sr in s:
            running_equity *= (1 + sr)
            peak_equity = max(peak_equity, running_equity)
        nd = len(s)
        if is_rf_arr:
            all_rf.extend(RF_DAILY_ARR[test_start:test_start + nd])
        else:
            all_rf.extend([0.0] * nd)

    return metrics(np.array(all_strat), np.array(all_btc), np.array(all_alloc),
                   rf_daily=np.array(all_rf))


# ============================================================
# ALLOCATION FUNCTIONS (Group A)
# ============================================================

def alloc_baseline(ctx):
    return np.clip(ctx['pred'] * 27 + 0.375, -0.25, 1.0)

# --- Exp 6: Centered + Trend Filter ---
def make_centered_trend(K, trend=True):
    def fn(ctx):
        raw = ctx['pred'] * K
        if trend and not np.isnan(ctx['sma_50']) and not np.isnan(ctx['sma_200']):
            if ctx['price'] < ctx['sma_200']:
                raw = min(raw, 0.0)
            elif ctx['price'] < ctx['sma_50']:
                raw = min(raw, 0.3)
        return np.clip(raw, -0.25, 1.0)
    return fn

# --- Exp 4: Target Volatility ---
def make_target_vol(target_annual_vol=0.15):
    def fn(ctx):
        realized_vol = ctx['vol_30'] * np.sqrt(365)
        if realized_vol < 0.05:
            realized_vol = 0.05
        position_scale = target_annual_vol / realized_vol
        raw = np.sign(ctx['pred']) * min(position_scale, 1.0) if abs(ctx['pred']) > 0.002 else 0.0
        # Trend filter
        if not np.isnan(ctx['sma_200']) and ctx['price'] < ctx['sma_200']:
            raw = min(raw, 0.0)
        return np.clip(raw, -0.25, 1.0)
    return fn

# --- Exp 5: Kelly ---
def make_kelly(K=27):
    def fn(ctx):
        pred = ctx['pred']
        # Estimate edge from prediction magnitude
        # Kelly: f = edge / odds. Approximate: f = pred * K * confidence
        confidence = 1.0 - np.clip(ctx['pred_std'] / 0.03, 0, 0.8)
        kelly_raw = pred * K * confidence
        # Half-Kelly for safety
        raw = kelly_raw * 0.5
        # Trend filter
        if not np.isnan(ctx['sma_200']) and ctx['price'] < ctx['sma_200']:
            raw = min(raw, 0.0)
        return np.clip(raw, -0.25, 1.0)
    return fn

# --- Exp 7: Drawdown Budget ---
def make_dd_budget(K=27, max_dd=-0.15):
    def fn(ctx):
        raw = ctx['pred'] * K
        dd = ctx['drawdown']
        if dd < max_dd * 0.5:
            scale = max(0.1, 1.0 - abs(dd) / abs(max_dd))
            raw *= scale
        if dd < max_dd:
            raw = min(raw, 0.0)  # only short/flat when budget exceeded
        # Trend filter
        if not np.isnan(ctx['sma_200']) and ctx['price'] < ctx['sma_200']:
            raw = min(raw, 0.0)
        return np.clip(raw, -0.25, 1.0)
    return fn

# --- Exp 9: Prediction Z-Score ---
def make_pred_zscore(K=27):
    def fn(ctx):
        pred_z = (ctx['pred'] - ctx['pred_rolling_mean']) / (ctx['pred_rolling_std'] + 1e-8)
        raw = pred_z * 0.3  # scale z-score to allocation range
        # Trend filter
        if not np.isnan(ctx['sma_200']) and ctx['price'] < ctx['sma_200']:
            raw = min(raw, 0.0)
        return np.clip(raw, -0.25, 1.0)
    return fn

# --- Exp 10: Bayesian Shrinkage ---
def make_shrinkage(K=27, shrink_factor=0.5):
    def fn(ctx):
        confidence = 1.0 - np.clip(ctx['pred_std'] / 0.03, 0, 0.9)
        shrunk_pred = ctx['pred'] * (shrink_factor + (1 - shrink_factor) * confidence)
        raw = shrunk_pred * K
        if not np.isnan(ctx['sma_200']) and ctx['price'] < ctx['sma_200']:
            raw = min(raw, 0.0)
        return np.clip(raw, -0.25, 1.0)
    return fn

# --- Exp 4+5+6+7+9 Combined ---
def make_full_smart(K=27, target_vol=0.15, max_dd=-0.15):
    def fn(ctx):
        pred = ctx['pred']
        # Vol scaling
        realized_vol = ctx['vol_30'] * np.sqrt(365)
        vol_scale = min(target_vol / max(realized_vol, 0.05), 2.0)
        # Confidence
        confidence = 1.0 - np.clip(ctx['pred_std'] / 0.03, 0, 0.8)
        # Pred z-score weighting
        pred_z = abs(ctx['pred'] - ctx['pred_rolling_mean']) / (ctx['pred_rolling_std'] + 1e-8)
        z_weight = min(pred_z / 2.0, 1.0)  # strong signal = weight 1, weak = 0
        # Base allocation
        raw = pred * K * confidence * vol_scale * max(z_weight, 0.3)
        # Half-Kelly safety
        raw *= 0.5
        # Drawdown budget
        dd = ctx['drawdown']
        if dd < max_dd * 0.5:
            raw *= max(0.1, 1.0 - abs(dd) / abs(max_dd))
        # Trend filter
        if not np.isnan(ctx['sma_50']) and not np.isnan(ctx['sma_200']):
            if ctx['price'] < ctx['sma_200']:
                raw = min(raw, 0.0)
            elif ctx['price'] < ctx['sma_50']:
                raw = min(raw, 0.3)
        return np.clip(raw, -0.25, 1.0)
    return fn


# ============================================================
# GROUP B: Different model targets
# ============================================================

# --- Exp 1: Risk-Adjusted Target ---
def train_risk_adjusted(daily_ret, returns, vols, df, dates, n, feature_cols, base_seed, indicators):
    """Train on return_3d / vol_7d instead of raw return_3d."""
    prices = df['price_usd'].values
    target_ra = np.zeros(n)
    for i in range(n - 3):
        ret_3d = (prices[i + 3] - prices[i]) / prices[i]
        vol = indicators['vol_7'][i]
        if vol > 0.001:
            target_ra[i] = ret_3d / vol
        else:
            target_ra[i] = 0
    # Clip extreme values
    target_ra = np.clip(target_ra, -10, 10)
    return train_xgb60(daily_ret, returns, vols, df, dates, n,
                       feature_cols, base_seed, target_array=target_ra)


# --- Exp 2: Two-Model Pipeline ---
def train_classifier_regressor(daily_ret, returns, vols, df, dates, n,
                                feature_cols, base_seed):
    """Train classifier (UP/DOWN) + regressor. Return both predictions."""
    prices = df['price_usd'].values
    X_all, _ = build_ml_features(df, returns, vols, n, feature_cols=feature_cols)

    target_reg = np.zeros(n)
    target_cls = np.zeros(n)
    for i in range(n - 3):
        ret = (prices[i + 3] - prices[i]) / prices[i]
        target_reg[i] = ret
        target_cls[i] = 1.0 if ret > 0 else 0.0

    xgb_p = dict(DEFAULT_XGB_PARAMS)
    xgb_cls_p = dict(DEFAULT_XGB_PARAMS)
    xgb_cls_p['objective'] = 'binary:logistic'
    xgb_cls_p['eval_metric'] = 'logloss'

    periods = _get_retrain_periods(dates, n, 'semi')
    pred_reg = np.full(n, np.nan)
    pred_cls = np.full(n, np.nan)

    for train_end, test_start, test_end in periods:
        train_mask = np.arange(60, train_end - 5 + 1)
        valid = ~np.any(np.isnan(X_all[train_mask]), axis=1)
        idx = train_mask[valid]
        if len(idx) < 100:
            continue

        Xt = np.nan_to_num(X_all[idx], nan=0.0)

        # Regressor (30 models)
        seeds_r = [base_seed + i * 7 for i in range(30)]
        args = [(s, Xt, target_reg[idx], xgb_p) for s in seeds_r]
        with ThreadPoolExecutor(max_workers=WORKERS) as ex:
            models_reg = list(ex.map(_train_one_xgb, args))

        # Classifier (30 models)
        cls_models = []
        for i in range(30):
            seed = base_seed + 1000 + i * 7
            p = dict(xgb_cls_p)
            p['random_state'] = seed
            ne = p.pop('n_estimators', 200)
            m = xgb.XGBClassifier(n_estimators=ne, use_label_encoder=False, **p)
            m.fit(Xt, target_cls[idx])
            cls_models.append(m)

        for t in range(test_start, test_end + 1):
            x_t = np.nan_to_num(X_all[t:t + 1].copy(), nan=0.0)
            reg_preds = [m.predict(x_t)[0] for m in models_reg]
            cls_probs = [m.predict_proba(x_t)[0, 1] for m in cls_models]
            pred_reg[t] = np.mean(reg_preds)
            pred_cls[t] = np.mean(cls_probs)

    return pred_reg, pred_cls


# --- Exp 8: Multi-Horizon Veto ---
def train_multi_horizon(daily_ret, returns, vols, df, dates, n,
                         feature_cols, base_seed):
    """Train on 3d, 7d, 14d targets. Return predictions for each."""
    prices = df['price_usd'].values
    X_all, _ = build_ml_features(df, returns, vols, n, feature_cols=feature_cols)

    targets = {}
    for h in [3, 7, 14]:
        t = np.zeros(n)
        for i in range(n - h):
            t[i] = (prices[i + h] - prices[i]) / prices[i]
        targets[h] = t

    xgb_p = dict(DEFAULT_XGB_PARAMS)
    periods = _get_retrain_periods(dates, n, 'semi')
    preds = {h: np.full(n, np.nan) for h in [3, 7, 14]}

    for train_end, test_start, test_end in periods:
        train_mask = np.arange(60, train_end - 5 + 1)
        valid = ~np.any(np.isnan(X_all[train_mask]), axis=1)
        idx = train_mask[valid]
        if len(idx) < 100:
            continue

        Xt = np.nan_to_num(X_all[idx], nan=0.0)

        for h in [3, 7, 14]:
            seeds = [base_seed + h * 100 + i * 7 for i in range(20)]
            args = [(s, Xt, targets[h][idx], xgb_p) for s in seeds]
            with ThreadPoolExecutor(max_workers=WORKERS) as ex:
                models = list(ex.map(_train_one_xgb, args))

            for t in range(test_start, test_end + 1):
                x_t = np.nan_to_num(X_all[t:t + 1].copy(), nan=0.0)
                p = [m.predict(x_t)[0] for m in models]
                preds[h][t] = np.mean(p)

    return preds


# ============================================================
# GROUP B ALLOCATION FUNCTIONS
# ============================================================

def make_risk_adjusted_alloc(K=27):
    """Allocation for risk-adjusted predictions (already vol-normalized)."""
    def fn(ctx):
        # pred is now return/vol, so scale differently
        raw = ctx['pred'] * K * 0.01  # smaller scale since pred is larger
        if not np.isnan(ctx['sma_200']) and ctx['price'] < ctx['sma_200']:
            raw = min(raw, 0.0)
        return np.clip(raw, -0.25, 1.0)
    return fn

def make_two_model_alloc(K=27, cls_threshold=0.5):
    """Only act when classifier and regressor agree."""
    def fn(ctx):
        pred_reg = ctx['pred']  # regressor prediction
        pred_cls = ctx.get('pred_cls', 0.5)  # classifier probability
        # Classifier says UP if prob > threshold
        cls_up = pred_cls > cls_threshold
        cls_down = pred_cls < (1 - cls_threshold)
        reg_up = pred_reg > 0
        reg_down = pred_reg < 0

        if cls_up and reg_up:
            raw = pred_reg * K
        elif cls_down and reg_down:
            raw = pred_reg * K
        else:
            raw = 0.0  # disagree → flat

        if not np.isnan(ctx['sma_200']) and ctx['price'] < ctx['sma_200']:
            raw = min(raw, 0.0)
        return np.clip(raw, -0.25, 1.0)
    return fn

def make_veto_alloc(K=27):
    """Multi-horizon veto: only act when all horizons agree."""
    def fn(ctx):
        p3 = ctx.get('pred_3d', 0)
        p7 = ctx.get('pred_7d', 0)
        p14 = ctx.get('pred_14d', 0)
        all_up = p3 > 0 and p7 > 0 and p14 > 0
        all_down = p3 < 0 and p7 < 0 and p14 < 0

        if all_up:
            raw = p3 * K  # use 3d for sizing
        elif all_down:
            raw = p3 * K
        else:
            raw = 0.0  # veto: no consensus

        if not np.isnan(ctx['sma_200']) and ctx['price'] < ctx['sma_200']:
            raw = min(raw, 0.0)
        return np.clip(raw, -0.25, 1.0)
    return fn


# ============================================================
# MAIN
# ============================================================

def main():
    P("=" * 100)
    P("PIPELINE V16 — ALL 10 EXPERIMENTS (16 cores)")
    P("=" * 100)
    start = datetime.now()
    P(f"  Start: {start.strftime('%Y-%m-%d %H:%M:%S')}")

    P("\nLoading data...")
    prices_arr, daily_ret, returns, vols, df = load_data()
    dates = df['date'].values
    n = len(prices_arr)
    prices = df['price_usd'].values

    global RF_DAILY_ARR
    import scripts.optimization.pipeline_v9 as v9m
    import scripts.optimization.pipeline_v10_mega as v10m
    import scripts.optimization.pipeline_v11_xgb as v11m
    import scripts.optimization.pipeline_v12_hybrid as v12m
    import scripts.optimization.pipeline_v13_definitive as v13m
    try:
        from src.features.macro.cdi_rates import build_rf_daily
        RF_DAILY_ARR = build_rf_daily(dates, source='auto')
    except Exception:
        from src.features.macro.cdi_rates import build_rf_daily
        RF_DAILY_ARR = build_rf_daily(dates, source='copom')
    v9m.RF_DAILY_ARR = RF_DAILY_ARR
    v10m.RF_DAILY_ARR = RF_DAILY_ARR
    v11m.RF_DAILY_ARR = RF_DAILY_ARR
    v12m.RF_DAILY_ARR = RF_DAILY_ARR
    v13m.RF_DAILY_ARR = RF_DAILY_ARR

    fc = get_clean_feats()
    indicators = precompute_indicators(prices, daily_ret, dates, n)
    P(f"  Features: {len(fc)} | Workers: {WORKERS}")

    # Define ALL Group A strategies
    group_a_strategies = [
        ('baseline_K27', alloc_baseline),
        ('centered_K20', make_centered_trend(20, trend=False)),
        ('centered_K25', make_centered_trend(25, trend=False)),
        ('centered_K27', make_centered_trend(27, trend=False)),
        ('centered_K30', make_centered_trend(30, trend=False)),
        ('trend_K20', make_centered_trend(20, trend=True)),
        ('trend_K25', make_centered_trend(25, trend=True)),
        ('trend_K27', make_centered_trend(27, trend=True)),
        ('trend_K30', make_centered_trend(30, trend=True)),
        ('trend_K35', make_centered_trend(35, trend=True)),
        ('targetvol_10', make_target_vol(0.10)),
        ('targetvol_15', make_target_vol(0.15)),
        ('targetvol_20', make_target_vol(0.20)),
        ('targetvol_25', make_target_vol(0.25)),
        ('kelly_K25', make_kelly(25)),
        ('kelly_K27', make_kelly(27)),
        ('kelly_K30', make_kelly(30)),
        ('dd_budget_15pct', make_dd_budget(27, -0.15)),
        ('dd_budget_20pct', make_dd_budget(27, -0.20)),
        ('pred_zscore', make_pred_zscore(27)),
        ('shrinkage_50', make_shrinkage(27, 0.5)),
        ('shrinkage_30', make_shrinkage(27, 0.3)),
        ('smart_K25_tv15', make_full_smart(25, 0.15, -0.15)),
        ('smart_K27_tv15', make_full_smart(27, 0.15, -0.15)),
        ('smart_K30_tv15', make_full_smart(30, 0.15, -0.15)),
        ('smart_K27_tv20', make_full_smart(27, 0.20, -0.15)),
        ('smart_K27_tv15_dd20', make_full_smart(27, 0.15, -0.20)),
    ]

    R = {'timestamp': start.isoformat(), 'method': 'pipeline_v16'}
    all_summaries = {}

    # ========================================
    # GROUP A: Train once, test many
    # ========================================
    P(f"\n{'#'*100}")
    P(f"GROUP A: SAME MODEL, DIFFERENT SIZING ({len(group_a_strategies)} strategies)")
    P("#" * 100)

    for seed in SEEDS_10:
        P(f"\n  === Seed {seed} ===")
        P(f"  Training XGB60...")
        pred_mean, pred_std, pred_all = train_xgb60(
            daily_ret, returns, vols, df, dates, n, fc, base_seed=seed)

        for name, alloc_fn in group_a_strategies:
            r = backtest_strategy(daily_ret, dates, n, prices, indicators,
                                  pred_mean, pred_std, alloc_fn)
            if r:
                if name not in all_summaries:
                    all_summaries[name] = []
                all_summaries[name].append(r)
                if seed == 42:
                    P(f"    {name:<30} {r['total']*100:+.1f}% S={r['sortino']:.2f} DD={r['max_dd']*100:.1f}%")
        gc.collect()

    R['group_a'] = {}
    for name, results in all_summaries.items():
        rets = [r['total'] * 100 for r in results]
        R['group_a'][name] = _seed_summary(rets, results)
    _save(R)

    # ========================================
    # GROUP B EXP 1: Risk-Adjusted Target
    # ========================================
    P(f"\n{'#'*100}")
    P(f"EXP 1: RISK-ADJUSTED TARGET ({datetime.now().strftime('%H:%M')})")
    P("#" * 100)

    ra_strategies = [
        ('ra_K20', make_risk_adjusted_alloc(20)),
        ('ra_K25', make_risk_adjusted_alloc(25)),
        ('ra_K27', make_risk_adjusted_alloc(27)),
        ('ra_K30', make_risk_adjusted_alloc(30)),
        ('ra_K35', make_risk_adjusted_alloc(35)),
        ('ra_K40', make_risk_adjusted_alloc(40)),
    ]
    ra_summaries = {}

    for seed in SEEDS_10:
        P(f"  seed={seed}...", end="")
        pred_mean, pred_std, _ = train_risk_adjusted(
            daily_ret, returns, vols, df, dates, n, fc, seed, indicators)
        first_print = True
        for name, alloc_fn in ra_strategies:
            r = backtest_strategy(daily_ret, dates, n, prices, indicators,
                                  pred_mean, pred_std, alloc_fn)
            if r:
                if name not in ra_summaries:
                    ra_summaries[name] = []
                ra_summaries[name].append(r)
                if first_print:
                    P(f" {name}: {r['total']*100:+.1f}% S={r['sortino']:.2f}")
                    first_print = False
        gc.collect()

    R['exp1_risk_adjusted'] = {}
    for name, results in ra_summaries.items():
        rets = [r['total'] * 100 for r in results]
        R['exp1_risk_adjusted'][name] = _seed_summary(rets, results)
    _save(R)

    # ========================================
    # GROUP B EXP 2: Two-Model Pipeline
    # ========================================
    P(f"\n{'#'*100}")
    P(f"EXP 2: TWO-MODEL PIPELINE ({datetime.now().strftime('%H:%M')})")
    P("#" * 100)

    tm_strategies = [
        ('twomodel_K25_t50', make_two_model_alloc(25, 0.50)),
        ('twomodel_K27_t50', make_two_model_alloc(27, 0.50)),
        ('twomodel_K27_t55', make_two_model_alloc(27, 0.55)),
        ('twomodel_K27_t60', make_two_model_alloc(27, 0.60)),
        ('twomodel_K30_t55', make_two_model_alloc(30, 0.55)),
    ]
    tm_summaries = {}

    for seed in SEEDS_10:
        P(f"  seed={seed}...", end="")
        pred_reg, pred_cls = train_classifier_regressor(
            daily_ret, returns, vols, df, dates, n, fc, seed)
        # Hack: store cls prediction in pred_std slot for backtest
        dummy_std = np.full(n, 0.01)
        first_print = True
        for name, alloc_fn_base in tm_strategies:
            # Create wrapper that passes cls prediction
            def make_wrapper(fn_base, p_cls):
                def wrapper(ctx):
                    ctx['pred_cls'] = p_cls[ctx_t_holder[0]] if not np.isnan(p_cls[ctx_t_holder[0]]) else 0.5
                    return fn_base(ctx)
                return wrapper

            # Need to pass t to the function — modify backtest slightly
            # Simpler: embed cls into pred_std (it's not used by these strategies)
            r = backtest_strategy_twomodel(
                daily_ret, dates, n, prices, indicators,
                pred_reg, pred_cls, dummy_std, alloc_fn_base)
            if r:
                if name not in tm_summaries:
                    tm_summaries[name] = []
                tm_summaries[name].append(r)
                if first_print:
                    P(f" {name}: {r['total']*100:+.1f}% S={r['sortino']:.2f}")
                    first_print = False
        gc.collect()

    R['exp2_two_model'] = {}
    for name, results in tm_summaries.items():
        rets = [r['total'] * 100 for r in results]
        R['exp2_two_model'][name] = _seed_summary(rets, results)
    _save(R)

    # ========================================
    # GROUP B EXP 8: Multi-Horizon Veto
    # ========================================
    P(f"\n{'#'*100}")
    P(f"EXP 8: MULTI-HORIZON VETO ({datetime.now().strftime('%H:%M')})")
    P("#" * 100)

    veto_strategies = [
        ('veto_K20', make_veto_alloc(20)),
        ('veto_K25', make_veto_alloc(25)),
        ('veto_K27', make_veto_alloc(27)),
        ('veto_K30', make_veto_alloc(30)),
    ]
    veto_summaries = {}

    for seed in SEEDS_10:
        P(f"  seed={seed}...", end="")
        horizon_preds = train_multi_horizon(
            daily_ret, returns, vols, df, dates, n, fc, seed)
        dummy_std = np.full(n, 0.01)
        first_print = True
        for name, alloc_fn_base in veto_strategies:
            r = backtest_strategy_veto(
                daily_ret, dates, n, prices, indicators,
                horizon_preds, dummy_std, alloc_fn_base)
            if r:
                if name not in veto_summaries:
                    veto_summaries[name] = []
                veto_summaries[name].append(r)
                if first_print:
                    P(f" {name}: {r['total']*100:+.1f}% S={r['sortino']:.2f}")
                    first_print = False
        gc.collect()

    R['exp8_veto'] = {}
    for name, results in veto_summaries.items():
        rets = [r['total'] * 100 for r in results]
        R['exp8_veto'][name] = _seed_summary(rets, results)
    _save(R)

    # ========================================
    # FINAL RANKING
    # ========================================
    elapsed = (datetime.now() - start).total_seconds() / 3600
    R['elapsed_hours'] = float(elapsed)

    P(f"\n\n{'='*100}")
    P("V16 ALL EXPERIMENTS — FINAL RANKING")
    P("=" * 100)

    all_v = []
    for group_name in ['group_a', 'exp1_risk_adjusted', 'exp2_two_model', 'exp8_veto']:
        data = R.get(group_name, {})
        tag = group_name.split('_')[0].upper() if 'exp' in group_name else 'A'
        for k, s in data.items():
            if isinstance(s, dict) and 'sortinos_mean' in s:
                all_v.append((f'[{tag}] {k}', s['mean'], s['spread'],
                              s['sortinos_mean'], s['max_dds_mean']))

    all_v.sort(key=lambda x: x[3], reverse=True)
    P(f"\n{'Rk':<4} {'Strategy':<45} {'Mean':>8} {'Spread':>8} {'Sortino':>8} {'MaxDD':>8}")
    P(f"{'-'*80}")
    for i, (name, mean, spread, sortino, mdd) in enumerate(all_v[:35], 1):
        P(f"{i:<4} {name:<45} {mean:>+7.1f}% {spread:>7.0f}pp {sortino:>7.2f} {mdd:>7.1f}%")

    _save(R)
    P(f"\n{'='*100}")
    P(f"V16 COMPLETE | {elapsed:.1f}h | {RESULTS_PATH}")
    P("=" * 100)


# ============================================================
# SPECIAL BACKTEST FUNCTIONS for Group B
# ============================================================

def backtest_strategy_twomodel(daily_ret, dates, n, prices, indicators,
                                pred_reg, pred_cls, pred_std, alloc_fn):
    """Backtest with both regressor and classifier predictions."""
    day_of_week = pd.to_datetime(dates).dayofweek
    periods = _get_retrain_periods(dates, n, 'semi')
    full_allocs = np.full(n, 0.0)
    is_rf_arr = isinstance(RF_DAILY_ARR, np.ndarray)
    all_strat, all_btc, all_alloc, all_rf = [], [], [], []
    prev_alloc = 0.0
    pred_history = []

    for train_end, test_start, test_end in periods:
        for t in range(test_start, test_end + 1):
            if np.isnan(pred_reg[t]):
                raw = prev_alloc
            elif day_of_week[t] == 4:
                pred_history.append(pred_reg[t])
                recent = pred_history[-20:]
                ctx = dict(
                    pred=pred_reg[t], pred_std=pred_std[t],
                    pred_cls=pred_cls[t] if not np.isnan(pred_cls[t]) else 0.5,
                    price=prices[t],
                    sma_20=indicators['sma_20'][t],
                    sma_50=indicators['sma_50'][t],
                    sma_200=indicators['sma_200'][t],
                    vol_7=indicators['vol_7'][t],
                    vol_30=indicators['vol_30'][t],
                    vol_median=indicators['vol_median'],
                    drawdown=0, pred_rolling_mean=np.mean(recent),
                    pred_rolling_std=np.std(recent) if len(recent) >= 5 else 0.01,
                )
                raw = alloc_fn(ctx)
            else:
                raw = prev_alloc
            full_allocs[t] = np.clip(raw, -0.25, 1.0)
            prev_alloc = full_allocs[t]

        s, b, a = backtest_allocations(daily_ret, full_allocs, test_start, test_end,
                                       cost=COST, rf_daily=RF_DAILY_ARR)
        all_strat.extend(s); all_btc.extend(b); all_alloc.extend(a)
        nd = len(s)
        if is_rf_arr:
            all_rf.extend(RF_DAILY_ARR[test_start:test_start + nd])
        else:
            all_rf.extend([0.0] * nd)

    return metrics(np.array(all_strat), np.array(all_btc), np.array(all_alloc),
                   rf_daily=np.array(all_rf))


def backtest_strategy_veto(daily_ret, dates, n, prices, indicators,
                            horizon_preds, pred_std, alloc_fn):
    """Backtest with multi-horizon veto predictions."""
    day_of_week = pd.to_datetime(dates).dayofweek
    periods = _get_retrain_periods(dates, n, 'semi')
    full_allocs = np.full(n, 0.0)
    is_rf_arr = isinstance(RF_DAILY_ARR, np.ndarray)
    all_strat, all_btc, all_alloc, all_rf = [], [], [], []
    prev_alloc = 0.0
    pred_history = []

    for train_end, test_start, test_end in periods:
        for t in range(test_start, test_end + 1):
            p3 = horizon_preds[3][t] if not np.isnan(horizon_preds[3][t]) else 0
            if np.isnan(horizon_preds[3][t]):
                raw = prev_alloc
            elif day_of_week[t] == 4:
                pred_history.append(p3)
                recent = pred_history[-20:]
                ctx = dict(
                    pred=p3, pred_std=pred_std[t],
                    pred_3d=horizon_preds[3][t] if not np.isnan(horizon_preds[3][t]) else 0,
                    pred_7d=horizon_preds[7][t] if not np.isnan(horizon_preds[7][t]) else 0,
                    pred_14d=horizon_preds[14][t] if not np.isnan(horizon_preds[14][t]) else 0,
                    price=prices[t],
                    sma_20=indicators['sma_20'][t],
                    sma_50=indicators['sma_50'][t],
                    sma_200=indicators['sma_200'][t],
                    vol_7=indicators['vol_7'][t],
                    vol_30=indicators['vol_30'][t],
                    vol_median=indicators['vol_median'],
                    drawdown=0, pred_rolling_mean=np.mean(recent),
                    pred_rolling_std=np.std(recent) if len(recent) >= 5 else 0.01,
                )
                raw = alloc_fn(ctx)
            else:
                raw = prev_alloc
            full_allocs[t] = np.clip(raw, -0.25, 1.0)
            prev_alloc = full_allocs[t]

        s, b, a = backtest_allocations(daily_ret, full_allocs, test_start, test_end,
                                       cost=COST, rf_daily=RF_DAILY_ARR)
        all_strat.extend(s); all_btc.extend(b); all_alloc.extend(a)
        nd = len(s)
        if is_rf_arr:
            all_rf.extend(RF_DAILY_ARR[test_start:test_start + nd])
        else:
            all_rf.extend([0.0] * nd)

    return metrics(np.array(all_strat), np.array(all_btc), np.array(all_alloc),
                   rf_daily=np.array(all_rf))


if __name__ == '__main__':
    main()
