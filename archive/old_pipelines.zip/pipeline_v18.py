"""
V18 Final Model + Interactive Charts + PBO Test
================================================
1. Run V18 + garch_persistence (38 features) — the new best config
2. Generate interactive Plotly charts (cumulative, monthly, weekly)
3. Run PBO (Probability of Backtest Overfitting) test
"""

import sys
import gc
import numpy as np
import pandas as pd
from pathlib import Path
import warnings
import json
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
from itertools import combinations

warnings.filterwarnings('ignore')
sys.stdout.reconfigure(line_buffering=True)

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

from archive.old_pipelines.pipeline_v09 import (
    load_data, build_ml_features, backtest_allocations,
    metrics, get_year_boundaries,
    SEEDS_10, COST, P, _seed_summary, convert_numpy,
)
from archive.old_pipelines.pipeline_v10 import MODELS
from archive.old_pipelines.pipeline_v11 import DEFAULT_XGB_PARAMS
from archive.old_pipelines.pipeline_v13 import _get_retrain_periods, _train_one_xgb

W = 16  # worker threads for parallel training


def get_clean_feats():
    """V18 base features: 32 clean (37feat minus broken exchange_netflow_ma7) + basis_pct."""
    return [f for f in MODELS['37feat'] if f != 'exchange_netflow_ma7'] + ['basis_pct']
RF_DAILY_ARR = None


# ============================================================
# GARCH COMPUTATION
# ============================================================

def compute_garch_features(daily_ret, n):
    """Compute GARCH(1,1) persistence (alpha+beta) — the only GARCH feature that improves V18."""
    try:
        from arch import arch_model
    except ImportError:
        P("  WARNING: 'arch' not installed (pip install arch). Using fallback.")
        return {'garch_persistence': np.full(n, 0.95)}

    P("  Computing GARCH persistence (~5 min)...")
    ret_pct = daily_ret * 100
    persistence = np.full(n, np.nan)
    min_window, refit = 252, 20
    last_model = None

    for t in range(min_window, n):
        try:
            if t % refit == 0 or last_model is None:
                data = ret_pct[max(0, t-756):t]
                am = arch_model(data, vol='Garch', p=1, q=1, mean='Zero', rescale=False)
                last_model = am.fit(disp='off', show_warning=False)
            params = last_model.params
            if 'alpha[1]' in params.index and 'beta[1]' in params.index:
                persistence[t] = params['alpha[1]'] + params['beta[1]']
        except Exception:
            if t > 0: persistence[t] = persistence[t-1]
        if t % 500 == 0:
            P(f"    GARCH progress: {t}/{n} ({t/n*100:.0f}%)")

    persistence = pd.Series(persistence).ffill().fillna(0.95).values
    P(f"  GARCH done: {n - min_window} observations")
    return {'garch_persistence': persistence}


# ============================================================
# ENGINE (V18 + GARCH persistence)
# ============================================================

def run_final(daily_ret, returns, vols, df, dates, n,
              feature_cols, garch_persistence, n_bags=80, base_seed=42,
              K_bull=50, K_mild=30, K_bear=15,
              retrain_freq='semi', target_horizon=3):
    """V18 final engine with garch_persistence as 38th feature."""

    xgb_params = dict(DEFAULT_XGB_PARAMS)
    prices = df['price_usd'].values
    X_all, _ = build_ml_features(df, returns, vols, n, feature_cols=feature_cols)
    # Add garch_persistence
    X_all = np.column_stack([X_all, garch_persistence])

    target = np.zeros(n)
    for i in range(n - target_horizon):
        target[i] = (prices[i + target_horizon] - prices[i]) / prices[i]

    dow = pd.to_datetime(dates).dayofweek
    sma_50 = pd.Series(prices).rolling(50).mean().values
    sma_200 = pd.Series(prices).rolling(200).mean().values
    periods = _get_retrain_periods(dates, n, retrain_freq)

    full_allocs = np.full(n, 0.0)
    is_rf = isinstance(RF_DAILY_ARR, np.ndarray)
    a_s, a_b, a_a, a_r, a_i = [], [], [], [], []
    prev = 0.0

    for te, ts, tend in periods:
        gap = max(target_horizon, 5)
        tm = np.arange(60, te - gap + 1)
        v = ~np.any(np.isnan(X_all[tm]), axis=1)
        idx = tm[v]
        if len(idx) < 100: continue
        Xt, yt = np.nan_to_num(X_all[idx], nan=0.0), target[idx]
        seeds = [base_seed + i * 7 for i in range(n_bags)]
        with ThreadPoolExecutor(max_workers=W) as ex:
            models = list(ex.map(_train_one_xgb, [(s, Xt, yt, xgb_params) for s in seeds]))
        if not models: continue

        for t in range(ts, tend + 1):
            if dow[t] != 4:
                full_allocs[t] = prev; continue
            x_t = np.nan_to_num(X_all[t:t+1].copy(), nan=0.0)
            avg = np.mean([m.predict(x_t)[0] for m in models])

            if not np.isnan(sma_50[t]) and not np.isnan(sma_200[t]):
                if prices[t] > sma_50[t] and sma_50[t] > sma_200[t]: raw = avg * K_bull
                elif prices[t] > sma_200[t]: raw = avg * K_mild
                else: raw = avg * K_bear
            else: raw = avg * K_mild

            full_allocs[t] = np.clip(raw, -0.25, 1.0)
            prev = full_allocs[t]

        s, b, a = backtest_allocations(daily_ret, full_allocs, ts, tend, cost=COST, rf_daily=RF_DAILY_ARR)
        a_s.extend(s); a_b.extend(b); a_a.extend(a)
        a_i.extend(range(ts, ts + len(s)))
        nd = len(s)
        a_r.extend(RF_DAILY_ARR[ts:ts+nd] if is_rf else [0.0]*nd)

    return (np.array(a_s), np.array(a_b), np.array(a_a),
            np.array(a_r), np.array(a_i))


# ============================================================
# CHARTS
# ============================================================

def generate_charts(dates, strat_daily, btc_daily, test_idx, prices, output_dir):
    """Generate interactive Plotly HTML charts."""
    try:
        import plotly.graph_objects as go
        from plotly.subplots import make_subplots
    except ImportError:
        P("  pip install plotly...")
        import subprocess
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'plotly'])
        import plotly.graph_objects as go
        from plotly.subplots import make_subplots

    dt = pd.to_datetime(dates)
    chart_dates = [dt[int(i)] for i in test_idx]

    # Cumulative returns
    strat_cum = np.cumprod(1 + strat_daily)
    btc_cum = np.cumprod(1 + btc_daily)

    # --- CHART 1: Cumulative Performance ---
    fig1 = go.Figure()
    fig1.add_trace(go.Scatter(x=chart_dates, y=strat_cum * 100,
                               name='Strategy', line=dict(color='blue', width=2)))
    fig1.add_trace(go.Scatter(x=chart_dates, y=btc_cum * 100,
                               name='Buy & Hold BTC', line=dict(color='orange', width=2)))
    fig1.update_layout(
        title='V18 Final (+GARCH persistence) vs Buy & Hold BTC',
        xaxis_title='Date', yaxis_title='Cumulative Return (%)',
        yaxis_type='log',
        hovermode='x unified',
        xaxis=dict(
            rangeselector=dict(buttons=[
                dict(count=1, label='1M', step='month'),
                dict(count=3, label='3M', step='month'),
                dict(count=6, label='6M', step='month'),
                dict(count=1, label='YTD', step='year', stepmode='todate'),
                dict(count=1, label='1Y', step='year'),
                dict(step='all', label='ALL')
            ]),
            rangeslider=dict(visible=True),
        ),
        template='plotly_white',
        height=700,
    )
    fig1.write_html(str(output_dir / 'v18_final_cumulative.html'))
    P(f"  Chart 1: v18_final_cumulative.html")

    # --- CHART 2: Weekly Returns Bar Chart ---
    # Aggregate to weekly
    df_weekly = pd.DataFrame({
        'date': chart_dates,
        'strat': strat_daily,
        'btc': btc_daily,
    })
    df_weekly['week'] = df_weekly['date'].dt.to_period('W').dt.start_time
    weekly = df_weekly.groupby('week').agg(
        strat_ret=('strat', lambda x: np.prod(1+x)-1),
        btc_ret=('btc', lambda x: np.prod(1+x)-1)
    ).reset_index()

    fig2 = go.Figure()
    fig2.add_trace(go.Bar(x=weekly['week'], y=weekly['strat_ret']*100,
                          name='Strategy', marker_color='blue', opacity=0.7))
    fig2.add_trace(go.Bar(x=weekly['week'], y=weekly['btc_ret']*100,
                          name='BTC', marker_color='orange', opacity=0.7))
    fig2.update_layout(
        title='Weekly Returns: Strategy vs BTC',
        xaxis_title='Week', yaxis_title='Return (%)',
        barmode='group', hovermode='x unified',
        xaxis=dict(rangeslider=dict(visible=True)),
        template='plotly_white', height=600,
    )
    fig2.write_html(str(output_dir / 'v18_final_weekly.html'))
    P(f"  Chart 2: v18_final_weekly.html")

    # --- CHART 3: Monthly Returns Heatmap ---
    df_monthly = df_weekly.copy()
    df_monthly['month'] = df_monthly['date'].dt.to_period('M')
    df_monthly['year'] = df_monthly['date'].dt.year
    df_monthly['mon'] = df_monthly['date'].dt.month
    monthly = df_monthly.groupby(['year', 'mon']).agg(
        strat_ret=('strat', lambda x: np.prod(1+x)-1),
        btc_ret=('btc', lambda x: np.prod(1+x)-1)
    ).reset_index()
    monthly['excess'] = monthly['strat_ret'] - monthly['btc_ret']

    # Pivot for heatmap
    pivot = monthly.pivot(index='year', columns='mon', values='excess')
    month_names = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']

    fig3 = go.Figure(data=go.Heatmap(
        z=pivot.values * 100,
        x=month_names[:pivot.shape[1]],
        y=[str(y) for y in pivot.index],
        colorscale='RdYlGn',
        zmid=0,
        text=np.round(pivot.values * 100, 1),
        texttemplate='%{text:.1f}%',
        hovertemplate='%{y} %{x}: %{z:.1f}% excess<extra></extra>',
    ))
    fig3.update_layout(
        title='Monthly Excess Return (Strategy - BTC) %',
        xaxis_title='Month', yaxis_title='Year',
        template='plotly_white', height=400,
    )
    fig3.write_html(str(output_dir / 'v18_final_monthly_excess.html'))
    P(f"  Chart 3: v18_final_monthly_excess.html")

    # --- CHART 4: Drawdown ---
    strat_peak = np.maximum.accumulate(strat_cum)
    strat_dd = (strat_cum - strat_peak) / strat_peak * 100
    btc_peak = np.maximum.accumulate(btc_cum)
    btc_dd = (btc_cum - btc_peak) / btc_peak * 100

    fig4 = go.Figure()
    fig4.add_trace(go.Scatter(x=chart_dates, y=strat_dd,
                               name='Strategy DD', fill='tozeroy',
                               line=dict(color='blue', width=1)))
    fig4.add_trace(go.Scatter(x=chart_dates, y=btc_dd,
                               name='BTC DD', fill='tozeroy',
                               line=dict(color='orange', width=1)))
    fig4.update_layout(
        title='Drawdown: Strategy vs BTC',
        xaxis_title='Date', yaxis_title='Drawdown (%)',
        hovermode='x unified',
        xaxis=dict(rangeslider=dict(visible=True)),
        template='plotly_white', height=500,
    )
    fig4.write_html(str(output_dir / 'v18_final_drawdown.html'))
    P(f"  Chart 4: v18_final_drawdown.html")

    # --- CHART 5: Rolling Sortino (90d) ---
    window = 90
    if len(strat_daily) > window:
        roll_sortino = []
        roll_dates = []
        for i in range(window, len(strat_daily)):
            s = strat_daily[i-window:i]
            downside = s[s < 0]
            if len(downside) > 0:
                ds = np.sqrt(np.mean(downside**2)) * np.sqrt(365)
                ann_ret = (np.prod(1+s)**(365/window) - 1)
                sortino = ann_ret / ds if ds > 0 else 0
            else:
                sortino = 10  # cap
            roll_sortino.append(min(sortino, 10))
            roll_dates.append(chart_dates[i])

        fig5 = go.Figure()
        fig5.add_trace(go.Scatter(x=roll_dates, y=roll_sortino,
                                   name='Rolling 90d Sortino',
                                   line=dict(color='green', width=2)))
        fig5.add_hline(y=2.0, line_dash='dash', line_color='red',
                       annotation_text='Sortino = 2.0')
        fig5.update_layout(
            title='Rolling 90-Day Sortino Ratio',
            xaxis_title='Date', yaxis_title='Sortino',
            hovermode='x unified',
            xaxis=dict(rangeslider=dict(visible=True)),
            template='plotly_white', height=500,
        )
        fig5.write_html(str(output_dir / 'v18_final_rolling_sortino.html'))
        P(f"  Chart 5: v18_final_rolling_sortino.html")


# ============================================================
# PBO TEST (Probability of Backtest Overfitting)
# ============================================================

def run_pbo_test(daily_ret, returns, vols, df, dates, n,
                 feature_cols, garch_persistence, N_splits=8):
    """
    PBO Test (Bailey, Borwein, Lopez de Prado, Zhu 2014).

    Method:
    1. Split OOS period into N_splits time blocks
    2. For each combination of N_splits/2 blocks as in-sample (IS), rest as out-of-sample (OOS)
    3. Run multiple configs on IS, pick the best
    4. Check if the best IS config also ranks well in OOS
    5. PBO = fraction of times where best IS config has negative OOS performance

    We test a grid of configs (different K values) to have enough variation.
    """
    P(f"\n  PBO Test (N_splits={N_splits})...")

    yb = get_year_boundaries(dates, n)
    oos_start = yb[2022]['start'] if 2022 in yb else 0
    oos_end = max(yb[yr]['end'] for yr in yb if yr >= 2022)
    oos_len = oos_end - oos_start + 1

    # Split OOS into N_splits blocks
    block_size = oos_len // N_splits
    blocks = []
    for i in range(N_splits):
        start = oos_start + i * block_size
        end = start + block_size - 1 if i < N_splits - 1 else oos_end
        blocks.append((start, end))

    P(f"    OOS: {oos_len} days, {N_splits} blocks of ~{block_size} days")

    # Configs to test (grid of K values)
    configs = []
    for kb in [30, 35, 40, 45, 50, 55]:
        for km in [20, 25, 30, 35]:
            for kbr in [10, 15, 20]:
                configs.append((kb, km, kbr))
    P(f"    Testing {len(configs)} configs")

    # Pre-compute: train model once per retrain period, collect predictions
    xgb_params = dict(DEFAULT_XGB_PARAMS)
    prices = df['price_usd'].values
    X_all, _ = build_ml_features(df, returns, vols, n, feature_cols=feature_cols)
    X_all = np.column_stack([X_all, garch_persistence])

    target = np.zeros(n)
    for i in range(n - 3):
        target[i] = (prices[i + 3] - prices[i]) / prices[i]

    dow = pd.to_datetime(dates).dayofweek
    sma_50 = pd.Series(prices).rolling(50).mean().values
    sma_200 = pd.Series(prices).rolling(200).mean().values
    periods = _get_retrain_periods(dates, n, 'semi')

    # Collect predictions for all Fridays in OOS
    friday_data = []  # list of (t, pred, regime, daily_ret_next_week)
    for te, ts, tend in periods:
        if tend < oos_start:
            continue
        gap = 5
        tm = np.arange(60, te - gap + 1)
        v = ~np.any(np.isnan(X_all[tm]), axis=1)
        idx = tm[v]
        if len(idx) < 100:
            continue
        Xt, yt = np.nan_to_num(X_all[idx], nan=0.0), target[idx]
        seeds = [42 + i * 7 for i in range(80)]
        with ThreadPoolExecutor(max_workers=W) as ex:
            models = list(ex.map(_train_one_xgb, [(s, Xt, yt, xgb_params) for s in seeds]))
        if not models:
            continue

        for t in range(max(ts, oos_start), min(tend, oos_end) + 1):
            if dow[t] != 4:
                continue
            x_t = np.nan_to_num(X_all[t:t+1].copy(), nan=0.0)
            pred = np.mean([m.predict(x_t)[0] for m in models])

            if not np.isnan(sma_50[t]) and not np.isnan(sma_200[t]):
                if prices[t] > sma_50[t] and sma_50[t] > sma_200[t]:
                    regime = 'BULL'
                elif prices[t] > sma_200[t]:
                    regime = 'MILD'
                else:
                    regime = 'BEAR'
            else:
                regime = 'MILD'

            # Collect next-week daily returns
            week_rets = daily_ret[t+1:min(t+6, n)]
            friday_data.append({
                't': t, 'pred': pred, 'regime': regime,
                'week_rets': week_rets,
            })

    P(f"    Collected {len(friday_data)} Friday predictions")

    # Function to compute Sortino for a config on a set of Fridays
    def eval_config(kb, km, kbr, fridays):
        all_daily = []
        for f in fridays:
            pred = f['pred']
            if f['regime'] == 'BULL':
                alloc = np.clip(pred * kb, -0.25, 1.0)
            elif f['regime'] == 'MILD':
                alloc = np.clip(pred * km, -0.25, 1.0)
            else:
                alloc = np.clip(pred * kbr, -0.25, 1.0)
            for dr in f['week_rets']:
                strat_ret = alloc * dr
                all_daily.append(strat_ret)
        if len(all_daily) < 20:
            return -999
        arr = np.array(all_daily)
        ann_ret = np.mean(arr) * 365
        downside = arr[arr < 0]
        if len(downside) == 0:
            return 10
        ds = np.sqrt(np.mean(downside**2)) * np.sqrt(365)
        return ann_ret / ds if ds > 0 else 0

    # Assign each friday to a block
    for f in friday_data:
        for bi, (bs, be) in enumerate(blocks):
            if bs <= f['t'] <= be:
                f['block'] = bi
                break
        else:
            f['block'] = N_splits - 1

    # CSCV: all combinations of N_splits/2 blocks as IS
    half = N_splits // 2
    all_combos = list(combinations(range(N_splits), half))
    P(f"    CSCV: {len(all_combos)} combinations of {half}/{N_splits} blocks")

    n_overfit = 0
    n_total = 0
    logit_values = []

    for combo_idx, is_blocks in enumerate(all_combos):
        oos_blocks = [i for i in range(N_splits) if i not in is_blocks]
        is_fridays = [f for f in friday_data if f['block'] in is_blocks]
        oos_fridays = [f for f in friday_data if f['block'] in oos_blocks]

        if len(is_fridays) < 10 or len(oos_fridays) < 10:
            continue

        # Evaluate all configs on IS
        is_scores = {}
        for cfg in configs:
            is_scores[cfg] = eval_config(*cfg, is_fridays)

        # Best IS config
        best_is_cfg = max(is_scores, key=is_scores.get)
        best_is_score = is_scores[best_is_cfg]

        # Evaluate best IS config on OOS
        oos_score = eval_config(*best_is_cfg, oos_fridays)

        # Evaluate all configs on OOS
        oos_scores = {}
        for cfg in configs:
            oos_scores[cfg] = eval_config(*cfg, oos_fridays)

        # Rank of best_is_cfg in OOS
        oos_ranked = sorted(oos_scores.values(), reverse=True)
        oos_rank = oos_ranked.index(oos_score) + 1 if oos_score in oos_ranked else len(configs)
        oos_pct = oos_rank / len(configs)

        # Logit: log(rank / (1 - rank))
        if 0 < oos_pct < 1:
            logit = np.log(oos_pct / (1 - oos_pct))
            logit_values.append(logit)

        # Overfit if OOS performance is negative
        if oos_score < 0:
            n_overfit += 1
        n_total += 1

        if combo_idx % 10 == 0:
            P(f"    CSCV {combo_idx+1}/{len(all_combos)}: IS best={best_is_cfg} "
              f"IS_S={best_is_score:.2f} OOS_S={oos_score:.2f} rank={oos_rank}/{len(configs)}")

    pbo = n_overfit / n_total if n_total > 0 else 1.0
    avg_logit = np.mean(logit_values) if logit_values else 0

    P(f"\n  PBO RESULTS:")
    P(f"    Combinations tested: {n_total}")
    P(f"    Times best IS had negative OOS: {n_overfit}")
    P(f"    PBO = {pbo:.4f} ({pbo*100:.1f}%)")
    P(f"    Average logit(rank): {avg_logit:.3f}")
    P(f"    Interpretation: {'LOW overfitting risk' if pbo < 0.50 else 'HIGH overfitting risk'}")

    return {
        'pbo': float(pbo),
        'n_total': n_total,
        'n_overfit': n_overfit,
        'avg_logit': float(avg_logit),
        'logit_values': [float(v) for v in logit_values],
    }


# ============================================================
# MAIN
# ============================================================

def main():
    P("=" * 80)
    P("V18 FINAL MODEL + CHARTS + PBO TEST")
    P("=" * 80)
    start = datetime.now()

    P("\nLoading data...")
    prices, daily_ret, returns, vols, df = load_data()
    dates = df['date'].values
    n = len(prices)

    global RF_DAILY_ARR
    import archive.old_pipelines.pipeline_v09 as v9m
    import archive.old_pipelines.pipeline_v13 as v13m
    try:
        from src.features.macro.cdi_rates import build_rf_daily
        RF_DAILY_ARR = build_rf_daily(dates, source='auto')
    except Exception:
        from src.features.macro.cdi_rates import build_rf_daily
        RF_DAILY_ARR = build_rf_daily(dates, source='copom')
    v9m.RF_DAILY_ARR = RF_DAILY_ARR; v13m.RF_DAILY_ARR = RF_DAILY_ARR

    fc = get_clean_feats()
    extra = ['fed_balance_sheet', 'futures_trade_count', 'vol_x_regime_duration',
             'velocity', 'hash_rate_pctchg_30d']
    fc = fc + [f for f in extra if f in df.columns and f not in fc]
    P(f"  {n} days | {len(fc)} + garch_persistence = 38 features")

    # Compute GARCH persistence
    garch = compute_garch_features(daily_ret, n)
    garch_pers = garch['garch_persistence']

    output_dir = ROOT / 'outputs/charts'
    output_dir.mkdir(parents=True, exist_ok=True)

    # ========================================
    # 1. RUN FINAL MODEL (10 seeds)
    # ========================================
    P(f"\n{'#'*80}")
    P("1. FINAL MODEL (V18 + garch_persistence, 10 seeds)")
    P("#" * 80)

    all_results = []
    for seed in SEEDS_10:
        P(f"  seed={seed}...", end="")
        strat_d, btc_d, alloc_d, rf_d, idx = run_final(
            daily_ret, returns, vols, df, dates, n,
            feature_cols=fc, garch_persistence=garch_pers,
            n_bags=80, base_seed=seed)
        m = metrics(strat_d, btc_d, alloc_d, rf_daily=rf_d)
        all_results.append(m)
        P(f" {m['total']*100:+.1f}% S={m['sortino']:.2f} DD={m['max_dd']*100:.1f}%")
        gc.collect()

    rets = [r['total']*100 for r in all_results]
    summary = _seed_summary(rets, all_results)
    P(f"\n  FINAL: mean={summary['mean']:+.1f}%, S={summary['sortinos_mean']:.2f}, "
      f"spread={summary['spread']:.0f}pp, MaxDD={summary['max_dds_mean']:.1f}%")

    # ========================================
    # 2. CHARTS (using seed=42)
    # ========================================
    P(f"\n{'#'*80}")
    P("2. GENERATING INTERACTIVE CHARTS (seed=42)")
    P("#" * 80)

    strat_d, btc_d, alloc_d, rf_d, idx = run_final(
        daily_ret, returns, vols, df, dates, n,
        feature_cols=fc, garch_persistence=garch_pers,
        n_bags=80, base_seed=42)

    generate_charts(dates, strat_d, btc_d, idx, df['price_usd'].values, output_dir)

    # ========================================
    # 3. PBO TEST
    # ========================================
    P(f"\n{'#'*80}")
    P("3. PBO TEST (Probability of Backtest Overfitting)")
    P("#" * 80)

    pbo_results = run_pbo_test(daily_ret, returns, vols, df, dates, n,
                                fc, garch_pers, N_splits=8)

    # ========================================
    # SAVE ALL
    # ========================================
    elapsed = (datetime.now() - start).total_seconds() / 60

    results = {
        'timestamp': start.isoformat(),
        'model': 'V18 + garch_persistence (38 features)',
        'config': {
            'n_bags': 80, 'K_bull': 50, 'K_mild': 30, 'K_bear': 15,
            'retrain': 'semi', 'features': len(fc) + 1,
        },
        'seed_summary': summary,
        'pbo': pbo_results,
        'elapsed_min': float(elapsed),
    }

    out = ROOT / 'outputs/results/v18_final_pbo.json'
    out.write_text(json.dumps(convert_numpy(results), indent=2, default=str), encoding='utf-8')

    P(f"\n\n{'='*80}")
    P("FINAL SUMMARY")
    P("=" * 80)
    P(f"  Model: V18 + garch_persistence (38 features)")
    P(f"  Return: {summary['mean']:+.1f}% | Sortino: {summary['sortinos_mean']:.2f} | "
      f"Spread: {summary['spread']:.0f}pp | MaxDD: {summary['max_dds_mean']:.1f}%")
    P(f"  PBO: {pbo_results['pbo']*100:.1f}% ({'LOW risk' if pbo_results['pbo'] < 0.50 else 'HIGH risk'})")
    P(f"  Charts: {output_dir}")
    P(f"  Elapsed: {elapsed:.1f} min")
    P(f"  Saved: {out}")


if __name__ == '__main__':
    main()
