"""Final backtest of E1 D7 combo (no-short) on production dataset.

Uses fresh dataset_production.csv (2026-04-19) with all 32 features including
V36 new features (Reserve-Risk, funding_rate_ma7, Puell Multiple).

Config: floor=0.0, K=60/30/15, sigmoid=15, 3d horizon, Friday rebalance.

3 seeds, reports global + YoY metrics including 2026 YTD.
"""
import sys, time, gc, json
import numpy as np, pandas as pd
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import xgboost as xgb

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

import archive.old_pipelines.pipeline_v22 as v22
from archive.old_pipelines.pipeline_v09 import build_ml_features, backtest_allocations, COST
from scripts.production.training import _get_retrain_periods
from src.features.macro.cdi_rates import build_rf_daily
import archive.old_pipelines.pipeline_v09 as v9m
import archive.old_pipelines.pipeline_v13 as v13m
from scripts.production.config import FEATURES_37, BAGS, HORIZON, WORKERS, EMERGENCY_THRESHOLD

DATASET = ROOT / "scripts" / "production" / "data" / "dataset_production.csv"
SEEDS = [42, 142, 242]
K_REGIME = {'BULL': 60, 'MILD': 30, 'BEAR': 15}


def load():
    df = pd.read_csv(DATASET)
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)
    prices = df['price_usd'].values
    n = len(prices)
    daily_ret = np.zeros(n)
    for i in range(1, n): daily_ret[i] = (prices[i] - prices[i-1]) / prices[i-1]
    returns, vols = {}, {}
    for w in [1,3,5,7,10,14,20,21,30,45,60]:
        r = np.zeros(n)
        for i in range(w, n): r[i] = (prices[i] - prices[i-w]) / prices[i-w]
        returns[w] = r
    for w in [5,7,10,14,21,30]:
        vols[w] = pd.Series(daily_ret).rolling(w).std().fillna(0.02).values
    return prices, daily_ret, returns, vols, df


def get_regime(t, prices, sma50, sma200):
    if np.isnan(sma50[t]) or np.isnan(sma200[t]): return 'MILD'
    if prices[t] > sma50[t] and sma50[t] > sma200[t]: return 'BULL'
    elif prices[t] > sma200[t]: return 'MILD'
    return 'BEAR'


def _train_reg(args):
    s, Xt, yt, params = args
    p = dict(params); p.pop('objective', None)
    allowed = {k:v for k,v in p.items() if k in
               ['max_leaves','colsample_bytree','subsample','learning_rate',
                'min_child_weight','reg_alpha','reg_lambda','grow_policy','tree_method']}
    m = xgb.XGBRegressor(n_estimators=p.pop('n_estimators', 200),
                          random_state=s, objective='reg:squarederror',
                          n_jobs=1, verbosity=0, **allowed)
    m.fit(Xt, yt); return m


def _train_cls(args):
    s, Xt, yb, params = args
    rng = np.random.RandomState(s); idx = rng.choice(len(Xt), size=len(Xt), replace=True)
    p = dict(params); p.pop('objective', None)
    allowed = {k:v for k,v in p.items() if k in
               ['max_leaves','colsample_bytree','subsample','learning_rate',
                'min_child_weight','reg_alpha','reg_lambda','grow_policy','tree_method']}
    m = xgb.XGBClassifier(n_estimators=p.pop('n_estimators', 200),
                           random_state=s, objective='binary:logistic',
                           eval_metric='logloss', n_jobs=1, **allowed)
    m.fit(Xt[idx], yb[idx]); return m


def run_one(seed, X_all, target, prices, daily_ret, dates, periods,
             dow, sma50, sma200, rf_daily, n):
    params = v22.XGB_PARAMS
    full_allocs = np.full(n, 0.0); prev_alloc = 0.0
    a_s, a_b, a_a, a_r = [], [], [], []
    reg_preds = np.zeros(n); cls_probs = np.full(n, 0.5); strat_ret = np.zeros(n)
    for te, ts, tend in periods:
        gap = max(HORIZON, 5); tm = np.arange(60, te - gap + 1)
        valid = ~np.any(np.isnan(X_all[tm]), axis=1); idx = tm[valid]
        if len(idx) < 100: continue
        Xt = np.nan_to_num(X_all[idx], nan=0.0); yt = target[idx]
        bag_seeds = [seed + i*7 for i in range(BAGS)]
        with ThreadPoolExecutor(max_workers=WORKERS) as ex:
            reg_models = list(ex.map(_train_reg, [(s, Xt, yt, params) for s in bag_seeds]))
        yb = (yt > 0).astype(int)
        with ThreadPoolExecutor(max_workers=WORKERS) as ex:
            cls_models = list(ex.map(_train_cls, [(s, Xt, yb, params) for s in bag_seeds]))
        X_test = np.nan_to_num(X_all[ts:tend+1], nan=0.0)
        rp = np.mean([m.predict(X_test) for m in reg_models], axis=0)
        cp = np.mean([m.predict_proba(X_test)[:,1] for m in cls_models], axis=0)
        reg_preds[ts:tend+1] = rp; cls_probs[ts:tend+1] = cp
        for t in range(ts, tend+1):
            pred = reg_preds[t]; p_up = cls_probs[t]
            conf_factor = 1.0 / (1.0 + np.exp(-abs(p_up - 0.5) * 15))
            is_rebal = dow[t] in [4]
            is_emerg = t > 0 and abs(daily_ret[t]) > EMERGENCY_THRESHOLD
            if not is_rebal and not is_emerg: full_allocs[t] = prev_alloc; continue
            regime = get_regime(t, prices, sma50, sma200)
            raw = pred * K_REGIME[regime] * conf_factor
            full_allocs[t] = float(np.clip(raw, 0.0, 1.0))  # NO SHORT (floor=0)
            prev_alloc = full_allocs[t]
        s, b, a = backtest_allocations(daily_ret, full_allocs, ts, tend, cost=COST, rf_daily=rf_daily)
        a_s.extend(s); a_b.extend(b); a_a.extend(a)
        a_r.extend(rf_daily[ts:ts+len(s)])
        for i in range(len(s)): strat_ret[ts+i] = s[i]
        del reg_models, cls_models; gc.collect()
    metrics = v22.metrics_v22(np.array(a_s), np.array(a_b), np.array(a_a), rf_daily=np.array(a_r))
    return metrics, reg_preds, cls_probs, full_allocs, strat_ret


def main():
    t0 = time.time()
    print('='*100, flush=True)
    print('E1 D7 combo FINAL BACKTEST (no-short, 32 features, fresh data 2026-04-19)', flush=True)
    print('='*100, flush=True)

    prices, daily_ret, returns, vols, df = load()
    print(f'Data: {len(df)} rows {df.date.min()} -> {df.date.max()}', flush=True)
    dates = df['date'].values; n = len(prices)
    rf_daily = build_rf_daily(dates, source='auto')
    v9m.RF_DAILY_ARR = rf_daily; v13m.RF_DAILY_ARR = rf_daily
    dow = pd.to_datetime(dates).dayofweek.values
    periods = _get_retrain_periods(dates, n, v22.RETRAIN)
    sma50 = pd.Series(prices).rolling(50).mean().values
    sma200 = pd.Series(prices).rolling(200).mean().values
    target = np.zeros(n)
    for i in range(n - HORIZON): target[i] = (prices[i + HORIZON] - prices[i]) / prices[i]

    feats = list(FEATURES_37)
    X_all, _ = build_ml_features(df, returns, vols, n, feature_cols=feats)
    print(f'Features: {X_all.shape[1]}', flush=True)

    outs = []
    for s in SEEDS:
        t1 = time.time()
        print(f'  seed {s}...', flush=True)
        metrics, rp, cp, allocs, sret = run_one(s, X_all, target, prices, daily_ret,
                                                   dates, periods, dow, sma50, sma200,
                                                   rf_daily, n)
        outs.append((metrics, rp, cp, allocs, sret))
        print(f'    S={metrics["sortino"]:.2f} Ret={metrics["total"]*100:+.0f}% ({(time.time()-t1)/60:.1f}m)', flush=True)

    # Aggregate
    S = [o[0]['sortino'] for o in outs]
    R = [o[0]['total']*100 for o in outs]
    DD = [o[0]['max_dd']*100 for o in outs]
    SH = [o[0].get('sharpe', 0) for o in outs]
    print(f'\nAGG: Sortino={np.mean(S):.3f}+/-{np.std(S):.3f}  Ret={np.mean(R):+.0f}%  DD={np.mean(DD):.1f}%  Sharpe={np.mean(SH):.2f}')

    # YoY breakdown
    print('\nYEAR-OVER-YEAR:')
    ds = pd.to_datetime(dates); years = ds.year.values
    preds_avg = np.mean([o[1] * np.array([1.0/(1.0+np.exp(-abs(o[2][i]-0.5)*15)) for i in range(n)]) for o in outs], axis=0)
    strat_avg = np.mean([o[4] for o in outs], axis=0)
    allocs_avg = np.mean([o[3] for o in outs], axis=0)
    for y in sorted(set(years[years >= 2022])):
        mask = years == y
        strat_y = strat_avg[mask]; bench_y = daily_ret[mask]
        preds_y = preds_avg[mask]; tgt_y = target[mask]; dow_y = dow[mask]; alloc_y = allocs_avg[mask]
        strat_total = np.prod(1 + strat_y) - 1 if len(strat_y) else 0
        bench_total = np.prod(1 + bench_y) - 1 if len(bench_y) else 0
        pmask = np.abs(preds_y) > 1e-6
        acc_all = (np.sign(preds_y[pmask]) == np.sign(tgt_y[pmask])).mean() if pmask.sum() else 0
        fri_mask = pmask & (dow_y == 4)
        acc_fri = (np.sign(preds_y[fri_mask]) == np.sign(tgt_y[fri_mask])).mean() if fri_mask.sum() > 10 else 0
        print(f'  {y}: strat={strat_total*100:+7.1f}%  btc={bench_total*100:+7.1f}%  '
              f'excess={(strat_total-bench_total)*100:+7.1f}pp  '
              f'acc_all={acc_all*100:.1f}%  acc_fri={acc_fri*100:.1f}%  '
              f'avg_alloc={alloc_y.mean():+.2f}  days={mask.sum()}')

    # 2026 YTD detailed
    print('\n2026 YTD DETAILED:')
    mask_26 = years == 2026
    if mask_26.sum() > 0:
        for seed_idx, (m, rp, cp, al, sr) in enumerate(outs):
            strat_y = sr[mask_26]
            strat_ytd = np.prod(1 + strat_y) - 1
            print(f'  seed {SEEDS[seed_idx]}: Ret 2026 YTD = {strat_ytd*100:+.2f}%  '
                  f'avg_alloc={al[mask_26].mean():+.2f}  '
                  f'days={mask_26.sum()}')
        # avg alloc timeline 2026
        alloc_2026 = np.mean([o[3][mask_26] for o in outs], axis=0)
        print(f'\n  Alloc 2026 YTD: min={alloc_2026.min():.2f} max={alloc_2026.max():.2f} '
              f'mean={alloc_2026.mean():.2f} std={alloc_2026.std():.2f}')
        # Last 10 days of 2026 with alloc
        dates_26 = dates[mask_26]
        prices_26 = prices[mask_26]
        print(f'\n  Last 10 days:')
        for i in range(max(0, len(dates_26)-10), len(dates_26)):
            d = pd.Timestamp(dates_26[i]).strftime('%Y-%m-%d')
            print(f'    {d}  price=${prices_26[i]:>8.0f}  alloc={alloc_2026[i]:+.2f}')

    # Save
    out_json = ROOT / 'outputs' / 'results' / 'e1_final_backtest.json'
    out_json.parent.mkdir(parents=True, exist_ok=True)
    with open(out_json, 'w') as f:
        json.dump({
            'sortino_mean': float(np.mean(S)), 'sortino_std': float(np.std(S)),
            'ret_mean': float(np.mean(R)), 'dd_mean': float(np.mean(DD)),
            'sharpe_mean': float(np.mean(SH)),
            'n_seeds': len(SEEDS), 'n_features': X_all.shape[1],
            'dataset_last_date': str(df.date.max()),
            'config': 'E1 D7 combo no-short (floor=0, K=60/30/15, sigmoid=15)',
        }, f, indent=2)
    print(f'\nSaved: {out_json}', flush=True)
    print(f'Total: {(time.time()-t0)/60:.1f}m', flush=True)


if __name__ == '__main__':
    main()
