"""
Accuracy deep-dive + scatter plot: prediction vs actual BTC return.

Analyzes:
  1. Scatter plot: model prediction vs actual 3d return (by regime)
  2. Accuracy by regime (BULL/MILD/BEAR)
  3. Accuracy by prediction magnitude (high conviction vs low)
  4. Win/loss ratio and edge analysis
  5. Where the model fails most

Usage:
    python scripts/optimization/accuracy_analysis.py
"""
import sys, gc, numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pathlib import Path
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
import warnings; warnings.filterwarnings('ignore')
sys.stdout.reconfigure(line_buffering=True)

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

from archive.old_pipelines.pipeline_v09 import (
    load_data, build_ml_features, COST, P,
)
from archive.old_pipelines.pipeline_v10 import MODELS
from archive.old_pipelines.pipeline_v13 import _get_retrain_periods, _train_one_xgb

XGB_PARAMS = {
    'max_leaves': 31, 'grow_policy': 'lossguide', 'tree_method': 'hist',
    'colsample_bytree': 0.5, 'subsample': 0.8,
    'learning_rate': 0.05, 'min_child_weight': 12,
    'n_estimators': 200, 'objective': 'reg:squarederror',
    'verbosity': 0, 'nthread': 1,
}

K_REGIME = {'BULL': 50, 'MILD': 30, 'BEAR': 15}
BAGS = 80
HORIZON = 3
REBAL_DOW = [4]
EMERGENCY_THRESHOLD = 0.08
WORKERS = 16
SEED = 242

BASE_FEATURES = [f for f in MODELS['37feat'] if f != 'exchange_netflow_ma7'] + ['basis_pct']
EXTRA_FEATURES = [
    'fed_balance_sheet', 'futures_trade_count',
    'vol_x_regime_duration', 'velocity', 'hash_rate_pctchg_30d',
]


def get_regime(t, prices, sma50, sma200):
    if np.isnan(sma50[t]) or np.isnan(sma200[t]):
        return 'MILD'
    if prices[t] > sma50[t] and sma50[t] > sma200[t]:
        return 'BULL'
    elif prices[t] > sma200[t]:
        return 'MILD'
    return 'BEAR'


def main():
    P("=" * 80)
    P("ACCURACY ANALYSIS + SCATTER PLOT")
    P("=" * 80)

    P("Loading data...")
    prices, daily_ret, returns, vols, df = load_data()
    dates = df['date'].values
    n = len(prices)

    try:
        from src.features.macro.cdi_rates import build_rf_daily
        rf_daily = build_rf_daily(dates, source='auto')
    except Exception:
        from src.features.macro.cdi_rates import build_rf_daily
        rf_daily = build_rf_daily(dates, source='copom')

    import archive.old_pipelines.pipeline_v09 as v9m
    import archive.old_pipelines.pipeline_v13 as v13m
    v9m.RF_DAILY_ARR = rf_daily
    v13m.RF_DAILY_ARR = rf_daily

    fc = BASE_FEATURES + [f for f in EXTRA_FEATURES if f not in BASE_FEATURES]
    fc = [f for f in fc if f in df.columns]

    X_all, _ = build_ml_features(df, returns, vols, n, feature_cols=fc)

    target = np.zeros(n)
    for i in range(n - HORIZON):
        target[i] = (prices[i + HORIZON] - prices[i]) / prices[i]

    dow = pd.to_datetime(dates).dayofweek
    periods = _get_retrain_periods(dates, n, 'semi')
    sma50 = pd.Series(prices).rolling(50).mean().values
    sma200 = pd.Series(prices).rolling(200).mean().values

    # Collect ALL predictions (not just rebalance days)
    P("Running model to collect all predictions...")
    all_preds = []

    for te, ts, tend in periods:
        gap = max(HORIZON, 5)
        tm = np.arange(60, te - gap + 1)
        valid = ~np.any(np.isnan(X_all[tm]), axis=1)
        idx = tm[valid]
        if len(idx) < 100:
            continue

        Xt = np.nan_to_num(X_all[idx], nan=0.0)
        yt = target[idx]

        bag_seeds = [SEED + i * 7 for i in range(BAGS)]
        with ThreadPoolExecutor(max_workers=WORKERS) as ex:
            models = list(ex.map(_train_one_xgb,
                [(s, Xt, yt, XGB_PARAMS) for s in bag_seeds]))

        P(f"  Period {pd.Timestamp(dates[ts]).date()} to {pd.Timestamp(dates[tend]).date()}")

        for t in range(ts, min(tend + 1, n - HORIZON)):
            x_t = np.nan_to_num(X_all[t:t + 1].copy(), nan=0.0)
            prediction = float(np.mean([m.predict(x_t)[0] for m in models]))
            actual = target[t]
            regime = get_regime(t, prices, sma50, sma200)
            year = pd.Timestamp(dates[t]).year

            all_preds.append({
                'date': str(pd.Timestamp(dates[t]).date()),
                'year': year,
                'prediction': prediction,
                'actual': actual,
                'regime': regime,
                'price': prices[t],
                'pred_direction': 1 if prediction > 0 else -1,
                'actual_direction': 1 if actual > 0 else -1,
                'correct': (prediction > 0 and actual > 0) or (prediction < 0 and actual < 0),
                'pred_magnitude': abs(prediction),
            })

        del models
        gc.collect()

    pdf = pd.DataFrame(all_preds)
    P(f"\nCollected {len(pdf)} predictions")

    # ═══════════════════════════════════════════════════════════
    # ANALYSIS
    # ═══════════════════════════════════════════════════════════

    P("")
    P("=" * 80)
    P("RESULTS")
    P("=" * 80)

    # 1. Overall accuracy
    overall_acc = pdf['correct'].mean()
    P(f"\n1. OVERALL ACCURACY: {overall_acc*100:.1f}% ({pdf['correct'].sum()}/{len(pdf)})")

    # Correlation
    corr = pdf['prediction'].corr(pdf['actual'])
    P(f"   Correlation pred vs actual: {corr:.3f}")

    # 2. Accuracy by regime
    P(f"\n2. ACCURACY BY REGIME:")
    P(f"   {'Regime':<8} {'Accuracy':>8} {'N_days':>8} {'Avg Pred':>10} {'Avg Actual':>10} {'Corr':>6}")
    P(f"   {'-'*55}")
    for regime in ['BULL', 'MILD', 'BEAR']:
        mask = pdf['regime'] == regime
        if mask.sum() == 0:
            continue
        sub = pdf[mask]
        acc = sub['correct'].mean()
        avg_pred = sub['prediction'].mean()
        avg_actual = sub['actual'].mean()
        c = sub['prediction'].corr(sub['actual'])
        P(f"   {regime:<8} {acc*100:7.1f}% {mask.sum():>8} {avg_pred*100:>9.2f}% {avg_actual*100:>9.2f}% {c:>5.3f}")

    # 3. Accuracy by year
    P(f"\n3. ACCURACY BY YEAR:")
    P(f"   {'Year':<6} {'Accuracy':>8} {'N_days':>8} {'Corr':>6}")
    P(f"   {'-'*35}")
    for year in sorted(pdf['year'].unique()):
        sub = pdf[pdf['year'] == year]
        acc = sub['correct'].mean()
        c = sub['prediction'].corr(sub['actual'])
        P(f"   {year:<6} {acc*100:7.1f}% {len(sub):>8} {c:>5.3f}")

    # 4. Accuracy by prediction conviction (magnitude)
    P(f"\n4. ACCURACY BY CONVICTION (prediction magnitude):")
    quantiles = [0, 0.25, 0.5, 0.75, 1.0]
    labels = ['Low (0-25%)', 'Medium (25-50%)', 'High (50-75%)', 'Very High (75-100%)']
    pdf['conviction_q'] = pd.qcut(pdf['pred_magnitude'], q=quantiles, labels=labels)

    P(f"   {'Conviction':<20} {'Accuracy':>8} {'N_days':>8} {'Avg |Pred|':>11} {'Win/Loss':>8}")
    P(f"   {'-'*60}")
    for label in labels:
        sub = pdf[pdf['conviction_q'] == label]
        if len(sub) == 0:
            continue
        acc = sub['correct'].mean()
        avg_mag = sub['pred_magnitude'].mean()
        # Win/loss ratio: avg profit on correct / avg loss on incorrect
        correct_pnl = sub[sub['correct']]['actual'].abs().mean() if sub['correct'].sum() > 0 else 0
        wrong_pnl = sub[~sub['correct']]['actual'].abs().mean() if (~sub['correct']).sum() > 0 else 1
        wl = correct_pnl / (wrong_pnl + 1e-10)
        P(f"   {label:<20} {acc*100:7.1f}% {len(sub):>8} {avg_mag*100:>10.2f}% {wl:>7.2f}x")

    # 5. Win/loss analysis
    P(f"\n5. WIN/LOSS ANALYSIS:")
    correct = pdf[pdf['correct']]
    wrong = pdf[~pdf['correct']]
    avg_win = correct['actual'].abs().mean() * 100
    avg_loss = wrong['actual'].abs().mean() * 100
    P(f"   Average win:  {avg_win:.2f}% ({len(correct)} days)")
    P(f"   Average loss: {avg_loss:.2f}% ({len(wrong)} days)")
    P(f"   Win/Loss ratio: {avg_win/avg_loss:.2f}x")
    P(f"   Edge per prediction: {pdf['actual'].where(pdf['prediction'] > 0, -pdf['actual']).mean()*100:.3f}%")

    # 6. Biggest misses
    P(f"\n6. BIGGEST MISSES (model predicted up, BTC crashed):")
    misses = pdf[(pdf['prediction'] > 0.01) & (pdf['actual'] < -0.05)].sort_values('actual')
    for _, row in misses.head(10).iterrows():
        P(f"   {row['date']} | Pred: {row['prediction']*100:+.2f}% | Actual: {row['actual']*100:+.2f}% | {row['regime']}")

    P(f"\n7. BIGGEST HITS (model predicted up, BTC rallied):")
    hits = pdf[(pdf['prediction'] > 0.02) & (pdf['actual'] > 0.05)].sort_values('actual', ascending=False)
    for _, row in hits.head(10).iterrows():
        P(f"   {row['date']} | Pred: {row['prediction']*100:+.2f}% | Actual: {row['actual']*100:+.2f}% | {row['regime']}")

    # ═══════════════════════════════════════════════════════════
    # SCATTER PLOT
    # ═══════════════════════════════════════════════════════════

    P("\nGenerating scatter plot...")

    fig, axes = plt.subplots(2, 2, figsize=(16, 14))

    # Colors by regime
    regime_colors = {'BULL': '#2ecc71', 'MILD': '#f39c12', 'BEAR': '#e74c3c'}

    # Plot 1: Full scatter by regime
    ax = axes[0, 0]
    for regime in ['BULL', 'MILD', 'BEAR']:
        sub = pdf[pdf['regime'] == regime]
        ax.scatter(sub['actual'] * 100, sub['prediction'] * 100,
                  alpha=0.3, s=8, c=regime_colors[regime], label=f"{regime} ({len(sub)}d)")

    # Add diagonal line (perfect prediction)
    lim = max(abs(pdf['actual'].max()), abs(pdf['prediction'].max())) * 100
    ax.plot([-lim, lim], [-lim, lim], 'k--', alpha=0.3, linewidth=1)
    ax.axhline(y=0, color='gray', alpha=0.3, linewidth=0.5)
    ax.axvline(x=0, color='gray', alpha=0.3, linewidth=0.5)

    # Shade quadrants
    ax.fill_between([-lim, 0], [-lim, -lim], [0, 0], alpha=0.03, color='green')  # both negative = correct
    ax.fill_between([0, lim], [0, 0], [lim, lim], alpha=0.03, color='green')      # both positive = correct
    ax.fill_between([-lim, 0], [0, 0], [lim, lim], alpha=0.03, color='red')       # wrong quadrants
    ax.fill_between([0, lim], [-lim, -lim], [0, 0], alpha=0.03, color='red')

    ax.set_xlabel('Actual BTC 3d Return (%)', fontsize=11)
    ax.set_ylabel('Model Prediction (%)', fontsize=11)
    ax.set_title(f'Prediction vs Actual (All Days, Accuracy={overall_acc*100:.1f}%, Corr={corr:.3f})',
                fontsize=12, fontweight='bold')
    ax.legend(fontsize=10)
    ax.set_xlim(-25, 25)
    ax.set_ylim(-12, 12)
    ax.grid(True, alpha=0.2)

    # Plot 2: Accuracy by regime bar chart
    ax = axes[0, 1]
    regimes = ['BULL', 'MILD', 'BEAR', 'ALL']
    accs = []
    counts = []
    for r in regimes:
        if r == 'ALL':
            accs.append(overall_acc * 100)
            counts.append(len(pdf))
        else:
            sub = pdf[pdf['regime'] == r]
            accs.append(sub['correct'].mean() * 100 if len(sub) > 0 else 0)
            counts.append(len(sub))

    colors = [regime_colors.get(r, '#3498db') for r in regimes]
    bars = ax.bar(regimes, accs, color=colors, alpha=0.7, edgecolor='black', linewidth=0.5)
    ax.axhline(y=50, color='red', linestyle='--', alpha=0.5, label='Random (50%)')
    ax.axhline(y=55, color='orange', linestyle='--', alpha=0.4, label='55% threshold')

    for bar, acc, count in zip(bars, accs, counts):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.5,
               f'{acc:.1f}%\n({count}d)', ha='center', fontsize=10)

    ax.set_ylabel('Directional Accuracy (%)', fontsize=11)
    ax.set_title('Accuracy by Market Regime', fontsize=12, fontweight='bold')
    ax.set_ylim(45, 70)
    ax.legend(fontsize=9)
    ax.grid(True, alpha=0.2, axis='y')

    # Plot 3: Accuracy by year
    ax = axes[1, 0]
    years = sorted(pdf['year'].unique())
    year_accs = [pdf[pdf['year'] == y]['correct'].mean() * 100 for y in years]
    year_counts = [len(pdf[pdf['year'] == y]) for y in years]

    bars = ax.bar([str(y) for y in years], year_accs, color='#3498db', alpha=0.7,
                  edgecolor='black', linewidth=0.5)
    ax.axhline(y=50, color='red', linestyle='--', alpha=0.5, label='Random (50%)')

    for bar, acc, count in zip(bars, year_accs, year_counts):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.5,
               f'{acc:.1f}%\n({count}d)', ha='center', fontsize=10)

    ax.set_ylabel('Directional Accuracy (%)', fontsize=11)
    ax.set_title('Accuracy by Year', fontsize=12, fontweight='bold')
    ax.set_ylim(45, 70)
    ax.legend(fontsize=9)
    ax.grid(True, alpha=0.2, axis='y')

    # Plot 4: Distribution of predictions vs actuals
    ax = axes[1, 1]
    ax.hist(pdf['actual'] * 100, bins=80, alpha=0.5, color='blue', label='Actual 3d return', density=True)
    ax.hist(pdf['prediction'] * 100, bins=80, alpha=0.5, color='red', label='Model prediction', density=True)
    ax.set_xlabel('Return (%)', fontsize=11)
    ax.set_ylabel('Density', fontsize=11)
    ax.set_title('Distribution: Predictions vs Actual Returns', fontsize=12, fontweight='bold')
    ax.legend(fontsize=10)
    ax.set_xlim(-20, 20)
    ax.grid(True, alpha=0.2)

    # Add text box with key stats
    stats_text = (f"Predictions: std={pdf['prediction'].std()*100:.2f}%\n"
                  f"Actuals: std={pdf['actual'].std()*100:.2f}%\n"
                  f"Model is {pdf['actual'].std()/pdf['prediction'].std():.1f}x more conservative")
    ax.text(0.02, 0.95, stats_text, transform=ax.transAxes, fontsize=9,
           verticalalignment='top', bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))

    plt.tight_layout()
    chart_path = ROOT / 'outputs' / 'charts' / 'accuracy_analysis.png'
    chart_path.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(chart_path, dpi=150, bbox_inches='tight')
    P(f"Saved chart: {chart_path}")

    plt.close()


if __name__ == '__main__':
    main()
