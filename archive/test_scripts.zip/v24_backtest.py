"""
V24: multi-set backtest. Each set is a variation of FEATURES_37, run through
the V22 backtest machinery. 3 seeds per set.

Sets:
  V0  baseline (FEATURES_37)
  V1  Remove [open_interest, futures_trade_count]         -> buggy data pre-2022
  V2  Remove [m2_yoy_growth, fed_balance_sheet]           -> replaced with fixed variants
  V3  Swap:
        m2_yoy_growth -> m2_supply_pctchg_90d (real 3m)
        fed_balance_sheet -> fed_bs_yoy_real
        open_interest -> open_interest_z180
        futures_trade_count -> futures_trade_count_z90
  V4  V0 + [mvrv_zscore_365d, puell_zscore_365d]          -> new on-chain (non-tested combo)
  V5  V0 + [days_since_halving, parkinson_vol_14d]        -> cyclic + intraday vol
  V6  V0 + [price_fracdiff_05, fed_fracdiff_05]           -> fractional diff
  V7  V0 + [nupl_x_halving, basis_x_vol, sopr_x_percentile, mvrv_x_hurst]  -> interactions
  V8  Combo: V3 + MVRV + Puell + halving + parkinson      -> best-of expected
"""
import sys, time
import numpy as np, pandas as pd
from pathlib import Path

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

import archive.old_pipelines.pipeline_v22 as v22
from archive.old_pipelines.pipeline_v09 import build_ml_features, metrics as _old_metrics
from scripts.production.training import _get_retrain_periods
from src.features.macro.cdi_rates import build_rf_daily
import archive.old_pipelines.pipeline_v09 as v9m
import archive.old_pipelines.pipeline_v13 as v13m

from scripts.production.config import FEATURES_37

SEEDS = [42, 142, 242]
DATASET = ROOT / "outputs" / "feature_selection" / "dataset_v24.csv"


def load_v24():
    df = pd.read_csv(DATASET)
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)
    prices = df['price_usd'].values
    n = len(prices)

    daily_ret = np.zeros(n)
    for i in range(1, n):
        daily_ret[i] = (prices[i] - prices[i-1]) / prices[i-1]

    returns = {}
    for w in [1, 3, 5, 7, 10, 14, 20, 21, 30, 45, 60]:
        r = np.zeros(n)
        for i in range(w, n):
            r[i] = (prices[i] - prices[i-w]) / prices[i-w]
        returns[w] = r

    vols = {}
    for w in [5, 7, 10, 14, 21, 30]:
        vols[w] = pd.Series(daily_ret).rolling(w).std().fillna(0.02).values

    return prices, daily_ret, returns, vols, df


# -------- Feature sets --------
BASELINE = list(FEATURES_37)

BUGGY_TO_REMOVE_ALL = ['open_interest', 'futures_trade_count', 'm2_yoy_growth', 'fed_balance_sheet']

def make_set(name, include=None, remove=None, add=None):
    feats = list(BASELINE)
    if remove:
        feats = [f for f in feats if f not in remove]
    if add:
        feats.extend([f for f in add if f not in feats])
    if include is not None:
        feats = include
    return name, feats


SETS = [
    ('V0_baseline',      BASELINE),
    ('V1_no_oi_ftc',     [f for f in BASELINE if f not in ('open_interest','futures_trade_count')]),
    ('V2_no_m2_fed',     [f for f in BASELINE if f not in ('m2_yoy_growth','fed_balance_sheet')]),
    ('V3_fix_all',       [f for f in BASELINE if f not in BUGGY_TO_REMOVE_ALL] + [
        'm2_supply_pctchg_90d', 'fed_bs_yoy_real',
        'open_interest_z180', 'futures_trade_count_z90',
    ]),
    ('V4_add_mvrv_puell', BASELINE + ['mvrv_zscore_365d', 'puell_zscore_365d']),
    ('V5_add_halving_park', BASELINE + ['days_since_halving', 'parkinson_vol_14d']),
    ('V6_add_fracdiff',   BASELINE + ['price_fracdiff_05', 'fed_fracdiff_05']),
    ('V7_interactions',   BASELINE + ['nupl_x_halving','basis_x_vol','sopr_x_percentile','mvrv_x_hurst']),
    ('V8_combo',          [f for f in BASELINE if f not in BUGGY_TO_REMOVE_ALL] + [
        'm2_supply_pctchg_90d','fed_bs_yoy_real','open_interest_z180','futures_trade_count_z90',
        'mvrv_zscore_365d','puell_zscore_365d','days_since_halving','parkinson_vol_14d',
    ]),
]


def run_backtest_for_set(name, feats, prices, daily_ret, returns, vols, df,
                          dates, n, periods, dow, sma50, sma200, rf_daily):
    missing = [f for f in feats if f not in df.columns]
    if missing:
        print(f"  [{name}] MISSING: {missing}")
        return None
    X_all, _ = build_ml_features(df, returns, vols, n, feature_cols=feats)
    target = np.zeros(n)
    for i in range(n - v22.HORIZON):
        target[i] = (prices[i + v22.HORIZON] - prices[i]) / prices[i]

    metrics = []
    for seed in SEEDS:
        m = v22.run_single_seed(seed, X_all, target, prices, daily_ret, dates,
                                periods, dow, sma50, sma200, rf_daily, n)
        metrics.append(m)
    return metrics


def main():
    t0 = time.time()
    print("=" * 75)
    print("V24 MULTI-SET BACKTEST — 3 seeds per set")
    print("=" * 75)

    prices, daily_ret, returns, vols, df = load_v24()
    dates = df['date'].values
    n = len(prices)

    rf_daily = build_rf_daily(dates, source='auto')
    v9m.RF_DAILY_ARR = rf_daily
    v13m.RF_DAILY_ARR = rf_daily

    # V22 uses REBAL_DOW=[4]
    v22.REBAL_DOW = [4]

    dow = pd.to_datetime(dates).dayofweek
    periods = _get_retrain_periods(dates, n, v22.RETRAIN)
    sma50 = pd.Series(prices).rolling(50).mean().values
    sma200 = pd.Series(prices).rolling(200).mean().values

    print(f"Data: {str(dates[0])[:10]} -> {str(dates[-1])[:10]}  n={n}")
    print(f"Sets: {len(SETS)}  Seeds per set: {len(SEEDS)}")
    print()

    results = {}
    for si, (name, feats) in enumerate(SETS):
        t1 = time.time()
        print(f"[{si+1}/{len(SETS)}] {name}  ({len(feats)} features)")
        mets = run_backtest_for_set(name, feats, prices, daily_ret, returns, vols, df,
                                     dates, n, periods, dow, sma50, sma200, rf_daily)
        if mets is None:
            continue
        s = np.array([m['sortino']  for m in mets])
        sh = np.array([m['sharpe']   for m in mets])
        r = np.array([m['total']*100 for m in mets])
        dd = np.array([m['max_dd']*100 for m in mets])
        results[name] = {
            'sortino': (s.mean(), s.std()),
            'sharpe':  (sh.mean(), sh.std()),
            'ret':     (r.mean(), r.std()),
            'dd':      (dd.mean(), dd.std()),
            'n_feats': len(feats),
        }
        elapsed = (time.time() - t1) / 60
        print(f"    Sortino {s.mean():.2f}+/-{s.std():.2f}  "
              f"Sharpe {sh.mean():.2f}+/-{sh.std():.2f}  "
              f"Ret {r.mean():+.0f}%+/-{r.std():.0f}%  "
              f"DD {dd.mean():.1f}%+/-{dd.std():.1f}%  "
              f"({elapsed:.1f}m)")

    total_min = (time.time() - t0) / 60
    print()
    print("=" * 75)
    print(f"ALL SETS DONE — total {total_min:.1f} minutes")
    print("=" * 75)
    print(f"{'Set':<22} {'Feats':>6} {'Sortino':>12} {'Sharpe':>12} {'Ret':>14} {'MaxDD':>12}")
    print('-' * 80)
    for name, r in results.items():
        so_m, so_s = r['sortino']; sh_m, sh_s = r['sharpe']
        rt_m, rt_s = r['ret'];     dd_m, dd_s = r['dd']
        print(f"{name:<22} {r['n_feats']:>6} "
              f"{so_m:>5.2f}+/-{so_s:<4.2f} "
              f"{sh_m:>5.2f}+/-{sh_s:<4.2f} "
              f"{rt_m:>+6.0f}%+/-{rt_s:<3.0f}% "
              f"{dd_m:>5.1f}%+/-{dd_s:<4.1f}%")

    # Delta vs baseline
    if 'V0_baseline' in results:
        base = results['V0_baseline']
        print()
        print("Delta vs V0_baseline (Sortino):")
        base_s = base['sortino'][0]
        for name, r in results.items():
            if name == 'V0_baseline': continue
            d = r['sortino'][0] - base_s
            marker = '**' if d > 0.1 else '  '
            print(f"  {marker}{name:<22} {d:+.3f}")


if __name__ == '__main__':
    main()
