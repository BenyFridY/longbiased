"""V25 isolate: test each fix individually to find the culprit.

Takes dataset_enhanced.csv as base and applies ONE fix at a time, then backtests.

Sets:
  BASE = V0 (original, Sortino 4.74)

  V25a = BASE with m2_yoy_growth fixed only
  V25b = BASE with fed_bs_yoy_change fixed only
  V25c = BASE with m2_3m_growth fixed only
  V25d = BASE with open_interest NaN only
  V25e = BASE with futures_trade_count NaN only
  V25f = BASE with all YoY/3m fixes (m2 + fed)
  V25g = BASE with OI + FTC NaN (no YoY changes)

Tells us: YoY fixes or NaN fixes destroy? Or both?
"""
import sys, time
import numpy as np, pandas as pd
from pathlib import Path

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

import archive.old_pipelines.pipeline_v22 as v22
from archive.old_pipelines.pipeline_v09 import build_ml_features
from scripts.production.training import _get_retrain_periods
from src.features.macro.cdi_rates import build_rf_daily
import archive.old_pipelines.pipeline_v09 as v9m
import archive.old_pipelines.pipeline_v13 as v13m

from scripts.production.config import FEATURES_37

DATASET = ROOT / "outputs" / "feature_selection" / "dataset_enhanced.csv"
SEEDS = [42, 142, 242]
BASELINE = list(FEATURES_37)


def load_base():
    df = pd.read_csv(DATASET)
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)
    prices = df['price_usd'].values
    n = len(prices)
    daily_ret = np.zeros(n)
    for i in range(1, n):
        daily_ret[i] = (prices[i] - prices[i-1]) / prices[i-1]
    returns, vols = {}, {}
    for w in [1, 3, 5, 7, 10, 14, 20, 21, 30, 45, 60]:
        r = np.zeros(n)
        for i in range(w, n):
            r[i] = (prices[i] - prices[i-w]) / prices[i-w]
        returns[w] = r
    for w in [5, 7, 10, 14, 21, 30]:
        vols[w] = pd.Series(daily_ret).rolling(w).std().fillna(0.02).values
    return prices, daily_ret, returns, vols, df


def apply_fix(df, fix_name):
    """Returns modified df with one specific fix applied."""
    df = df.copy()
    if fix_name == 'm2_yoy':
        df['m2_yoy_growth'] = (1 + df['m2_supply_pctchg_90d']) ** (365.0/90.0) - 1
    elif fix_name == 'fed_bs_yoy':
        df['fed_bs_yoy_change'] = df['fed_balance_sheet'].pct_change(252)
    elif fix_name == 'm2_3m':
        df['m2_3m_growth'] = df['m2_supply_pctchg_90d']
    elif fix_name == 'oi_nan':
        mask = (df['date'] < '2022-01-01') | (df['open_interest'] < 1e6)
        df.loc[mask, 'open_interest'] = np.nan
    elif fix_name == 'ftc_nan':
        df.loc[df['futures_trade_count'] < 1000, 'futures_trade_count'] = np.nan
    elif fix_name == 'all_yoy':
        df['m2_yoy_growth'] = (1 + df['m2_supply_pctchg_90d']) ** (365.0/90.0) - 1
        df['fed_bs_yoy_change'] = df['fed_balance_sheet'].pct_change(252)
        df['m2_3m_growth'] = df['m2_supply_pctchg_90d']
    elif fix_name == 'all_nan':
        mask_oi = (df['date'] < '2022-01-01') | (df['open_interest'] < 1e6)
        df.loc[mask_oi, 'open_interest'] = np.nan
        df.loc[df['futures_trade_count'] < 1000, 'futures_trade_count'] = np.nan
    return df


def run_set(name, df, prices, daily_ret, returns, vols, ctx):
    dates, n, rf_daily, dow, periods, sma50, sma200 = ctx
    X_all, _ = build_ml_features(df, returns, vols, n, feature_cols=BASELINE)
    target = np.zeros(n)
    for i in range(n - v22.HORIZON):
        target[i] = (prices[i + v22.HORIZON] - prices[i]) / prices[i]
    mets = []
    for seed in SEEDS:
        m = v22.run_single_seed(seed, X_all, target, prices, daily_ret, dates,
                                periods, dow, sma50, sma200, rf_daily, n)
        mets.append(m)
    s = np.array([m['sortino'] for m in mets])
    sh = np.array([m['sharpe'] for m in mets])
    r = np.array([m['total']*100 for m in mets])
    dd = np.array([m['max_dd']*100 for m in mets])
    print(f"{name:<22}  Sortino {s.mean():.2f}+/-{s.std():.2f}  "
          f"Sharpe {sh.mean():.2f}+/-{sh.std():.2f}  "
          f"Ret {r.mean():+.0f}%+/-{r.std():.0f}%  "
          f"DD {dd.mean():.1f}%")
    return s.mean(), r.mean()


def main():
    t0 = time.time()
    print("=" * 85)
    print("V25 ISOLATE — one fix at a time, 3 seeds each")
    print("=" * 85)
    print("Reference: V0 baseline = Sortino 4.74, Ret +1047%")
    print()

    prices, daily_ret, returns, vols, df_base = load_base()
    dates = df_base['date'].values
    n = len(prices)
    rf_daily = build_rf_daily(dates, source='auto')
    v9m.RF_DAILY_ARR = rf_daily
    v13m.RF_DAILY_ARR = rf_daily
    v22.REBAL_DOW = [4]
    dow = pd.to_datetime(dates).dayofweek
    periods = _get_retrain_periods(dates, n, v22.RETRAIN)
    sma50 = pd.Series(prices).rolling(50).mean().values
    sma200 = pd.Series(prices).rolling(200).mean().values
    ctx = (dates, n, rf_daily, dow, periods, sma50, sma200)

    # Reduced set: isolate YoY fixes vs NaN fixes at the macro level first
    fixes = [
        ('V0_base',       None),
        ('V25f_all_yoy',  'all_yoy'),     # all YoY/3m fixes together
        ('V25g_all_nan',  'all_nan'),     # OI+FTC NaN together
        ('V25d_oi_nan',   'oi_nan'),      # only OI NaN
    ]

    results = {}
    for name, fix in fixes:
        t1 = time.time()
        df = df_base if fix is None else apply_fix(df_base, fix)
        s, r = run_set(name, df, prices, daily_ret, returns, vols, ctx)
        results[name] = (s, r)
        print(f"  ({(time.time()-t1)/60:.1f}m)")

    print()
    print("=" * 85)
    print(f"TOTAL: {(time.time()-t0)/60:.1f} min")
    print("=" * 85)
    base_s = results['V0_base'][0]
    print(f"{'Set':<22} {'ΔSortino':>10} {'Verdict':<20}")
    for name, (s, r) in results.items():
        delta = s - base_s
        if name == 'V0_base':
            verdict = '(reference)'
        elif delta > -0.15:
            verdict = 'SAFE'
        elif delta > -0.5:
            verdict = 'mild degrade'
        elif delta > -2:
            verdict = 'BIG degrade'
        else:
            verdict = 'DESTROYS'
        print(f"{name:<22} {delta:>+10.2f}  {verdict:<20}")


if __name__ == '__main__':
    main()
