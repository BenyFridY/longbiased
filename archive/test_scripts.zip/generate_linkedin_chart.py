"""
Generate LinkedIn chart: Strategy equity curve vs BTC buy & hold.
Dark theme, clean, professional.
"""
import sys, numpy as np, pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as mtick
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import warnings; warnings.filterwarnings('ignore')

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

from archive.old_pipelines.pipeline_v09 import (
    load_data, build_ml_features, backtest_allocations, COST,
)
from archive.old_pipelines.pipeline_v10 import MODELS
from archive.old_pipelines.pipeline_v13 import _get_retrain_periods, _train_one_xgb

# V21/V22 config
XGB_PARAMS = {
    'max_leaves': 31, 'grow_policy': 'lossguide', 'tree_method': 'hist',
    'colsample_bytree': 0.5, 'subsample': 0.8, 'learning_rate': 0.05,
    'min_child_weight': 12, 'n_estimators': 200,
    'objective': 'reg:squarederror', 'verbosity': 0, 'nthread': 1,
}
K_REGIME = {'BULL': 50, 'MILD': 30, 'BEAR': 15}
BAGS = 80
HORIZON = 3
REBAL_DOW = [4]
EMERGENCY_THRESHOLD = 0.08
WORKERS = 16
SEED = 242  # best median seed

BASE_FEATURES = [f for f in MODELS['37feat'] if f != 'exchange_netflow_ma7'] + ['basis_pct']
EXTRA_FEATURES = [
    'fed_balance_sheet', 'futures_trade_count',
    'vol_x_regime_duration', 'velocity', 'hash_rate_pctchg_30d',
]


def get_regime(t, prices, sma50, sma200):
    if np.isnan(sma50[t]) or np.isnan(sma200[t]):
        return 'MILD'
    if prices[t] > sma50[t] and sma50[t] > sma200[t]:
        return 'BULL'
    elif prices[t] > sma200[t]:
        return 'MILD'
    return 'BEAR'


def main():
    print("Loading data...")
    prices, daily_ret, returns, vols, df = load_data()
    dates = df['date'].values
    n = len(prices)

    try:
        from src.features.macro.cdi_rates import build_rf_daily
        rf_daily = build_rf_daily(dates, source='auto')
    except Exception:
        from src.features.macro.cdi_rates import build_rf_daily
        rf_daily = build_rf_daily(dates, source='copom')

    import archive.old_pipelines.pipeline_v09 as v9m
    import archive.old_pipelines.pipeline_v13 as v13m
    v9m.RF_DAILY_ARR = rf_daily
    v13m.RF_DAILY_ARR = rf_daily

    fc = BASE_FEATURES + [f for f in EXTRA_FEATURES if f not in BASE_FEATURES]
    fc = [f for f in fc if f in df.columns]

    X_all, _ = build_ml_features(df, returns, vols, n, feature_cols=fc)

    target = np.zeros(n)
    for i in range(n - HORIZON):
        target[i] = (prices[i + HORIZON] - prices[i]) / prices[i]

    dow = pd.to_datetime(dates).dayofweek
    periods = _get_retrain_periods(dates, n, 'semi')
    sma50 = pd.Series(prices).rolling(50).mean().values
    sma200 = pd.Series(prices).rolling(200).mean().values

    # Run single seed to get daily returns
    print(f"Running seed {SEED}...")
    full_allocs = np.full(n, 0.0)
    prev_alloc = 0.0
    a_s, a_b, a_dates = [], [], []

    for te, ts, tend in periods:
        gap = max(HORIZON, 5)
        tm = np.arange(60, te - gap + 1)
        valid = ~np.any(np.isnan(X_all[tm]), axis=1)
        idx = tm[valid]
        if len(idx) < 100:
            continue

        Xt = np.nan_to_num(X_all[idx], nan=0.0)
        yt = target[idx]

        bag_seeds = [SEED + i * 7 for i in range(BAGS)]
        with ThreadPoolExecutor(max_workers=WORKERS) as ex:
            models = list(ex.map(_train_one_xgb,
                [(s, Xt, yt, XGB_PARAMS) for s in bag_seeds]))

        for t in range(ts, tend + 1):
            is_rebal = dow[t] in REBAL_DOW
            is_emerg = t > 0 and abs(daily_ret[t]) > EMERGENCY_THRESHOLD
            if not is_rebal and not is_emerg:
                full_allocs[t] = prev_alloc
                continue
            x_t = np.nan_to_num(X_all[t:t + 1].copy(), nan=0.0)
            prediction = float(np.mean([m.predict(x_t)[0] for m in models]))
            regime = get_regime(t, prices, sma50, sma200)
            K = K_REGIME[regime]
            full_allocs[t] = np.clip(prediction * K, -0.25, 1.0)
            prev_alloc = full_allocs[t]

        s, b, a = backtest_allocations(daily_ret, full_allocs, ts, tend,
                                       cost=0.0002, rf_daily=rf_daily)
        a_s.extend(s)
        a_b.extend(b)
        # Collect dates for this period
        for t in range(ts, ts + len(s)):
            a_dates.append(dates[t + 1])

        del models

    # Build equity curves
    strat_equity = np.cumprod(1 + np.array(a_s))
    btc_equity = np.cumprod(1 + np.array(a_b))
    plot_dates = pd.to_datetime(a_dates)

    strat_ret = (strat_equity[-1] - 1) * 100
    btc_ret = (btc_equity[-1] - 1) * 100

    print(f"Strategy: +{strat_ret:.0f}%")
    print(f"BTC B&H:  +{btc_ret:.0f}%")

    # ═══════════════════════════════════════════════════════════════
    # PLOT — dark theme, LinkedIn-ready
    # ═══════════════════════════════════════════════════════════════

    bg_color = '#0d1117'
    text_color = '#c9d1d9'
    grid_color = '#21262d'
    strat_color = '#58a6ff'
    btc_color = '#f0883e'

    fig, ax = plt.subplots(figsize=(12, 6.5), facecolor=bg_color)
    ax.set_facecolor(bg_color)

    # Plot lines — no return numbers
    ax.plot(plot_dates, strat_equity, color=strat_color, linewidth=2.5,
            label='ML Strategy', zorder=3)
    ax.plot(plot_dates, btc_equity, color=btc_color, linewidth=1.8,
            label='BTC Buy & Hold', alpha=0.85, zorder=2)

    # Fill between
    ax.fill_between(plot_dates, btc_equity, strat_equity,
                     where=strat_equity > btc_equity,
                     alpha=0.08, color=strat_color, zorder=1)

    # Styling
    ax.set_yscale('log')
    ax.yaxis.set_major_formatter(mtick.FuncFormatter(lambda x, _: f'{x:.0f}x'))
    ax.set_ylabel('')
    ax.set_xlabel('')

    # Grid
    ax.grid(True, alpha=0.3, color=grid_color, linestyle='-', linewidth=0.5)
    ax.tick_params(colors=text_color, labelsize=11)

    for spine in ax.spines.values():
        spine.set_color(grid_color)

    # Legend
    legend = ax.legend(loc='upper left', fontsize=13, framealpha=0.9,
                       facecolor='#161b22', edgecolor=grid_color,
                       labelcolor=text_color)

    # Title — clean, no numbers
    ax.set_title('Same asset.  Same period.  Different approach.',
                 color=text_color, fontsize=17, fontweight='bold', pad=15)

    plt.tight_layout()

    out_path = ROOT / 'outputs' / 'charts' / 'linkedin_equity_curve.png'
    fig.savefig(out_path, dpi=200, facecolor=bg_color, bbox_inches='tight')
    print(f"\nSaved: {out_path}")

    plt.close()


if __name__ == '__main__':
    main()
