"""
V20 Allocation Research — COMPREHENSIVE
========================================

Tests 7 regime definitions × 18 allocation formulas = 126 combinations.
Training is shared across all combos (train once, evaluate many).

REGIMES (how to classify BULL/MILD/BEAR):
  1. SMA50/200 (current V19)
  2. SMA20/100 (faster response)
  3. Volatility (vol regime)
  4. RSI-based
  5. Momentum (ret_30d + ret_60d)
  6. Price percentile (position in 1y range)
  7. Composite (SMA + vol + momentum)

FORMULAS (how to convert prediction → allocation):
  Baseline, Kelly×1/3/5/8, Kelly-vol, Kelly-empirical, Log-Kelly,
  Mean-Variance, Adaptive-vol, Blend,
  Tanh, Tanh-aggressive, Sigmoid,
  Rank, Sign-magnitude, Winsorize, Normalize-then-K
"""

import sys
import gc
import numpy as np
import pandas as pd
from pathlib import Path
import warnings
import json
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor

warnings.filterwarnings('ignore')
sys.stdout.reconfigure(line_buffering=True)

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

from archive.old_pipelines.pipeline_v09 import (
    load_data, build_ml_features, backtest_allocations,
    metrics, SEEDS_10, COST, P, _seed_summary, convert_numpy,
)
from archive.old_pipelines.pipeline_v10 import MODELS
from archive.old_pipelines.pipeline_v11 import DEFAULT_XGB_PARAMS
from archive.old_pipelines.pipeline_v13 import _get_retrain_periods, _train_one_xgb

W = 16
RF_DAILY_ARR = None
RESULTS_PATH = ROOT / 'outputs/results/v20_alloc_research.json'


def get_v18_feats():
    base = [f for f in MODELS['37feat'] if f != 'exchange_netflow_ma7'] + ['basis_pct']
    extra = ['fed_balance_sheet', 'futures_trade_count', 'vol_x_regime_duration',
             'velocity', 'hash_rate_pctchg_30d']
    return base + [f for f in extra if f not in base]


# ============================================================
# REGIME DEFINITIONS
# ============================================================
# Each returns a function: (t, precomputed_signals) → 'BULL'/'MILD'/'BEAR'

def make_regime_sma50_200(prices, **kw):
    """V19 current: SMA50/SMA200 golden/death cross."""
    sma50 = pd.Series(prices).rolling(50).mean().values
    sma200 = pd.Series(prices).rolling(200).mean().values
    def classify(t):
        if np.isnan(sma50[t]) or np.isnan(sma200[t]):
            return 'MILD'
        if prices[t] > sma50[t] and sma50[t] > sma200[t]:
            return 'BULL'
        elif prices[t] > sma200[t]:
            return 'MILD'
        return 'BEAR'
    return classify


def make_regime_sma20_100(prices, **kw):
    """Faster SMAs: responds quicker to trend changes."""
    sma20 = pd.Series(prices).rolling(20).mean().values
    sma100 = pd.Series(prices).rolling(100).mean().values
    def classify(t):
        if np.isnan(sma20[t]) or np.isnan(sma100[t]):
            return 'MILD'
        if prices[t] > sma20[t] and sma20[t] > sma100[t]:
            return 'BULL'
        elif prices[t] > sma100[t]:
            return 'MILD'
        return 'BEAR'
    return classify


def make_regime_volatility(daily_ret, **kw):
    """Volatility regime: low vol = favorable, high vol = unfavorable."""
    vol30 = pd.Series(daily_ret).rolling(30).std().fillna(0.03).values
    vol_expanding_median = pd.Series(vol30).expanding(60).median().fillna(0.03).values
    vol_expanding_q75 = pd.Series(vol30).expanding(60).quantile(0.75).fillna(0.04).values
    def classify(t):
        if t < 60:
            return 'MILD'
        v = vol30[t]
        if v < vol_expanding_median[t]:
            return 'BULL'   # Low vol = calm = favorable
        elif v > vol_expanding_q75[t]:
            return 'BEAR'   # High vol = turbulent = unfavorable
        return 'MILD'
    return classify


def make_regime_rsi(df, **kw):
    """RSI-based: overbought/oversold zones."""
    if 'rsi_14d' in df.columns:
        rsi = df['rsi_14d'].values
    else:
        rsi = np.full(len(df), 50.0)
    def classify(t):
        r = rsi[t]
        if np.isnan(r):
            return 'MILD'
        if r > 55:
            return 'BULL'
        elif r < 45:
            return 'BEAR'
        return 'MILD'
    return classify


def make_regime_momentum(prices, **kw):
    """Momentum: recent returns determine regime."""
    n = len(prices)
    ret30 = np.zeros(n)
    ret60 = np.zeros(n)
    for i in range(30, n):
        ret30[i] = (prices[i] - prices[i-30]) / prices[i-30]
    for i in range(60, n):
        ret60[i] = (prices[i] - prices[i-60]) / prices[i-60]
    def classify(t):
        if t < 60:
            return 'MILD'
        if ret30[t] > 0 and ret60[t] > 0:
            return 'BULL'
        elif ret30[t] < 0 and ret60[t] < 0:
            return 'BEAR'
        return 'MILD'
    return classify


def make_regime_percentile(df, **kw):
    """Price percentile in 1-year range."""
    if 'price_percentile_1y' in df.columns:
        pctl = df['price_percentile_1y'].values
    else:
        prices = df['price_usd'].values
        pctl = pd.Series(prices).rolling(365, min_periods=60).rank(pct=True).fillna(0.5).values
    def classify(t):
        p = pctl[t]
        if np.isnan(p):
            return 'MILD'
        if p > 0.6:
            return 'BULL'
        elif p < 0.3:
            return 'BEAR'
        return 'MILD'
    return classify


def make_regime_composite(prices, daily_ret, df, **kw):
    """Composite: SMA trend + vol + momentum. Majority vote."""
    sma_fn = make_regime_sma50_200(prices)
    vol_fn = make_regime_volatility(daily_ret)
    mom_fn = make_regime_momentum(prices)
    def classify(t):
        votes = [sma_fn(t), vol_fn(t), mom_fn(t)]
        bull = votes.count('BULL')
        bear = votes.count('BEAR')
        if bull >= 2:
            return 'BULL'
        elif bear >= 2:
            return 'BEAR'
        return 'MILD'
    return classify


REGIME_MAKERS = {
    'sma50_200':    make_regime_sma50_200,
    'sma20_100':    make_regime_sma20_100,
    'volatility':   make_regime_volatility,
    'rsi':          make_regime_rsi,
    'momentum':     make_regime_momentum,
    'percentile':   make_regime_percentile,
    'composite':    make_regime_composite,
}


# ============================================================
# ALLOCATION FORMULAS
# ============================================================
# All receive: avg_pred, regime, residual_var, recent_vol, hist_preds,
#              hist_results, price_t, sma200_t, median_vol

def alloc_baseline(avg_pred, regime, residual_var, recent_vol, **kw):
    K = {'BULL': 50, 'MILD': 30, 'BEAR': 15}[regime]
    return np.clip(avg_pred * K, -0.25, 1.0)

def alloc_kelly_1x(avg_pred, regime, residual_var, recent_vol, **kw):
    if residual_var < 1e-10: return 0.0
    kelly_f = avg_pred / residual_var
    cap = {'BULL': 1.0, 'MILD': 0.70, 'BEAR': 0.40}[regime]
    floor = {'BULL': -0.25, 'MILD': -0.20, 'BEAR': -0.25}[regime]
    return np.clip(kelly_f, floor, cap)

def alloc_kelly_3x(avg_pred, regime, residual_var, recent_vol, **kw):
    if residual_var < 1e-10: return 0.0
    kelly_f = avg_pred / residual_var * 3.0
    cap = {'BULL': 1.0, 'MILD': 0.70, 'BEAR': 0.40}[regime]
    return np.clip(kelly_f, -0.25, cap)

def alloc_kelly_5x(avg_pred, regime, residual_var, recent_vol, **kw):
    if residual_var < 1e-10: return 0.0
    kelly_f = avg_pred / residual_var * 5.0
    cap = {'BULL': 1.0, 'MILD': 0.80, 'BEAR': 0.50}[regime]
    return np.clip(kelly_f, -0.25, cap)

def alloc_kelly_8x(avg_pred, regime, residual_var, recent_vol, **kw):
    if residual_var < 1e-10: return 0.0
    kelly_f = avg_pred / residual_var * 8.0
    cap = {'BULL': 1.0, 'MILD': 1.0, 'BEAR': 0.60}[regime]
    return np.clip(kelly_f, -0.25, cap)

def alloc_kelly_vol(avg_pred, regime, residual_var, recent_vol, **kw):
    vol_3d_sq = max(3.0 * recent_vol ** 2, 1e-8)
    raw_kelly = avg_pred / vol_3d_sq
    mult = {'BULL': 5.0, 'MILD': 3.0, 'BEAR': 1.5}[regime]
    return np.clip(raw_kelly * mult, -0.25, 1.0)

def alloc_kelly_empirical(avg_pred, regime, residual_var, recent_vol,
                          hist_results=None, **kw):
    if hist_results is None or len(hist_results) < 20:
        K = {'BULL': 50, 'MILD': 30, 'BEAR': 15}[regime]
        return np.clip(avg_pred * K, -0.25, 1.0)
    recent = hist_results[-52:]
    preds_h = np.array([r[0] for r in recent])
    actuals_h = np.array([r[1] for r in recent])
    correct = np.sign(preds_h) == np.sign(actuals_h)
    p = correct.mean()
    if p <= 0.5: return 0.0
    wins = np.abs(actuals_h[correct])
    losses = np.abs(actuals_h[~correct])
    if len(wins) == 0 or len(losses) == 0:
        K = {'BULL': 30, 'MILD': 20, 'BEAR': 10}[regime]
        return np.clip(avg_pred * K, -0.25, 1.0)
    b = wins.mean() / (losses.mean() + 1e-10)
    kelly_pct = max((p * b - (1-p)) / b, 0)
    K_kelly = kelly_pct / 0.02
    regime_scale = {'BULL': 2.0, 'MILD': 1.5, 'BEAR': 1.0}[regime]
    return np.clip(avg_pred * K_kelly * regime_scale, -0.25, 1.0)

def alloc_log_kelly(avg_pred, regime, residual_var, recent_vol, **kw):
    if residual_var < 1e-10: return 0.0
    compressed = np.log1p(abs(avg_pred) * 100) / np.log1p(100) * np.sign(avg_pred)
    kelly_f = compressed / residual_var * 5.0
    cap = {'BULL': 1.0, 'MILD': 0.80, 'BEAR': 0.50}[regime]
    return np.clip(kelly_f, -0.25, cap)

def alloc_mean_variance(avg_pred, regime, residual_var, recent_vol, **kw):
    gamma = {'BULL': 0.5, 'MILD': 1.0, 'BEAR': 3.0}[regime]
    vol_sq = max(recent_vol ** 2, 1e-8)
    w = avg_pred / (gamma * vol_sq)
    return np.clip(w, -0.25, 1.0)

def alloc_adaptive_vol(avg_pred, regime, residual_var, recent_vol, **kw):
    median_vol = kw.get('median_vol', 0.03)
    vol_ratio = max(recent_vol / (median_vol + 1e-10), 0.3)
    K_base = {'BULL': 50, 'MILD': 30, 'BEAR': 15}[regime]
    return np.clip(avg_pred * K_base / vol_ratio, -0.25, 1.0)

def alloc_blend(avg_pred, regime, residual_var, recent_vol, **kw):
    K = {'BULL': 50, 'MILD': 30, 'BEAR': 15}[regime]
    base = np.clip(avg_pred * K, -0.25, 1.0)
    if residual_var > 1e-10:
        kelly = np.clip(avg_pred / residual_var * 5.0, -0.25,
                        {'BULL': 1.0, 'MILD': 0.80, 'BEAR': 0.50}[regime])
    else:
        kelly = base
    return np.clip(0.5 * base + 0.5 * kelly, -0.25, 1.0)

def alloc_tanh(avg_pred, regime, residual_var, recent_vol, **kw):
    scale = {'BULL': 80, 'MILD': 50, 'BEAR': 25}[regime]
    raw = np.tanh(avg_pred * scale)
    return raw * 1.0 if raw >= 0 else raw * 0.25

def alloc_tanh_aggr(avg_pred, regime, residual_var, recent_vol, **kw):
    scale = {'BULL': 150, 'MILD': 80, 'BEAR': 40}[regime]
    raw = np.tanh(avg_pred * scale)
    return raw * 1.0 if raw >= 0 else raw * 0.25

def alloc_sigmoid(avg_pred, regime, residual_var, recent_vol, **kw):
    scale = {'BULL': 80, 'MILD': 50, 'BEAR': 25}[regime]
    return 1.25 / (1.0 + np.exp(-avg_pred * scale)) - 0.25

def alloc_rank(avg_pred, regime, residual_var, recent_vol, hist_preds=None, **kw):
    if hist_preds is None or len(hist_preds) < 15:
        K = {'BULL': 50, 'MILD': 30, 'BEAR': 15}[regime]
        return np.clip(avg_pred * K, -0.25, 1.0)
    window = hist_preds[-52:]
    rank = np.mean([1 for p in window if avg_pred > p])
    max_long = {'BULL': 1.0, 'MILD': 0.70, 'BEAR': 0.40}[regime]
    max_short = {'BULL': -0.25, 'MILD': -0.20, 'BEAR': -0.25}[regime]
    if rank >= 0.5:
        return (rank - 0.5) * 2.0 * max_long
    else:
        return (0.5 - rank) * 2.0 * max_short

def alloc_sign_mag(avg_pred, regime, residual_var, recent_vol, **kw):
    if residual_var < 1e-10: return 0.0
    direction = np.sign(avg_pred)
    z = abs(avg_pred) / (np.sqrt(residual_var) + 1e-10)
    max_long = {'BULL': 1.0, 'MILD': 0.70, 'BEAR': 0.40}[regime]
    size = np.clip(z / 2.0, 0.05, 1.0)
    return size * max_long if direction > 0 else -size * 0.25

def alloc_winsorize(avg_pred, regime, residual_var, recent_vol, hist_preds=None, **kw):
    K = {'BULL': 50, 'MILD': 30, 'BEAR': 15}[regime]
    if hist_preds is not None and len(hist_preds) >= 20:
        recent = np.array(hist_preds[-52:])
        mu, sigma = np.mean(recent), np.std(recent) + 1e-10
        pred = np.clip(avg_pred, mu - 2*sigma, mu + 2*sigma)
    else:
        pred = avg_pred
    return np.clip(pred * K, -0.25, 1.0)

def alloc_normalize(avg_pred, regime, residual_var, recent_vol, hist_preds=None, **kw):
    if hist_preds is None or len(hist_preds) < 20:
        K = {'BULL': 50, 'MILD': 30, 'BEAR': 15}[regime]
        return np.clip(avg_pred * K, -0.25, 1.0)
    recent = np.array(hist_preds[-52:])
    z = (avg_pred - np.mean(recent)) / (np.std(recent) + 1e-10)
    scale = {'BULL': 0.50, 'MILD': 0.35, 'BEAR': 0.20}[regime]
    return np.clip(z * scale, -0.25, 1.0)


ALLOC_FORMULAS = {
    'baseline':       alloc_baseline,
    'kelly_1x':       alloc_kelly_1x,
    'kelly_3x':       alloc_kelly_3x,
    'kelly_5x':       alloc_kelly_5x,
    'kelly_8x':       alloc_kelly_8x,
    'kelly_vol':      alloc_kelly_vol,
    'kelly_empir':    alloc_kelly_empirical,
    'log_kelly':      alloc_log_kelly,
    'mean_var':       alloc_mean_variance,
    'adapt_vol':      alloc_adaptive_vol,
    'blend':          alloc_blend,
    'tanh':           alloc_tanh,
    'tanh_aggr':      alloc_tanh_aggr,
    'sigmoid':        alloc_sigmoid,
    'rank':           alloc_rank,
    'sign_mag':       alloc_sign_mag,
    'winsorize':      alloc_winsorize,
    'normalize':      alloc_normalize,
}


# ============================================================
# OPTIMIZED ENGINE — train once, evaluate all combos
# ============================================================

def run_all_combos(daily_ret, returns, vols, df, dates, n,
                   feature_cols, base_seed=42, n_bags=80,
                   rebal_days=None, emergency_threshold=0.08):
    """Train models once, then evaluate ALL regime×formula combos."""
    if rebal_days is None:
        rebal_days = [4]

    xgb_params = dict(DEFAULT_XGB_PARAMS)
    prices = df['price_usd'].values
    X_all, _ = build_ml_features(df, returns, vols, n, feature_cols=feature_cols)

    target = np.zeros(n)
    for i in range(n - 3):
        target[i] = (prices[i + 3] - prices[i]) / prices[i]

    actual_3d = np.full(n, np.nan)
    for i in range(n - 3):
        actual_3d[i] = (prices[i + 3] - prices[i]) / prices[i]

    dow = pd.to_datetime(dates).dayofweek
    vol_30d = pd.Series(daily_ret).rolling(30).std().fillna(0.03).values
    median_vol = np.median(vol_30d[vol_30d > 0])
    periods = _get_retrain_periods(dates, n, 'semi')
    is_rf = isinstance(RF_DAILY_ARR, np.ndarray)

    # --- PHASE 1: Train models and precompute predictions ---
    # Store: for each period, the trained models predictions + residual_var
    period_data = []  # list of (ts, tend, day_predictions)
    # day_predictions[t] = {'avg': float, 'bags': np.array, 'residual_var': float}
    P(f"      Training seed={base_seed}...")

    for te, ts, tend in periods:
        gap = 5
        tm = np.arange(60, te - gap + 1)
        v = ~np.any(np.isnan(X_all[tm]), axis=1)
        idx = tm[v]
        if len(idx) < 100:
            continue
        Xt, yt = np.nan_to_num(X_all[idx], nan=0.0), target[idx]
        seeds = [base_seed + i * 7 for i in range(n_bags)]
        with ThreadPoolExecutor(max_workers=W) as ex:
            models = list(ex.map(_train_one_xgb, [(s, Xt, yt, xgb_params) for s in seeds]))
        if not models:
            continue

        # Residual variance from training data
        train_preds = np.mean([m.predict(Xt) for m in models], axis=0)
        residual_var = float(np.var(yt - train_preds))

        # Precompute predictions for all test days
        day_preds = {}
        for t in range(ts, tend + 1):
            is_rebal = dow[t] in rebal_days
            is_emerg = (t > 0 and abs(daily_ret[t]) > emergency_threshold)
            if not is_rebal and not is_emerg:
                continue
            x_t = np.nan_to_num(X_all[t:t + 1].copy(), nan=0.0)
            bags = np.array([m.predict(x_t)[0] for m in models])
            day_preds[t] = {
                'avg': float(np.mean(bags)),
                'bags': bags,
                'residual_var': residual_var,
                'actual_3d': actual_3d[t],
                'vol': vol_30d[t],
            }

        period_data.append((ts, tend, day_preds))

    del models
    gc.collect()

    # --- PHASE 2: Build regime classifiers ---
    regime_classifiers = {}
    for rname, maker in REGIME_MAKERS.items():
        regime_classifiers[rname] = maker(
            prices=prices, daily_ret=daily_ret, df=df)

    # --- PHASE 3: Evaluate all regime × formula combos ---
    combo_results = {}

    for rname, regime_fn in regime_classifiers.items():
        for fname, formula_fn in ALLOC_FORMULAS.items():
            key = f"{rname}|{fname}"

            full_allocs = np.full(n, 0.0)
            prev = 0.0
            hist_preds = []
            hist_results = []
            a_s, a_b, a_a, a_r, a_i = [], [], [], [], []

            for ts, tend, day_preds in period_data:
                for t in range(ts, tend + 1):
                    if t not in day_preds:
                        full_allocs[t] = prev
                        continue

                    dp = day_preds[t]
                    regime = regime_fn(t)
                    hist_preds.append(dp['avg'])
                    if not np.isnan(dp['actual_3d']):
                        hist_results.append((dp['avg'], dp['actual_3d']))

                    full_allocs[t] = formula_fn(
                        avg_pred=dp['avg'],
                        regime=regime,
                        residual_var=dp['residual_var'],
                        recent_vol=dp['vol'],
                        hist_preds=hist_preds,
                        hist_results=hist_results,
                        price_t=prices[t],
                        sma200_t=0,  # not used by most formulas
                        median_vol=median_vol,
                    )
                    prev = full_allocs[t]

                s, b, a = backtest_allocations(daily_ret, full_allocs, ts, tend,
                                               cost=COST, rf_daily=RF_DAILY_ARR)
                a_s.extend(s); a_b.extend(b); a_a.extend(a)
                a_i.extend(range(ts, ts + len(s)))
                nd = len(s)
                a_r.extend(RF_DAILY_ARR[ts:ts + nd] if is_rf else [0.0] * nd)

            combo_results[key] = (np.array(a_s), np.array(a_b),
                                  np.array(a_a), np.array(a_r))

    return combo_results


def main():
    P("=" * 80)
    P("V20 COMPREHENSIVE — 7 REGIMES × 18 FORMULAS = 126 COMBOS")
    P("=" * 80)
    start = datetime.now()

    prices, daily_ret, returns, vols, df = load_data()
    dates = df['date'].values; n = len(prices)

    global RF_DAILY_ARR
    import archive.old_pipelines.pipeline_v09 as v9m
    import archive.old_pipelines.pipeline_v13 as v13m
    try:
        from src.features.macro.cdi_rates import build_rf_daily
        RF_DAILY_ARR = build_rf_daily(dates, source='auto')
    except Exception:
        from src.features.macro.cdi_rates import build_rf_daily
        RF_DAILY_ARR = build_rf_daily(dates, source='copom')
    v9m.RF_DAILY_ARR = RF_DAILY_ARR; v13m.RF_DAILY_ARR = RF_DAILY_ARR

    fc = get_v18_feats()
    fc = [f for f in fc if f in df.columns]
    P(f"  {n} days | {len(fc)} features")
    P(f"  {len(REGIME_MAKERS)} regimes × {len(ALLOC_FORMULAS)} formulas = "
      f"{len(REGIME_MAKERS) * len(ALLOC_FORMULAS)} combos × {len(SEEDS_10)} seeds\n")

    # Collect results per combo across seeds
    all_combo_metrics = {}  # key → list of metric dicts

    for si, seed in enumerate(SEEDS_10):
        P(f"  === SEED {seed} ({si+1}/{len(SEEDS_10)}) ===")
        combo_results = run_all_combos(
            daily_ret, returns, vols, df, dates, n, fc, base_seed=seed)

        for key, (s, b, a, r) in combo_results.items():
            m = metrics(s, b, a, rf_daily=r)
            if m is not None:
                if key not in all_combo_metrics:
                    all_combo_metrics[key] = []
                all_combo_metrics[key].append(m)

        gc.collect()
        elapsed_so_far = (datetime.now() - start).total_seconds() / 60
        P(f"      Done. Elapsed: {elapsed_so_far:.1f} min")

    # --- AGGREGATE RESULTS ---
    P(f"\n{'=' * 90}")
    P("AGGREGATING RESULTS...")
    P("=" * 90)

    final_results = []
    for key, mlist in all_combo_metrics.items():
        rname, fname = key.split('|')
        rets = [m['total'] * 100 for m in mlist]
        summary = _seed_summary(rets, mlist)
        avg_alloc = np.mean([m['avg_alloc'] for m in mlist])
        short_pct = np.mean([m['short_pct'] for m in mlist])
        final_results.append({
            'regime': rname,
            'formula': fname,
            'config': f"{rname}|{fname}",
            'sortino': summary['sortinos_mean'],
            'return': summary['mean'],
            'spread': summary['spread'],
            'max_dd': summary['max_dds_mean'],
            'avg_alloc': round(avg_alloc * 100, 1),
            'short_pct': round(short_pct * 100, 1),
        })

    # --- TOP 30 RANKING ---
    final_results.sort(key=lambda x: x['sortino'], reverse=True)

    P(f"\n{'=' * 100}")
    P(f"TOP 30 (of {len(final_results)} combos)")
    P("=" * 100)
    P(f"  {'#':>3} {'Regime':<14} {'Formula':<14} {'Sortino':>8} {'Return':>10} "
      f"{'Spread':>8} {'MaxDD':>8} {'AvgAlloc':>9} {'Short%':>7}")
    P(f"  {'-' * 90}")

    for i, r in enumerate(final_results[:30]):
        marker = ' ***' if i == 0 else ''
        bl = ' (V19)' if r['regime'] == 'sma50_200' and r['formula'] == 'baseline' else ''
        P(f"  {i+1:3d} {r['regime']:<14} {r['formula']:<14} {r['sortino']:>8.2f} "
          f"{r['return']:>+9.0f}% {r['spread']:>7.0f}pp {r['max_dd']:>7.1f}% "
          f"{r['avg_alloc']:>8.1f}% {r['short_pct']:>6.1f}%{marker}{bl}")

    # --- BEST PER REGIME ---
    P(f"\n{'=' * 100}")
    P("BEST FORMULA PER REGIME")
    P("=" * 100)
    for rname in REGIME_MAKERS:
        regime_results = [r for r in final_results if r['regime'] == rname]
        if regime_results:
            best = regime_results[0]  # already sorted by sortino
            P(f"  {rname:<14}: {best['formula']:<14} S={best['sortino']:.2f} "
              f"ret={best['return']:+.0f}% DD={best['max_dd']:.1f}%")

    # --- BEST PER FORMULA ---
    P(f"\n{'=' * 100}")
    P("BEST REGIME PER FORMULA")
    P("=" * 100)
    for fname in ALLOC_FORMULAS:
        formula_results = sorted(
            [r for r in final_results if r['formula'] == fname],
            key=lambda x: x['sortino'], reverse=True)
        if formula_results:
            best = formula_results[0]
            P(f"  {fname:<14}: {best['regime']:<14} S={best['sortino']:.2f} "
              f"ret={best['return']:+.0f}% DD={best['max_dd']:.1f}%")

    elapsed = (datetime.now() - start).total_seconds() / 60
    P(f"\n  Total elapsed: {elapsed:.1f} min")

    # Save
    output = {
        'pipeline': 'V20_comprehensive',
        'timestamp': start.isoformat(),
        'elapsed_min': float(elapsed),
        'n_regimes': len(REGIME_MAKERS),
        'n_formulas': len(ALLOC_FORMULAS),
        'n_combos': len(final_results),
        'top30': final_results[:30],
        'all_results': final_results,
    }
    RESULTS_PATH.parent.mkdir(parents=True, exist_ok=True)
    RESULTS_PATH.write_text(json.dumps(convert_numpy(output), indent=2, default=str),
                            encoding='utf-8')
    P(f"  Saved: {RESULTS_PATH}")


if __name__ == '__main__':
    main()
