"""V31: test V29.4 winner with the FULL V23 pipeline (regressor + classifier + sigmoid)
and sweep the decision-layer parameters (sigmoid_scale, floor, alpha).

Previous tests (V26-V30) used pipeline_v22 (regressor only, no sigmoid).
V23 in production adds:
  - Secondary classifier predicting P(up)
  - Sigmoid confidence factor: sigmoid(|P_up - 0.5| * SIGMOID_SCALE)
  - Floor ALLOC_MIN, ceiling ALLOC_MAX

Tests (each 3 seeds, pipeline V23 with both ensembles):

  V31.0 — V29.4 + sigmoid scale 15 (CURRENT PRODUCTION)
  V31.1 — V29.4 + NO sigmoid (regressor only, = V22-style)
  V31.2 — V29.4 + sigmoid scale 5 (less aggressive scaling)
  V31.3 — V29.4 + sigmoid scale 10
  V31.4 — V29.4 + sigmoid scale 20
  V31.5 — V29.4 + sigmoid scale 25

  V31.6 — V29.4 + floor -0.5 (more short allowed)
  V31.7 — V29.4 + floor 0.0 (no short allowed)
  V31.8 — V29.4 + ceiling 0.75 (less agressive long)

  V31.9 — V29.4 + reg_alpha 0.1 on both models
"""
import sys, time, json, gc
import numpy as np, pandas as pd
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import xgboost as xgb

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

import archive.old_pipelines.pipeline_v22 as v22
from archive.old_pipelines.pipeline_v09 import build_ml_features, backtest_allocations, COST
from scripts.production.training import _get_retrain_periods, _train_one_xgb
from src.features.macro.cdi_rates import build_rf_daily
import archive.old_pipelines.pipeline_v09 as v9m
import archive.old_pipelines.pipeline_v13 as v13m
from scripts.production.config import FEATURES_37, K_REGIME, BAGS, HORIZON, WORKERS, EMERGENCY_THRESHOLD

DATASET = ROOT / "outputs" / "feature_selection" / "dataset_enhanced.csv"
SEEDS_3 = [42, 142, 242]
RESULTS = ROOT / "outputs" / "results" / "v31_v23_pipeline.json"
DAY_NAMES = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun']


def load():
    df = pd.read_csv(DATASET)
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)
    prices = df['price_usd'].values
    n = len(prices)
    daily_ret = np.zeros(n)
    for i in range(1, n):
        daily_ret[i] = (prices[i] - prices[i-1]) / prices[i-1]
    returns, vols = {}, {}
    for w in [1, 3, 5, 7, 10, 14, 20, 21, 30, 45, 60]:
        r = np.zeros(n)
        for i in range(w, n):
            r[i] = (prices[i] - prices[i-w]) / prices[i-w]
        returns[w] = r
    for w in [5, 7, 10, 14, 21, 30]:
        vols[w] = pd.Series(daily_ret).rolling(w).std().fillna(0.02).values
    return prices, daily_ret, returns, vols, df


def get_regime(t, prices, sma50, sma200):
    if np.isnan(sma50[t]) or np.isnan(sma200[t]): return 'MILD'
    if prices[t] > sma50[t] and sma50[t] > sma200[t]: return 'BULL'
    elif prices[t] > sma200[t]: return 'MILD'
    return 'BEAR'


def train_classifier_bag(Xt, yt, bag_seeds, xgb_params):
    """Train classifier ensemble for confidence."""
    yt_bin = (yt > 0).astype(int)
    models = []
    for s in bag_seeds:
        rng = np.random.RandomState(s)
        # Bootstrap sample
        idx = rng.choice(len(Xt), size=len(Xt), replace=True)
        p = dict(xgb_params)
        p.pop('objective', None)
        m = xgb.XGBClassifier(
            n_estimators=p.pop('n_estimators', 200),
            random_state=s, objective='binary:logistic',
            eval_metric='logloss', n_jobs=1,
            **{k:v for k,v in p.items() if k in
               ['max_leaves','colsample_bytree','subsample','learning_rate',
                'min_child_weight','reg_alpha','reg_lambda','grow_policy','tree_method']})
        m.fit(Xt[idx], yt_bin[idx])
        models.append(m)
    return models


def run_v23(seed, X_all, target, prices, daily_ret, dates, periods,
            dow, sma50, sma200, rf_daily, n,
            sigmoid_scale=15, alloc_min=-0.25, alloc_max=1.0,
            use_sigmoid=True, xgb_params=None):
    """V23-style: regressor + classifier + sigmoid + floor."""
    params = xgb_params if xgb_params is not None else v22.XGB_PARAMS
    full_allocs = np.full(n, 0.0)
    prev_alloc = 0.0
    a_s, a_b, a_a, a_r = [], [], [], []
    all_preds = np.zeros(n)
    all_actuals = target.copy()

    for te, ts, tend in periods:
        gap = max(HORIZON, 5)
        tm = np.arange(60, te - gap + 1)
        valid = ~np.any(np.isnan(X_all[tm]), axis=1)
        idx = tm[valid]
        if len(idx) < 100: continue
        Xt = np.nan_to_num(X_all[idx], nan=0.0)
        yt = target[idx]

        bag_seeds = [seed + i * 7 for i in range(BAGS)]
        with ThreadPoolExecutor(max_workers=WORKERS) as ex:
            reg_models = list(ex.map(_train_one_xgb,
                [(s, Xt, yt, params) for s in bag_seeds]))
        cls_models = train_classifier_bag(Xt, yt, bag_seeds, params) if use_sigmoid else None

        for t in range(ts, tend + 1):
            x_t = np.nan_to_num(X_all[t:t + 1].copy(), nan=0.0)
            prediction = float(np.mean([m.predict(x_t)[0] for m in reg_models]))

            if use_sigmoid and cls_models:
                p_up = float(np.mean([m.predict_proba(x_t)[0, 1] for m in cls_models]))
                conf = abs(p_up - 0.5)
                conf_factor = float(1.0 / (1.0 + np.exp(-conf * sigmoid_scale)))
            else:
                conf_factor = 1.0

            all_preds[t] = prediction * conf_factor  # logged with confidence

            is_rebal = dow[t] in [4]
            is_emerg = t > 0 and abs(daily_ret[t]) > EMERGENCY_THRESHOLD
            if not is_rebal and not is_emerg:
                full_allocs[t] = prev_alloc; continue

            regime = get_regime(t, prices, sma50, sma200)
            K = K_REGIME[regime]
            raw = prediction * K * conf_factor
            full_allocs[t] = float(np.clip(raw, alloc_min, alloc_max))
            prev_alloc = full_allocs[t]

        s, b, a = backtest_allocations(daily_ret, full_allocs, ts, tend,
                                       cost=COST, rf_daily=rf_daily)
        a_s.extend(s); a_b.extend(b); a_a.extend(a)
        a_r.extend(rf_daily[ts:ts + len(s)])
        del reg_models
        if cls_models: del cls_models
        gc.collect()

    metrics = v22.metrics_v22(np.array(a_s), np.array(a_b), np.array(a_a),
                              rf_daily=np.array(a_r))
    return metrics, all_preds, all_actuals


def accuracy_per_dow(preds, actuals, dow):
    mask = np.abs(preds) > 1e-6
    out = {'all': float((np.sign(preds[mask]) == np.sign(actuals[mask])).mean())}
    for d, name in enumerate(DAY_NAMES):
        dmask = mask & (dow == d)
        if dmask.sum() > 10:
            out[name] = float((np.sign(preds[dmask]) == np.sign(actuals[dmask])).mean())
        else:
            out[name] = None
    return out


def agg(name, outputs, dow, config=""):
    sortinos = [o[0]['sortino'] for o in outputs]
    rets     = [o[0]['total']*100 for o in outputs]
    dds      = [o[0]['max_dd']*100 for o in outputs]
    preds_avg = np.mean([o[1] for o in outputs], axis=0)
    actuals = outputs[0][2]
    acc = accuracy_per_dow(preds_avg, actuals, dow)
    result = {
        'name': name, 'config': config,
        'sortino_mean': float(np.mean(sortinos)), 'sortino_std': float(np.std(sortinos)),
        'ret_mean': float(np.mean(rets)), 'ret_std': float(np.std(rets)),
        'dd_mean': float(np.mean(dds)), 'dd_std': float(np.std(dds)),
        'acc': acc,
    }
    print(f"{name:<28}  {config:<20}  S={result['sortino_mean']:.2f}+/-{result['sortino_std']:.2f}  "
          f"Ret={result['ret_mean']:+.0f}%  DD={result['dd_mean']:.1f}%  "
          f"Fri={acc.get('Fri', 0)*100:.1f}%")
    return result


def main():
    t0 = time.time()
    print("=" * 100)
    print("V31 — V23 pipeline (regressor + classifier + sigmoid) on V29.4 config")
    print("Feature set: 29 features (V29 already in production)")
    print("Fracdiff d=0.3")
    print("=" * 100)

    prices, daily_ret, returns, vols, df = load()
    dates = df['date'].values
    n = len(prices)
    rf_daily = build_rf_daily(dates, source='auto')
    v9m.RF_DAILY_ARR = rf_daily
    v13m.RF_DAILY_ARR = rf_daily
    dow = pd.to_datetime(dates).dayofweek.values
    periods = _get_retrain_periods(dates, n, v22.RETRAIN)
    sma50 = pd.Series(prices).rolling(50).mean().values
    sma200 = pd.Series(prices).rolling(200).mean().values

    # V29 features (29 - already in FEATURES_37 after v29_apply_to_production)
    feats = list(FEATURES_37)
    X_v29, _ = build_ml_features(df, returns, vols, n, feature_cols=feats)

    target = np.zeros(n)
    for i in range(n - HORIZON):
        target[i] = (prices[i + HORIZON] - prices[i]) / prices[i]

    results = []
    def save():
        RESULTS.parent.mkdir(parents=True, exist_ok=True)
        with open(RESULTS, 'w') as f:
            json.dump({'results': results, 'elapsed_min': (time.time()-t0)/60}, f, indent=2)

    tests = [
        ('V31.0_sigmoid_15', 'current prod', dict(sigmoid_scale=15)),
        ('V31.1_no_sigmoid', 'no confidence', dict(use_sigmoid=False)),
        ('V31.2_sigmoid_5',  's=5',  dict(sigmoid_scale=5)),
        ('V31.3_sigmoid_10', 's=10', dict(sigmoid_scale=10)),
        ('V31.4_sigmoid_20', 's=20', dict(sigmoid_scale=20)),
        ('V31.5_sigmoid_25', 's=25', dict(sigmoid_scale=25)),
        ('V31.6_floor_m050', 'floor=-0.5', dict(alloc_min=-0.5)),
        ('V31.7_no_short',   'floor=0.0',  dict(alloc_min=0.0)),
        ('V31.8_ceil_075',   'ceil=0.75',  dict(alloc_max=0.75)),
    ]

    for name, cfg_desc, kwargs in tests:
        t1 = time.time()
        print(f"\n-- {name}: {cfg_desc} --")
        outs = [run_v23(s, X_v29, target, prices, daily_ret, dates, periods,
                         dow, sma50, sma200, rf_daily, n, **kwargs) for s in SEEDS_3]
        results.append(agg(name, outs, dow, cfg_desc)); save()
        print(f"  ({(time.time()-t1)/60:.1f}m)")

    # V31.9: reg_alpha 0.1
    t1 = time.time()
    print(f"\n-- V31.9: reg_alpha=0.1 + sigmoid_15 --")
    p_reg = dict(v22.XGB_PARAMS); p_reg['reg_alpha'] = 0.1; p_reg['reg_lambda'] = 0.1
    outs = [run_v23(s, X_v29, target, prices, daily_ret, dates, periods,
                     dow, sma50, sma200, rf_daily, n,
                     xgb_params=p_reg) for s in SEEDS_3]
    results.append(agg('V31.9_reg01_sig15', outs, dow, 'a=0.1 + s=15')); save()
    print(f"  ({(time.time()-t1)/60:.1f}m)")

    elapsed = (time.time() - t0) / 60
    print()
    print("=" * 100)
    print(f"V31 TOTAL: {elapsed:.1f} min")
    print("=" * 100)
    print("\nRanked by Sortino:")
    for r in sorted(results, key=lambda x: -x['sortino_mean']):
        acc = r['acc']
        print(f"  {r['name']:<28}  {r['config']:<20}  S={r['sortino_mean']:.2f}+/-{r['sortino_std']:.2f}  "
              f"Ret={r['ret_mean']:+.0f}%  DD={r['dd_mean']:.1f}%  Fri={acc.get('Fri', 0)*100:.1f}%")
    save()


if __name__ == '__main__':
    main()
