"""
OVERFITTING DIAGNOSTIC — V13-era config vs V22 config, per-year breakdown.

Tests whether iterative improvements (V13→V22) added real value or just
overfit to the 2022-2024 period that was most "seen" during development.

Configs:
  V13-era: K=30 fixed (no regime), Bag40 XGB pure, colsample=0.7,
           semi-annual retrain, Friday rebalance, NO emergency
  V22:     K=50/30/15 dynamic regime, Bag80, colsample=0.5,
           semi-annual retrain, Friday + emergency 8%

If V22 wins in ALL years (especially 2025-2026), the improvements are genuine.
If V22 only wins in 2022-2024 but not 2025-2026, there's sequential overfitting.

Usage:
    python scripts/optimization/overfitting_diagnostic.py
"""
import sys, gc, json, numpy as np, pandas as pd
from pathlib import Path
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
import warnings; warnings.filterwarnings('ignore')
sys.stdout.reconfigure(line_buffering=True)

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

from archive.old_pipelines.pipeline_v09 import (
    load_data, build_ml_features, backtest_allocations,
    get_year_boundaries, COST, P, convert_numpy,
)
from archive.old_pipelines.pipeline_v10 import MODELS
from archive.old_pipelines.pipeline_v13 import _get_retrain_periods, _train_one_xgb


# ═══════════════════════════════════════════════════════════════
# CONFIG A: V13-era (before dynamic regime, before fine-tuning)
# ═══════════════════════════════════════════════════════════════
CONFIG_V13 = {
    'name': 'V13-era',
    'xgb_params': {
        'max_leaves': 31, 'grow_policy': 'lossguide', 'tree_method': 'hist',
        'colsample_bytree': 0.7, 'subsample': 0.8,
        'learning_rate': 0.05, 'min_child_weight': 12,
        'n_estimators': 200, 'objective': 'reg:squarederror',
        'verbosity': 0, 'nthread': 1,
    },
    'K_fixed': 30,           # No regime — fixed K
    'K_regime': None,         # No regime switching
    'bags': 40,
    'horizon': 3,
    'retrain': 'semi',
    'rebal_dow': [4],         # Friday
    'emergency_threshold': None,  # No emergency rebalance
    'workers': 16,
}

# ═══════════════════════════════════════════════════════════════
# CONFIG B: V22 (final model)
# ═══════════════════════════════════════════════════════════════
CONFIG_V22 = {
    'name': 'V22',
    'xgb_params': {
        'max_leaves': 31, 'grow_policy': 'lossguide', 'tree_method': 'hist',
        'colsample_bytree': 0.5, 'subsample': 0.8,
        'learning_rate': 0.05, 'min_child_weight': 12,
        'n_estimators': 200, 'objective': 'reg:squarederror',
        'verbosity': 0, 'nthread': 1,
    },
    'K_fixed': None,
    'K_regime': {'BULL': 50, 'MILD': 30, 'BEAR': 15},
    'bags': 80,
    'horizon': 3,
    'retrain': 'semi',
    'rebal_dow': [4],
    'emergency_threshold': 0.08,
    'workers': 16,
}

ALLOC_MIN = -0.25
ALLOC_MAX = 1.0
FEATURES_37 = [f for f in MODELS['37feat'] if f != 'exchange_netflow_ma7'] + ['basis_pct']
EXTRA_FEATURES = [
    'fed_balance_sheet', 'futures_trade_count',
    'vol_x_regime_duration', 'velocity', 'hash_rate_pctchg_30d',
]


def get_regime(t, prices, sma50, sma200):
    if np.isnan(sma50[t]) or np.isnan(sma200[t]):
        return 'MILD'
    if prices[t] > sma50[t] and sma50[t] > sma200[t]:
        return 'BULL'
    elif prices[t] > sma200[t]:
        return 'MILD'
    return 'BEAR'


def compute_allocation(prediction, config, t=None, prices=None, sma50=None, sma200=None):
    if config['K_regime'] is not None:
        regime = get_regime(t, prices, sma50, sma200)
        K = config['K_regime'][regime]
    else:
        K = config['K_fixed']
    return np.clip(prediction * K, ALLOC_MIN, ALLOC_MAX)


def metrics_by_year(strat_rets, btc_rets, allocs, rf_rets, dates_oos):
    """Compute metrics for the full OOS and per-year."""
    s = np.array(strat_rets)
    b = np.array(btc_rets)
    a = np.array(allocs)
    rf = np.array(rf_rets)
    d = pd.to_datetime(dates_oos)

    def calc(s_, b_, rf_):
        if len(s_) < 10:
            return None
        total = np.prod(1 + s_) - 1
        btc_total = np.prod(1 + b_) - 1
        ex = s_ - rf_
        downside = np.minimum(ex, 0.0)
        dd_std = np.sqrt(np.mean(downside ** 2))
        sortino = np.mean(ex) / (dd_std + 1e-10) * np.sqrt(365)
        sharpe = np.mean(ex) / (np.std(s_) + 1e-10) * np.sqrt(365)
        cum = np.cumprod(1 + s_)
        pk = np.maximum.accumulate(cum)
        max_dd = np.min((cum - pk) / (pk + 1e-10))
        return {
            'return': total, 'btc': btc_total,
            'excess': total - btc_total,
            'sortino': sortino, 'sharpe': sharpe,
            'max_dd': max_dd, 'n_days': len(s_),
        }

    results = {'TOTAL': calc(s, b, rf)}

    for yr in sorted(set(d.year)):
        mask = d.year == yr
        if mask.sum() < 10:
            continue
        results[str(yr)] = calc(s[mask], b[mask], rf[mask])

    return results


def run_config(config, X_all, target, prices, daily_ret, dates, periods,
               dow, sma50, sma200, rf_daily, n, seed):
    """Run a single config + seed. Returns per-day arrays for OOS."""
    full_allocs = np.full(n, 0.0)
    prev_alloc = 0.0
    a_s, a_b, a_a, a_r, a_d = [], [], [], [], []

    bags = config['bags']
    xgb_params = config['xgb_params']
    horizon = config['horizon']
    workers = config['workers']
    emerg = config.get('emergency_threshold')

    for te, ts, tend in periods:
        gap = max(horizon, 5)
        tm = np.arange(60, te - gap + 1)
        valid = ~np.any(np.isnan(X_all[tm]), axis=1)
        idx = tm[valid]
        if len(idx) < 100:
            continue

        Xt = np.nan_to_num(X_all[idx], nan=0.0)
        yt = target[idx]

        bag_seeds = [seed + i * 7 for i in range(bags)]
        with ThreadPoolExecutor(max_workers=workers) as ex:
            models = list(ex.map(_train_one_xgb,
                [(s, Xt, yt, xgb_params) for s in bag_seeds]))

        for t in range(ts, tend + 1):
            is_rebal = dow[t] in config['rebal_dow']
            is_emerg = emerg is not None and t > 0 and abs(daily_ret[t]) > emerg
            if not is_rebal and not is_emerg:
                full_allocs[t] = prev_alloc
                continue

            x_t = np.nan_to_num(X_all[t:t + 1].copy(), nan=0.0)
            prediction = float(np.mean([m.predict(x_t)[0] for m in models]))
            full_allocs[t] = compute_allocation(
                prediction, config, t=t, prices=prices, sma50=sma50, sma200=sma200)
            prev_alloc = full_allocs[t]

        s, b, a = backtest_allocations(daily_ret, full_allocs, ts, tend,
                                       cost=COST, rf_daily=rf_daily)
        a_s.extend(s)
        a_b.extend(b)
        a_a.extend(a)
        a_r.extend(rf_daily[ts:ts + len(s)])
        a_d.extend(dates[ts:ts + len(s)])

        del models
        gc.collect()

    return a_s, a_b, a_a, a_r, a_d


def main():
    NUM_SEEDS = 5
    seeds = [42 + i * 100 for i in range(NUM_SEEDS)]

    P("=" * 80)
    P("OVERFITTING DIAGNOSTIC — V13-era vs V22 per-year")
    P("=" * 80)
    P(f"  Seeds: {NUM_SEEDS}")
    P(f"  V13-era: K=30 fixed, Bag40, colsample=0.7, no emergency")
    P(f"  V22:     K=50/30/15 regime, Bag80, colsample=0.5, emergency 8%")
    P("")

    start = datetime.now()

    P("Loading data...")
    prices, daily_ret, returns, vols, df = load_data()
    dates = df['date'].values
    n = len(prices)
    P(f"  {n} days | {dates[0]} to {dates[-1]}")

    # CDI
    try:
        from src.features.macro.cdi_rates import build_rf_daily
        rf_daily = build_rf_daily(dates, source='auto')
    except Exception:
        from src.features.macro.cdi_rates import build_rf_daily
        rf_daily = build_rf_daily(dates, source='copom')

    import archive.old_pipelines.pipeline_v09 as v9m
    import archive.old_pipelines.pipeline_v13 as v13m
    v9m.RF_DAILY_ARR = rf_daily
    v13m.RF_DAILY_ARR = rf_daily

    # Features (same 37 for both configs — isolate allocation logic)
    fc = FEATURES_37 + [f for f in EXTRA_FEATURES if f not in FEATURES_37]
    fc = [f for f in fc if f in df.columns]
    P(f"  {len(fc)} features")

    X_all, _ = build_ml_features(df, returns, vols, n, feature_cols=fc)

    target = np.zeros(n)
    for i in range(n - 3):
        target[i] = (prices[i + 3] - prices[i]) / prices[i]

    dow = pd.to_datetime(dates).dayofweek
    periods = _get_retrain_periods(dates, n, 'semi')
    sma50 = pd.Series(prices).rolling(50).mean().values
    sma200 = pd.Series(prices).rolling(200).mean().values

    P("")
    configs = [CONFIG_V13, CONFIG_V22]

    all_results = {}

    for config in configs:
        name = config['name']
        P(f"{'='*60}")
        P(f"  Running {name}...")
        P(f"{'='*60}")

        yearly_per_seed = []

        for si, seed in enumerate(seeds):
            P(f"  Seed {seed} ({si+1}/{NUM_SEEDS})...")
            a_s, a_b, a_a, a_r, a_d = run_config(
                config, X_all, target, prices, daily_ret, dates,
                periods, dow, sma50, sma200, rf_daily, n, seed)

            yr_metrics = metrics_by_year(a_s, a_b, a_a, a_r, a_d)
            yearly_per_seed.append(yr_metrics)

            total = yr_metrics['TOTAL']
            P(f"    Sortino={total['sortino']:.2f}  "
              f"Return={total['return']*100:+.0f}%  "
              f"MaxDD={total['max_dd']*100:.1f}%")

        # Aggregate across seeds
        all_years = set()
        for ym in yearly_per_seed:
            all_years.update(ym.keys())

        agg = {}
        for yr in sorted(all_years):
            vals = [ym[yr] for ym in yearly_per_seed if yr in ym and ym[yr] is not None]
            if not vals:
                continue
            agg[yr] = {
                'return_avg': np.mean([v['return'] for v in vals]),
                'return_std': np.std([v['return'] for v in vals]),
                'sortino_avg': np.mean([v['sortino'] for v in vals]),
                'sortino_std': np.std([v['sortino'] for v in vals]),
                'sharpe_avg': np.mean([v['sharpe'] for v in vals]),
                'max_dd_avg': np.mean([v['max_dd'] for v in vals]),
                'btc_avg': np.mean([v['btc'] for v in vals]),
                'excess_avg': np.mean([v['excess'] for v in vals]),
                'n_days': vals[0]['n_days'],
            }

        all_results[name] = agg

    # ═══════════════════════════════════════════════════════════════
    # PRINT COMPARISON
    # ═══════════════════════════════════════════════════════════════
    elapsed = (datetime.now() - start).total_seconds() / 60

    P("")
    P("=" * 90)
    P(f"OVERFITTING DIAGNOSTIC RESULTS — {NUM_SEEDS} seeds ({elapsed:.0f} min)")
    P("=" * 90)

    years = sorted([y for y in all_results['V22'].keys() if y != 'TOTAL'])

    # Header
    P("")
    P(f"{'Year':<8} | {'V13-era':^35} | {'V22':^35} | {'Winner':^8}")
    P(f"{'':8} | {'Return':>8} {'Sortino':>8} {'MaxDD':>7} {'Sharpe':>7} "
      f"| {'Return':>8} {'Sortino':>8} {'MaxDD':>7} {'Sharpe':>7} |")
    P("-" * 90)

    for yr in years + ['TOTAL']:
        v13 = all_results['V13-era'].get(yr)
        v22 = all_results['V22'].get(yr)
        if not v13 or not v22:
            continue

        winner = 'V22' if v22['sortino_avg'] > v13['sortino_avg'] else 'V13'

        label = yr if yr != 'TOTAL' else 'TOTAL'
        P(f"{label:<8} | "
          f"{v13['return_avg']*100:+7.1f}% {v13['sortino_avg']:7.2f} "
          f"{v13['max_dd_avg']*100:6.1f}% {v13['sharpe_avg']:6.2f} | "
          f"{v22['return_avg']*100:+7.1f}% {v22['sortino_avg']:7.2f} "
          f"{v22['max_dd_avg']*100:6.1f}% {v22['sharpe_avg']:6.2f} | "
          f"  {winner}")

    P("")
    P("BTC Buy & Hold per year:")
    for yr in years:
        v22 = all_results['V22'].get(yr)
        if v22:
            P(f"  {yr}: BTC {v22['btc_avg']*100:+.1f}%")

    P("")
    P("INTERPRETATION:")
    P("  If V22 wins in ALL years (especially 2025-2026) → improvements are genuine")
    P("  If V22 only wins in 2022-2024 → sequential overfitting on early OOS data")
    P("")

    # Check specifically 2025-2026
    late_years = [y for y in ['2025', '2026'] if y in all_results['V22']]
    v22_wins_late = 0
    for yr in late_years:
        v13 = all_results['V13-era'].get(yr)
        v22 = all_results['V22'].get(yr)
        if v13 and v22 and v22['sortino_avg'] > v13['sortino_avg']:
            v22_wins_late += 1

    if late_years:
        P(f"  V22 wins in {v22_wins_late}/{len(late_years)} late-period years (2025-2026)")
        if v22_wins_late == len(late_years):
            P("  >> PASS: Improvements generalize to unseen-ish period")
        elif v22_wins_late == 0:
            P("  >> FAIL: Improvements only helped early OOS years — likely overfitting")
        else:
            P("  >> MIXED: Partial generalization")

    # Save
    output = {
        'diagnostic': 'overfitting_sequential',
        'timestamp': datetime.now().isoformat(),
        'elapsed_min': elapsed,
        'n_seeds': NUM_SEEDS,
        'configs': {
            'V13-era': 'K=30 fixed, Bag40, colsample=0.7, no emergency, semi retrain',
            'V22': 'K=50/30/15 regime, Bag80, colsample=0.5, emergency 8%, semi retrain',
        },
        'results': {k: {yr: convert_numpy(v) for yr, v in d.items()}
                    for k, d in all_results.items()},
    }

    out_path = ROOT / 'outputs' / 'results' / 'overfitting_diagnostic.json'
    with open(out_path, 'w') as f:
        json.dump(output, f, indent=2, default=convert_numpy)
    P(f"Saved: {out_path}")


if __name__ == '__main__':
    main()
