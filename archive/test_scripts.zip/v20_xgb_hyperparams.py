"""V20 XGBoost Hyperparameter Search.
Tests key hyperparameter variations vs baseline.
Phase 1: 3 seeds screening. Phase 2: top 3 with 10 seeds.
"""
import sys, gc, json, numpy as np, pandas as pd
from pathlib import Path
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
import warnings; warnings.filterwarnings('ignore')
sys.stdout.reconfigure(line_buffering=True)

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

from archive.old_pipelines.pipeline_v09 import (
    load_data, build_ml_features, backtest_allocations,
    metrics, COST, P, convert_numpy,
)
from archive.old_pipelines.pipeline_v10 import MODELS
from archive.old_pipelines.pipeline_v11 import DEFAULT_XGB_PARAMS
from archive.old_pipelines.pipeline_v13 import _get_retrain_periods, _train_one_xgb

W = 16
BAGS = 80

prices, daily_ret, returns, vols, df = load_data()
dates = df['date'].values; n = len(prices)

try:
    from src.features.macro.cdi_rates import build_rf_daily
    RF_DAILY_ARR = build_rf_daily(dates, source='auto')
except Exception:
    from src.features.macro.cdi_rates import build_rf_daily
    RF_DAILY_ARR = build_rf_daily(dates, source='copom')

import archive.old_pipelines.pipeline_v09 as v9m
import archive.old_pipelines.pipeline_v13 as v13m
v9m.RF_DAILY_ARR = RF_DAILY_ARR; v13m.RF_DAILY_ARR = RF_DAILY_ARR

base = [f for f in MODELS['37feat'] if f != 'exchange_netflow_ma7'] + ['basis_pct']
extra = ['fed_balance_sheet', 'futures_trade_count', 'vol_x_regime_duration',
         'velocity', 'hash_rate_pctchg_30d']
fc = base + [f for f in extra if f not in base]
fc = [f for f in fc if f in df.columns]

X_all, _ = build_ml_features(df, returns, vols, n, feature_cols=fc)
target = np.zeros(n)
for i in range(n - 3):
    target[i] = (prices[i + 3] - prices[i]) / prices[i]

dow = pd.to_datetime(dates).dayofweek
periods = _get_retrain_periods(dates, n, 'semi')

# Regime
sma50 = pd.Series(prices).rolling(50).mean().values
sma200 = pd.Series(prices).rolling(200).mean().values


def get_regime(t):
    if np.isnan(sma50[t]) or np.isnan(sma200[t]):
        return 'MILD'
    if prices[t] > sma50[t] and sma50[t] > sma200[t]:
        return 'BULL'
    elif prices[t] > sma200[t]:
        return 'MILD'
    return 'BEAR'


def alloc_baseline(pred, regime):
    K = {'BULL': 50, 'MILD': 30, 'BEAR': 15}[regime]
    return np.clip(pred * K, -0.25, 1.0)


# ─── HYPERPARAMETER CONFIGS ───
# Baseline
BASE = dict(DEFAULT_XGB_PARAMS)

CONFIGS = {}

# 0) Baseline
CONFIGS['BASELINE'] = dict(BASE)

# 1) Vary learning_rate
for lr in [0.005, 0.01, 0.02, 0.03, 0.08, 0.1, 0.15]:
    c = dict(BASE)
    c['learning_rate'] = lr
    CONFIGS[f'lr={lr}'] = c

# 2) Vary n_estimators
for ne in [50, 100, 300, 400, 600]:
    c = dict(BASE)
    c['n_estimators'] = ne
    CONFIGS[f'n_est={ne}'] = c

# 3) Vary max_leaves
for ml in [7, 15, 63, 127]:
    c = dict(BASE)
    c['max_leaves'] = ml
    CONFIGS[f'leaves={ml}'] = c

# 4) Vary min_child_weight
for mcw in [3, 5, 8, 20, 30, 50]:
    c = dict(BASE)
    c['min_child_weight'] = mcw
    CONFIGS[f'mcw={mcw}'] = c

# 5) Vary colsample_bytree
for cs in [0.3, 0.5, 0.9, 1.0]:
    c = dict(BASE)
    c['colsample_bytree'] = cs
    CONFIGS[f'colsamp={cs}'] = c

# 6) Vary subsample
for ss in [0.5, 0.6, 0.7, 1.0]:
    c = dict(BASE)
    c['subsample'] = ss
    CONFIGS[f'subsamp={ss}'] = c

# 7) Promising combos
# Slower learning + more trees
c = dict(BASE); c['learning_rate'] = 0.02; c['n_estimators'] = 400
CONFIGS['lr02_n400'] = c

c = dict(BASE); c['learning_rate'] = 0.01; c['n_estimators'] = 600
CONFIGS['lr01_n600'] = c

c = dict(BASE); c['learning_rate'] = 0.03; c['n_estimators'] = 300
CONFIGS['lr03_n300'] = c

# Deeper trees
c = dict(BASE); c['max_leaves'] = 63; c['min_child_weight'] = 20
CONFIGS['deep_reg'] = c

# Shallower + more regularized
c = dict(BASE); c['max_leaves'] = 15; c['min_child_weight'] = 20; c['colsample_bytree'] = 0.5
CONFIGS['shallow_reg'] = c

# More regularized overall
c = dict(BASE); c['colsample_bytree'] = 0.5; c['subsample'] = 0.6; c['min_child_weight'] = 20
CONFIGS['heavy_reg'] = c

# Less regularized
c = dict(BASE); c['colsample_bytree'] = 0.9; c['subsample'] = 1.0; c['min_child_weight'] = 5
CONFIGS['light_reg'] = c

# 8) Add max_depth as alternative to max_leaves
for md in [3, 4, 5, 6, 8]:
    c = dict(BASE)
    del c['max_leaves']
    del c['grow_policy']
    c['max_depth'] = md
    CONFIGS[f'depth={md}'] = c

# 9) Add reg_alpha / reg_lambda
for alpha in [0.1, 1.0, 5.0]:
    c = dict(BASE); c['reg_alpha'] = alpha
    CONFIGS[f'alpha={alpha}'] = c

for lam in [0.5, 2.0, 5.0, 10.0]:
    c = dict(BASE); c['reg_lambda'] = lam
    CONFIGS[f'lambda={lam}'] = c

P("=" * 80)
P(f"V20 XGB HYPERPARAMETER SEARCH — {len(CONFIGS)} configs")
P("=" * 80)
P(f"  {n} days | {len(fc)} features | Bag{BAGS}")
P(f"  Phase 1: 3 seeds screening")
P(f"  Baseline: lr=0.05, n=200, leaves=31, mcw=12, col=0.7, sub=0.8")
P("")

# ─── PHASE 1: 3 seeds ───
SEEDS_P1 = [42, 142, 242]
start = datetime.now()

results_p1 = {}

for ci, (config_name, xgb_p) in enumerate(CONFIGS.items()):
    P(f"  [{ci+1}/{len(CONFIGS)}] {config_name}...")
    seed_metrics = []

    for seed in SEEDS_P1:
        full_allocs = np.full(n, 0.0)
        prev = 0.0
        a_s, a_b, a_a, a_r = [], [], [], []

        for te, ts, tend in periods:
            gap = 5
            tm = np.arange(60, te - gap + 1)
            v = ~np.any(np.isnan(X_all[tm]), axis=1)
            idx = tm[v]
            if len(idx) < 100:
                continue
            Xt, yt = np.nan_to_num(X_all[idx], nan=0.0), target[idx]
            bag_seeds = [seed + i * 7 for i in range(BAGS)]
            with ThreadPoolExecutor(max_workers=W) as ex:
                models = list(ex.map(_train_one_xgb,
                    [(s, Xt, yt, xgb_p) for s in bag_seeds]))

            for t in range(ts, tend + 1):
                is_rebal = dow[t] == 4
                is_emerg = t > 0 and abs(daily_ret[t]) > 0.08
                if not is_rebal and not is_emerg:
                    full_allocs[t] = prev
                    continue
                x_t = np.nan_to_num(X_all[t:t + 1].copy(), nan=0.0)
                avg = float(np.mean([m.predict(x_t)[0] for m in models]))
                regime = get_regime(t)
                full_allocs[t] = alloc_baseline(avg, regime)
                prev = full_allocs[t]

            s, b, a = backtest_allocations(daily_ret, full_allocs, ts, tend,
                                           cost=COST, rf_daily=RF_DAILY_ARR)
            a_s.extend(s); a_b.extend(b); a_a.extend(a)
            a_r.extend(RF_DAILY_ARR[ts:ts + len(s)])
            del models
            gc.collect()

        m = metrics(np.array(a_s), np.array(a_b), np.array(a_a),
                     rf_daily=np.array(a_r))
        seed_metrics.append(m)

    avg_sortino = np.mean([m['sortino'] for m in seed_metrics])
    avg_ret = np.mean([m['total'] for m in seed_metrics])
    avg_dd = np.mean([m['max_dd'] for m in seed_metrics])
    results_p1[config_name] = {
        'sortino': avg_sortino,
        'return': avg_ret * 100,
        'max_dd': avg_dd * 100,
        'seeds': seed_metrics,
        'params': {k: v for k, v in xgb_p.items()
                   if k not in ['objective', 'verbosity', 'nthread', 'tree_method']},
    }
    P(f"         S={avg_sortino:.2f}  Ret={avg_ret*100:+.0f}%  DD={avg_dd*100:.1f}%")
    gc.collect()

elapsed_p1 = (datetime.now() - start).total_seconds() / 60

# Sort by sortino
ranked = sorted(results_p1.items(), key=lambda x: x[1]['sortino'], reverse=True)

P("")
P("=" * 80)
P(f"PHASE 1 RESULTS — {len(CONFIGS)} configs x 3 seeds ({elapsed_p1:.0f} min)")
P("=" * 80)
P(f"  {'#':>3} {'Config':<25} {'Sortino':>8} {'Return':>10} {'MaxDD':>8} {'Key params'}")
P(f"  {'-' * 85}")

for i, (name, r) in enumerate(ranked):
    params_str = ', '.join(f'{k}={v}' for k, v in r['params'].items()
                           if k in ['learning_rate', 'n_estimators', 'max_leaves',
                                    'min_child_weight', 'colsample_bytree', 'subsample',
                                    'max_depth', 'reg_alpha', 'reg_lambda'])
    marker = ' ***' if name == 'BASELINE' else ''
    P(f"  {i+1:>3} {name:<25} {r['sortino']:>8.2f} {r['return']:>+9.0f}% {r['max_dd']:>7.1f}%  {params_str}{marker}")

# ─── PHASE 2: top 5 with 10 seeds ───
P("")
P("=" * 80)
P("PHASE 2 — TOP 5 x 10 SEEDS")
P("=" * 80)

top5_names = [name for name, _ in ranked[:5]]
# Always include baseline
if 'BASELINE' not in top5_names:
    top5_names.append('BASELINE')

SEEDS_P2 = [42 + i * 100 for i in range(10)]
start2 = datetime.now()

results_p2 = {}

for ci, config_name in enumerate(top5_names):
    xgb_p = CONFIGS[config_name]
    P(f"  [{ci+1}/{len(top5_names)}] {config_name} x 10 seeds...")
    seed_metrics = []

    for si, seed in enumerate(SEEDS_P2):
        full_allocs = np.full(n, 0.0)
        prev = 0.0
        a_s, a_b, a_a, a_r = [], [], [], []

        for te, ts, tend in periods:
            gap = 5
            tm = np.arange(60, te - gap + 1)
            v = ~np.any(np.isnan(X_all[tm]), axis=1)
            idx = tm[v]
            if len(idx) < 100:
                continue
            Xt, yt = np.nan_to_num(X_all[idx], nan=0.0), target[idx]
            bag_seeds = [seed + i * 7 for i in range(BAGS)]
            with ThreadPoolExecutor(max_workers=W) as ex:
                models = list(ex.map(_train_one_xgb,
                    [(s, Xt, yt, xgb_p) for s in bag_seeds]))

            for t in range(ts, tend + 1):
                is_rebal = dow[t] == 4
                is_emerg = t > 0 and abs(daily_ret[t]) > 0.08
                if not is_rebal and not is_emerg:
                    full_allocs[t] = prev
                    continue
                x_t = np.nan_to_num(X_all[t:t + 1].copy(), nan=0.0)
                avg = float(np.mean([m.predict(x_t)[0] for m in models]))
                regime = get_regime(t)
                full_allocs[t] = alloc_baseline(avg, regime)
                prev = full_allocs[t]

            s, b, a = backtest_allocations(daily_ret, full_allocs, ts, tend,
                                           cost=COST, rf_daily=RF_DAILY_ARR)
            a_s.extend(s); a_b.extend(b); a_a.extend(a)
            a_r.extend(RF_DAILY_ARR[ts:ts + len(s)])
            del models
            gc.collect()

        m = metrics(np.array(a_s), np.array(a_b), np.array(a_a),
                     rf_daily=np.array(a_r))
        seed_metrics.append(m)

    sortinos = [m['sortino'] for m in seed_metrics]
    rets = [m['total'] * 100 for m in seed_metrics]
    dds = [m['max_dd'] * 100 for m in seed_metrics]
    results_p2[config_name] = {
        'sortino_avg': np.mean(sortinos),
        'sortino_std': np.std(sortinos),
        'return_avg': np.mean(rets),
        'return_std': np.std(rets),
        'dd_avg': np.mean(dds),
        'dd_std': np.std(dds),
        'sortinos': sortinos,
        'params': results_p1[config_name]['params'],
    }
    P(f"         S={np.mean(sortinos):.2f}+/-{np.std(sortinos):.2f}  "
      f"Ret={np.mean(rets):+.0f}%+/-{np.std(rets):.0f}%  "
      f"DD={np.mean(dds):.1f}%+/-{np.std(dds):.1f}%")
    gc.collect()

elapsed_p2 = (datetime.now() - start2).total_seconds() / 60

P("")
P("=" * 80)
P(f"PHASE 2 RESULTS — TOP {len(top5_names)} x 10 seeds ({elapsed_p2:.0f} min)")
P("=" * 80)
P(f"  {'Config':<25} {'Sortino':>8} {'std':>5} {'Return':>10} {'std':>6} {'MaxDD':>8} {'std':>5}")
P(f"  {'-' * 70}")

p2_ranked = sorted(results_p2.items(), key=lambda x: x[1]['sortino_avg'], reverse=True)
for name, r in p2_ranked:
    marker = ' ***' if name == 'BASELINE' else ''
    P(f"  {name:<25} {r['sortino_avg']:>8.2f} {r['sortino_std']:>5.2f}"
      f"  {r['return_avg']:>+8.0f}% {r['return_std']:>5.0f}%"
      f"  {r['dd_avg']:>7.1f}% {r['dd_std']:>4.1f}%{marker}")

# Seed-by-seed: best vs baseline
best_name = p2_ranked[0][0]
if best_name != 'BASELINE' and 'BASELINE' in results_p2:
    P("")
    P(f"SEED-BY-SEED: {best_name} vs BASELINE")
    P(f"  {'Seed':>6} {'Best':>8} {'BASE':>8} {'Winner':>8}")
    wins_best, wins_base = 0, 0
    for i, seed in enumerate(SEEDS_P2):
        sb = results_p2[best_name]['sortinos'][i]
        sbl = results_p2['BASELINE']['sortinos'][i]
        w = best_name[:8] if sb > sbl else 'BASE'
        if sb > sbl: wins_best += 1
        else: wins_base += 1
        P(f"  {seed:>6} {sb:>8.2f} {sbl:>8.2f} {w:>8}")
    P(f"  {best_name}: {wins_best}/10 | BASELINE: {wins_base}/10")

total_elapsed = (datetime.now() - start).total_seconds() / 60
P(f"\n  Total elapsed: {total_elapsed:.0f} min")

# Save results
out = {
    'phase1': {k: {kk: vv for kk, vv in v.items() if kk != 'seeds'}
               for k, v in results_p1.items()},
    'phase2': {k: {kk: vv for kk, vv in v.items()}
               for k, v in results_p2.items()},
    'ranking_p1': [name for name, _ in ranked],
}
out_path = ROOT / 'outputs' / 'results' / 'v20_xgb_hyperparams.json'
with open(out_path, 'w') as f:
    json.dump(out, f, indent=2, default=convert_numpy)
P(f"  Saved: {out_path}")
