"""
Compare V22 Model vs BTC Trend Following (from BQ)
Period: Oct 2025 to today. Business days only.
"""
import sys, gc, numpy as np, pandas as pd
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

from archive.old_pipelines.pipeline_v09 import load_data, build_ml_features
from archive.old_pipelines.pipeline_v10 import MODELS
from archive.old_pipelines.pipeline_v13 import _get_retrain_periods, _train_one_xgb
from scripts.production.config import K_REGIME, XGB_PARAMS, BAGS, EMERGENCY_THRESHOLD

print("Loading data...")
prices, daily_ret, returns, vols, df = load_data()
dates = df['date'].values
n = len(prices)

try:
    from src.features.macro.cdi_rates import build_rf_daily
    rf_daily = build_rf_daily(dates, source='auto')
except:
    from src.features.macro.cdi_rates import build_rf_daily
    rf_daily = build_rf_daily(dates, source='copom')

import archive.old_pipelines.pipeline_v09 as v9m
import archive.old_pipelines.pipeline_v13 as v13m
v9m.RF_DAILY_ARR = rf_daily
v13m.RF_DAILY_ARR = rf_daily

fc = [f for f in MODELS['37feat'] if f != 'exchange_netflow_ma7'] + ['basis_pct'] + [
    'fed_balance_sheet', 'futures_trade_count', 'vol_x_regime_duration', 'velocity', 'hash_rate_pctchg_30d']
fc = [f for f in fc if f in df.columns]
X_all, _ = build_ml_features(df, returns, vols, n, feature_cols=fc)

target = np.zeros(n)
for i in range(n - 3):
    target[i] = (prices[i + 3] - prices[i]) / prices[i]

sma50 = pd.Series(prices).rolling(50).mean().values
sma200 = pd.Series(prices).rolling(200).mean().values
periods = _get_retrain_periods(dates, n, 'semi')
dow = pd.to_datetime(dates).dayofweek
dt_dates = pd.to_datetime(dates)

# Generate V22 signals
print("Generating V22 signals...")
seed = 242
start_idx = np.where(dt_dates >= '2025-09-01')[0][0]  # start early for warmup

v22_signals = {}
prev_alloc = 0.0

for te, ts, tend in periods:
    gap = 5
    tm = np.arange(60, te - gap + 1)
    valid = ~np.any(np.isnan(X_all[tm]), axis=1)
    idx = tm[valid]
    if len(idx) < 100:
        continue
    Xt = np.nan_to_num(X_all[idx], nan=0.0)
    yt = target[idx]
    bag_seeds = [seed + i * 7 for i in range(BAGS)]
    with ThreadPoolExecutor(max_workers=16) as ex:
        models = list(ex.map(_train_one_xgb, [(s, Xt, yt, XGB_PARAMS) for s in bag_seeds]))

    for t in range(ts, tend + 1):
        is_rebal = dow[t] == 4
        is_emerg = t > 0 and abs(daily_ret[t]) > EMERGENCY_THRESHOLD

        if is_rebal or is_emerg:
            x_t = np.nan_to_num(X_all[t:t + 1], nan=0.0)
            pred = float(np.mean([m.predict(x_t)[0] for m in models]))
            if np.isnan(sma50[t]) or np.isnan(sma200[t]):
                regime = 'MILD'
            elif prices[t] > sma50[t] and sma50[t] > sma200[t]:
                regime = 'BULL'
            elif prices[t] > sma200[t]:
                regime = 'MILD'
            else:
                regime = 'BEAR'
            alloc = float(np.clip(pred * K_REGIME[regime], -0.25, 1.0))
            prev_alloc = alloc
        else:
            alloc = prev_alloc

        date_str = str(dt_dates[t].date())
        v22_signals[date_str] = {
            'alloc': alloc,
            'price': prices[t],
            'daily_ret': daily_ret[t],
            'rf': rf_daily[t],
        }

    del models
    gc.collect()

# Load Trend Following signals from BQ
print("Fetching Trend Following signals from BigQuery...")
import subprocess, json
bq_result = subprocess.run(
    ['bq', 'query', '--format=json', '--max_rows=10000',
     'SELECT reference_date, CAST(asset_weight AS FLOAT64) as weight '
     'FROM `hdx-data-platform-users.team_trading.actively_managed_strategy_signals` '
     'WHERE strategy_name = "BTC_Trend_Following" AND asset_name = "BTC" '
     'AND reference_date >= "2025-10-01" ORDER BY reference_date'],
    capture_output=True, text=True, timeout=60, shell=(sys.platform == 'win32')
)
tf_data = json.loads(bq_result.stdout)
tf = pd.DataFrame(tf_data)
tf['reference_date'] = pd.to_datetime(tf['reference_date']).dt.strftime('%Y-%m-%d')
tf['weight'] = pd.to_numeric(tf['weight'])
print(f"  {len(tf)} signals loaded")

# Brazilian holidays 2025-2026
br_holidays = {
    '2025-10-12', '2025-11-02', '2025-11-15', '2025-11-20', '2025-12-25', '2025-12-31',
    '2026-01-01', '2026-02-16', '2026-02-17', '2026-02-18', '2026-04-03',
    '2026-04-21', '2026-05-01', '2026-06-04', '2026-09-07', '2026-10-12',
    '2026-11-02', '2026-11-15', '2026-11-20', '2026-12-25',
}

# Merge — business days only
results = []
for _, row in tf.iterrows():
    d = row['reference_date']
    dow_d = pd.Timestamp(d).dayofweek
    if dow_d >= 5:  # weekend
        continue
    if d in br_holidays:
        continue
    if d in v22_signals:
        v22 = v22_signals[d]
        results.append({
            'date': d,
            'tf_weight': row['weight'],
            'v22_alloc': v22['alloc'],
            'price': v22['price'],
            'daily_ret': v22['daily_ret'],
            'rf': v22['rf'],
        })

res = pd.DataFrame(results)
print(f"\nPeriod: {res['date'].min()} to {res['date'].max()}")
print(f"Business days: {len(res)}")

# Compute returns
tf_rets, v22_rets, btc_rets, rf_rets = [], [], [], []
for i in range(len(res) - 1):
    br = res.iloc[i + 1]['daily_ret']
    rf = res.iloc[i]['rf']

    a_tf = res.iloc[i]['tf_weight']
    tf_r = a_tf * br + (1 - a_tf) * rf if a_tf >= 0 else a_tf * br + 1.0 * rf
    tf_rets.append(tf_r)

    a_v22 = res.iloc[i]['v22_alloc']
    v22_r = a_v22 * br + (1 - a_v22) * rf if a_v22 >= 0 else a_v22 * br + 1.0 * rf
    v22_rets.append(v22_r)

    btc_rets.append(br)
    rf_rets.append(rf)

tf_arr = np.array(tf_rets)
v22_arr = np.array(v22_rets)
btc_arr = np.array(btc_rets)
rf_arr = np.array(rf_rets)

# Metrics
def calc_sortino(rets, rf):
    ex = rets - rf[:len(rets)]
    ds = np.minimum(ex, 0)
    dd = np.sqrt(np.mean(ds ** 2))
    return np.mean(ex) / (dd + 1e-10) * np.sqrt(252)

def calc_sharpe(rets, rf):
    ex = rets - rf[:len(rets)]
    return np.mean(ex) / (np.std(rets) + 1e-10) * np.sqrt(252)

def calc_maxdd(rets):
    cum = np.cumprod(1 + rets)
    pk = np.maximum.accumulate(cum)
    return np.min((cum - pk) / (pk + 1e-10))

tf_cum = (np.prod(1 + tf_arr) - 1) * 100
v22_cum = (np.prod(1 + v22_arr) - 1) * 100
btc_cum = (np.prod(1 + btc_arr) - 1) * 100

print()
print("=" * 75)
print(f"  V22 MODEL vs BTC TREND FOLLOWING ({res['date'].min()} to {res['date'].max()})")
print("=" * 75)
print()
print(f"  {'Metric':<20} {'Trend Following':>18} {'V22 Model':>18} {'BTC B&H':>18}")
print(f"  {'---':<20} {'---':>18} {'---':>18} {'---':>18}")
print(f"  {'Return':<20} {tf_cum:>+17.1f}% {v22_cum:>+17.1f}% {btc_cum:>+17.1f}%")
print(f"  {'Sortino':<20} {calc_sortino(tf_arr, rf_arr):>18.2f} {calc_sortino(v22_arr, rf_arr):>18.2f} {calc_sortino(btc_arr, rf_arr):>18.2f}")
print(f"  {'Sharpe':<20} {calc_sharpe(tf_arr, rf_arr):>18.2f} {calc_sharpe(v22_arr, rf_arr):>18.2f} {calc_sharpe(btc_arr, rf_arr):>18.2f}")
print(f"  {'MaxDD':<20} {calc_maxdd(tf_arr)*100:>17.1f}% {calc_maxdd(v22_arr)*100:>17.1f}% {calc_maxdd(btc_arr)*100:>17.1f}%")
print(f"  {'Avg Alloc':<20} {res['tf_weight'].mean()*100:>17.1f}% {res['v22_alloc'].mean()*100:>17.1f}%")
print()

# Monthly breakdown
res_df = pd.DataFrame({
    'date': pd.to_datetime(res['date'].values[:-1]),
    'tf': tf_arr, 'v22': v22_arr, 'btc': btc_arr
})
res_df['month'] = res_df['date'].dt.to_period('M')
monthly = res_df.groupby('month').agg(
    tf_ret=('tf', lambda x: (np.prod(1 + x) - 1) * 100),
    v22_ret=('v22', lambda x: (np.prod(1 + x) - 1) * 100),
    btc_ret=('btc', lambda x: (np.prod(1 + x) - 1) * 100),
    days=('tf', 'count'),
).reset_index()

print(f"  Monthly breakdown:")
print(f"  {'Month':>10} {'TF':>8} {'V22':>8} {'BTC':>8} {'V22-TF':>8} {'Days':>5}")
print(f"  {'---':>10} {'---':>8} {'---':>8} {'---':>8} {'---':>8} {'---':>5}")
v22_wins = 0
for _, row in monthly.iterrows():
    diff = row['v22_ret'] - row['tf_ret']
    marker = " *" if diff > 0 else ""
    if diff > 0:
        v22_wins += 1
    print(f"  {str(row['month']):>10} {row['tf_ret']:>+7.1f}% {row['v22_ret']:>+7.1f}% {row['btc_ret']:>+7.1f}% {diff:>+7.1f}%{marker} {row['days']:>5}")

print(f"\n  V22 wins: {v22_wins}/{len(monthly)} months")
print("=" * 75)
