"""V31 extras: 3 combos to validate with V23 pipeline (sigmoid+classifier).

Running after v31_v23_pipeline.py (the main battery).

Tests (3 seeds each, pipeline V23):

  V31.A — V29 + sigmoid 15 + mcw=6   (V27 winner for Ret, validate with sigmoid)
  V31.B — V29 + sigmoid 15 + d=0.25 fracdiff (V30 marginal winner)
  V31.C — V25 full features + sigmoid 15 (NO pruning — isolate pruning effect under V23)
"""
import sys, time, json, gc
import numpy as np, pandas as pd
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import xgboost as xgb

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

import archive.old_pipelines.pipeline_v22 as v22
from archive.old_pipelines.pipeline_v09 import build_ml_features, backtest_allocations, COST
from scripts.production.training import _get_retrain_periods, _train_one_xgb
from src.features.macro.cdi_rates import build_rf_daily
import archive.old_pipelines.pipeline_v09 as v9m
import archive.old_pipelines.pipeline_v13 as v13m
from scripts.production.config import FEATURES_37, K_REGIME, BAGS, HORIZON, WORKERS, EMERGENCY_THRESHOLD

DATASET = ROOT / "outputs" / "feature_selection" / "dataset_enhanced.csv"
SEEDS_3 = [42, 142, 242]
RESULTS = ROOT / "outputs" / "results" / "v31_extras.json"
DAY_NAMES = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun']

# V25 full features (pre-V29 pruning)
V25_FULL_FEATURES = [
    'cusum_pos', 'miners_revenue_ratio', 'mr_score_30d', 'adx',
    'cusum_neg', 'structural_break_score', 'macd_histogram',
    'eth_btc_ratio', 'm2_yoy_growth', 'volatility_7d', 'basis_ma7',
    'nupl_ma30', 'hurst_60d', 'eth', 'bb_position', 'eth_pctchg_30d',
    'price_percentile_1y', 'stablecoin_zscore', 'btc_gold_corr_30d',
    'stablecoin_supply_change_30d', 'copper_return_30d', 'ou_theta_60d',
    'fractal_dimension_30d', 'kpss_stat_30d',
    'half_life_60d', 'sortino_30d', 'obv_trend', 'volume_sma20_ratio',
    'aroon_down_30d', 'trend_strength',
    'basis_pct',
    'fed_balance_sheet',
    'vol_x_regime_duration', 'velocity', 'hash_rate_pctchg_30d',
    'price_fracdiff_05', 'fed_fracdiff_05',
]


def load():
    df = pd.read_csv(DATASET)
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)
    prices = df['price_usd'].values
    n = len(prices)
    daily_ret = np.zeros(n)
    for i in range(1, n):
        daily_ret[i] = (prices[i] - prices[i-1]) / prices[i-1]
    returns, vols = {}, {}
    for w in [1, 3, 5, 7, 10, 14, 20, 21, 30, 45, 60]:
        r = np.zeros(n)
        for i in range(w, n):
            r[i] = (prices[i] - prices[i-w]) / prices[i-w]
        returns[w] = r
    for w in [5, 7, 10, 14, 21, 30]:
        vols[w] = pd.Series(daily_ret).rolling(w).std().fillna(0.02).values
    return prices, daily_ret, returns, vols, df


def fractional_diff(series, d=0.5, thres=0.01):
    w = [1.0]; k = 1
    while abs(w[-1]) > thres and k < len(series):
        w.append(-w[-1] * (d - k + 1) / k); k += 1
    w = np.array(w[::-1])
    arr = series.values if hasattr(series, 'values') else np.asarray(series)
    out = np.full(len(arr), np.nan)
    W = len(w)
    for i in range(W - 1, len(arr)):
        window = arr[i - W + 1:i + 1]
        if np.any(np.isnan(window)): continue
        out[i] = (w * window).sum()
    return out


def get_regime(t, prices, sma50, sma200):
    if np.isnan(sma50[t]) or np.isnan(sma200[t]): return 'MILD'
    if prices[t] > sma50[t] and sma50[t] > sma200[t]: return 'BULL'
    elif prices[t] > sma200[t]: return 'MILD'
    return 'BEAR'


def train_classifier_bag(Xt, yt, bag_seeds, xgb_params):
    yt_bin = (yt > 0).astype(int)
    models = []
    for s in bag_seeds:
        rng = np.random.RandomState(s)
        idx = rng.choice(len(Xt), size=len(Xt), replace=True)
        p = dict(xgb_params)
        p.pop('objective', None)
        m = xgb.XGBClassifier(
            n_estimators=p.pop('n_estimators', 200),
            random_state=s, objective='binary:logistic',
            eval_metric='logloss', n_jobs=1,
            **{k:v for k,v in p.items() if k in
               ['max_leaves','colsample_bytree','subsample','learning_rate',
                'min_child_weight','reg_alpha','reg_lambda','grow_policy','tree_method']})
        m.fit(Xt[idx], yt_bin[idx])
        models.append(m)
    return models


def run_v23(seed, X_all, target, prices, daily_ret, dates, periods,
            dow, sma50, sma200, rf_daily, n,
            sigmoid_scale=15, alloc_min=-0.25, alloc_max=1.0,
            use_sigmoid=True, xgb_params=None):
    params = xgb_params if xgb_params is not None else v22.XGB_PARAMS
    full_allocs = np.full(n, 0.0)
    prev_alloc = 0.0
    a_s, a_b, a_a, a_r = [], [], [], []
    all_preds = np.zeros(n)
    all_actuals = target.copy()

    for te, ts, tend in periods:
        gap = max(HORIZON, 5)
        tm = np.arange(60, te - gap + 1)
        valid = ~np.any(np.isnan(X_all[tm]), axis=1)
        idx = tm[valid]
        if len(idx) < 100: continue
        Xt = np.nan_to_num(X_all[idx], nan=0.0)
        yt = target[idx]
        bag_seeds = [seed + i * 7 for i in range(BAGS)]
        with ThreadPoolExecutor(max_workers=WORKERS) as ex:
            reg_models = list(ex.map(_train_one_xgb,
                [(s, Xt, yt, params) for s in bag_seeds]))
        cls_models = train_classifier_bag(Xt, yt, bag_seeds, params) if use_sigmoid else None

        for t in range(ts, tend + 1):
            x_t = np.nan_to_num(X_all[t:t + 1].copy(), nan=0.0)
            prediction = float(np.mean([m.predict(x_t)[0] for m in reg_models]))
            if use_sigmoid and cls_models:
                p_up = float(np.mean([m.predict_proba(x_t)[0, 1] for m in cls_models]))
                conf = abs(p_up - 0.5)
                conf_factor = float(1.0 / (1.0 + np.exp(-conf * sigmoid_scale)))
            else:
                conf_factor = 1.0
            all_preds[t] = prediction * conf_factor

            is_rebal = dow[t] in [4]
            is_emerg = t > 0 and abs(daily_ret[t]) > EMERGENCY_THRESHOLD
            if not is_rebal and not is_emerg:
                full_allocs[t] = prev_alloc; continue
            regime = get_regime(t, prices, sma50, sma200)
            K = K_REGIME[regime]
            raw = prediction * K * conf_factor
            full_allocs[t] = float(np.clip(raw, alloc_min, alloc_max))
            prev_alloc = full_allocs[t]

        s, b, a = backtest_allocations(daily_ret, full_allocs, ts, tend,
                                       cost=COST, rf_daily=rf_daily)
        a_s.extend(s); a_b.extend(b); a_a.extend(a)
        a_r.extend(rf_daily[ts:ts + len(s)])
        del reg_models
        if cls_models: del cls_models
        gc.collect()
    metrics = v22.metrics_v22(np.array(a_s), np.array(a_b), np.array(a_a),
                              rf_daily=np.array(a_r))
    return metrics, all_preds, all_actuals


def accuracy_per_dow(preds, actuals, dow):
    mask = np.abs(preds) > 1e-6
    out = {'all': float((np.sign(preds[mask]) == np.sign(actuals[mask])).mean())}
    for d, name in enumerate(DAY_NAMES):
        dmask = mask & (dow == d)
        if dmask.sum() > 10:
            out[name] = float((np.sign(preds[dmask]) == np.sign(actuals[dmask])).mean())
        else:
            out[name] = None
    return out


def agg(name, outputs, dow, cfg=""):
    sortinos = [o[0]['sortino'] for o in outputs]
    rets     = [o[0]['total']*100 for o in outputs]
    dds      = [o[0]['max_dd']*100 for o in outputs]
    preds_avg = np.mean([o[1] for o in outputs], axis=0)
    actuals = outputs[0][2]
    acc = accuracy_per_dow(preds_avg, actuals, dow)
    result = {
        'name': name, 'config': cfg,
        'sortino_mean': float(np.mean(sortinos)), 'sortino_std': float(np.std(sortinos)),
        'ret_mean': float(np.mean(rets)), 'ret_std': float(np.std(rets)),
        'dd_mean': float(np.mean(dds)), 'dd_std': float(np.std(dds)),
        'acc': acc,
    }
    print(f"{name:<28}  {cfg:<30}  S={result['sortino_mean']:.2f}+/-{result['sortino_std']:.2f}  "
          f"Ret={result['ret_mean']:+.0f}%  DD={result['dd_mean']:.1f}%  Fri={acc.get('Fri', 0)*100:.1f}%")
    return result


def main():
    t0 = time.time()
    print("=" * 100)
    print("V31 EXTRAS -- 3 combos with V23 pipeline")
    print("=" * 100)

    prices, daily_ret, returns, vols, df = load()
    dates = df['date'].values
    n = len(prices)
    rf_daily = build_rf_daily(dates, source='auto')
    v9m.RF_DAILY_ARR = rf_daily
    v13m.RF_DAILY_ARR = rf_daily
    dow = pd.to_datetime(dates).dayofweek.values
    periods = _get_retrain_periods(dates, n, v22.RETRAIN)
    sma50 = pd.Series(prices).rolling(50).mean().values
    sma200 = pd.Series(prices).rolling(200).mean().values

    target = np.zeros(n)
    for i in range(n - HORIZON):
        target[i] = (prices[i + HORIZON] - prices[i]) / prices[i]

    # V29 features (29)
    feats_v29 = list(FEATURES_37)
    X_v29, fnames = build_ml_features(df, returns, vols, n, feature_cols=feats_v29)

    # V29 with fracdiff d=0.25
    log_prices = np.log(prices)
    fed_log = np.log(df['fed_balance_sheet'].replace(0, np.nan).values)
    X_v29_d025 = X_v29.copy()
    if 'price_fracdiff_05' in fnames:
        X_v29_d025[:, fnames.index('price_fracdiff_05')] = fractional_diff(log_prices, d=0.25)
    if 'fed_fracdiff_05' in fnames:
        X_v29_d025[:, fnames.index('fed_fracdiff_05')] = fractional_diff(fed_log, d=0.25)

    # V25 full features (37)
    feats_v25 = V25_FULL_FEATURES
    X_v25, _ = build_ml_features(df, returns, vols, n, feature_cols=feats_v25)

    results = []
    def save():
        RESULTS.parent.mkdir(parents=True, exist_ok=True)
        with open(RESULTS, 'w') as f:
            json.dump({'results': results, 'elapsed_min': (time.time()-t0)/60}, f, indent=2)

    # V31.A: V29 + sigmoid + mcw=6
    t1 = time.time()
    print("\n-- V31.A: V29 + sigmoid 15 + mcw=6 --")
    p = dict(v22.XGB_PARAMS); p['min_child_weight'] = 6
    outs = [run_v23(s, X_v29, target, prices, daily_ret, dates, periods,
                     dow, sma50, sma200, rf_daily, n,
                     sigmoid_scale=15, xgb_params=p) for s in SEEDS_3]
    results.append(agg('V31.A_mcw6', outs, dow, 'V29+s15+mcw=6')); save()
    print(f"  ({(time.time()-t1)/60:.1f}m)")

    # V31.B: V29 + sigmoid + d=0.25
    t1 = time.time()
    print("\n-- V31.B: V29 + sigmoid 15 + fracdiff d=0.25 --")
    outs = [run_v23(s, X_v29_d025, target, prices, daily_ret, dates, periods,
                     dow, sma50, sma200, rf_daily, n, sigmoid_scale=15)
            for s in SEEDS_3]
    results.append(agg('V31.B_d025', outs, dow, 'V29+s15+d=0.25')); save()
    print(f"  ({(time.time()-t1)/60:.1f}m)")

    # V31.C: V25 FULL (no pruning) + sigmoid
    t1 = time.time()
    print("\n-- V31.C: V25 FULL (37 features, no pruning) + sigmoid 15 --")
    outs = [run_v23(s, X_v25, target, prices, daily_ret, dates, periods,
                     dow, sma50, sma200, rf_daily, n, sigmoid_scale=15)
            for s in SEEDS_3]
    results.append(agg('V31.C_v25_full', outs, dow, 'V25 37feat + s15')); save()
    print(f"  ({(time.time()-t1)/60:.1f}m)")

    elapsed = (time.time() - t0) / 60
    print()
    print("=" * 100)
    print(f"V31 EXTRAS TOTAL: {elapsed:.1f} min")
    print("=" * 100)
    print("\nRanked by Sortino:")
    for r in sorted(results, key=lambda x: -x['sortino_mean']):
        acc = r['acc']
        print(f"  {r['name']:<28}  {r['config']:<30}  S={r['sortino_mean']:.2f}+/-{r['sortino_std']:.2f}  "
              f"Ret={r['ret_mean']:+.0f}%  Fri={acc.get('Fri', 0)*100:.1f}%")
    save()


if __name__ == '__main__':
    main()
