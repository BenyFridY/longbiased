"""V33 — Data audit + incremental improvements.

Uses dataset_production.csv (fresh to 2026-04-18) instead of dataset_enhanced.csv (stale 2026-03-03).

Each experiment tested with 3 seeds, V23 pipeline (regressor + classifier + sigmoid 15),
evaluated both globally (2022-2026) and per-year (focus 2026 YTD).

Experiments:
  B1: Drop fractal_dimension_30d (bug), fed_balance_sheet, fed_fracdiff_05
  B2: B1 + add btc_dominance from BQ
  B3: B2 + add daily_active_addresses + daily_transactions from BQ
  B4: B3 + monthly retrain (vs semi-annual current)
"""
import sys, time, json, gc
import numpy as np, pandas as pd
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import xgboost as xgb

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

import archive.old_pipelines.pipeline_v22 as v22
from archive.old_pipelines.pipeline_v09 import build_ml_features, backtest_allocations, COST
from scripts.production.training import _get_retrain_periods
from src.features.macro.cdi_rates import build_rf_daily
import archive.old_pipelines.pipeline_v09 as v9m
import archive.old_pipelines.pipeline_v13 as v13m
from scripts.production.config import FEATURES_37, BAGS, HORIZON, WORKERS, EMERGENCY_THRESHOLD

DATASET = ROOT / "scripts" / "production" / "data" / "dataset_production.csv"
RESULTS = ROOT / "outputs" / "results" / "v33_experiments.json"
SEEDS = [42, 142, 242]
DAY_NAMES = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun']
K_DEFAULT = {'BULL': 60, 'MILD': 30, 'BEAR': 15}


def load_data():
    df = pd.read_csv(DATASET)
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)
    prices = df['price_usd'].values
    n = len(prices)
    daily_ret = np.zeros(n)
    for i in range(1, n):
        daily_ret[i] = (prices[i] - prices[i-1]) / prices[i-1]
    returns, vols = {}, {}
    for w in [1, 3, 5, 7, 10, 14, 20, 21, 30, 45, 60]:
        r = np.zeros(n)
        for i in range(w, n): r[i] = (prices[i] - prices[i-w]) / prices[i-w]
        returns[w] = r
    for w in [5, 7, 10, 14, 21, 30]:
        vols[w] = pd.Series(daily_ret).rolling(w).std().fillna(0.02).values
    return prices, daily_ret, returns, vols, df


def fetch_btc_dominance(min_date, max_date):
    """Fetch btc dominance from BQ."""
    from google.cloud import bigquery
    client = bigquery.Client(project='hdx-data-platform')
    q = f'''
    SELECT reference_date AS date,
           coin_dominance_with_stablecoins AS btc_dominance,
           coin_dominance_without_stablecoins AS btc_dom_wo_stable
    FROM `hdx-data-platform.refined.messari_total_marketcap_and_coin_dominance`
    WHERE symbol='BTC' AND reference_date BETWEEN '{min_date}' AND '{max_date}'
    ORDER BY reference_date
    '''
    df = client.query(q).to_dataframe()
    df['date'] = pd.to_datetime(df['date'])
    df = df.drop_duplicates('date').sort_values('date').reset_index(drop=True)
    df['btc_dominance'] = df['btc_dominance'].astype(float)
    df['btc_dom_wo_stable'] = df['btc_dom_wo_stable'].astype(float)
    return df


def fetch_network_activity(min_date, max_date):
    """Fetch daily active addresses + transactions from BQ."""
    from google.cloud import bigquery
    client = bigquery.Client(project='hdx-data-platform')
    q = f'''
    SELECT reference_date AS date,
           daily_active_addresses,
           daily_transactions
    FROM `hdx-data-platform.refined.messari_network_activity`
    WHERE symbol='BTC' AND reference_date BETWEEN '{min_date}' AND '{max_date}'
    ORDER BY reference_date
    '''
    df = client.query(q).to_dataframe()
    df['date'] = pd.to_datetime(df['date'])
    df = df.drop_duplicates('date').sort_values('date').reset_index(drop=True)
    return df


def _train_reg(args):
    s, Xt, yt, params = args
    p = dict(params); p.pop('objective', None)
    allowed = {k:v for k,v in p.items() if k in
               ['max_leaves','colsample_bytree','subsample','learning_rate',
                'min_child_weight','reg_alpha','reg_lambda','grow_policy','tree_method']}
    m = xgb.XGBRegressor(n_estimators=p.pop('n_estimators', 200),
                          random_state=s, objective='reg:squarederror',
                          n_jobs=1, verbosity=0, **allowed)
    m.fit(Xt, yt)
    return m


def _train_cls(args):
    s, Xt, yb, params = args
    rng = np.random.RandomState(s)
    idx = rng.choice(len(Xt), size=len(Xt), replace=True)
    p = dict(params); p.pop('objective', None)
    allowed = {k:v for k,v in p.items() if k in
               ['max_leaves','colsample_bytree','subsample','learning_rate',
                'min_child_weight','reg_alpha','reg_lambda','grow_policy','tree_method']}
    m = xgb.XGBClassifier(n_estimators=p.pop('n_estimators', 200),
                           random_state=s, objective='binary:logistic',
                           eval_metric='logloss', n_jobs=1, **allowed)
    m.fit(Xt[idx], yb[idx])
    return m


def get_regime(t, prices, sma50, sma200):
    if np.isnan(sma50[t]) or np.isnan(sma200[t]): return 'MILD'
    if prices[t] > sma50[t] and sma50[t] > sma200[t]: return 'BULL'
    elif prices[t] > sma200[t]: return 'MILD'
    return 'BEAR'


def run_one(seed, X_all, target, prices, daily_ret, dates, periods,
             dow, sma50, sma200, rf_daily, n, alloc_min=0.0, sigmoid_scale=15):
    """V23 pipeline with floor=0 (V31.7 default). Returns (metrics, reg_preds, cls_probs, allocs, strat_ret)."""
    params = v22.XGB_PARAMS
    K = K_DEFAULT
    full_allocs = np.full(n, 0.0)
    prev_alloc = 0.0
    a_s, a_b, a_a, a_r = [], [], [], []
    reg_preds = np.zeros(n)
    cls_probs = np.full(n, 0.5)
    strat_ret = np.zeros(n)

    for te, ts, tend in periods:
        gap = max(HORIZON, 5)
        tm = np.arange(60, te - gap + 1)
        valid = ~np.any(np.isnan(X_all[tm]), axis=1)
        idx = tm[valid]
        if len(idx) < 100: continue
        Xt = np.nan_to_num(X_all[idx], nan=0.0)
        yt = target[idx]

        bag_seeds = [seed + i * 7 for i in range(BAGS)]
        args_r = [(s, Xt, yt, params) for s in bag_seeds]
        with ThreadPoolExecutor(max_workers=WORKERS) as ex:
            reg_models = list(ex.map(_train_reg, args_r))

        yb = (yt > 0).astype(int)
        args_c = [(s, Xt, yb, params) for s in bag_seeds]
        with ThreadPoolExecutor(max_workers=WORKERS) as ex:
            cls_models = list(ex.map(_train_cls, args_c))

        X_test = np.nan_to_num(X_all[ts:tend + 1], nan=0.0)
        rp = np.mean([m.predict(X_test) for m in reg_models], axis=0)
        cp = np.mean([m.predict_proba(X_test)[:, 1] for m in cls_models], axis=0)
        reg_preds[ts:tend + 1] = rp
        cls_probs[ts:tend + 1] = cp

        for t in range(ts, tend + 1):
            prediction = reg_preds[t]
            p_up = cls_probs[t]
            conf = abs(p_up - 0.5)
            conf_factor = float(1.0 / (1.0 + np.exp(-conf * sigmoid_scale)))
            is_rebal = dow[t] in [4]
            is_emerg = t > 0 and abs(daily_ret[t]) > EMERGENCY_THRESHOLD
            if not is_rebal and not is_emerg:
                full_allocs[t] = prev_alloc; continue
            regime = get_regime(t, prices, sma50, sma200)
            Kv = K[regime]
            raw = prediction * Kv * conf_factor
            full_allocs[t] = float(np.clip(raw, alloc_min, 1.0))
            prev_alloc = full_allocs[t]

        s, b, a = backtest_allocations(daily_ret, full_allocs, ts, tend,
                                        cost=COST, rf_daily=rf_daily)
        a_s.extend(s); a_b.extend(b); a_a.extend(a)
        a_r.extend(rf_daily[ts:ts + len(s)])
        for i in range(len(s)):
            strat_ret[ts + i] = s[i]

        del reg_models, cls_models; gc.collect()

    metrics = v22.metrics_v22(np.array(a_s), np.array(a_b), np.array(a_a),
                               rf_daily=np.array(a_r))
    return metrics, reg_preds, cls_probs, full_allocs, strat_ret


def accuracy_per_dow(preds, actuals, dow):
    mask = np.abs(preds) > 1e-6
    out = {'all': float((np.sign(preds[mask]) == np.sign(actuals[mask])).mean()) if mask.sum() else None}
    for d, name in enumerate(DAY_NAMES):
        dmask = mask & (dow == d)
        if dmask.sum() > 10:
            out[name] = float((np.sign(preds[dmask]) == np.sign(actuals[dmask])).mean())
        else:
            out[name] = None
    return out


def yoy_breakdown(strat_ret, daily_ret, preds, target, dates, dow):
    ds = pd.to_datetime(dates)
    years = ds.year.values
    rows = []
    for y in sorted(set(years[years >= 2022])):
        mask = years == y
        strat_y = strat_ret[mask]; bench_y = daily_ret[mask]
        preds_y = preds[mask]; tgt_y = target[mask]; dow_y = dow[mask]
        strat_total = np.prod(1 + strat_y) - 1 if len(strat_y) else 0
        bench_total = np.prod(1 + bench_y) - 1 if len(bench_y) else 0
        pmask = np.abs(preds_y) > 1e-6
        acc_all = (np.sign(preds_y[pmask]) == np.sign(tgt_y[pmask])).mean() if pmask.sum() else None
        fri_mask = pmask & (dow_y == 4)
        acc_fri = (np.sign(preds_y[fri_mask]) == np.sign(tgt_y[fri_mask])).mean() if fri_mask.sum() > 10 else None
        rows.append({
            'year': int(y),
            'strat_ret': float(strat_total * 100),
            'btc_ret': float(bench_total * 100),
            'acc_all': float(acc_all * 100) if acc_all else None,
            'acc_fri': float(acc_fri * 100) if acc_fri else None,
            'days': int(mask.sum()),
        })
    return rows


def run_experiment(name, feature_cols, desc="", df=None, prices=None, daily_ret=None,
                    returns=None, vols=None, dates=None, n=None, rf_daily=None, dow=None,
                    periods=None, sma50=None, sma200=None, target=None):
    """Train+eval 3 seeds, aggregate, return dict."""
    print(f"\n{'='*100}\n[{time.strftime('%H:%M:%S')}] {name}: {desc}\n{'='*100}", flush=True)
    print(f"  Features ({len(feature_cols)}): {feature_cols[:5]}... +{len(feature_cols)-5} more", flush=True)

    X_all, fnames = build_ml_features(df, returns, vols, n, feature_cols=feature_cols)
    print(f"  X shape: {X_all.shape}", flush=True)

    outs = []
    for s in SEEDS:
        t1 = time.time()
        print(f"  seed {s}...", flush=True)
        metrics, rp, cp, allocs, sret = run_one(s, X_all, target, prices, daily_ret,
                                                   dates, periods, dow, sma50, sma200,
                                                   rf_daily, n)
        outs.append((metrics, rp, cp, allocs, sret))
        print(f"    S={metrics['sortino']:.2f} Ret={metrics['total']*100:+.0f}% ({(time.time()-t1)/60:.1f}m)",
              flush=True)

    sortinos = [o[0]['sortino'] for o in outs]
    rets = [o[0]['total']*100 for o in outs]
    dds = [o[0]['max_dd']*100 for o in outs]
    preds_avg = np.mean([o[1] * np.array([1.0 / (1.0 + np.exp(-abs(o[2][i] - 0.5) * 15))
                                            for i in range(n)]) for o in outs], axis=0)
    acc = accuracy_per_dow(preds_avg, target, dow)
    yoy = yoy_breakdown(np.mean([o[4] for o in outs], axis=0), daily_ret,
                         preds_avg, target, dates, dow)

    result = {
        'name': name, 'desc': desc, 'n_features': len(feature_cols),
        'sortino_mean': float(np.mean(sortinos)), 'sortino_std': float(np.std(sortinos)),
        'ret_mean': float(np.mean(rets)), 'dd_mean': float(np.mean(dds)),
        'acc': acc, 'yoy': yoy,
    }
    print(f"\n  SUMMARY {name}: S={result['sortino_mean']:.3f}+/-{result['sortino_std']:.3f}  "
          f"Ret={result['ret_mean']:+.0f}%  DD={result['dd_mean']:.1f}%  Fri={(acc.get('Fri') or 0)*100:.1f}%  all={(acc.get('all') or 0)*100:.2f}%", flush=True)
    print(f"  YoY:", flush=True)
    for row in yoy:
        acc_s = f"{row['acc_all']:.1f}%" if row['acc_all'] else 'n/a'
        print(f"    {row['year']}: ret={row['strat_ret']:+.1f}% btc={row['btc_ret']:+.1f}% acc_all={acc_s}", flush=True)
    return result


def main():
    t0 = time.time()
    print("=" * 100, flush=True)
    print("V33 — Data audit + incremental improvements", flush=True)
    print("  Using fresh dataset_production.csv (2026-04-18)", flush=True)
    print("  Floor=0 (V31.7) baseline, V23 pipeline (reg+cls+sigmoid)", flush=True)
    print("=" * 100, flush=True)

    prices, daily_ret, returns, vols, df = load_data()
    print(f"Data: {len(df)} rows, {df.date.min()} to {df.date.max()}", flush=True)
    dates = df['date'].values
    n = len(prices)
    rf_daily = build_rf_daily(dates, source='auto')
    v9m.RF_DAILY_ARR = rf_daily
    v13m.RF_DAILY_ARR = rf_daily
    dow = pd.to_datetime(dates).dayofweek.values
    periods = _get_retrain_periods(dates, n, v22.RETRAIN)
    sma50 = pd.Series(prices).rolling(50).mean().values
    sma200 = pd.Series(prices).rolling(200).mean().values
    target = np.zeros(n)
    for i in range(n - HORIZON):
        target[i] = (prices[i + HORIZON] - prices[i]) / prices[i]

    results = []
    def save():
        RESULTS.parent.mkdir(parents=True, exist_ok=True)
        with open(RESULTS, 'w') as f:
            json.dump({'results': results, 'elapsed_min': (time.time()-t0)/60}, f, indent=2)

    common = dict(df=df, prices=prices, daily_ret=daily_ret, returns=returns, vols=vols,
                   dates=dates, n=n, rf_daily=rf_daily, dow=dow, periods=periods,
                   sma50=sma50, sma200=sma200, target=target)

    # ===== B0: Baseline (29 features, fresh data) =====
    r = run_experiment('B0_baseline_fresh', list(FEATURES_37),
                        desc='V31.7 equiv (floor=0) on fresh data', **common)
    results.append(r); save()

    # ===== B1: Drop 3 broken/stale features =====
    feats_b1 = [f for f in FEATURES_37 if f not in
                ['fractal_dimension_30d', 'fed_balance_sheet', 'fed_fracdiff_05']]
    r = run_experiment('B1_drop3', feats_b1,
                        desc='Drop fractal_dim (bug), fed_bs, fed_fracdiff', **common)
    results.append(r); save()

    # ===== B2: B1 + btc_dominance =====
    print(f"\n[{time.strftime('%H:%M:%S')}] Fetching btc_dominance from BQ...", flush=True)
    dom = fetch_btc_dominance(df.date.min().strftime('%Y-%m-%d'),
                                df.date.max().strftime('%Y-%m-%d'))
    df_b2 = df.merge(dom, on='date', how='left')
    df_b2['btc_dominance'] = df_b2['btc_dominance'].ffill()
    df_b2['btc_dom_wo_stable'] = df_b2['btc_dom_wo_stable'].ffill()
    print(f"  btc_dominance rows: {dom.shape[0]}, merged NaN: {df_b2['btc_dominance'].isna().sum()}", flush=True)

    feats_b2 = feats_b1 + ['btc_dominance']
    common_b2 = dict(common); common_b2['df'] = df_b2
    r = run_experiment('B2_add_dominance', feats_b2,
                        desc='B1 + btc_dominance', **common_b2)
    results.append(r); save()

    # ===== B3: B2 + network activity =====
    print(f"\n[{time.strftime('%H:%M:%S')}] Fetching network activity from BQ...", flush=True)
    net = fetch_network_activity(df.date.min().strftime('%Y-%m-%d'),
                                   df.date.max().strftime('%Y-%m-%d'))
    df_b3 = df_b2.merge(net, on='date', how='left')
    df_b3['daily_active_addresses'] = df_b3['daily_active_addresses'].ffill()
    df_b3['daily_transactions'] = df_b3['daily_transactions'].ffill()
    # Derive pct changes for stationarity
    df_b3['active_addr_pctchg_30d'] = df_b3['daily_active_addresses'].pct_change(30)
    df_b3['transactions_pctchg_30d'] = df_b3['daily_transactions'].pct_change(30)
    print(f"  network activity rows: {net.shape[0]}", flush=True)

    feats_b3 = feats_b2 + ['active_addr_pctchg_30d', 'transactions_pctchg_30d']
    common_b3 = dict(common); common_b3['df'] = df_b3
    r = run_experiment('B3_add_network', feats_b3,
                        desc='B2 + active_addr + transactions (pctchg 30d)', **common_b3)
    results.append(r); save()

    elapsed = (time.time() - t0) / 60
    print(f"\n{'='*100}\nV33 DONE: {elapsed:.1f} min\n{'='*100}", flush=True)
    print("\nFinal ranking (3 seeds each):", flush=True)
    for r in sorted(results, key=lambda x: -x['sortino_mean']):
        acc_2026 = next((y['acc_all'] for y in r['yoy'] if y['year'] == 2026), None)
        acc_2026_s = f"{acc_2026:.1f}%" if acc_2026 else 'n/a'
        print(f"  {r['name']:<25}  n_feat={r['n_features']:<3} S={r['sortino_mean']:.3f}+/-{r['sortino_std']:.3f}  "
              f"Ret={r['ret_mean']:+.0f}%  DD={r['dd_mean']:.1f}%  "
              f"Fri={(r['acc'].get('Fri') or 0)*100:.1f}%  all={(r['acc'].get('all') or 0)*100:.2f}%  "
              f"2026_acc={acc_2026_s}", flush=True)
    save()


if __name__ == '__main__':
    main()
