"""Apply V25_FINAL to production dataset + compute fracdiff features.

Changes:
  1. YoY fixes in dataset_enhanced.csv (same column names, right math):
     - m2_yoy_growth = (1 + m2_supply_pctchg_90d)^(365/90) - 1  (real YoY approx)
     - fed_bs_yoy_change = fed_balance_sheet.pct_change(252)    (real YoY)
     - m2_3m_growth = m2_supply_pctchg_90d                      (real 3m)

  2. NOT applied: open_interest / futures_trade_count NaN cleaning
     Rationale: V25d test showed that NaN in OI destroys the model (Sortino 1.54).
     Instead, we'll REMOVE those columns from FEATURES_37 in config.py.

  3. Add fracdiff columns:
     - price_fracdiff_05
     - fed_fracdiff_05
"""
import sys
import numpy as np, pandas as pd
from pathlib import Path

ROOT = Path(__file__).parent.parent.parent
DATASET = ROOT / "outputs" / "feature_selection" / "dataset_enhanced.csv"


def fractional_diff(series, d=0.5, thres=0.01):
    """Lopez de Prado fractional differentiation (fixed-window)."""
    w = [1.0]
    k = 1
    while abs(w[-1]) > thres and k < len(series):
        w.append(-w[-1] * (d - k + 1) / k)
        k += 1
    w = np.array(w[::-1])
    arr = series.values
    out = np.full(len(arr), np.nan)
    W = len(w)
    for i in range(W - 1, len(arr)):
        window = arr[i - W + 1:i + 1]
        if np.any(np.isnan(window)):
            continue
        out[i] = (w * window).sum()
    return pd.Series(out, index=series.index)


def main():
    print("Loading dataset_enhanced.csv...")
    df = pd.read_csv(DATASET)
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)
    print(f"  {len(df)} rows, {len(df.columns)} cols")

    # ── YoY fixes (same names, right math) ──
    print("\nApplying YoY fixes (same names):")

    old_m2y = df['m2_yoy_growth'].copy()
    df['m2_yoy_growth'] = (1 + df['m2_supply_pctchg_90d']) ** (365.0/90.0) - 1
    print(f"  m2_yoy_growth:    before mean={old_m2y.mean():.4f}  after mean={df['m2_yoy_growth'].mean():.4f}")

    old_fedy = df['fed_bs_yoy_change'].copy()
    df['fed_bs_yoy_change'] = df['fed_balance_sheet'].pct_change(252)
    print(f"  fed_bs_yoy_change: before mean={old_fedy.mean():.4f}  after mean={df['fed_bs_yoy_change'].mean():.4f}")

    old_m23 = df['m2_3m_growth'].copy()
    df['m2_3m_growth'] = df['m2_supply_pctchg_90d']
    print(f"  m2_3m_growth:     before mean={old_m23.mean():.4f}  after mean={df['m2_3m_growth'].mean():.4f}")

    # ── Fracdiff features (NEW) ──
    print("\nComputing fracdiff (d=0.5):")
    df['price_fracdiff_05'] = fractional_diff(np.log(df['price_usd']), d=0.5)
    df['fed_fracdiff_05'] = fractional_diff(np.log(df['fed_balance_sheet']), d=0.5)
    print(f"  price_fracdiff_05: valid={df['price_fracdiff_05'].notna().sum()}/{len(df)}")
    print(f"  fed_fracdiff_05:   valid={df['fed_fracdiff_05'].notna().sum()}/{len(df)}")

    # Save in place
    df.to_csv(DATASET, index=False)
    print(f"\nSaved: {DATASET}")
    print(f"  {len(df)} rows, {len(df.columns)} cols")


if __name__ == '__main__':
    main()
