"""V20 Robustness — Top 3 configs with 20 seeds."""
import sys, gc, numpy as np, pandas as pd
from pathlib import Path
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
import warnings; warnings.filterwarnings('ignore')
sys.stdout.reconfigure(line_buffering=True)

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

from archive.old_pipelines.pipeline_v09 import (
    load_data, build_ml_features, backtest_allocations,
    metrics, COST, P, convert_numpy,
)
from archive.old_pipelines.pipeline_v10 import MODELS
from archive.old_pipelines.pipeline_v11 import DEFAULT_XGB_PARAMS
from archive.old_pipelines.pipeline_v13 import _get_retrain_periods, _train_one_xgb

W = 16
NUM_SEEDS = 20
SEEDS = [42 + i * 100 for i in range(NUM_SEEDS)]

prices, daily_ret, returns, vols, df = load_data()
dates = df['date'].values; n = len(prices)

try:
    from src.features.macro.cdi_rates import build_rf_daily
    RF_DAILY_ARR = build_rf_daily(dates, source='auto')
except Exception:
    from src.features.macro.cdi_rates import build_rf_daily
    RF_DAILY_ARR = build_rf_daily(dates, source='copom')

import archive.old_pipelines.pipeline_v09 as v9m
import archive.old_pipelines.pipeline_v13 as v13m
v9m.RF_DAILY_ARR = RF_DAILY_ARR; v13m.RF_DAILY_ARR = RF_DAILY_ARR

base = [f for f in MODELS['37feat'] if f != 'exchange_netflow_ma7'] + ['basis_pct']
extra = ['fed_balance_sheet', 'futures_trade_count', 'vol_x_regime_duration',
         'velocity', 'hash_rate_pctchg_30d']
fc = base + [f for f in extra if f not in base]
fc = [f for f in fc if f in df.columns]

X_all, _ = build_ml_features(df, returns, vols, n, feature_cols=fc)
target = np.zeros(n)
for i in range(n - 3):
    target[i] = (prices[i + 3] - prices[i]) / prices[i]

xgb_params = dict(DEFAULT_XGB_PARAMS)
dow = pd.to_datetime(dates).dayofweek
periods = _get_retrain_periods(dates, n, 'semi')

# Precompute regime signals
sma50 = pd.Series(prices).rolling(50).mean().values
sma200 = pd.Series(prices).rolling(200).mean().values
ret30 = np.zeros(n)
ret60 = np.zeros(n)
for i in range(30, n):
    ret30[i] = (prices[i] - prices[i-30]) / prices[i-30]
for i in range(60, n):
    ret60[i] = (prices[i] - prices[i-60]) / prices[i-60]
vol30 = pd.Series(daily_ret).rolling(30).std().fillna(0.03).values
vol_med = pd.Series(vol30).expanding(60).median().fillna(0.03).values
vol_q75 = pd.Series(vol30).expanding(60).quantile(0.75).fillna(0.04).values


def regime_sma50_200(t):
    if np.isnan(sma50[t]) or np.isnan(sma200[t]):
        return 'MILD'
    if prices[t] > sma50[t] and sma50[t] > sma200[t]:
        return 'BULL'
    elif prices[t] > sma200[t]:
        return 'MILD'
    return 'BEAR'


def regime_composite(t):
    v1 = regime_sma50_200(t)
    if t < 60:
        v2, v3 = 'MILD', 'MILD'
    else:
        v2 = 'BULL' if vol30[t] < vol_med[t] else ('BEAR' if vol30[t] > vol_q75[t] else 'MILD')
        v3 = 'BULL' if (ret30[t] > 0 and ret60[t] > 0) else ('BEAR' if (ret30[t] < 0 and ret60[t] < 0) else 'MILD')
    votes = [v1, v2, v3]
    if votes.count('BULL') >= 2:
        return 'BULL'
    elif votes.count('BEAR') >= 2:
        return 'BEAR'
    return 'MILD'


def alloc_baseline(pred, regime):
    K = {'BULL': 50, 'MILD': 30, 'BEAR': 15}[regime]
    return np.clip(pred * K, -0.25, 1.0)


def alloc_winsorize(pred, regime, hist_preds):
    K = {'BULL': 50, 'MILD': 30, 'BEAR': 15}[regime]
    if len(hist_preds) >= 20:
        recent = np.array(hist_preds[-52:])
        mu = np.mean(recent)
        sigma = np.std(recent) + 1e-10
        pred = np.clip(pred, mu - 2 * sigma, mu + 2 * sigma)
    return np.clip(pred * K, -0.25, 1.0)


CONFIGS = {
    'sma50_200|baseline':  (regime_sma50_200, 'baseline'),
    'sma50_200|winsorize': (regime_sma50_200, 'winsorize'),
    'composite|baseline':  (regime_composite, 'baseline'),
}

P("=" * 80)
P(f"V20 ROBUSTNESS — TOP 3 CONFIGS x {NUM_SEEDS} SEEDS")
P("=" * 80)
P(f"  {n} days | {len(fc)} features | {NUM_SEEDS} seeds")
start = datetime.now()

all_results = {k: [] for k in CONFIGS}

for si, seed in enumerate(SEEDS):
    P(f"  Seed {seed} ({si+1}/{NUM_SEEDS})...")

    trained = []
    for te, ts, tend in periods:
        gap = 5
        tm = np.arange(60, te - gap + 1)
        v = ~np.any(np.isnan(X_all[tm]), axis=1)
        idx = tm[v]
        if len(idx) < 100:
            continue
        Xt, yt = np.nan_to_num(X_all[idx], nan=0.0), target[idx]
        bag_seeds = [seed + i * 7 for i in range(80)]
        with ThreadPoolExecutor(max_workers=W) as ex:
            models = list(ex.map(_train_one_xgb, [(s, Xt, yt, xgb_params) for s in bag_seeds]))

        day_preds = {}
        for t in range(ts, tend + 1):
            is_rebal = dow[t] in [4]
            is_emerg = t > 0 and abs(daily_ret[t]) > 0.08
            if not is_rebal and not is_emerg:
                continue
            x_t = np.nan_to_num(X_all[t:t + 1].copy(), nan=0.0)
            avg = float(np.mean([m.predict(x_t)[0] for m in models]))
            day_preds[t] = avg
        trained.append((ts, tend, day_preds))
        del models
        gc.collect()

    for config_name, (regime_fn, formula_name) in CONFIGS.items():
        full_allocs = np.full(n, 0.0)
        prev = 0.0
        hist_preds = []
        a_s, a_b, a_a, a_r = [], [], [], []

        for ts, tend, day_preds in trained:
            for t in range(ts, tend + 1):
                if t not in day_preds:
                    full_allocs[t] = prev
                    continue
                avg = day_preds[t]
                regime = regime_fn(t)
                hist_preds.append(avg)
                if formula_name == 'baseline':
                    full_allocs[t] = alloc_baseline(avg, regime)
                else:
                    full_allocs[t] = alloc_winsorize(avg, regime, hist_preds)
                prev = full_allocs[t]

            s, b, a = backtest_allocations(daily_ret, full_allocs, ts, tend,
                                           cost=COST, rf_daily=RF_DAILY_ARR)
            a_s.extend(s)
            a_b.extend(b)
            a_a.extend(a)
            a_r.extend(RF_DAILY_ARR[ts:ts + len(s)])

        m = metrics(np.array(a_s), np.array(a_b), np.array(a_a), rf_daily=np.array(a_r))
        all_results[config_name].append(m)

    del trained
    gc.collect()

elapsed = (datetime.now() - start).total_seconds() / 60

P("")
P("=" * 80)
P(f"RESULTS — {NUM_SEEDS} SEEDS")
P("=" * 80)
P(f"  {'Config':<28} {'Sortino':>8} {'std':>6} {'Return':>10} {'std':>8} {'MaxDD':>8} {'std':>6}")
P(f"  {'-' * 70}")

for config_name, mlist in all_results.items():
    sortinos = [m['sortino'] for m in mlist]
    rets = [m['total'] * 100 for m in mlist]
    dds = [m['max_dd'] * 100 for m in mlist]
    P(f"  {config_name:<28} {np.mean(sortinos):>8.2f} {np.std(sortinos):>5.2f}"
      f"  {np.mean(rets):>+8.0f}% {np.std(rets):>6.0f}%"
      f"  {np.mean(dds):>7.1f}% {np.std(dds):>5.1f}%")

# Seed-by-seed comparison
P("")
P("=" * 80)
P("SEED-BY-SEED: sma50_200|baseline vs composite|baseline")
P("=" * 80)
P(f"  {'Seed':>6} {'SMA S':>8} {'COMP S':>8} {'Winner':>8}")
P(f"  {'-' * 35}")

sma_wins = 0
comp_wins = 0
for i, seed in enumerate(SEEDS):
    s_sma = all_results['sma50_200|baseline'][i]['sortino']
    s_comp = all_results['composite|baseline'][i]['sortino']
    winner = 'SMA' if s_sma > s_comp else 'COMP'
    if s_sma > s_comp:
        sma_wins += 1
    else:
        comp_wins += 1
    P(f"  {seed:>6} {s_sma:>8.2f} {s_comp:>8.2f} {winner:>8}")

P(f"  {'-' * 35}")
P(f"  SMA wins: {sma_wins}/{NUM_SEEDS} | Composite wins: {comp_wins}/{NUM_SEEDS}")

# Distribution
P("")
P("=" * 80)
P("DISTRIBUTION")
P("=" * 80)
for config_name, mlist in all_results.items():
    sortinos = sorted([m['sortino'] for m in mlist])
    rets = sorted([m['total'] * 100 for m in mlist])
    n5 = NUM_SEEDS // 4
    n50 = NUM_SEEDS // 2
    n75 = 3 * NUM_SEEDS // 4
    P(f"  {config_name}:")
    P(f"    Sortino: min={sortinos[0]:.2f} p25={sortinos[n5]:.2f} "
      f"median={sortinos[n50]:.2f} p75={sortinos[n75]:.2f} max={sortinos[-1]:.2f}")
    P(f"    Return:  min={rets[0]:+.0f}% p25={rets[n5]:+.0f}% "
      f"median={rets[n50]:+.0f}% p75={rets[n75]:+.0f}% max={rets[-1]:+.0f}%")

P(f"\n  Elapsed: {elapsed:.1f} min")
