"""V24 final: combine best insights from V24 sweep.

From V24 sweep:
  - V1 (no OI/FTC)   Sortino 4.68, Ret +1086% — neutral Sortino, best Ret
  - V6 (+fracdiff)   Sortino 5.08, Ret +1065% — best Sortino
  - Remaining best  combine: remove OI/FTC, add fracdiff

Configs tested here:
  V9  = V1 + V6 (no OI/FTC + fracdiff)     — should be best
  V10 = V6 + remove m2 too (cleaner)       — sanity
  V11 = baseline + oi_fracdiff_05 only     — was fracdiff of price only the win?

Validation: 10 seeds on the winning config.
"""
import sys, time
import numpy as np, pandas as pd
from pathlib import Path

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

import archive.old_pipelines.pipeline_v22 as v22
from archive.old_pipelines.pipeline_v09 import build_ml_features
from scripts.production.training import _get_retrain_periods
from src.features.macro.cdi_rates import build_rf_daily
import archive.old_pipelines.pipeline_v09 as v9m
import archive.old_pipelines.pipeline_v13 as v13m

from scripts.production.config import FEATURES_37

DATASET = ROOT / "outputs" / "feature_selection" / "dataset_v24.csv"

# Reuse loader logic
def load_v24():
    df = pd.read_csv(DATASET)
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)
    prices = df['price_usd'].values
    n = len(prices)
    daily_ret = np.zeros(n)
    for i in range(1, n):
        daily_ret[i] = (prices[i] - prices[i-1]) / prices[i-1]
    returns = {}
    for w in [1, 3, 5, 7, 10, 14, 20, 21, 30, 45, 60]:
        r = np.zeros(n)
        for i in range(w, n):
            r[i] = (prices[i] - prices[i-w]) / prices[i-w]
        returns[w] = r
    vols = {}
    for w in [5, 7, 10, 14, 21, 30]:
        vols[w] = pd.Series(daily_ret).rolling(w).std().fillna(0.02).values
    return prices, daily_ret, returns, vols, df


BASELINE = list(FEATURES_37)

SETS = [
    # Phase 1: 3 seeds exploratory combos
    ('V9_combo_1',
     [f for f in BASELINE if f not in ('open_interest','futures_trade_count')]
     + ['price_fracdiff_05', 'fed_fracdiff_05']),
    ('V10_combo_2',
     [f for f in BASELINE if f not in ('open_interest','futures_trade_count','m2_yoy_growth')]
     + ['price_fracdiff_05', 'fed_fracdiff_05']),
    ('V11_price_only',
     BASELINE + ['price_fracdiff_05']),
    ('V12_fed_only',
     BASELINE + ['fed_fracdiff_05']),
]


def run_set(name, feats, seeds, ctx):
    prices, daily_ret, returns, vols, df, dates, n, periods, dow, sma50, sma200, rf_daily = ctx
    missing = [f for f in feats if f not in df.columns]
    if missing:
        print(f"  [{name}] MISSING: {missing}")
        return None
    X_all, _ = build_ml_features(df, returns, vols, n, feature_cols=feats)
    target = np.zeros(n)
    for i in range(n - v22.HORIZON):
        target[i] = (prices[i + v22.HORIZON] - prices[i]) / prices[i]
    metrics = []
    for seed in seeds:
        m = v22.run_single_seed(seed, X_all, target, prices, daily_ret, dates,
                                periods, dow, sma50, sma200, rf_daily, n)
        metrics.append(m)
    return metrics


def summarize(name, mets, n_feats):
    s = np.array([m['sortino'] for m in mets])
    sh = np.array([m['sharpe'] for m in mets])
    r = np.array([m['total']*100 for m in mets])
    dd = np.array([m['max_dd']*100 for m in mets])
    print(f"{name:<22} {n_feats:>6}  "
          f"Sortino {s.mean():.2f}+/-{s.std():.2f}  "
          f"Sharpe {sh.mean():.2f}+/-{sh.std():.2f}  "
          f"Ret {r.mean():+.0f}%+/-{r.std():.0f}%  "
          f"DD {dd.mean():.1f}%+/-{dd.std():.1f}%")
    return (s.mean(), s.std(), r.mean(), r.std(), dd.mean(), dd.std())


def main():
    t0 = time.time()
    print("=" * 80)
    print("V24 FINAL — combining best findings from V24 sweep")
    print("=" * 80)

    prices, daily_ret, returns, vols, df = load_v24()
    dates = df['date'].values
    n = len(prices)
    rf_daily = build_rf_daily(dates, source='auto')
    v9m.RF_DAILY_ARR = rf_daily
    v13m.RF_DAILY_ARR = rf_daily
    v22.REBAL_DOW = [4]
    dow = pd.to_datetime(dates).dayofweek
    periods = _get_retrain_periods(dates, n, v22.RETRAIN)
    sma50 = pd.Series(prices).rolling(50).mean().values
    sma200 = pd.Series(prices).rolling(200).mean().values
    ctx = (prices, daily_ret, returns, vols, df, dates, n, periods, dow, sma50, sma200, rf_daily)

    print("Phase 1: 3 seeds exploratory combos")
    print("-" * 80)
    results = {}
    for name, feats in SETS:
        t1 = time.time()
        mets = run_set(name, feats, [42, 142, 242], ctx)
        if mets:
            results[name] = summarize(name, mets, len(feats))
            print(f"  ({(time.time()-t1)/60:.1f}m)")

    # Identify winner (by Sortino)
    winner = max(results.keys(), key=lambda k: results[k][0])
    print()
    print(f"Winner by Sortino: {winner} ({results[winner][0]:.2f})")
    print()

    # Phase 2: validate winner + original baseline + V6 with 10 seeds
    print("Phase 2: 10-seed validation (winner + V0 + V6)")
    print("-" * 80)
    validate_sets = {winner: [f for f in SETS if f[0] == winner][0][1]}
    validate_sets['V0_baseline'] = BASELINE
    validate_sets['V6_fracdiff'] = BASELINE + ['price_fracdiff_05', 'fed_fracdiff_05']

    val_seeds = [42, 142, 242, 342, 442, 542, 642, 742, 842, 942]
    val_results = {}
    for name, feats in validate_sets.items():
        t1 = time.time()
        mets = run_set(name, feats, val_seeds, ctx)
        if mets:
            val_results[name] = summarize(name, mets, len(feats))
            print(f"  ({(time.time()-t1)/60:.1f}m)")

    print()
    print("=" * 80)
    print(f"TOTAL TIME: {(time.time()-t0)/60:.1f} minutes")
    print("=" * 80)


if __name__ == '__main__':
    main()
