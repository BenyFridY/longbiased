"""Fetch new candidate features and cache for V34 experiments.

Features:
  1. fear_greed_index (alternative.me, 2018+)
  2. binance_funding_rate_BTCUSDT (Binance futures, 2019-12-31+, 8h bars -> daily mean)
  3. sopr (bitcoin-data.com, 2022+)
  4. mvrv, reserve_risk, puell_multiple (bitcoin-data.com, if not rate limited)
"""
import sys, time, requests
import numpy as np, pandas as pd
from pathlib import Path
from datetime import datetime

ROOT = Path(__file__).parent.parent.parent
OUT = ROOT / "scripts" / "production" / "data" / "v34_features.csv"


def fetch_fear_greed():
    print("[fear_greed] fetching...")
    r = requests.get('https://api.alternative.me/fng/?limit=0', timeout=30)
    data = r.json()['data']
    rows = [{'date': datetime.fromtimestamp(int(d['timestamp'])).strftime('%Y-%m-%d'),
             'fear_greed': int(d['value'])} for d in data]
    df = pd.DataFrame(rows)
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)
    print(f"  {len(df)} days, {df.date.min()} -> {df.date.max()}")
    return df


def fetch_binance_funding():
    print("[funding_rate] fetching Binance BTCUSDT...")
    all_data = []
    end_time = int(datetime.now().timestamp() * 1000)
    start_time = int(datetime(2019, 12, 31).timestamp() * 1000)
    cur_start = start_time
    while cur_start < end_time:
        try:
            r = requests.get(
                f'https://fapi.binance.com/fapi/v1/fundingRate'
                f'?symbol=BTCUSDT&startTime={cur_start}&limit=1000',
                timeout=30)
            data = r.json()
            if not data: break
            all_data.extend(data)
            last_time = data[-1]['fundingTime']
            if last_time <= cur_start: break
            cur_start = last_time + 1
            time.sleep(0.2)  # rate limit
        except Exception as e:
            print(f"  err: {e}")
            time.sleep(2)
    df = pd.DataFrame(all_data)
    df['date'] = pd.to_datetime(df['fundingTime'], unit='ms').dt.floor('D')
    df['funding_rate'] = df['fundingRate'].astype(float)
    # Aggregate to daily mean (3 bars per day)
    daily = df.groupby('date')['funding_rate'].agg(['mean', 'min', 'max']).reset_index()
    daily.columns = ['date', 'funding_rate_mean', 'funding_rate_min', 'funding_rate_max']
    print(f"  {len(daily)} days, {daily.date.min()} -> {daily.date.max()}")
    return daily


def fetch_bitcoindata_metric(metric, col):
    print(f"[{metric}] fetching...")
    tries = 0
    while tries < 5:
        r = requests.get(f'https://bitcoin-data.com/v1/{metric}', timeout=30)
        if r.status_code == 200:
            data = r.json()
            if isinstance(data, list) and len(data) > 0:
                df = pd.DataFrame(data)
                df = df.rename(columns={'d': 'date'})
                df[col] = pd.to_numeric(df[col], errors='coerce')
                df['date'] = pd.to_datetime(df['date'])
                df = df[['date', col]].dropna().sort_values('date').reset_index(drop=True)
                print(f"  {len(df)} days, {df.date.min()} -> {df.date.max()}")
                return df
        elif r.status_code == 429:
            tries += 1
            print(f"  rate limited, wait 30s (try {tries}/5)")
            time.sleep(30)
        else:
            print(f"  error {r.status_code}")
            return None
    return None


def main():
    t0 = time.time()
    dfs = []

    dfs.append(fetch_fear_greed())
    dfs.append(fetch_binance_funding())
    s = fetch_bitcoindata_metric('sopr', 'sopr')
    if s is not None: dfs.append(s)
    m = fetch_bitcoindata_metric('mvrv', 'mvrv')
    if m is not None: dfs.append(m)
    rr = fetch_bitcoindata_metric('reserve-risk', 'reserveRisk')
    if rr is not None: dfs.append(rr)
    pm = fetch_bitcoindata_metric('puell-multiple', 'puellMultiple')
    if pm is not None: dfs.append(pm)

    # Merge all on date
    out = dfs[0]
    for d in dfs[1:]:
        out = out.merge(d, on='date', how='outer')
    out = out.sort_values('date').reset_index(drop=True)

    OUT.parent.mkdir(parents=True, exist_ok=True)
    out.to_csv(OUT, index=False)
    print(f"\nSaved {len(out)} rows, {len(out.columns)-1} features: {OUT}")
    print(f"Columns: {list(out.columns)}")
    print(f"Elapsed: {(time.time()-t0)/60:.1f} min")

    # Quick quality check
    print("\nCoverage for 2022-01-01 to today:")
    mask = out.date >= '2022-01-01'
    for c in out.columns:
        if c == 'date': continue
        nan_pct = out.loc[mask, c].isna().mean() * 100
        last_val = out.loc[mask, c].dropna().iloc[-1] if not out.loc[mask, c].dropna().empty else None
        print(f"  {c}: {nan_pct:.1f}% NaN, last={last_val}")


if __name__ == '__main__':
    main()
