"""V21 — Confirm best hyperparameter candidates with 10 seeds."""
import sys, gc, numpy as np, pandas as pd
from pathlib import Path
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
import warnings; warnings.filterwarnings('ignore')
sys.stdout.reconfigure(line_buffering=True)

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

from archive.old_pipelines.pipeline_v09 import (
    load_data, build_ml_features, backtest_allocations,
    metrics, COST, P,
)
from archive.old_pipelines.pipeline_v10 import MODELS
from archive.old_pipelines.pipeline_v11 import DEFAULT_XGB_PARAMS
from archive.old_pipelines.pipeline_v13 import _get_retrain_periods, _train_one_xgb

W = 16; BAGS = 80
SEEDS = [42 + i * 100 for i in range(10)]

prices, daily_ret, returns, vols, df = load_data()
dates = df['date'].values; n = len(prices)

try:
    from src.features.macro.cdi_rates import build_rf_daily
    RF_DAILY_ARR = build_rf_daily(dates, source='auto')
except Exception:
    from src.features.macro.cdi_rates import build_rf_daily
    RF_DAILY_ARR = build_rf_daily(dates, source='copom')

import archive.old_pipelines.pipeline_v09 as v9m
import archive.old_pipelines.pipeline_v13 as v13m
v9m.RF_DAILY_ARR = RF_DAILY_ARR; v13m.RF_DAILY_ARR = RF_DAILY_ARR

base = [f for f in MODELS['37feat'] if f != 'exchange_netflow_ma7'] + ['basis_pct']
extra = ['fed_balance_sheet', 'futures_trade_count', 'vol_x_regime_duration',
         'velocity', 'hash_rate_pctchg_30d']
fc = base + [f for f in extra if f not in base]
fc = [f for f in fc if f in df.columns]

X_all, _ = build_ml_features(df, returns, vols, n, feature_cols=fc)
target = np.zeros(n)
for i in range(n - 3):
    target[i] = (prices[i + 3] - prices[i]) / prices[i]

dow = pd.to_datetime(dates).dayofweek
periods = _get_retrain_periods(dates, n, 'semi')

sma50 = pd.Series(prices).rolling(50).mean().values
sma200 = pd.Series(prices).rolling(200).mean().values


def get_regime(t):
    if np.isnan(sma50[t]) or np.isnan(sma200[t]):
        return 'MILD'
    if prices[t] > sma50[t] and sma50[t] > sma200[t]:
        return 'BULL'
    elif prices[t] > sma200[t]:
        return 'MILD'
    return 'BEAR'


BASE = dict(DEFAULT_XGB_PARAMS)

CONFIGS = {
    'BASELINE (sub=0.8, col=0.7)': dict(BASE),
    'subsamp=0.6': {**BASE, 'subsample': 0.6},
    'subsamp=0.7': {**BASE, 'subsample': 0.7},
    'colsamp=0.5': {**BASE, 'colsample_bytree': 0.5},
    'sub=0.7+col=0.5': {**BASE, 'subsample': 0.7, 'colsample_bytree': 0.5},
    'sub=0.6+col=0.5': {**BASE, 'subsample': 0.6, 'colsample_bytree': 0.5},
}

P("=" * 80)
P(f"V21 HP CONFIRMATION — {len(CONFIGS)} configs x {len(SEEDS)} seeds")
P("=" * 80)
start = datetime.now()

all_results = {}

for ci, (config_name, xgb_p) in enumerate(CONFIGS.items()):
    P(f"  [{ci+1}/{len(CONFIGS)}] {config_name}...")
    seed_metrics = []

    for si, seed in enumerate(SEEDS):
        full_allocs = np.full(n, 0.0)
        prev = 0.0
        a_s, a_b, a_a, a_r = [], [], [], []

        for te, ts, tend in periods:
            tm = np.arange(60, te - 5 + 1)
            v = ~np.any(np.isnan(X_all[tm]), axis=1)
            idx = tm[v]
            if len(idx) < 100:
                continue
            Xt = np.nan_to_num(X_all[idx], nan=0.0)
            yt = target[idx]
            bag_seeds = [seed + i * 7 for i in range(BAGS)]
            with ThreadPoolExecutor(max_workers=W) as ex:
                models = list(ex.map(_train_one_xgb,
                    [(s, Xt, yt, xgb_p) for s in bag_seeds]))

            for t in range(ts, tend + 1):
                is_rebal = dow[t] == 4
                is_emerg = t > 0 and abs(daily_ret[t]) > 0.08
                if not is_rebal and not is_emerg:
                    full_allocs[t] = prev
                    continue
                x_t = np.nan_to_num(X_all[t:t + 1].copy(), nan=0.0)
                avg = float(np.mean([m.predict(x_t)[0] for m in models]))
                regime = get_regime(t)
                K = {'BULL': 50, 'MILD': 30, 'BEAR': 15}[regime]
                full_allocs[t] = np.clip(avg * K, -0.25, 1.0)
                prev = full_allocs[t]

            s, b, a = backtest_allocations(daily_ret, full_allocs, ts, tend,
                                           cost=COST, rf_daily=RF_DAILY_ARR)
            a_s.extend(s)
            a_b.extend(b)
            a_a.extend(a)
            a_r.extend(RF_DAILY_ARR[ts:ts + len(s)])
            del models
            gc.collect()

        m = metrics(np.array(a_s), np.array(a_b), np.array(a_a),
                    rf_daily=np.array(a_r))
        seed_metrics.append(m)

    sortinos = [m['sortino'] for m in seed_metrics]
    rets = [m['total'] * 100 for m in seed_metrics]
    dds = [m['max_dd'] * 100 for m in seed_metrics]

    all_results[config_name] = {
        'sortino_avg': np.mean(sortinos),
        'sortino_std': np.std(sortinos),
        'ret_avg': np.mean(rets),
        'ret_std': np.std(rets),
        'dd_avg': np.mean(dds),
        'dd_std': np.std(dds),
        'sortinos': sortinos,
    }
    P(f"    S={np.mean(sortinos):.2f}+/-{np.std(sortinos):.2f}  "
      f"Ret={np.mean(rets):+.0f}%+/-{np.std(rets):.0f}%  "
      f"DD={np.mean(dds):.1f}%+/-{np.std(dds):.1f}%")
    gc.collect()

elapsed = (datetime.now() - start).total_seconds() / 60

P("")
P("=" * 80)
P(f"RESULTS — {len(SEEDS)} seeds ({elapsed:.0f} min)")
P("=" * 80)
P(f"  {'Config':<30} {'Sortino':>8} {'std':>5} {'Return':>10} {'std':>6} "
  f"{'MaxDD':>8} {'std':>5}")
P(f"  {'-' * 75}")

ranked = sorted(all_results.items(), key=lambda x: x[1]['sortino_avg'], reverse=True)
for name, r in ranked:
    P(f"  {name:<30} {r['sortino_avg']:>8.2f} {r['sortino_std']:>5.2f}"
      f"  {r['ret_avg']:>+8.0f}% {r['ret_std']:>5.0f}%"
      f"  {r['dd_avg']:>7.1f}% {r['dd_std']:>4.1f}%")

# Seed-by-seed: best vs baseline
P("")
best_name = ranked[0][0]
base_name = [n for n in all_results if 'BASELINE' in n][0]

if best_name != base_name:
    P(f"SEED-BY-SEED: {best_name} vs BASELINE")
    P(f"  {'Seed':>6} {'Best':>8} {'BASE':>8} {'Winner':>10}")
    P(f"  {'-' * 35}")
    wins_best, wins_base = 0, 0
    for i, seed in enumerate(SEEDS):
        sb = all_results[best_name]['sortinos'][i]
        sbl = all_results[base_name]['sortinos'][i]
        w = 'NEW' if sb > sbl else 'BASE'
        if sb > sbl:
            wins_best += 1
        else:
            wins_base += 1
        P(f"  {seed:>6} {sb:>8.2f} {sbl:>8.2f} {w:>10}")
    P(f"  {'-' * 35}")
    P(f"  NEW: {wins_best}/{len(SEEDS)} | BASELINE: {wins_base}/{len(SEEDS)}")

# Also compare all configs seed-by-seed vs baseline
P("")
P("HEAD-TO-HEAD vs BASELINE (wins out of 10 seeds):")
for name, r in ranked:
    if 'BASELINE' in name:
        continue
    wins = sum(1 for i in range(len(SEEDS))
               if r['sortinos'][i] > all_results[base_name]['sortinos'][i])
    dd_diff = r['dd_avg'] - all_results[base_name]['dd_avg']
    s_diff = r['sortino_avg'] - all_results[base_name]['sortino_avg']
    P(f"  {name:<30} wins={wins}/10  dS={s_diff:+.2f}  dDD={dd_diff:+.1f}pp")

P(f"\n  Elapsed: {elapsed:.0f} min")
