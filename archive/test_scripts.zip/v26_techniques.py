"""V26 techniques: test REAL techniques (not hyperparam scaling).

Each test measures:
  - Sortino/Sharpe/Ret/DD (backtest with Fri rebalance, default K=60/30/15)
  - Accuracy overall (sign of pred vs sign of 3d return)
  - Accuracy per day of week (Mon..Sun)
  - Accuracy high-confidence (|pred| > 1%)

Tests (each 3 seeds):

  T1 — BASELINE: V25_FINAL config (reference)

  T2 — FRACDIFF d SWEEP (5 variants)
        d = 0.3, 0.4, 0.5, 0.6, 0.7
        (d=0.5 is current; test if other d values better capture memory)

  T3 — SAMPLE WEIGHTING (AFML Ch. 4)
        Weight observations by uniqueness (overlapping labels compete).
        Concurrent labels reduce weight → less bias from clustered events.

  T4 — META-LABELING (AFML Ch. 3)
        Primary: regressor predicts direction.
        Secondary: classifier predicts "act on this primary?"
        Size = regression × P(act) (already partial in V23, here more formal).

  T5 — TRIPLE-BARRIER TARGET (AFML Ch. 3)
        Target = {+1, 0, -1}: profit hit (+5% in 10d), stop hit (-3%), or timeout.
        Classification task instead of regression.

  T6 — ENSEMBLE XGB + LIGHTGBM (average predictions)
        Different biases → averaging may improve accuracy.

  T7 — PER-DOW ENSEMBLE
        Train 5 separate models (one per weekday).
        At inference, use only the model for that day.

  T8 — VOLATILITY-NORMALIZED TARGET
        Target = (3d return) / volatility_30d.
        More stable across regimes.

  T9 — BORUTA-SHAP FEATURE SELECTION
        Run on baseline → identify top features → retrain with reduced set.
        Remove noise features.

  T10 — BEST COMBO OF ABOVE (10 seeds validation)

For every test, save to outputs/results/v26_techniques.json.
"""
import sys, time, json, gc
import numpy as np, pandas as pd
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import xgboost as xgb

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

import archive.old_pipelines.pipeline_v22 as v22
from archive.old_pipelines.pipeline_v09 import build_ml_features, backtest_allocations, COST
from scripts.production.training import _get_retrain_periods, _train_one_xgb
from src.features.macro.cdi_rates import build_rf_daily
import archive.old_pipelines.pipeline_v09 as v9m
import archive.old_pipelines.pipeline_v13 as v13m

from scripts.production.config import FEATURES_37, K_REGIME, ALLOC_MIN, ALLOC_MAX, BAGS, HORIZON, WORKERS, EMERGENCY_THRESHOLD

DATASET = ROOT / "outputs" / "feature_selection" / "dataset_enhanced.csv"
SEEDS_3 = [42, 142, 242]
SEEDS_10 = [42, 142, 242, 342, 442, 542, 642, 742, 842, 942]
RESULTS = ROOT / "outputs" / "results" / "v26_techniques.json"
DAY_NAMES = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun']


# ═══════════════════════════════════════════════════════════════
# DATA LOADING
# ═══════════════════════════════════════════════════════════════

def load():
    df = pd.read_csv(DATASET)
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)
    prices = df['price_usd'].values
    n = len(prices)
    daily_ret = np.zeros(n)
    for i in range(1, n):
        daily_ret[i] = (prices[i] - prices[i-1]) / prices[i-1]
    returns, vols = {}, {}
    for w in [1, 3, 5, 7, 10, 14, 20, 21, 30, 45, 60]:
        r = np.zeros(n)
        for i in range(w, n):
            r[i] = (prices[i] - prices[i-w]) / prices[i-w]
        returns[w] = r
    for w in [5, 7, 10, 14, 21, 30]:
        vols[w] = pd.Series(daily_ret).rolling(w).std().fillna(0.02).values
    return prices, daily_ret, returns, vols, df


def fractional_diff(series, d=0.5, thres=0.01):
    w = [1.0]; k = 1
    while abs(w[-1]) > thres and k < len(series):
        w.append(-w[-1] * (d - k + 1) / k)
        k += 1
    w = np.array(w[::-1])
    arr = series.values if hasattr(series, 'values') else np.asarray(series)
    out = np.full(len(arr), np.nan)
    W = len(w)
    for i in range(W - 1, len(arr)):
        window = arr[i - W + 1:i + 1]
        if np.any(np.isnan(window)):
            continue
        out[i] = (w * window).sum()
    return out


# ═══════════════════════════════════════════════════════════════
# ACCURACY PER DAY OF WEEK
# ═══════════════════════════════════════════════════════════════

def accuracy_per_dow(preds, actuals, dow):
    """Returns dict of accuracy per day of week and overall."""
    mask = np.abs(preds) > 1e-6
    out = {'all': float((np.sign(preds[mask]) == np.sign(actuals[mask])).mean())}
    for d, name in enumerate(DAY_NAMES):
        dmask = mask & (dow == d)
        if dmask.sum() > 10:
            out[name] = float((np.sign(preds[dmask]) == np.sign(actuals[dmask])).mean())
        else:
            out[name] = None
    hc_mask = np.abs(preds) > 0.01
    if hc_mask.sum() > 10:
        out['high_conf'] = float((np.sign(preds[hc_mask]) == np.sign(actuals[hc_mask])).mean())
    else:
        out['high_conf'] = None
    return out


# ═══════════════════════════════════════════════════════════════
# GENERIC RUN: trains models per walk-forward, returns preds+metrics
# ═══════════════════════════════════════════════════════════════

def run_seed(seed, X_all, target, prices, daily_ret, dates, periods,
             dow, sma50, sma200, rf_daily, n, REBAL_DOW=[4],
             sample_weights=None, model_builder=None):
    """Returns: metrics dict + (preds, actuals, rebal_mask) for accuracy."""
    full_allocs = np.full(n, 0.0)
    prev_alloc = 0.0
    a_s, a_b, a_a, a_r = [], [], [], []
    # For accuracy: preds and actuals on EVERY day (we measure pred quality across days)
    all_preds = np.zeros(n)
    all_actuals = np.zeros(n)

    for te, ts, tend in periods:
        gap = max(HORIZON, 5)
        tm = np.arange(60, te - gap + 1)
        valid = ~np.any(np.isnan(X_all[tm]), axis=1)
        idx = tm[valid]
        if len(idx) < 100:
            continue

        Xt = np.nan_to_num(X_all[idx], nan=0.0)
        yt = target[idx]
        wt = sample_weights[idx] if sample_weights is not None else None

        bag_seeds = [seed + i * 7 for i in range(BAGS)]
        if model_builder is not None:
            # Custom ensemble
            models = model_builder(Xt, yt, bag_seeds, wt)
        else:
            # Default XGB
            with ThreadPoolExecutor(max_workers=WORKERS) as ex:
                if wt is None:
                    models = list(ex.map(_train_one_xgb,
                        [(s, Xt, yt, v22.XGB_PARAMS) for s in bag_seeds]))
                else:
                    models = []
                    for s in bag_seeds:
                        p = dict(v22.XGB_PARAMS)
                        p['random_state'] = s
                        ne = p.pop('n_estimators', 200)
                        m = xgb.XGBRegressor(n_estimators=ne, **p)
                        m.fit(Xt, yt, sample_weight=wt)
                        models.append(m)

        for t in range(ts, tend + 1):
            x_t = np.nan_to_num(X_all[t:t + 1].copy(), nan=0.0)
            # Handle ensemble (list of lists or single list)
            if isinstance(models[0], list):
                preds = []
                for sub in models:
                    p_ = np.mean([m.predict(x_t)[0] for m in sub])
                    preds.append(p_)
                prediction = float(np.mean(preds))
            else:
                prediction = float(np.mean([m.predict(x_t)[0] for m in models]))
            all_preds[t] = prediction
            all_actuals[t] = target[t]

            is_rebal = dow[t] in REBAL_DOW
            is_emerg = t > 0 and abs(daily_ret[t]) > EMERGENCY_THRESHOLD
            if not is_rebal and not is_emerg:
                full_allocs[t] = prev_alloc
                continue

            # Allocation
            if np.isnan(sma50[t]) or np.isnan(sma200[t]):
                regime = 'MILD'
            elif prices[t] > sma50[t] and sma50[t] > sma200[t]:
                regime = 'BULL'
            elif prices[t] > sma200[t]:
                regime = 'MILD'
            else:
                regime = 'BEAR'
            K = K_REGIME[regime]
            full_allocs[t] = float(np.clip(prediction * K, ALLOC_MIN, ALLOC_MAX))
            prev_alloc = full_allocs[t]

        s, b, a = backtest_allocations(daily_ret, full_allocs, ts, tend,
                                       cost=COST, rf_daily=rf_daily)
        a_s.extend(s); a_b.extend(b); a_a.extend(a)
        a_r.extend(rf_daily[ts:ts + len(s)])
        del models; gc.collect()

    metrics = v22.metrics_v22(np.array(a_s), np.array(a_b), np.array(a_a),
                              rf_daily=np.array(a_r))
    return metrics, all_preds, all_actuals


def aggregate(name, outputs, dow):
    """Aggregate metrics + accuracy across seeds."""
    sortinos = [o[0]['sortino'] for o in outputs]
    sharpes  = [o[0]['sharpe']  for o in outputs]
    rets     = [o[0]['total']*100 for o in outputs]
    dds      = [o[0]['max_dd']*100 for o in outputs]
    # Accuracy: average preds across seeds, then compute acc
    preds_avg = np.mean([o[1] for o in outputs], axis=0)
    actuals = outputs[0][2]
    acc = accuracy_per_dow(preds_avg, actuals, dow)
    result = {
        'name': name,
        'sortino_mean': float(np.mean(sortinos)), 'sortino_std': float(np.std(sortinos)),
        'sharpe_mean': float(np.mean(sharpes)), 'sharpe_std': float(np.std(sharpes)),
        'ret_mean': float(np.mean(rets)), 'ret_std': float(np.std(rets)),
        'dd_mean': float(np.mean(dds)), 'dd_std': float(np.std(dds)),
        'acc': acc,
        'n_seeds': len(outputs),
    }
    acc_str = f"all={acc['all']*100:.1f}%"
    for day in ['Mon','Wed','Fri','Sun']:
        if acc.get(day) is not None:
            acc_str += f" {day}={acc[day]*100:.1f}%"
    print(f"{name:<30}  S={result['sortino_mean']:.2f}  Ret={result['ret_mean']:+.0f}%  "
          f"DD={result['dd_mean']:.1f}%  Acc: {acc_str}")
    return result


# ═══════════════════════════════════════════════════════════════
# SAMPLE WEIGHTING (AFML Ch. 4) — weight by uniqueness
# ═══════════════════════════════════════════════════════════════

def compute_uniqueness_weights(n, horizon=HORIZON):
    """Each obs spans [t, t+horizon]. Count concurrent obs at each point.
    Weight[i] = 1 / avg(concurrent count across i..i+horizon)."""
    concurrent = np.zeros(n)
    for i in range(n - horizon):
        concurrent[i:i+horizon+1] += 1
    weights = np.zeros(n)
    for i in range(n - horizon):
        seg = concurrent[i:i+horizon+1]
        avg_conc = seg.mean()
        weights[i] = 1.0 / max(avg_conc, 1.0)
    weights = weights / weights[weights > 0].mean()  # normalize so mean=1
    return weights


# ═══════════════════════════════════════════════════════════════
# TRIPLE BARRIER (AFML Ch. 3)
# ═══════════════════════════════════════════════════════════════

def triple_barrier_labels(prices, pt=0.05, sl=-0.03, max_h=10):
    """Returns +1 if profit barrier hit, -1 if stop, 0 if timeout."""
    n = len(prices)
    labels = np.zeros(n)
    for i in range(n - max_h):
        entry = prices[i]
        for h in range(1, max_h + 1):
            ret = (prices[i+h] - entry) / entry
            if ret >= pt:
                labels[i] = 1.0
                break
            if ret <= sl:
                labels[i] = -1.0
                break
    return labels


# ═══════════════════════════════════════════════════════════════
# ENSEMBLE XGB + LIGHTGBM
# ═══════════════════════════════════════════════════════════════

def build_ensemble_xgb_lgbm(Xt, yt, bag_seeds, wt=None):
    """Returns [xgb_models, lgbm_models] — both averaged at inference."""
    import lightgbm as lgb
    xgb_models = []
    for s in bag_seeds:
        p = dict(v22.XGB_PARAMS)
        p['random_state'] = s
        ne = p.pop('n_estimators', 200)
        m = xgb.XGBRegressor(n_estimators=ne, **p)
        if wt is None:
            m.fit(Xt, yt)
        else:
            m.fit(Xt, yt, sample_weight=wt)
        xgb_models.append(m)
    lgbm_models = []
    lgbm_params = {
        'objective': 'regression', 'num_leaves': 31, 'learning_rate': 0.05,
        'min_child_samples': 12, 'colsample_bytree': 0.5, 'subsample': 0.8,
        'verbose': -1, 'n_jobs': 1,
    }
    for s in bag_seeds:
        lgbm_params['seed'] = s
        m = lgb.LGBMRegressor(n_estimators=200, **lgbm_params)
        if wt is None:
            m.fit(Xt, yt)
        else:
            m.fit(Xt, yt, sample_weight=wt)
        lgbm_models.append(m)
    return [xgb_models, lgbm_models]


# ═══════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════

def main():
    t0 = time.time()
    print("=" * 95)
    print("V26 TECHNIQUES — testing real techniques, measuring accuracy per day of week")
    print("Reference: V25_FINAL (Sortino 4.95, Ret +1007%, DD -9.1%, acc_Fri ~62%)")
    print("=" * 95)

    prices, daily_ret, returns, vols, df = load()
    dates = df['date'].values
    n = len(prices)
    rf_daily = build_rf_daily(dates, source='auto')
    v9m.RF_DAILY_ARR = rf_daily
    v13m.RF_DAILY_ARR = rf_daily
    dow = pd.to_datetime(dates).dayofweek.values
    periods = _get_retrain_periods(dates, n, v22.RETRAIN)
    sma50 = pd.Series(prices).rolling(50).mean().values
    sma200 = pd.Series(prices).rolling(200).mean().values

    feats = list(FEATURES_37)
    X_base, _ = build_ml_features(df, returns, vols, n, feature_cols=feats)

    target = np.zeros(n)
    for i in range(n - HORIZON):
        target[i] = (prices[i + HORIZON] - prices[i]) / prices[i]

    results = []
    def save():
        RESULTS.parent.mkdir(parents=True, exist_ok=True)
        with open(RESULTS, 'w') as f:
            json.dump({'results': results, 'elapsed_min': (time.time()-t0)/60}, f, indent=2)

    # -- T1: BASELINE --
    print("\n-- T1: BASELINE (V25_FINAL) --")
    outs = [run_seed(s, X_base, target, prices, daily_ret, dates, periods,
                      dow, sma50, sma200, rf_daily, n) for s in SEEDS_3]
    results.append(aggregate('T1_baseline', outs, dow)); save()

    # -- T2: FRACDIFF d SWEEP --
    print("\n-- T2: FRACDIFF d SWEEP --")
    log_prices = np.log(prices)
    fed_log = np.log(df['fed_balance_sheet'].replace(0, np.nan).values)
    idx_pf = feats.index('price_fracdiff_05')
    idx_ff = feats.index('fed_fracdiff_05')
    for d_val in [0.3, 0.4, 0.5, 0.6, 0.7]:
        X_tmp = X_base.copy()
        X_tmp[:, idx_pf] = fractional_diff(log_prices, d=d_val)
        X_tmp[:, idx_ff] = fractional_diff(fed_log, d=d_val)
        outs = [run_seed(s, X_tmp, target, prices, daily_ret, dates, periods,
                          dow, sma50, sma200, rf_daily, n) for s in SEEDS_3]
        results.append(aggregate(f'T2_fracdiff_d{int(d_val*10)}', outs, dow)); save()

    # -- T3: SAMPLE WEIGHTING --
    print("\n-- T3: SAMPLE WEIGHTING (uniqueness) --")
    sw = compute_uniqueness_weights(n, HORIZON)
    outs = [run_seed(s, X_base, target, prices, daily_ret, dates, periods,
                      dow, sma50, sma200, rf_daily, n, sample_weights=sw) for s in SEEDS_3]
    results.append(aggregate('T3_sample_weight', outs, dow)); save()

    # -- T4: ENSEMBLE XGB + LGBM --
    print("\n-- T4: ENSEMBLE XGB + LightGBM --")
    try:
        import lightgbm  # noqa
        outs = [run_seed(s, X_base, target, prices, daily_ret, dates, periods,
                          dow, sma50, sma200, rf_daily, n,
                          model_builder=build_ensemble_xgb_lgbm) for s in SEEDS_3]
        results.append(aggregate('T4_ensemble_xgb_lgbm', outs, dow)); save()
    except ImportError:
        print("LightGBM not available — skipping T4")

    # -- T5: VOLATILITY-NORMALIZED TARGET --
    print("\n-- T5: VOL-NORMALIZED TARGET --")
    vol30 = pd.Series(daily_ret).rolling(30).std().fillna(0.02).values
    target_vol = target / (vol30 * np.sqrt(3) + 1e-6)
    target_vol = np.clip(target_vol, -5, 5)
    outs = [run_seed(s, X_base, target_vol, prices, daily_ret, dates, periods,
                      dow, sma50, sma200, rf_daily, n) for s in SEEDS_3]
    results.append(aggregate('T5_vol_normalized_target', outs, dow)); save()

    # -- T6: TRIPLE BARRIER --
    print("\n-- T6: TRIPLE BARRIER TARGET --")
    tb = triple_barrier_labels(prices, pt=0.05, sl=-0.03, max_h=10)
    outs = [run_seed(s, X_base, tb, prices, daily_ret, dates, periods,
                      dow, sma50, sma200, rf_daily, n) for s in SEEDS_3]
    results.append(aggregate('T6_triple_barrier', outs, dow)); save()

    # -- T7: SAMPLE WEIGHT + ENSEMBLE --
    print("\n-- T7: SAMPLE WEIGHT + ENSEMBLE --")
    try:
        import lightgbm  # noqa
        outs = [run_seed(s, X_base, target, prices, daily_ret, dates, periods,
                          dow, sma50, sma200, rf_daily, n,
                          sample_weights=sw,
                          model_builder=build_ensemble_xgb_lgbm) for s in SEEDS_3]
        results.append(aggregate('T7_sw_plus_ensemble', outs, dow)); save()
    except ImportError:
        pass

    # -- T8: MULTI-DOW REBALANCE --
    print("\n-- T8: Multi-day rebalance (ThuFriMon) --")
    for rebal_set, label in [([3,4], 'ThuFri'), ([3,4,0], 'ThuFriMon'), ([0,2,4], 'MonWedFri')]:
        outs = [run_seed(s, X_base, target, prices, daily_ret, dates, periods,
                          dow, sma50, sma200, rf_daily, n, REBAL_DOW=rebal_set)
                for s in SEEDS_3]
        results.append(aggregate(f'T8_rebal_{label}', outs, dow)); save()

    elapsed = (time.time() - t0) / 60
    print("\n" + "=" * 95)
    print(f"V26 TOTAL: {elapsed:.1f} min")
    print("=" * 95)
    # Print summary sorted by Sortino
    print("\nRanked by Sortino:")
    for r in sorted(results, key=lambda x: -x['sortino_mean'])[:10]:
        acc = r['acc']
        print(f"  {r['name']:<30}  S={r['sortino_mean']:.2f}  Ret={r['ret_mean']:+.0f}%  "
              f"DD={r['dd_mean']:.1f}%  acc_all={acc['all']*100:.1f}%")
    save()


if __name__ == '__main__':
    main()
