"""V21 — Fair Horizon Comparison.
Calibrates K per horizon so allocations have the same scale.
Then compares signal quality across horizons.
"""
import sys, gc, numpy as np, pandas as pd
from pathlib import Path
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
import warnings; warnings.filterwarnings('ignore')
sys.stdout.reconfigure(line_buffering=True)

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

from archive.old_pipelines.pipeline_v09 import (
    load_data, build_ml_features, backtest_allocations,
    metrics, COST, P, convert_numpy,
)
from archive.old_pipelines.pipeline_v10 import MODELS
from archive.old_pipelines.pipeline_v11 import DEFAULT_XGB_PARAMS
from archive.old_pipelines.pipeline_v13 import _get_retrain_periods, _train_one_xgb

W = 16; BAGS = 80

prices, daily_ret, returns, vols, df = load_data()
dates = df['date'].values; n = len(prices)

try:
    from src.features.macro.cdi_rates import build_rf_daily
    RF_DAILY_ARR = build_rf_daily(dates, source='auto')
except Exception:
    from src.features.macro.cdi_rates import build_rf_daily
    RF_DAILY_ARR = build_rf_daily(dates, source='copom')

import archive.old_pipelines.pipeline_v09 as v9m
import archive.old_pipelines.pipeline_v13 as v13m
v9m.RF_DAILY_ARR = RF_DAILY_ARR; v13m.RF_DAILY_ARR = RF_DAILY_ARR

base = [f for f in MODELS['37feat'] if f != 'exchange_netflow_ma7'] + ['basis_pct']
extra = ['fed_balance_sheet', 'futures_trade_count', 'vol_x_regime_duration',
         'velocity', 'hash_rate_pctchg_30d']
fc = base + [f for f in extra if f not in base]
fc = [f for f in fc if f in df.columns]

X_all, _ = build_ml_features(df, returns, vols, n, feature_cols=fc)
xgb_params = dict(DEFAULT_XGB_PARAMS)
dow = pd.to_datetime(dates).dayofweek
periods = _get_retrain_periods(dates, n, 'semi')

sma50 = pd.Series(prices).rolling(50).mean().values
sma200 = pd.Series(prices).rolling(200).mean().values


def get_regime(t):
    if np.isnan(sma50[t]) or np.isnan(sma200[t]):
        return 'MILD'
    if prices[t] > sma50[t] and sma50[t] > sma200[t]:
        return 'BULL'
    elif prices[t] > sma200[t]:
        return 'MILD'
    return 'BEAR'


HORIZONS = [2, 3, 5, 7]
SEEDS = [42, 142, 242, 342, 442]
start = datetime.now()

# ─── STEP 1: Measure prediction scale per horizon ───
P("=" * 80)
P("STEP 1: Measure prediction scale per horizon (seed=42)")
P("=" * 80)

pred_scales = {}
for h in HORIZONS:
    target_h = np.zeros(n)
    for i in range(n - h):
        target_h[i] = (prices[i + h] - prices[i]) / prices[i]
    gap_h = max(h, 5)

    all_preds = []
    for te, ts, tend in periods:
        tm = np.arange(60, te - gap_h + 1)
        v = ~np.any(np.isnan(X_all[tm]), axis=1)
        idx = tm[v]
        if len(idx) < 100:
            continue
        Xt = np.nan_to_num(X_all[idx], nan=0.0)
        yt = target_h[idx]
        bag_seeds = [42 + i * 7 for i in range(BAGS)]
        with ThreadPoolExecutor(max_workers=W) as ex:
            models = list(ex.map(_train_one_xgb,
                [(s, Xt, yt, xgb_params) for s in bag_seeds]))

        for t in range(ts, tend + 1):
            if dow[t] != 4:
                continue
            x_t = np.nan_to_num(X_all[t:t + 1].copy(), nan=0.0)
            avg = float(np.mean([m.predict(x_t)[0] for m in models]))
            all_preds.append(avg)
        del models
        gc.collect()

    preds = np.array(all_preds)
    scale = np.std(preds)
    pred_scales[h] = scale
    P(f"  h={h}d: pred_std={scale*100:.2f}%  "
      f"pred_abs_mean={np.mean(np.abs(preds))*100:.2f}%  "
      f"range=[{np.min(preds)*100:.1f}%, {np.max(preds)*100:.1f}%]")

# ─── K calibration ───
P("")
P("K calibration (matching 3d allocation scale):")
ref_scale = pred_scales[3]
K_CONFIGS = {}
for h in HORIZONS:
    ratio = ref_scale / pred_scales[h]
    k_bull = round(50 * ratio)
    k_mild = round(30 * ratio)
    k_bear = round(15 * ratio)
    K_CONFIGS[h] = {'BULL': k_bull, 'MILD': k_mild, 'BEAR': k_bear}
    P(f"  h={h}d: scale_ratio={ratio:.2f} -> "
      f"K_bull={k_bull}, K_mild={k_mild}, K_bear={k_bear}")

# ─── STEP 2: Fair comparison ───
P("")
P("=" * 80)
P("STEP 2: Fair comparison (K calibrated per horizon) x 5 seeds")
P("=" * 80)

results = {}

for h in HORIZONS:
    target_h = np.zeros(n)
    for i in range(n - h):
        target_h[i] = (prices[i + h] - prices[i]) / prices[i]
    gap_h = max(h, 5)
    K_h = K_CONFIGS[h]

    P(f"  h={h}d (K={K_h['BULL']}/{K_h['MILD']}/{K_h['BEAR']})...")

    seed_metrics = []
    for seed in SEEDS:
        full_allocs = np.full(n, 0.0)
        prev = 0.0
        a_s, a_b, a_a, a_r = [], [], [], []

        for te, ts, tend in periods:
            tm = np.arange(60, te - gap_h + 1)
            v = ~np.any(np.isnan(X_all[tm]), axis=1)
            idx = tm[v]
            if len(idx) < 100:
                continue
            Xt = np.nan_to_num(X_all[idx], nan=0.0)
            yt = target_h[idx]
            bag_seeds = [seed + i * 7 for i in range(BAGS)]
            with ThreadPoolExecutor(max_workers=W) as ex:
                models = list(ex.map(_train_one_xgb,
                    [(s, Xt, yt, xgb_params) for s in bag_seeds]))

            for t in range(ts, tend + 1):
                is_rebal = dow[t] == 4
                is_emerg = t > 0 and abs(daily_ret[t]) > 0.08
                if not is_rebal and not is_emerg:
                    full_allocs[t] = prev
                    continue
                x_t = np.nan_to_num(X_all[t:t + 1].copy(), nan=0.0)
                avg = float(np.mean([m.predict(x_t)[0] for m in models]))
                regime = get_regime(t)
                K = K_h[regime]
                full_allocs[t] = np.clip(avg * K, -0.25, 1.0)
                prev = full_allocs[t]

            s, b, a = backtest_allocations(daily_ret, full_allocs, ts, tend,
                                           cost=COST, rf_daily=RF_DAILY_ARR)
            a_s.extend(s)
            a_b.extend(b)
            a_a.extend(a)
            a_r.extend(RF_DAILY_ARR[ts:ts + len(s)])
            del models
            gc.collect()

        m = metrics(np.array(a_s), np.array(a_b), np.array(a_a),
                    rf_daily=np.array(a_r))
        seed_metrics.append(m)

    sortinos = [m['sortino'] for m in seed_metrics]
    rets = [m['total'] * 100 for m in seed_metrics]
    dds = [m['max_dd'] * 100 for m in seed_metrics]
    results[h] = {
        'sortino': np.mean(sortinos),
        'sortino_std': np.std(sortinos),
        'ret': np.mean(rets),
        'dd': np.mean(dds),
        'K': K_h,
        'sortinos': sortinos,
    }
    P(f"    S={np.mean(sortinos):.2f}+/-{np.std(sortinos):.2f}  "
      f"Ret={np.mean(rets):+.0f}%  DD={np.mean(dds):.1f}%")
    gc.collect()

elapsed = (datetime.now() - start).total_seconds() / 60

# ─── FINAL SUMMARY ───
P("")
P("=" * 80)
P(f"RESULTADO FINAL — COMPARACAO JUSTA DE HORIZONTES ({elapsed:.0f} min)")
P("=" * 80)
P("")
P("  Cada horizonte com K calibrado para mesma escala de alocacao.")
P("  Diferenca = qualidade PURA do sinal, nao escala da aposta.")
P("")
P(f"  {'Horizonte':>10} {'K (B/M/B)':>12} {'Sortino':>8} {'std':>5} "
  f"{'Retorno':>10} {'MaxDD':>8} {'Mismatch':>10}")
P(f"  {'-' * 68}")

for h in HORIZONS:
    r = results[h]
    k_str = f"{r['K']['BULL']}/{r['K']['MILD']}/{r['K']['BEAR']}"
    mismatch = f"{7-h}d"
    marker = "  <-- ATUAL" if h == 3 else ""
    P(f"  {h:>8}d {k_str:>12} {r['sortino']:>8.2f} {r['sortino_std']:>5.2f} "
      f"{r['ret']:>+9.0f}% {r['dd']:>7.1f}% {mismatch:>10}{marker}")

P("")
P("  Mismatch = diferenca entre horizonte de previsao e holding period (7d)")
P("")

best_h = max(results.keys(), key=lambda h: results[h]['sortino'])
P(f"  MELHOR SINAL: h={best_h}d (S={results[best_h]['sortino']:.2f})")
P(f"  ATUAL (3d):   S={results[3]['sortino']:.2f}")
diff = results[best_h]['sortino'] - results[3]['sortino']
if abs(diff) < 0.05:
    P(f"  Diferenca: {diff:+.2f} -> IRRELEVANTE (dentro do ruido)")
elif diff > 0:
    P(f"  Diferenca: {diff:+.2f} -> h={best_h}d eh MELHOR")
else:
    P(f"  Diferenca: {diff:+.2f} -> 3d eh MELHOR")

# Seed-by-seed
P("")
P(f"  SEED-BY-SEED: melhor ({best_h}d) vs 3d")
wins_best = 0
wins_3d = 0
for i, seed in enumerate(SEEDS):
    sb = results[best_h]['sortinos'][i]
    s3 = results[3]['sortinos'][i]
    w = f"{best_h}d" if sb > s3 else "3d"
    if sb > s3:
        wins_best += 1
    else:
        wins_3d += 1
    P(f"    seed={seed}: {best_h}d={sb:.2f}  3d={s3:.2f}  -> {w}")
P(f"    Score: {best_h}d={wins_best}/5  3d={wins_3d}/5")
