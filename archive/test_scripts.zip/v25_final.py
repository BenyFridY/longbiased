"""V25 final: the correct fix approach.

Previous findings:
  - V0_base           4.70  (baseline, with bugged data)
  - V25f_all_yoy      4.61  (YoY fixes alone = SAFE, drops only 0.09)
  - V25g_all_nan      1.54  (OI+FTC NaN = DESTROYS)
  - V25d_oi_nan       1.54  (same — OI NaN is the culprit)
  - V1_no_oi_ftc      4.68  (just REMOVING OI/FTC = SAFE)

Conclusion: the right fix is:
  1. Fix YoY math (rename-equivalent, keep values right)
  2. REMOVE open_interest and futures_trade_count columns entirely
     (don't NaN them — XGBoost treats NaN badly when 40% of rows are missing)
  3. Add fracdiff (V6 winner)

Testing final V25 config:
  V25_FINAL = YoY_fixed + no_OI + no_FTC
  V25_FINAL+frac = V25_FINAL + price_fracdiff + fed_fracdiff
"""
import sys, time
import numpy as np, pandas as pd
from pathlib import Path

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

import archive.old_pipelines.pipeline_v22 as v22
from archive.old_pipelines.pipeline_v09 import build_ml_features
from scripts.production.training import _get_retrain_periods
from src.features.macro.cdi_rates import build_rf_daily
import archive.old_pipelines.pipeline_v09 as v9m
import archive.old_pipelines.pipeline_v13 as v13m

from scripts.production.config import FEATURES_37

DATASET_V24 = ROOT / "outputs" / "feature_selection" / "dataset_v24.csv"  # has fracdiff
DATASET = ROOT / "outputs" / "feature_selection" / "dataset_enhanced.csv"
SEEDS = [42, 142, 242]
BASELINE = list(FEATURES_37)


def load():
    df = pd.read_csv(DATASET)
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)
    prices = df['price_usd'].values
    n = len(prices)
    daily_ret = np.zeros(n)
    for i in range(1, n):
        daily_ret[i] = (prices[i] - prices[i-1]) / prices[i-1]
    returns, vols = {}, {}
    for w in [1, 3, 5, 7, 10, 14, 20, 21, 30, 45, 60]:
        r = np.zeros(n)
        for i in range(w, n):
            r[i] = (prices[i] - prices[i-w]) / prices[i-w]
        returns[w] = r
    for w in [5, 7, 10, 14, 21, 30]:
        vols[w] = pd.Series(daily_ret).rolling(w).std().fillna(0.02).values
    return prices, daily_ret, returns, vols, df


def apply_yoy_fix(df):
    df = df.copy()
    df['m2_yoy_growth'] = (1 + df['m2_supply_pctchg_90d']) ** (365.0/90.0) - 1
    df['fed_bs_yoy_change'] = df['fed_balance_sheet'].pct_change(252)
    df['m2_3m_growth'] = df['m2_supply_pctchg_90d']
    return df


def run_set(name, feats, df, prices, daily_ret, returns, vols, ctx):
    dates, n, rf_daily, dow, periods, sma50, sma200 = ctx
    missing = [f for f in feats if f not in df.columns]
    if missing:
        print(f"  [{name}] MISSING: {missing}")
        return None
    X_all, _ = build_ml_features(df, returns, vols, n, feature_cols=feats)
    target = np.zeros(n)
    for i in range(n - v22.HORIZON):
        target[i] = (prices[i + v22.HORIZON] - prices[i]) / prices[i]
    mets = []
    for seed in SEEDS:
        m = v22.run_single_seed(seed, X_all, target, prices, daily_ret, dates,
                                periods, dow, sma50, sma200, rf_daily, n)
        mets.append(m)
    s = np.array([m['sortino'] for m in mets])
    sh = np.array([m['sharpe'] for m in mets])
    r = np.array([m['total']*100 for m in mets])
    dd = np.array([m['max_dd']*100 for m in mets])
    print(f"{name:<28}  Sortino {s.mean():.2f}+/-{s.std():.2f}  "
          f"Sharpe {sh.mean():.2f}+/-{sh.std():.2f}  "
          f"Ret {r.mean():+.0f}%+/-{r.std():.0f}%  "
          f"DD {dd.mean():.1f}%")
    return s.mean(), r.mean()


def main():
    t0 = time.time()
    print("=" * 90)
    print("V25 FINAL: YoY fixes + remove OI/FTC (not NaN)")
    print("=" * 90)
    print("References:")
    print("  V0_base      4.70  (buggy data)")
    print("  V1_no_oi_ftc 4.68  (remove OI/FTC only)")
    print("  V25f_yoy     4.61  (YoY fixes only)")
    print("  V6_fracdiff  5.08  (baseline + fracdiff)")
    print()

    prices, daily_ret, returns, vols, df = load()
    dates = df['date'].values
    n = len(prices)
    rf_daily = build_rf_daily(dates, source='auto')
    v9m.RF_DAILY_ARR = rf_daily
    v13m.RF_DAILY_ARR = rf_daily
    v22.REBAL_DOW = [4]
    dow = pd.to_datetime(dates).dayofweek
    periods = _get_retrain_periods(dates, n, v22.RETRAIN)
    sma50 = pd.Series(prices).rolling(50).mean().values
    sma200 = pd.Series(prices).rolling(200).mean().values
    ctx = (dates, n, rf_daily, dow, periods, sma50, sma200)

    df_yoy = apply_yoy_fix(df)

    # Load V24 dataset to get fracdiff columns, merge into df_yoy
    df_v24 = pd.read_csv(DATASET_V24)
    df_v24['date'] = pd.to_datetime(df_v24['date'])
    df_v24 = df_v24.sort_values('date').reset_index(drop=True)
    df_yoy_frac = df_yoy.copy()
    for c in ['price_fracdiff_05', 'fed_fracdiff_05']:
        df_yoy_frac[c] = df_v24[c].values

    feats_no_oi_ftc = [f for f in BASELINE if f not in ('open_interest', 'futures_trade_count')]

    # V25_FINAL: YoY fixed + remove OI/FTC
    run_set('V25_FINAL', feats_no_oi_ftc, df_yoy,
            prices, daily_ret, returns, vols, ctx)

    # V25_FINAL+fracdiff: add fracdiff on top
    feats_with_frac = feats_no_oi_ftc + ['price_fracdiff_05', 'fed_fracdiff_05']
    run_set('V25_FINAL+fracdiff', feats_with_frac, df_yoy_frac,
            prices, daily_ret, returns, vols, ctx)

    elapsed = (time.time() - t0) / 60
    print()
    print("=" * 90)
    print(f"TOTAL: {elapsed:.1f} min")
    print("=" * 90)


if __name__ == '__main__':
    main()
