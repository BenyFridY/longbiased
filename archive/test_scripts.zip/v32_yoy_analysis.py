"""V32 year-over-year analysis for 3 candidate configs:
  1. V29 current prod (baseline_default, floor=-0.25) — with short
  2. V31.7 (baseline_floor0)                          — no short
  3. log_target_floor0                                — no short + log target

For each: per-year return + per-year accuracy (all days and Friday).
Uses 3 seeds for robustness.
"""
import sys, time, json, gc
import numpy as np, pandas as pd
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import xgboost as xgb

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

import archive.old_pipelines.pipeline_v22 as v22
from archive.old_pipelines.pipeline_v09 import build_ml_features, backtest_allocations, COST
from scripts.production.training import _get_retrain_periods
from src.features.macro.cdi_rates import build_rf_daily
import archive.old_pipelines.pipeline_v09 as v9m
import archive.old_pipelines.pipeline_v13 as v13m
from scripts.production.config import FEATURES_37, BAGS, HORIZON, WORKERS, EMERGENCY_THRESHOLD

DATASET = ROOT / "outputs" / "feature_selection" / "dataset_enhanced.csv"
RESULTS = ROOT / "outputs" / "results" / "v32_yoy.json"
SEEDS = [42, 142, 242]


def load():
    df = pd.read_csv(DATASET)
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)
    prices = df['price_usd'].values
    n = len(prices)
    daily_ret = np.zeros(n)
    for i in range(1, n):
        daily_ret[i] = (prices[i] - prices[i-1]) / prices[i-1]
    returns, vols = {}, {}
    for w in [1, 3, 5, 7, 10, 14, 20, 21, 30, 45, 60]:
        r = np.zeros(n)
        for i in range(w, n): r[i] = (prices[i] - prices[i-w]) / prices[i-w]
        returns[w] = r
    for w in [5, 7, 10, 14, 21, 30]:
        vols[w] = pd.Series(daily_ret).rolling(w).std().fillna(0.02).values
    return prices, daily_ret, returns, vols, df


def get_regime(t, prices, sma50, sma200):
    if np.isnan(sma50[t]) or np.isnan(sma200[t]): return 'MILD'
    if prices[t] > sma50[t] and sma50[t] > sma200[t]: return 'BULL'
    elif prices[t] > sma200[t]: return 'MILD'
    return 'BEAR'


def _train_reg(args):
    s, Xt, yt, params, obj = args
    p = dict(params); p.pop('objective', None)
    allowed = {k:v for k,v in p.items() if k in
               ['max_leaves','colsample_bytree','subsample','learning_rate',
                'min_child_weight','reg_alpha','reg_lambda','grow_policy','tree_method']}
    m = xgb.XGBRegressor(n_estimators=p.pop('n_estimators', 200),
                          random_state=s, objective=obj, n_jobs=1, verbosity=0, **allowed)
    m.fit(Xt, yt)
    return m


def _train_cls(args):
    s, Xt, yb, params = args
    rng = np.random.RandomState(s)
    idx = rng.choice(len(Xt), size=len(Xt), replace=True)
    p = dict(params); p.pop('objective', None)
    allowed = {k:v for k,v in p.items() if k in
               ['max_leaves','colsample_bytree','subsample','learning_rate',
                'min_child_weight','reg_alpha','reg_lambda','grow_policy','tree_method']}
    m = xgb.XGBClassifier(n_estimators=p.pop('n_estimators', 200),
                           random_state=s, objective='binary:logistic',
                           eval_metric='logloss', n_jobs=1, **allowed)
    m.fit(Xt[idx], yb[idx])
    return m


def train_and_predict(seed, X_all, target, prices, daily_ret, periods, n,
                       target_transform=None):
    """Train V23 pipeline, return reg_preds[n], cls_probs[n]."""
    params = v22.XGB_PARAMS
    reg_preds = np.zeros(n)
    cls_probs = np.full(n, 0.5)

    for te, ts, tend in periods:
        gap = max(HORIZON, 5)
        tm = np.arange(60, te - gap + 1)
        valid = ~np.any(np.isnan(X_all[tm]), axis=1)
        idx = tm[valid]
        if len(idx) < 100: continue
        Xt = np.nan_to_num(X_all[idx], nan=0.0)
        yt_raw = target[idx]
        if target_transform == 'log':
            yt = np.sign(yt_raw) * np.log(1 + np.abs(yt_raw))
        else:
            yt = yt_raw

        bag_seeds = [seed + i * 7 for i in range(BAGS)]
        args_r = [(s, Xt, yt, params, 'reg:squarederror') for s in bag_seeds]
        with ThreadPoolExecutor(max_workers=WORKERS) as ex:
            reg_models = list(ex.map(_train_reg, args_r))

        yb = (yt_raw > 0).astype(int)
        args_c = [(s, Xt, yb, params) for s in bag_seeds]
        with ThreadPoolExecutor(max_workers=WORKERS) as ex:
            cls_models = list(ex.map(_train_cls, args_c))

        X_test = np.nan_to_num(X_all[ts:tend + 1], nan=0.0)
        rp = np.mean([m.predict(X_test) for m in reg_models], axis=0)
        cp = np.mean([m.predict_proba(X_test)[:, 1] for m in cls_models], axis=0)

        if target_transform == 'log':
            rp = np.sign(rp) * (np.exp(np.abs(rp)) - 1)

        reg_preds[ts:tend + 1] = rp
        cls_probs[ts:tend + 1] = cp

        del reg_models, cls_models; gc.collect()

    return reg_preds, cls_probs


def evaluate(reg_preds, cls_probs, prices, daily_ret, dates, periods, dow, sma50, sma200,
             rf_daily, n, alloc_min=-0.25, sigmoid_scale=15):
    """Apply decision layer, return (allocations[n], strategy_ret[per_day_from_start], target[n])."""
    K = {'BULL': 60, 'MILD': 30, 'BEAR': 15}
    full_allocs = np.full(n, 0.0)
    prev_alloc = 0.0
    all_strat_ret = np.zeros(n)

    for te, ts, tend in periods:
        for t in range(ts, tend + 1):
            prediction = reg_preds[t]
            p_up = cls_probs[t]
            conf = abs(p_up - 0.5)
            conf_factor = float(1.0 / (1.0 + np.exp(-conf * sigmoid_scale)))

            is_rebal = dow[t] in [4]
            is_emerg = t > 0 and abs(daily_ret[t]) > EMERGENCY_THRESHOLD
            if not is_rebal and not is_emerg:
                full_allocs[t] = prev_alloc; continue

            regime = get_regime(t, prices, sma50, sma200)
            Kv = K[regime]
            raw = prediction * Kv * conf_factor
            full_allocs[t] = float(np.clip(raw, alloc_min, 1.0))
            prev_alloc = full_allocs[t]

        s, b, a = backtest_allocations(daily_ret, full_allocs, ts, tend,
                                        cost=COST, rf_daily=rf_daily)
        for i, d in enumerate(range(ts, ts + len(s))):
            all_strat_ret[d] = s[i]

    return full_allocs, all_strat_ret


def yoy_breakdown(allocs, strat_ret, reg_preds, cls_probs, target, daily_ret, dates, dow,
                    sigmoid_scale=15):
    """Compute per-year return + per-year accuracy."""
    ds = pd.to_datetime(dates)
    years = ds.year
    unique_years = sorted(set(years[years >= 2022]))

    rows = []
    for y in unique_years:
        mask = years == y
        if not mask.any(): continue
        strat_y = strat_ret[mask]
        bench_y = daily_ret[mask]
        # Total return per year (compound)
        strat_total = np.prod(1 + strat_y) - 1 if len(strat_y) > 0 else 0
        bench_total = np.prod(1 + bench_y) - 1 if len(bench_y) > 0 else 0
        # Accuracy per year
        preds_y = reg_preds[mask] * np.array([1.0 / (1.0 + np.exp(-abs(cls_probs[mask][i] - 0.5) * sigmoid_scale))
                                              for i in range(mask.sum())])
        actuals_y = target[mask]
        dow_y = dow[mask]
        pred_mask = np.abs(preds_y) > 1e-6
        acc_all = (np.sign(preds_y[pred_mask]) == np.sign(actuals_y[pred_mask])).mean() if pred_mask.sum() > 0 else None
        fri_mask = pred_mask & (dow_y == 4)
        acc_fri = (np.sign(preds_y[fri_mask]) == np.sign(actuals_y[fri_mask])).mean() if fri_mask.sum() > 10 else None
        # Avg allocation
        avg_alloc = allocs[mask].mean()

        rows.append({
            'year': int(y),
            'strat_ret': float(strat_total * 100),
            'btc_ret': float(bench_total * 100),
            'excess_ret': float((strat_total - bench_total) * 100),
            'acc_all': float(acc_all * 100) if acc_all else None,
            'acc_fri': float(acc_fri * 100) if acc_fri else None,
            'avg_alloc': float(avg_alloc),
            'days': int(mask.sum()),
        })
    return rows


def main():
    t0 = time.time()
    print("=" * 100, flush=True)
    print("V32 Year-over-Year analysis — 3 candidate configs", flush=True)
    print("=" * 100, flush=True)

    prices, daily_ret, returns, vols, df = load()
    dates = df['date'].values
    n = len(prices)
    rf_daily = build_rf_daily(dates, source='auto')
    v9m.RF_DAILY_ARR = rf_daily
    v13m.RF_DAILY_ARR = rf_daily
    dow = pd.to_datetime(dates).dayofweek.values
    periods = _get_retrain_periods(dates, n, v22.RETRAIN)
    sma50 = pd.Series(prices).rolling(50).mean().values
    sma200 = pd.Series(prices).rolling(200).mean().values

    target = np.zeros(n)
    for i in range(n - HORIZON):
        target[i] = (prices[i + HORIZON] - prices[i]) / prices[i]

    feats_v29 = list(FEATURES_37)
    X_v29, fnames = build_ml_features(df, returns, vols, n, feature_cols=feats_v29)
    print(f"{n} rows, {X_v29.shape[1]} features\n", flush=True)

    # Train baseline (same for V29 prod and V31.7 — decision layer differs)
    print(f"[{time.strftime('%H:%M:%S')}] Training baseline x 3 seeds...", flush=True)
    t1 = time.time()
    baseline = {'reg': [], 'cls': []}
    for s in SEEDS:
        print(f"  seed {s}...", flush=True)
        rp, cp = train_and_predict(s, X_v29, target, prices, daily_ret, periods, n)
        baseline['reg'].append(rp); baseline['cls'].append(cp)
    print(f"  {(time.time()-t1)/60:.1f}m", flush=True)

    # Train log_target
    print(f"\n[{time.strftime('%H:%M:%S')}] Training log_target x 3 seeds...", flush=True)
    t1 = time.time()
    log_base = {'reg': [], 'cls': []}
    for s in SEEDS:
        print(f"  seed {s}...", flush=True)
        rp, cp = train_and_predict(s, X_v29, target, prices, daily_ret, periods, n,
                                    target_transform='log')
        log_base['reg'].append(rp); log_base['cls'].append(cp)
    print(f"  {(time.time()-t1)/60:.1f}m", flush=True)

    # Evaluate 3 configs
    configs = [
        ('V29_prod (with short)', baseline, -0.25),
        ('V31.7 (no short)',      baseline, 0.0),
        ('log_target + no short', log_base, 0.0),
    ]

    all_results = {}
    for name, base, alloc_min in configs:
        print(f"\n{'='*100}\n{name}\n{'='*100}", flush=True)
        yoy_per_seed = []
        for si, s in enumerate(SEEDS):
            allocs, strat = evaluate(base['reg'][si], base['cls'][si], prices, daily_ret,
                                      dates, periods, dow, sma50, sma200, rf_daily, n,
                                      alloc_min=alloc_min)
            rows = yoy_breakdown(allocs, strat, base['reg'][si], base['cls'][si],
                                  target, daily_ret, dates, dow)
            yoy_per_seed.append(rows)

        # Aggregate across seeds
        years = [r['year'] for r in yoy_per_seed[0]]
        agg_rows = []
        for yi, y in enumerate(years):
            strat_rets = [yps[yi]['strat_ret'] for yps in yoy_per_seed]
            accs_all = [yps[yi]['acc_all'] for yps in yoy_per_seed if yps[yi]['acc_all']]
            accs_fri = [yps[yi]['acc_fri'] for yps in yoy_per_seed if yps[yi]['acc_fri']]
            avg_allocs = [yps[yi]['avg_alloc'] for yps in yoy_per_seed]
            btc_r = yoy_per_seed[0][yi]['btc_ret']
            row = {
                'year': y,
                'btc_ret': btc_r,
                'strat_ret_mean': float(np.mean(strat_rets)),
                'strat_ret_std': float(np.std(strat_rets)),
                'acc_all_mean': float(np.mean(accs_all)) if accs_all else None,
                'acc_fri_mean': float(np.mean(accs_fri)) if accs_fri else None,
                'avg_alloc_mean': float(np.mean(avg_allocs)),
                'days': yoy_per_seed[0][yi]['days'],
            }
            agg_rows.append(row)
            acc_all_s = f"{row['acc_all_mean']:.1f}%" if row['acc_all_mean'] else 'n/a'
            acc_fri_s = f"{row['acc_fri_mean']:.1f}%" if row['acc_fri_mean'] else 'n/a'
            print(f"  {y}:  strat={row['strat_ret_mean']:+.1f}% +/- {row['strat_ret_std']:.1f}%  "
                  f"btc={btc_r:+.1f}%  excess={row['strat_ret_mean']-btc_r:+.1f}pp  "
                  f"acc_all={acc_all_s}  fri={acc_fri_s}  avg_alloc={row['avg_alloc_mean']:+.2f}",
                  flush=True)

        all_results[name] = agg_rows

    RESULTS.parent.mkdir(parents=True, exist_ok=True)
    with open(RESULTS, 'w') as f:
        json.dump(all_results, f, indent=2)
    print(f"\nSaved: {RESULTS}", flush=True)
    print(f"TOTAL: {(time.time()-t0)/60:.1f}m", flush=True)


if __name__ == '__main__':
    main()
