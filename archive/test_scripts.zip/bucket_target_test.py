"""
BUCKET TARGET TEST — Classification vs Regression

Instead of predicting continuous ret_3d, classify into buckets:
  - Strong Down: ret_3d < -3%
  - Down:        -3% <= ret_3d < -1%
  - Flat:        -1% <= ret_3d < +1%
  - Up:          +1% <= ret_3d < +3%
  - Strong Up:   ret_3d >= +3%

Then map class probabilities to allocation.

Compares:
  A) V22 baseline (regression, as-is)
  B) Classification with XGBClassifier, proba-weighted allocation

Usage:
    python scripts/optimization/bucket_target_test.py
"""
import sys, gc, json, numpy as np, pandas as pd
from pathlib import Path
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
import xgboost as xgb
import warnings; warnings.filterwarnings('ignore')
sys.stdout.reconfigure(line_buffering=True)

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

from archive.old_pipelines.pipeline_v09 import (
    load_data, build_ml_features, backtest_allocations,
    COST, P, convert_numpy,
)
from archive.old_pipelines.pipeline_v10 import MODELS
from archive.old_pipelines.pipeline_v13 import _get_retrain_periods, _train_one_xgb

XGB_PARAMS_REG = {
    'max_leaves': 31, 'grow_policy': 'lossguide', 'tree_method': 'hist',
    'colsample_bytree': 0.5, 'subsample': 0.8,
    'learning_rate': 0.05, 'min_child_weight': 12,
    'n_estimators': 200, 'objective': 'reg:squarederror',
    'verbosity': 0, 'nthread': 1,
}

XGB_PARAMS_CLF = {
    'max_leaves': 31, 'grow_policy': 'lossguide', 'tree_method': 'hist',
    'colsample_bytree': 0.5, 'subsample': 0.8,
    'learning_rate': 0.05, 'min_child_weight': 12,
    'n_estimators': 200, 'objective': 'multi:softprob',
    'num_class': 5, 'eval_metric': 'mlogloss',
    'verbosity': 0, 'nthread': 1,
}

K_REGIME = {'BULL': 50, 'MILD': 30, 'BEAR': 15}
ALLOC_MIN = -0.25
ALLOC_MAX = 1.0
BAGS = 80
HORIZON = 3
REBAL_DOW = [4]
EMERGENCY_THRESHOLD = 0.08
WORKERS = 16

BASE_FEATURES = [f for f in MODELS['37feat'] if f != 'exchange_netflow_ma7'] + ['basis_pct']
EXTRA_FEATURES = [
    'fed_balance_sheet', 'futures_trade_count',
    'vol_x_regime_duration', 'velocity', 'hash_rate_pctchg_30d',
]

# Bucket boundaries for classification
BUCKET_EDGES = [-np.inf, -0.03, -0.01, 0.01, 0.03, np.inf]
BUCKET_LABELS = [0, 1, 2, 3, 4]  # strong_down, down, flat, up, strong_up
# Expected return per bucket (rough midpoints for allocation mapping)
BUCKET_RETURNS = [-0.05, -0.02, 0.0, 0.02, 0.05]


def get_regime(t, prices, sma50, sma200):
    if np.isnan(sma50[t]) or np.isnan(sma200[t]):
        return 'MILD'
    if prices[t] > sma50[t] and sma50[t] > sma200[t]:
        return 'BULL'
    elif prices[t] > sma200[t]:
        return 'MILD'
    return 'BEAR'


def ret_to_bucket(ret):
    for i in range(len(BUCKET_EDGES) - 1):
        if ret < BUCKET_EDGES[i + 1]:
            return i
    return len(BUCKET_EDGES) - 2


def _train_one_clf(args):
    seed, Xt, yt_classes, params = args
    p = dict(params)
    p['random_state'] = seed
    model = xgb.XGBClassifier(**p)
    model.fit(Xt, yt_classes)
    return model


def proba_to_prediction(proba):
    """Convert class probabilities to expected return."""
    expected = sum(p * r for p, r in zip(proba, BUCKET_RETURNS))
    return expected


def metrics_v22(s, b, a, rf_daily=None):
    if len(s) < 10:
        return None
    if rf_daily is None:
        rf_daily = 0.0
    ts = np.prod(1 + s) - 1
    tb = np.prod(1 + b) - 1
    ex = s - rf_daily
    downside = np.minimum(ex, 0.0)
    dd_std = np.sqrt(np.mean(downside ** 2))
    sortino = np.mean(ex) / (dd_std + 1e-10) * np.sqrt(365)
    sharpe = np.mean(ex) / (np.std(s) + 1e-10) * np.sqrt(365)
    cum = np.cumprod(1 + s)
    pk = np.maximum.accumulate(cum)
    max_dd = np.min((cum - pk) / (pk + 1e-10))
    return {
        'total': ts, 'btc': tb, 'sortino': sortino, 'sharpe': sharpe,
        'max_dd': max_dd, 'avg_alloc': float(np.mean(a)),
    }


def run_regression(seed, X_all, target, prices, daily_ret, dates, periods,
                   dow, sma50, sma200, rf_daily, n):
    """Standard V22 regression approach."""
    full_allocs = np.full(n, 0.0)
    prev_alloc = 0.0
    a_s, a_b, a_a, a_r = [], [], [], []
    n_correct = 0
    n_total = 0

    for te, ts, tend in periods:
        gap = max(HORIZON, 5)
        tm = np.arange(60, te - gap + 1)
        valid = ~np.any(np.isnan(X_all[tm]), axis=1)
        idx = tm[valid]
        if len(idx) < 100:
            continue

        Xt = np.nan_to_num(X_all[idx], nan=0.0)
        yt = target[idx]

        bag_seeds = [seed + i * 7 for i in range(BAGS)]
        with ThreadPoolExecutor(max_workers=WORKERS) as ex:
            models = list(ex.map(_train_one_xgb,
                [(s, Xt, yt, XGB_PARAMS_REG) for s in bag_seeds]))

        for t in range(ts, tend + 1):
            is_rebal = dow[t] in REBAL_DOW
            is_emerg = t > 0 and abs(daily_ret[t]) > EMERGENCY_THRESHOLD
            if not is_rebal and not is_emerg:
                full_allocs[t] = prev_alloc
                continue

            x_t = np.nan_to_num(X_all[t:t + 1].copy(), nan=0.0)
            prediction = float(np.mean([m.predict(x_t)[0] for m in models]))
            regime = get_regime(t, prices, sma50, sma200)
            K = K_REGIME[regime]
            full_allocs[t] = np.clip(prediction * K, ALLOC_MIN, ALLOC_MAX)
            prev_alloc = full_allocs[t]

            if t + HORIZON < n:
                actual = target[t]
                if (prediction > 0 and actual > 0) or (prediction < 0 and actual < 0):
                    n_correct += 1
                n_total += 1

        s, b, a = backtest_allocations(daily_ret, full_allocs, ts, tend,
                                       cost=COST, rf_daily=rf_daily)
        a_s.extend(s); a_b.extend(b); a_a.extend(a)
        a_r.extend(rf_daily[ts:ts + len(s)])
        del models; gc.collect()

    m = metrics_v22(np.array(a_s), np.array(a_b), np.array(a_a), rf_daily=np.array(a_r))
    if m:
        m['accuracy'] = n_correct / n_total if n_total > 0 else 0
    return m


def run_classification(seed, X_all, target, prices, daily_ret, dates, periods,
                       dow, sma50, sma200, rf_daily, n):
    """Classification approach: predict bucket, map to allocation via expected return."""
    target_classes = np.array([ret_to_bucket(t) for t in target])

    full_allocs = np.full(n, 0.0)
    prev_alloc = 0.0
    a_s, a_b, a_a, a_r = [], [], [], []
    n_correct = 0
    n_correct_dir = 0
    n_total = 0

    for te, ts, tend in periods:
        gap = max(HORIZON, 5)
        tm = np.arange(60, te - gap + 1)
        valid = ~np.any(np.isnan(X_all[tm]), axis=1)
        idx = tm[valid]
        if len(idx) < 100:
            continue

        Xt = np.nan_to_num(X_all[idx], nan=0.0)
        yt_cls = target_classes[idx]

        bag_seeds = [seed + i * 7 for i in range(BAGS)]
        with ThreadPoolExecutor(max_workers=WORKERS) as ex:
            models = list(ex.map(_train_one_clf,
                [(s, Xt, yt_cls, XGB_PARAMS_CLF) for s in bag_seeds]))

        for t in range(ts, tend + 1):
            is_rebal = dow[t] in REBAL_DOW
            is_emerg = t > 0 and abs(daily_ret[t]) > EMERGENCY_THRESHOLD
            if not is_rebal and not is_emerg:
                full_allocs[t] = prev_alloc
                continue

            x_t = np.nan_to_num(X_all[t:t + 1].copy(), nan=0.0)
            # Average class probabilities across bags
            all_proba = np.array([m.predict_proba(x_t)[0] for m in models])
            avg_proba = all_proba.mean(axis=0)

            # Map probabilities to expected return
            prediction = proba_to_prediction(avg_proba)

            regime = get_regime(t, prices, sma50, sma200)
            K = K_REGIME[regime]
            full_allocs[t] = np.clip(prediction * K, ALLOC_MIN, ALLOC_MAX)
            prev_alloc = full_allocs[t]

            if t + HORIZON < n:
                actual = target[t]
                actual_bucket = ret_to_bucket(actual)
                pred_bucket = np.argmax(avg_proba)
                if pred_bucket == actual_bucket:
                    n_correct += 1
                if (prediction > 0 and actual > 0) or (prediction < 0 and actual < 0):
                    n_correct_dir += 1
                n_total += 1

        s, b, a = backtest_allocations(daily_ret, full_allocs, ts, tend,
                                       cost=COST, rf_daily=rf_daily)
        a_s.extend(s); a_b.extend(b); a_a.extend(a)
        a_r.extend(rf_daily[ts:ts + len(s)])
        del models; gc.collect()

    m = metrics_v22(np.array(a_s), np.array(a_b), np.array(a_a), rf_daily=np.array(a_r))
    if m:
        m['bucket_accuracy'] = n_correct / n_total if n_total > 0 else 0
        m['dir_accuracy'] = n_correct_dir / n_total if n_total > 0 else 0
    return m


def main():
    NUM_SEEDS = 3
    seeds = [42 + i * 100 for i in range(NUM_SEEDS)]

    P("=" * 80)
    P("BUCKET TARGET TEST — Classification vs Regression")
    P("=" * 80)
    P(f"  Buckets: Strong Down (<-3%), Down (-3 to -1%), Flat (-1 to +1%),")
    P(f"           Up (+1 to +3%), Strong Up (>+3%)")
    P(f"  Seeds: {NUM_SEEDS}")
    P("")

    start = datetime.now()

    P("Loading data...")
    prices, daily_ret, returns, vols, df = load_data()
    dates = df['date'].values
    n = len(prices)

    try:
        from src.features.macro.cdi_rates import build_rf_daily
        rf_daily = build_rf_daily(dates, source='auto')
    except Exception:
        from src.features.macro.cdi_rates import build_rf_daily
        rf_daily = build_rf_daily(dates, source='copom')

    import archive.old_pipelines.pipeline_v09 as v9m
    import archive.old_pipelines.pipeline_v13 as v13m
    v9m.RF_DAILY_ARR = rf_daily
    v13m.RF_DAILY_ARR = rf_daily

    fc = BASE_FEATURES + [f for f in EXTRA_FEATURES if f not in BASE_FEATURES]
    fc = [f for f in fc if f in df.columns]

    X_all, _ = build_ml_features(df, returns, vols, n, feature_cols=fc)

    target = np.zeros(n)
    for i in range(n - HORIZON):
        target[i] = (prices[i + HORIZON] - prices[i]) / prices[i]

    # Show bucket distribution
    oos_target = target[730:]  # rough OOS start
    buckets = [ret_to_bucket(t) for t in oos_target if t != 0]
    bucket_names = ['Strong Down', 'Down', 'Flat', 'Up', 'Strong Up']
    P("Target bucket distribution (OOS):")
    for i, name in enumerate(bucket_names):
        count = buckets.count(i)
        P(f"  {name:<12}: {count:>4} ({count/len(buckets)*100:.1f}%)")
    P("")

    dow = pd.to_datetime(dates).dayofweek
    periods = _get_retrain_periods(dates, n, 'semi')
    sma50 = pd.Series(prices).rolling(50).mean().values
    sma200 = pd.Series(prices).rolling(200).mean().values

    # Run regression (baseline)
    P("=" * 60)
    P("  A) REGRESSION (V22 baseline)")
    P("=" * 60)
    reg_metrics = []
    for si, seed in enumerate(seeds):
        P(f"  Seed {seed} ({si+1}/{NUM_SEEDS})...")
        m = run_regression(seed, X_all, target, prices, daily_ret, dates,
                          periods, dow, sma50, sma200, rf_daily, n)
        reg_metrics.append(m)
        P(f"    Sortino={m['sortino']:.2f}  Return={m['total']*100:+.0f}%  "
          f"MaxDD={m['max_dd']*100:.1f}%  Acc={m['accuracy']*100:.1f}%")

    # Run classification
    P("")
    P("=" * 60)
    P("  B) CLASSIFICATION (5 buckets)")
    P("=" * 60)
    clf_metrics = []
    for si, seed in enumerate(seeds):
        P(f"  Seed {seed} ({si+1}/{NUM_SEEDS})...")
        m = run_classification(seed, X_all, target, prices, daily_ret, dates,
                              periods, dow, sma50, sma200, rf_daily, n)
        clf_metrics.append(m)
        P(f"    Sortino={m['sortino']:.2f}  Return={m['total']*100:+.0f}%  "
          f"MaxDD={m['max_dd']*100:.1f}%  "
          f"BucketAcc={m['bucket_accuracy']*100:.1f}%  "
          f"DirAcc={m['dir_accuracy']*100:.1f}%")

    elapsed = (datetime.now() - start).total_seconds() / 60

    P("")
    P("=" * 80)
    P(f"RESULTS — {NUM_SEEDS} seeds ({elapsed:.0f} min)")
    P("=" * 80)
    P("")

    def avg(lst, key):
        return np.mean([m[key] for m in lst])

    P(f"{'Approach':<20} | {'Sortino':>8} | {'Return':>9} | {'MaxDD':>7} | {'Sharpe':>7} | {'Dir Acc':>7}")
    P("-" * 70)
    P(f"{'Regression (V22)':<20} | {avg(reg_metrics, 'sortino'):>7.2f} | "
      f"{avg(reg_metrics, 'total')*100:>+8.0f}% | "
      f"{avg(reg_metrics, 'max_dd')*100:>6.1f}% | "
      f"{avg(reg_metrics, 'sharpe'):>6.2f} | "
      f"{avg(reg_metrics, 'accuracy')*100:>5.1f}%")
    P(f"{'Classification':<20} | {avg(clf_metrics, 'sortino'):>7.2f} | "
      f"{avg(clf_metrics, 'total')*100:>+8.0f}% | "
      f"{avg(clf_metrics, 'max_dd')*100:>6.1f}% | "
      f"{avg(clf_metrics, 'sharpe'):>6.2f} | "
      f"{avg(clf_metrics, 'dir_accuracy')*100:>5.1f}%")

    P("")
    delta_s = avg(clf_metrics, 'sortino') - avg(reg_metrics, 'sortino')
    P(f"Delta Sortino: {delta_s:+.2f}")
    if delta_s > 0.1:
        P(">> Classification IMPROVES on regression")
    elif delta_s < -0.1:
        P(">> Classification is WORSE than regression")
    else:
        P(">> No meaningful difference")

    # Save
    output = {
        'test': 'bucket_target',
        'timestamp': datetime.now().isoformat(),
        'elapsed_min': elapsed,
        'n_seeds': NUM_SEEDS,
        'bucket_edges': [float(e) if np.isfinite(e) else str(e) for e in BUCKET_EDGES],
        'regression': {
            'sortino': float(avg(reg_metrics, 'sortino')),
            'return': float(avg(reg_metrics, 'total')),
            'max_dd': float(avg(reg_metrics, 'max_dd')),
            'accuracy': float(avg(reg_metrics, 'accuracy')),
        },
        'classification': {
            'sortino': float(avg(clf_metrics, 'sortino')),
            'return': float(avg(clf_metrics, 'total')),
            'max_dd': float(avg(clf_metrics, 'max_dd')),
            'dir_accuracy': float(avg(clf_metrics, 'dir_accuracy')),
            'bucket_accuracy': float(avg(clf_metrics, 'bucket_accuracy')),
        },
    }
    out_path = ROOT / 'outputs' / 'results' / 'bucket_target_test.json'
    with open(out_path, 'w') as f:
        json.dump(output, f, indent=2, default=convert_numpy)
    P(f"\nSaved: {out_path}")


if __name__ == '__main__':
    main()
