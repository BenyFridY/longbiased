"""V37 — FINAL sweep: K variants + days_since_halving on E1 (no-short).

Last round of experiments. After this: pick winner and STOP.

E1 reference: Sortino 6.441, Ret +860%, 2024 avg_alloc=+0.16 (conservative in bull).

Hypothesis: with floor=0, BEAR K matters less (can't go short). Test higher BULL/MILD K
to amplify correct bull signals without the short-side risk that hurt V32 K tests.

Also test days_since_halving (cyclic feature, never tested).

Tests (3 seeds each):
  F1: E1 + K=80/40/15
  F2: E1 + K=100/50/20
  F3: E1 + K=120/60/30
  F4: E1 + days_since_halving feature
  F5: E1 + best K from F1-F3 + days_since_halving
"""
import sys, time, gc, json
import numpy as np, pandas as pd
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import xgboost as xgb

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

import archive.old_pipelines.pipeline_v22 as v22
from archive.old_pipelines.pipeline_v09 import build_ml_features, backtest_allocations, COST
from scripts.production.training import _get_retrain_periods
from src.features.macro.cdi_rates import build_rf_daily
import archive.old_pipelines.pipeline_v09 as v9m
import archive.old_pipelines.pipeline_v13 as v13m
from scripts.production.config import FEATURES_37, BAGS, HORIZON, WORKERS, EMERGENCY_THRESHOLD

DATASET = ROOT / "scripts" / "production" / "data" / "dataset_production.csv"
RESULTS = ROOT / "outputs" / "results" / "v37_experiments.json"
SEEDS = [42, 142, 242]

# Known BTC halving dates
HALVINGS = pd.to_datetime(['2012-11-28', '2016-07-09', '2020-05-11', '2024-04-19'])


def load():
    df = pd.read_csv(DATASET)
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)
    prices = df['price_usd'].values
    n = len(prices)
    daily_ret = np.zeros(n)
    for i in range(1, n): daily_ret[i] = (prices[i] - prices[i-1]) / prices[i-1]
    returns, vols = {}, {}
    for w in [1,3,5,7,10,14,20,21,30,45,60]:
        r = np.zeros(n)
        for i in range(w, n): r[i] = (prices[i] - prices[i-w]) / prices[i-w]
        returns[w] = r
    for w in [5,7,10,14,21,30]:
        vols[w] = pd.Series(daily_ret).rolling(w).std().fillna(0.02).values
    return prices, daily_ret, returns, vols, df


def add_halving_feature(df):
    dates = pd.to_datetime(df['date'])
    out = np.zeros(len(dates))
    for i, d in enumerate(dates):
        past = HALVINGS[HALVINGS <= d]
        if len(past) == 0: out[i] = 0
        else: out[i] = (d - past.max()).days
    df['days_since_halving'] = out
    return df


def get_regime(t, prices, sma50, sma200):
    if np.isnan(sma50[t]) or np.isnan(sma200[t]): return 'MILD'
    if prices[t] > sma50[t] and sma50[t] > sma200[t]: return 'BULL'
    elif prices[t] > sma200[t]: return 'MILD'
    return 'BEAR'


def _train_reg(args):
    s, Xt, yt, params = args
    p = dict(params); p.pop('objective', None)
    allowed = {k:v for k,v in p.items() if k in
               ['max_leaves','colsample_bytree','subsample','learning_rate',
                'min_child_weight','reg_alpha','reg_lambda','grow_policy','tree_method']}
    m = xgb.XGBRegressor(n_estimators=p.pop('n_estimators', 200),
                          random_state=s, objective='reg:squarederror',
                          n_jobs=1, verbosity=0, **allowed)
    m.fit(Xt, yt); return m


def _train_cls(args):
    s, Xt, yb, params = args
    rng = np.random.RandomState(s); idx = rng.choice(len(Xt), size=len(Xt), replace=True)
    p = dict(params); p.pop('objective', None)
    allowed = {k:v for k,v in p.items() if k in
               ['max_leaves','colsample_bytree','subsample','learning_rate',
                'min_child_weight','reg_alpha','reg_lambda','grow_policy','tree_method']}
    m = xgb.XGBClassifier(n_estimators=p.pop('n_estimators', 200),
                           random_state=s, objective='binary:logistic',
                           eval_metric='logloss', n_jobs=1, **allowed)
    m.fit(Xt[idx], yb[idx]); return m


def run_one(seed, X_all, target, prices, daily_ret, dates, periods,
             dow, sma50, sma200, rf_daily, n, k_regime, alloc_min=0.0):
    params = v22.XGB_PARAMS
    full_allocs = np.full(n, 0.0); prev_alloc = 0.0
    a_s, a_b, a_a, a_r = [], [], [], []
    reg_preds = np.zeros(n); cls_probs = np.full(n, 0.5); strat_ret = np.zeros(n)
    for te, ts, tend in periods:
        gap = max(HORIZON, 5); tm = np.arange(60, te - gap + 1)
        valid = ~np.any(np.isnan(X_all[tm]), axis=1); idx = tm[valid]
        if len(idx) < 100: continue
        Xt = np.nan_to_num(X_all[idx], nan=0.0); yt = target[idx]
        bag_seeds = [seed + i*7 for i in range(BAGS)]
        with ThreadPoolExecutor(max_workers=WORKERS) as ex:
            reg_models = list(ex.map(_train_reg, [(s, Xt, yt, params) for s in bag_seeds]))
        yb = (yt > 0).astype(int)
        with ThreadPoolExecutor(max_workers=WORKERS) as ex:
            cls_models = list(ex.map(_train_cls, [(s, Xt, yb, params) for s in bag_seeds]))
        X_test = np.nan_to_num(X_all[ts:tend+1], nan=0.0)
        rp = np.mean([m.predict(X_test) for m in reg_models], axis=0)
        cp = np.mean([m.predict_proba(X_test)[:,1] for m in cls_models], axis=0)
        reg_preds[ts:tend+1] = rp; cls_probs[ts:tend+1] = cp
        for t in range(ts, tend+1):
            pred = reg_preds[t]; p_up = cls_probs[t]
            conf_factor = 1.0 / (1.0 + np.exp(-abs(p_up - 0.5) * 15))
            is_rebal = dow[t] in [4]
            is_emerg = t > 0 and abs(daily_ret[t]) > EMERGENCY_THRESHOLD
            if not is_rebal and not is_emerg: full_allocs[t] = prev_alloc; continue
            regime = get_regime(t, prices, sma50, sma200)
            raw = pred * k_regime[regime] * conf_factor
            full_allocs[t] = float(np.clip(raw, alloc_min, 1.0))
            prev_alloc = full_allocs[t]
        s, b, a = backtest_allocations(daily_ret, full_allocs, ts, tend, cost=COST, rf_daily=rf_daily)
        a_s.extend(s); a_b.extend(b); a_a.extend(a)
        a_r.extend(rf_daily[ts:ts+len(s)])
        for i in range(len(s)): strat_ret[ts+i] = s[i]
        del reg_models, cls_models; gc.collect()
    metrics = v22.metrics_v22(np.array(a_s), np.array(a_b), np.array(a_a), rf_daily=np.array(a_r))
    return metrics, reg_preds, cls_probs, full_allocs, strat_ret


def yoy(strat_ret, daily_ret, dates, years_min=2022):
    ds = pd.to_datetime(dates); years = ds.year.values
    rows = []
    for y in sorted(set(years[years >= years_min])):
        mask = years == y
        strat_y = strat_ret[mask]; bench_y = daily_ret[mask]
        st = np.prod(1 + strat_y) - 1 if len(strat_y) else 0
        bt = np.prod(1 + bench_y) - 1 if len(bench_y) else 0
        rows.append({'year': int(y), 'strat': float(st*100), 'btc': float(bt*100), 'days': int(mask.sum())})
    return rows


def run_exp(name, desc, k_regime, feature_cols, df, prices, daily_ret, returns, vols,
             dates, n, rf_daily, dow, periods, sma50, sma200, target):
    print(f"\n[{time.strftime('%H:%M:%S')}] {name}: {desc}", flush=True)
    print(f"  K={k_regime}, features={len(feature_cols)}", flush=True)
    X_all, _ = build_ml_features(df, returns, vols, n, feature_cols=feature_cols)
    outs = []
    for s in SEEDS:
        t1 = time.time()
        print(f"  seed {s}...", flush=True)
        m, rp, cp, al, sr = run_one(s, X_all, target, prices, daily_ret, dates, periods,
                                      dow, sma50, sma200, rf_daily, n, k_regime=k_regime)
        outs.append((m, rp, cp, al, sr))
        print(f"    S={m['sortino']:.2f} Ret={m['total']*100:+.0f}% ({(time.time()-t1)/60:.1f}m)", flush=True)

    S = [o[0]['sortino'] for o in outs]; R = [o[0]['total']*100 for o in outs]
    DD = [o[0]['max_dd']*100 for o in outs]
    strat_avg = np.mean([o[4] for o in outs], axis=0)
    alloc_avg = np.mean([o[3] for o in outs], axis=0)
    y_rows = yoy(strat_avg, daily_ret, dates)
    # avg alloc per year
    years = pd.to_datetime(dates).year.values
    for r in y_rows:
        mask = years == r['year']
        r['avg_alloc'] = float(alloc_avg[mask].mean())
    result = {
        'name': name, 'desc': desc,
        'sortino': float(np.mean(S)), 'sortino_std': float(np.std(S)),
        'ret': float(np.mean(R)), 'dd': float(np.mean(DD)),
        'k': k_regime, 'yoy': y_rows,
    }
    print(f"\n  SUMMARY {name}: S={result['sortino']:.3f}+/-{result['sortino_std']:.3f}  "
          f"Ret={result['ret']:+.0f}%  DD={result['dd']:.1f}%", flush=True)
    print(f"  YoY:", flush=True)
    for r in y_rows:
        print(f"    {r['year']}: strat={r['strat']:+.1f}% btc={r['btc']:+.1f}% alloc={r['avg_alloc']:+.2f}",
              flush=True)
    return result


def main():
    t0 = time.time()
    print('='*100, flush=True)
    print('V37 — K sweep + days_since_halving on E1 (no-short, 32 features)', flush=True)
    print('Reference: E1 baseline K=60/30/15 Sortino=6.441, 2024 alloc=+0.16 (conservative)', flush=True)
    print('='*100, flush=True)

    prices, daily_ret, returns, vols, df = load()
    df = add_halving_feature(df)
    print(f'Data: {len(df)} rows', flush=True)
    print(f'days_since_halving last: {df["days_since_halving"].iloc[-1]}', flush=True)

    dates = df['date'].values; n = len(prices)
    rf_daily = build_rf_daily(dates, source='auto')
    v9m.RF_DAILY_ARR = rf_daily; v13m.RF_DAILY_ARR = rf_daily
    dow = pd.to_datetime(dates).dayofweek.values
    periods = _get_retrain_periods(dates, n, v22.RETRAIN)
    sma50 = pd.Series(prices).rolling(50).mean().values
    sma200 = pd.Series(prices).rolling(200).mean().values
    target = np.zeros(n)
    for i in range(n - HORIZON): target[i] = (prices[i + HORIZON] - prices[i]) / prices[i]

    results = []
    def save():
        RESULTS.parent.mkdir(parents=True, exist_ok=True)
        with open(RESULTS, 'w') as f:
            json.dump({'results': results, 'elapsed_min': (time.time()-t0)/60}, f, indent=2)

    common = dict(df=df, prices=prices, daily_ret=daily_ret, returns=returns, vols=vols,
                   dates=dates, n=n, rf_daily=rf_daily, dow=dow, periods=periods,
                   sma50=sma50, sma200=sma200, target=target)
    base32 = list(FEATURES_37)
    base33 = base32 + ['days_since_halving']

    # F1-F3: K variants (32 features)
    r = run_exp('F1_K80_40_15', 'K=80/40/15 aggressive BULL',
                 {'BULL':80,'MILD':40,'BEAR':15}, base32, **common)
    results.append(r); save()
    r = run_exp('F2_K100_50_20', 'K=100/50/20 very aggressive',
                 {'BULL':100,'MILD':50,'BEAR':20}, base32, **common)
    results.append(r); save()
    r = run_exp('F3_K120_60_30', 'K=120/60/30 extreme (ceiling will cap)',
                 {'BULL':120,'MILD':60,'BEAR':30}, base32, **common)
    results.append(r); save()

    # F4: days_since_halving with baseline K
    r = run_exp('F4_halving', 'Base K + days_since_halving cyclic',
                 {'BULL':60,'MILD':30,'BEAR':15}, base33, **common)
    results.append(r); save()

    # F5: best K + halving
    best_k = max([r for r in results if r['name'].startswith('F1') or r['name'].startswith('F2') or r['name'].startswith('F3')],
                 key=lambda x: x['sortino'])
    print(f"\nBest K variant: {best_k['name']} (S={best_k['sortino']:.3f})", flush=True)
    r = run_exp('F5_best_K_halving', f"Best K ({best_k['name']}) + halving",
                 best_k['k'], base33, **common)
    results.append(r); save()

    # Final ranking
    elapsed = (time.time() - t0) / 60
    print(f'\n{"="*100}\nV37 DONE: {elapsed:.1f}m\n{"="*100}', flush=True)
    print(f'Reference (E1 baseline): S=6.441, Ret=+860%, 2024 alloc=+0.16\n', flush=True)
    for r in sorted(results, key=lambda x: -x['sortino']):
        print(f"  {r['name']:<22}  S={r['sortino']:.3f}+/-{r['sortino_std']:.3f}  "
              f"Ret={r['ret']:+.0f}%  DD={r['dd']:.1f}%  K={r['k']}", flush=True)
        for y in r['yoy']:
            print(f"    {y['year']}: strat={y['strat']:+.1f}% btc={y['btc']:+.1f}% alloc={y['avg_alloc']:+.2f}", flush=True)
    save()


if __name__ == '__main__':
    main()
