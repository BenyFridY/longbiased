"""
K_MILD sensitivity test — Is K_MILD=30 too aggressive given 54% accuracy in MILD regime?

Tests: K_MILD = 30 (current), 25, 20, 15, 10
All other params identical to V22.

Usage:
    python scripts/optimization/k_mild_test.py
"""
import sys, gc, json, numpy as np, pandas as pd
from pathlib import Path
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
import warnings; warnings.filterwarnings('ignore')
sys.stdout.reconfigure(line_buffering=True)

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

from archive.old_pipelines.pipeline_v09 import (
    load_data, build_ml_features, backtest_allocations,
    COST, P, convert_numpy,
)
from archive.old_pipelines.pipeline_v10 import MODELS
from archive.old_pipelines.pipeline_v13 import _get_retrain_periods, _train_one_xgb

XGB_PARAMS = {
    'max_leaves': 31, 'grow_policy': 'lossguide', 'tree_method': 'hist',
    'colsample_bytree': 0.5, 'subsample': 0.8,
    'learning_rate': 0.05, 'min_child_weight': 12,
    'n_estimators': 200, 'objective': 'reg:squarederror',
    'verbosity': 0, 'nthread': 1,
}

ALLOC_MIN = -0.25
ALLOC_MAX = 1.0
BAGS = 80
HORIZON = 3
REBAL_DOW = [4]
EMERGENCY_THRESHOLD = 0.08
WORKERS = 16

BASE_FEATURES = [f for f in MODELS['37feat'] if f != 'exchange_netflow_ma7'] + ['basis_pct']
EXTRA_FEATURES = [
    'fed_balance_sheet', 'futures_trade_count',
    'vol_x_regime_duration', 'velocity', 'hash_rate_pctchg_30d',
]

K_MILD_VALUES = [30, 25, 20, 15, 10]


def get_regime(t, prices, sma50, sma200):
    if np.isnan(sma50[t]) or np.isnan(sma200[t]):
        return 'MILD'
    if prices[t] > sma50[t] and sma50[t] > sma200[t]:
        return 'BULL'
    elif prices[t] > sma200[t]:
        return 'MILD'
    return 'BEAR'


def metrics_v22(s, b, a, rf_daily=None):
    if len(s) < 10:
        return None
    if rf_daily is None:
        rf_daily = 0.0
    ts = np.prod(1 + s) - 1
    tb = np.prod(1 + b) - 1
    ex = s - rf_daily
    downside = np.minimum(ex, 0.0)
    dd_std = np.sqrt(np.mean(downside ** 2))
    sortino = np.mean(ex) / (dd_std + 1e-10) * np.sqrt(365)
    sharpe = np.mean(ex) / (np.std(s) + 1e-10) * np.sqrt(365)
    cum = np.cumprod(1 + s)
    pk = np.maximum.accumulate(cum)
    max_dd = np.min((cum - pk) / (pk + 1e-10))
    return {
        'total': ts, 'btc': tb, 'sortino': sortino, 'sharpe': sharpe,
        'max_dd': max_dd, 'avg_alloc': float(np.mean(a)),
    }


def run_seed(seed, k_mild, X_all, target, prices, daily_ret, dates, periods,
             dow, sma50, sma200, rf_daily, n):
    K_REGIME = {'BULL': 50, 'MILD': k_mild, 'BEAR': 15}
    full_allocs = np.full(n, 0.0)
    prev_alloc = 0.0
    a_s, a_b, a_a, a_r = [], [], [], []

    # Count regime days and accuracy
    mild_correct = 0
    mild_total = 0

    for te, ts, tend in periods:
        gap = max(HORIZON, 5)
        tm = np.arange(60, te - gap + 1)
        valid = ~np.any(np.isnan(X_all[tm]), axis=1)
        idx = tm[valid]
        if len(idx) < 100:
            continue

        Xt = np.nan_to_num(X_all[idx], nan=0.0)
        yt = target[idx]

        bag_seeds = [seed + i * 7 for i in range(BAGS)]
        with ThreadPoolExecutor(max_workers=WORKERS) as ex:
            models = list(ex.map(_train_one_xgb,
                [(s, Xt, yt, XGB_PARAMS) for s in bag_seeds]))

        for t in range(ts, tend + 1):
            is_rebal = dow[t] in REBAL_DOW
            is_emerg = t > 0 and abs(daily_ret[t]) > EMERGENCY_THRESHOLD
            if not is_rebal and not is_emerg:
                full_allocs[t] = prev_alloc
                continue

            x_t = np.nan_to_num(X_all[t:t + 1].copy(), nan=0.0)
            prediction = float(np.mean([m.predict(x_t)[0] for m in models]))
            regime = get_regime(t, prices, sma50, sma200)
            K = K_REGIME[regime]
            full_allocs[t] = np.clip(prediction * K, ALLOC_MIN, ALLOC_MAX)
            prev_alloc = full_allocs[t]

            # Track MILD accuracy
            if regime == 'MILD' and t + HORIZON < n:
                actual_ret = (prices[t + HORIZON] - prices[t]) / prices[t]
                if (prediction > 0 and actual_ret > 0) or (prediction < 0 and actual_ret < 0):
                    mild_correct += 1
                mild_total += 1

        s, b, a = backtest_allocations(daily_ret, full_allocs, ts, tend,
                                       cost=COST, rf_daily=rf_daily)
        a_s.extend(s)
        a_b.extend(b)
        a_a.extend(a)
        a_r.extend(rf_daily[ts:ts + len(s)])

        del models
        gc.collect()

    m = metrics_v22(np.array(a_s), np.array(a_b), np.array(a_a),
                    rf_daily=np.array(a_r))
    if m:
        m['mild_accuracy'] = mild_correct / mild_total if mild_total > 0 else 0
        m['mild_decisions'] = mild_total
    return m


def main():
    NUM_SEEDS = 5
    seeds = [42 + i * 100 for i in range(NUM_SEEDS)]

    P("=" * 80)
    P("K_MILD SENSITIVITY TEST")
    P("=" * 80)
    P(f"  Testing K_MILD = {K_MILD_VALUES}")
    P(f"  K_BULL=50, K_BEAR=15 (fixed)")
    P(f"  Seeds: {NUM_SEEDS}")
    P("")

    start = datetime.now()

    P("Loading data...")
    prices, daily_ret, returns, vols, df = load_data()
    dates = df['date'].values
    n = len(prices)

    try:
        from src.features.macro.cdi_rates import build_rf_daily
        rf_daily = build_rf_daily(dates, source='auto')
    except Exception:
        from src.features.macro.cdi_rates import build_rf_daily
        rf_daily = build_rf_daily(dates, source='copom')

    import archive.old_pipelines.pipeline_v09 as v9m
    import archive.old_pipelines.pipeline_v13 as v13m
    v9m.RF_DAILY_ARR = rf_daily
    v13m.RF_DAILY_ARR = rf_daily

    fc = BASE_FEATURES + [f for f in EXTRA_FEATURES if f not in BASE_FEATURES]
    fc = [f for f in fc if f in df.columns]

    X_all, _ = build_ml_features(df, returns, vols, n, feature_cols=fc)

    target = np.zeros(n)
    for i in range(n - HORIZON):
        target[i] = (prices[i + HORIZON] - prices[i]) / prices[i]

    dow = pd.to_datetime(dates).dayofweek
    periods = _get_retrain_periods(dates, n, 'semi')
    sma50 = pd.Series(prices).rolling(50).mean().values
    sma200 = pd.Series(prices).rolling(200).mean().values

    all_results = {}

    for k_mild in K_MILD_VALUES:
        P(f"\n{'='*60}")
        P(f"  K_MILD = {k_mild}  (K_BULL=50, K_BEAR=15)")
        P(f"{'='*60}")

        seed_metrics = []
        for si, seed in enumerate(seeds):
            P(f"  Seed {seed} ({si+1}/{NUM_SEEDS})...")
            m = run_seed(seed, k_mild, X_all, target, prices, daily_ret,
                        dates, periods, dow, sma50, sma200, rf_daily, n)
            seed_metrics.append(m)
            P(f"    Sortino={m['sortino']:.2f}  Return={m['total']*100:+.0f}%  "
              f"MaxDD={m['max_dd']*100:.1f}%  MILD_acc={m['mild_accuracy']*100:.1f}%")

        sortinos = [m['sortino'] for m in seed_metrics]
        rets = [m['total'] * 100 for m in seed_metrics]
        dds = [m['max_dd'] * 100 for m in seed_metrics]
        sharpes = [m['sharpe'] for m in seed_metrics]
        mild_accs = [m['mild_accuracy'] for m in seed_metrics]

        all_results[k_mild] = {
            'sortino_avg': np.mean(sortinos),
            'sortino_std': np.std(sortinos),
            'return_avg': np.mean(rets),
            'return_std': np.std(rets),
            'sharpe_avg': np.mean(sharpes),
            'max_dd_avg': np.mean(dds),
            'max_dd_std': np.std(dds),
            'mild_accuracy': np.mean(mild_accs),
            'mild_decisions': seed_metrics[0]['mild_decisions'],
        }

    elapsed = (datetime.now() - start).total_seconds() / 60

    P("")
    P("=" * 90)
    P(f"K_MILD SENSITIVITY RESULTS — {NUM_SEEDS} seeds ({elapsed:.0f} min)")
    P("=" * 90)
    P("")
    P(f"{'K_MILD':>7} | {'Sortino':>14} | {'Return':>14} | {'MaxDD':>10} | {'Sharpe':>8} | {'MILD acc':>8}")
    P("-" * 80)

    best_sortino = max(r['sortino_avg'] for r in all_results.values())

    for k_mild in K_MILD_VALUES:
        r = all_results[k_mild]
        marker = " <<< BEST" if r['sortino_avg'] == best_sortino else ""
        current = " (current)" if k_mild == 30 else ""
        P(f"  K={k_mild:>3}{current:<10} | "
          f"{r['sortino_avg']:5.2f} +/- {r['sortino_std']:.2f} | "
          f"{r['return_avg']:+7.0f}% +/- {r['return_std']:3.0f}% | "
          f"{r['max_dd_avg']:6.1f}% | "
          f"{r['sharpe_avg']:6.2f} | "
          f"{r['mild_accuracy']*100:5.1f}%{marker}")

    P("")
    P(f"MILD regime accuracy: ~{all_results[30]['mild_accuracy']*100:.0f}% "
      f"({all_results[30]['mild_decisions']} rebalance decisions in MILD)")
    P("")

    # Delta vs baseline
    base = all_results[30]
    P("Delta vs K_MILD=30 (current):")
    for k_mild in K_MILD_VALUES:
        if k_mild == 30:
            continue
        r = all_results[k_mild]
        P(f"  K={k_mild:>3}: Sortino {r['sortino_avg'] - base['sortino_avg']:+.2f}, "
          f"Return {r['return_avg'] - base['return_avg']:+.0f}pp, "
          f"MaxDD {r['max_dd_avg'] - base['max_dd_avg']:+.1f}pp")

    # Save
    output = {
        'test': 'k_mild_sensitivity',
        'timestamp': datetime.now().isoformat(),
        'elapsed_min': elapsed,
        'n_seeds': NUM_SEEDS,
        'results': {str(k): convert_numpy(v) for k, v in all_results.items()},
    }
    out_path = ROOT / 'outputs' / 'results' / 'k_mild_sensitivity.json'
    with open(out_path, 'w') as f:
        json.dump(output, f, indent=2, default=convert_numpy)
    P(f"\nSaved: {out_path}")


if __name__ == '__main__':
    main()
