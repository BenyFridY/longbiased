"""V25 backtest: test the fixed dataset with 10 seeds vs baseline.

Sets:
  V25.0 = baseline with corrected dataset (37 features, same names, right math)
  V25.1 = V25.0 + fracdiff (adopt V6's learning)

Baseline is V0 (original dataset, 37 features) — should match Sortino 4.74.
If V25.0 is close to V0, fixes are safe (just cosmetic).
If V25.0 differs a lot, fixes changed the signal — report.
"""
import sys, time
import numpy as np, pandas as pd
from pathlib import Path

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

import archive.old_pipelines.pipeline_v22 as v22
from archive.old_pipelines.pipeline_v09 import build_ml_features
from scripts.production.training import _get_retrain_periods
from src.features.macro.cdi_rates import build_rf_daily
import archive.old_pipelines.pipeline_v09 as v9m
import archive.old_pipelines.pipeline_v13 as v13m

from scripts.production.config import FEATURES_37

DATASET_FIXED = ROOT / "outputs" / "feature_selection" / "dataset_enhanced_v25.csv"
DATASET_V24 = ROOT / "outputs" / "feature_selection" / "dataset_v24.csv"  # has fracdiff columns


def load(path):
    df = pd.read_csv(path)
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)
    prices = df['price_usd'].values
    n = len(prices)
    daily_ret = np.zeros(n)
    for i in range(1, n):
        daily_ret[i] = (prices[i] - prices[i-1]) / prices[i-1]
    returns, vols = {}, {}
    for w in [1, 3, 5, 7, 10, 14, 20, 21, 30, 45, 60]:
        r = np.zeros(n)
        for i in range(w, n):
            r[i] = (prices[i] - prices[i-w]) / prices[i-w]
        returns[w] = r
    for w in [5, 7, 10, 14, 21, 30]:
        vols[w] = pd.Series(daily_ret).rolling(w).std().fillna(0.02).values
    return prices, daily_ret, returns, vols, df


def build_context(prices, daily_ret, returns, vols, df):
    dates = df['date'].values
    n = len(prices)
    rf_daily = build_rf_daily(dates, source='auto')
    v9m.RF_DAILY_ARR = rf_daily
    v13m.RF_DAILY_ARR = rf_daily
    v22.REBAL_DOW = [4]
    dow = pd.to_datetime(dates).dayofweek
    periods = _get_retrain_periods(dates, n, v22.RETRAIN)
    sma50 = pd.Series(prices).rolling(50).mean().values
    sma200 = pd.Series(prices).rolling(200).mean().values
    return dates, n, rf_daily, dow, periods, sma50, sma200


def run_set(name, feats, df, prices, daily_ret, returns, vols, ctx, seeds):
    dates, n, rf_daily, dow, periods, sma50, sma200 = ctx
    missing = [f for f in feats if f not in df.columns]
    if missing:
        print(f"  [{name}] MISSING: {missing}")
        return None
    X_all, _ = build_ml_features(df, returns, vols, n, feature_cols=feats)
    target = np.zeros(n)
    for i in range(n - v22.HORIZON):
        target[i] = (prices[i + v22.HORIZON] - prices[i]) / prices[i]
    mets = []
    for seed in seeds:
        m = v22.run_single_seed(seed, X_all, target, prices, daily_ret, dates,
                                periods, dow, sma50, sma200, rf_daily, n)
        mets.append(m)
    return mets


def summ(name, mets, n_feats):
    s = np.array([m['sortino'] for m in mets])
    sh = np.array([m['sharpe'] for m in mets])
    r = np.array([m['total']*100 for m in mets])
    dd = np.array([m['max_dd']*100 for m in mets])
    print(f"{name:<30} {n_feats:>3}  Sortino {s.mean():.2f}+/-{s.std():.2f}  "
          f"Sharpe {sh.mean():.2f}+/-{sh.std():.2f}  "
          f"Ret {r.mean():+.0f}%+/-{r.std():.0f}%  "
          f"DD {dd.mean():.1f}%+/-{dd.std():.1f}%")
    return s.mean(), r.mean()


BASELINE = list(FEATURES_37)
SEEDS = [42, 142, 242]  # 3 seeds for fast validation


def main():
    t0 = time.time()
    print("=" * 90)
    print("V25 BACKTEST — fixed dataset, 10 seeds each")
    print("=" * 90)

    # Load fixed dataset
    prices, daily_ret, returns, vols, df_fixed = load(DATASET_FIXED)
    ctx = build_context(prices, daily_ret, returns, vols, df_fixed)

    # Load V24 dataset (has fracdiff columns) for V25.1
    df_v24 = pd.read_csv(DATASET_V24)
    df_v24['date'] = pd.to_datetime(df_v24['date'])
    # Merge fracdiff columns into fixed dataset
    for c in ['price_fracdiff_05', 'fed_fracdiff_05']:
        if c in df_v24.columns:
            df_fixed[c] = df_v24.sort_values('date').reset_index(drop=True)[c].values

    print(f"\nDataset: {len(df_fixed)} rows, {df_fixed['date'].min().date()} -> {df_fixed['date'].max().date()}")
    print(f"Seeds: {SEEDS}\n")

    print(f"{'Set':<30} {'N':>3}  {'Metrics':<80}")
    print('-' * 120)

    # V25.0: baseline with fixed dataset
    t1 = time.time()
    mets = run_set('V25.0_fixed_baseline', BASELINE, df_fixed,
                    prices, daily_ret, returns, vols, ctx, SEEDS)
    if mets:
        s25, r25 = summ('V25.0_fixed_baseline', mets, len(BASELINE))
        print(f"  ({(time.time()-t1)/60:.1f}m)")

    # V25.1: fixed baseline + fracdiff
    t1 = time.time()
    feats_1 = BASELINE + ['price_fracdiff_05', 'fed_fracdiff_05']
    mets = run_set('V25.1_fixed_+fracdiff', feats_1, df_fixed,
                    prices, daily_ret, returns, vols, ctx, SEEDS)
    if mets:
        s25f, r25f = summ('V25.1_fixed_+fracdiff', mets, len(feats_1))
        print(f"  ({(time.time()-t1)/60:.1f}m)")

    print()
    print("=" * 90)
    print(f"TOTAL: {(time.time()-t0)/60:.1f} min")
    print("=" * 90)
    print()
    print("Reference (V24 final 10 seeds):")
    print("  V0_baseline   Sortino 4.74  Ret +1047%  DD -9.9%")
    print("  V6_fracdiff   Sortino 5.09  Ret +1071%  DD -10.0%")


if __name__ == '__main__':
    main()
