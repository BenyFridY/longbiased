"""
V24: build an enriched dataset with fixed + new features, ready for backtesting.

Fixes confirmed as bugs (100%):
  - m2_yoy_growth: pct_change(52) on daily ffilled = 52 days (was supposed to be 52 weeks=1y)
  - fed_bs_yoy_change: same bug
  - m2_3m_growth: pct_change(13) = 13 days (was supposed to be 3 months)
  - open_interest: 1100+ days of garbage before 2022 (constant $35,756, even a $17.80 day)
  - futures_trade_count: 132 days with <100 counts (missing/partial data)

New features added:
  - m2_yoy_real = pct_change(252)  ~1 business year
  - fed_bs_yoy_real = pct_change(252)
  - m2_3m_real = pct_change(63)
  - open_interest_clean: NaN before 2022-01-01, z-score 180d after
  - futures_trade_count_clean: NaN for days with count<1000, z-score 90d after
  - fed_balance_sheet_pctchg_90d (normalize level)
  - mvrv_ratio = price / realized_price
  - mvrv_zscore_365d = (price - realized_price) / std(price - realized_price, 365d)
  - puell_multiple = miners_revenue / rolling_365d_mean
  - puell_zscore_365d
  - days_since_halving (from dataset if present)
  - log_return_1d_fracdiff (0.5) — fractional differentiation
  - price_fracdiff — stationary but with memory
  - nupl_x_halving = nupl_ma30 * log(days_since_halving + 1)
  - basis_x_vol = basis_pct * volatility_30d
  - sopr_x_percentile = sopr * price_percentile_1y
"""
import pandas as pd, numpy as np
from pathlib import Path

ROOT = Path(__file__).parent.parent.parent
SRC = ROOT / "outputs" / "feature_selection" / "dataset_enhanced.csv"
OUT = ROOT / "outputs" / "feature_selection" / "dataset_v24.csv"


def fractional_diff(series, d=0.5, thres=0.01):
    """López de Prado fractional differentiation (FFD - fixed-window)."""
    # Compute weights up to threshold
    w = [1.0]
    k = 1
    while abs(w[-1]) > thres and k < len(series):
        w.append(-w[-1] * (d - k + 1) / k)
        k += 1
    w = np.array(w[::-1])  # oldest first when applied

    arr = series.values
    out = np.full(len(arr), np.nan)
    W = len(w)
    for i in range(W - 1, len(arr)):
        window = arr[i - W + 1:i + 1]
        if np.any(np.isnan(window)):
            continue
        out[i] = (w * window).sum()
    return pd.Series(out, index=series.index)


def main():
    print("Loading dataset_enhanced.csv ...")
    df = pd.read_csv(SRC)
    df['date'] = pd.to_datetime(df['date'])
    print(f"  {len(df)} rows, {len(df.columns)} columns")

    # =========================================================================
    # FIX 1: m2 / fed YoY calculations
    # =========================================================================
    # Original uses pct_change(52) on DAILY data = 52 days, not 52 weeks.
    # True YoY = pct_change(252) business days or pct_change(365) calendar days.
    if 'm2_supply' in df.columns:
        df['m2_yoy_real'] = df['m2_supply'].pct_change(252)
        df['m2_3m_real'] = df['m2_supply'].pct_change(63)
    if 'fed_balance_sheet' in df.columns:
        df['fed_bs_yoy_real'] = df['fed_balance_sheet'].pct_change(252)
        df['fed_bs_pctchg_90d'] = df['fed_balance_sheet'].pct_change(90)

    # =========================================================================
    # FIX 2: open_interest / futures_trade_count — clean + normalize
    # =========================================================================
    # OI is garbage before 2022-01-01 (constant fake, or $17 outlier)
    # Futures trade count is unreliable when <1000 (missing days)
    if 'open_interest' in df.columns:
        oi_clean = df['open_interest'].copy()
        oi_clean = oi_clean.where(df['date'] >= '2022-01-01', np.nan)
        oi_clean = oi_clean.where(oi_clean > 1e7, np.nan)  # >$10M reasonable floor
        df['open_interest_clean'] = oi_clean
        df['open_interest_z180'] = (oi_clean - oi_clean.rolling(180, min_periods=30).mean()) / \
                                    oi_clean.rolling(180, min_periods=30).std()
        df['open_interest_z180'] = df['open_interest_z180'].fillna(0)

    if 'futures_trade_count' in df.columns:
        ftc = df['futures_trade_count'].copy()
        ftc = ftc.where(ftc > 1000, np.nan)
        df['futures_trade_count_clean'] = ftc
        df['futures_trade_count_z90'] = (ftc - ftc.rolling(90, min_periods=20).mean()) / \
                                         ftc.rolling(90, min_periods=20).std()
        df['futures_trade_count_z90'] = df['futures_trade_count_z90'].fillna(0)

    # =========================================================================
    # NEW: MVRV Z-score — valuation metric
    # =========================================================================
    if 'realized_price' in df.columns:
        spread = df['price_usd'] - df['realized_price']
        df['mvrv_ratio'] = df['price_usd'] / df['realized_price']
        df['mvrv_zscore_365d'] = spread / spread.rolling(365, min_periods=60).std()
        df['mvrv_zscore_365d'] = df['mvrv_zscore_365d'].clip(-5, 5).fillna(0)

    # =========================================================================
    # NEW: Puell Multiple — miner stress indicator
    # =========================================================================
    if 'miners_revenue_usd' in df.columns:
        mr = df['miners_revenue_usd']
        ma365 = mr.rolling(365, min_periods=60).mean()
        df['puell_multiple'] = mr / ma365
        std365 = df['puell_multiple'].rolling(365, min_periods=60).std()
        df['puell_zscore_365d'] = (df['puell_multiple'] - df['puell_multiple'].rolling(365, min_periods=60).mean()) / std365
        df['puell_zscore_365d'] = df['puell_zscore_365d'].clip(-5, 5).fillna(0)

    # =========================================================================
    # NEW: fractional differentiation (Lopez de Prado)
    # =========================================================================
    # d=0.5 preserves more memory than d=1 (returns); d=0.3 even more memory
    print("Computing fractional differentiation (d=0.5, may take a moment)...")
    df['price_fracdiff_05'] = fractional_diff(np.log(df['price_usd']), d=0.5)
    if 'fed_balance_sheet' in df.columns:
        df['fed_fracdiff_05'] = fractional_diff(np.log(df['fed_balance_sheet']), d=0.5)
    if 'open_interest_clean' in df.columns:
        # only fracdiff where data is valid
        oi_log = np.log(df['open_interest_clean'].where(df['open_interest_clean'] > 0))
        df['oi_fracdiff_05'] = fractional_diff(oi_log, d=0.5)

    # =========================================================================
    # NEW: Interaction features
    # =========================================================================
    if 'nupl_ma30' in df.columns and 'days_since_halving' in df.columns:
        df['nupl_x_halving'] = df['nupl_ma30'] * np.log1p(df['days_since_halving'])
    if 'basis_pct' in df.columns and 'volatility_30d' in df.columns:
        df['basis_x_vol'] = df['basis_pct'] * df['volatility_30d']
    if 'sopr' in df.columns and 'price_percentile_1y' in df.columns:
        df['sopr_x_percentile'] = df['sopr'] * df['price_percentile_1y']
    if 'mvrv_zscore_365d' in df.columns and 'hurst_60d' in df.columns:
        df['mvrv_x_hurst'] = df['mvrv_zscore_365d'] * df['hurst_60d']

    # =========================================================================
    # Sanity check
    # =========================================================================
    new_feats = [
        'm2_yoy_real', 'm2_3m_real', 'fed_bs_yoy_real', 'fed_bs_pctchg_90d',
        'open_interest_clean', 'open_interest_z180',
        'futures_trade_count_clean', 'futures_trade_count_z90',
        'mvrv_ratio', 'mvrv_zscore_365d',
        'puell_multiple', 'puell_zscore_365d',
        'price_fracdiff_05', 'fed_fracdiff_05', 'oi_fracdiff_05',
        'nupl_x_halving', 'basis_x_vol', 'sopr_x_percentile', 'mvrv_x_hurst',
    ]
    print(f"\n{'feature':<32} {'min':>10} {'max':>10} {'mean':>10} {'valid':>10}")
    print('-' * 75)
    for f in new_feats:
        if f in df.columns:
            v = df[f]
            print(f'{f:<32} {v.min():>10.3f} {v.max():>10.3f} {v.mean():>10.3f} {v.notna().sum():>10}')

    df.to_csv(OUT, index=False)
    print(f"\nSaved: {OUT} ({len(df)} rows, {len(df.columns)} columns)")


if __name__ == '__main__':
    main()
