"""Recompute fracdiff with d=0.3 in dataset_enhanced.csv (was d=0.5)."""
import sys
import numpy as np, pandas as pd
from pathlib import Path

ROOT = Path(__file__).parent.parent.parent
DATASET = ROOT / "outputs" / "feature_selection" / "dataset_enhanced.csv"


def fractional_diff(series, d=0.3, thres=0.01):
    w = [1.0]
    k = 1
    while abs(w[-1]) > thres and k < len(series):
        w.append(-w[-1] * (d - k + 1) / k)
        k += 1
    w = np.array(w[::-1])
    arr = series.values
    out = np.full(len(arr), np.nan)
    W = len(w)
    for i in range(W - 1, len(arr)):
        window = arr[i - W + 1:i + 1]
        if np.any(np.isnan(window)):
            continue
        out[i] = (w * window).sum()
    return pd.Series(out, index=series.index)


def main():
    print("Loading dataset_enhanced.csv...")
    df = pd.read_csv(DATASET)
    df['date'] = pd.to_datetime(df['date'])
    print(f"  {len(df)} rows")

    print("\nRecomputing fracdiff with d=0.3 (was d=0.5)...")
    old_p = df['price_fracdiff_05'].copy()
    df['price_fracdiff_05'] = fractional_diff(np.log(df['price_usd']), d=0.3)
    print(f"  price_fracdiff_05: old mean={old_p.mean():.4f}, new mean={df['price_fracdiff_05'].mean():.4f}")

    old_f = df['fed_fracdiff_05'].copy()
    fed_log = np.log(df['fed_balance_sheet'].replace(0, np.nan))
    df['fed_fracdiff_05'] = fractional_diff(fed_log, d=0.3)
    print(f"  fed_fracdiff_05: old mean={old_f.mean():.4f}, new mean={df['fed_fracdiff_05'].mean():.4f}")

    df.to_csv(DATASET, index=False)
    print(f"\nSaved: {DATASET}")


if __name__ == '__main__':
    main()
