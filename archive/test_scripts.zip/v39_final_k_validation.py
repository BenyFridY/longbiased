"""V39 — FINAL 10-seed validation of 2 K variants on E1 D7 combo no-short.

The final model is E1 (29 V29 features + 3 V36 on-chain + floor=0).
Only open decision: K regime. Test 2 candidates with 10 seeds for statistical rigor.

Tests (10 seeds each):
  H1: E1 + K=60/30/15 (conservative, max Sortino) — current config
  H2: E1 + K=100/50/20 (balanced aggressive, V37 F2)

This is the FINAL test. After this: decide and stop.
"""
import sys, time, gc, json
import numpy as np, pandas as pd
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import xgboost as xgb

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

import archive.old_pipelines.pipeline_v22 as v22
from archive.old_pipelines.pipeline_v09 import build_ml_features, backtest_allocations, COST
from scripts.production.training import _get_retrain_periods
from src.features.macro.cdi_rates import build_rf_daily
import archive.old_pipelines.pipeline_v09 as v9m
import archive.old_pipelines.pipeline_v13 as v13m
from scripts.production.config import FEATURES_37, BAGS, HORIZON, WORKERS, EMERGENCY_THRESHOLD

DATASET = ROOT / "scripts" / "production" / "data" / "dataset_production.csv"
RESULTS = ROOT / "outputs" / "results" / "v39_final_k.json"
SEEDS_10 = [42, 142, 242, 342, 442, 542, 642, 742, 842, 942]
K_VARIANTS = {
    'H1_conservative': {'BULL': 60, 'MILD': 30, 'BEAR': 15},
    'H2_balanced':     {'BULL': 100, 'MILD': 50, 'BEAR': 20},
}


def load():
    df = pd.read_csv(DATASET)
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)
    prices = df['price_usd'].values
    n = len(prices)
    daily_ret = np.zeros(n)
    for i in range(1, n): daily_ret[i] = (prices[i] - prices[i-1]) / prices[i-1]
    returns, vols = {}, {}
    for w in [1,3,5,7,10,14,20,21,30,45,60]:
        r = np.zeros(n)
        for i in range(w, n): r[i] = (prices[i] - prices[i-w]) / prices[i-w]
        returns[w] = r
    for w in [5,7,10,14,21,30]:
        vols[w] = pd.Series(daily_ret).rolling(w).std().fillna(0.02).values
    return prices, daily_ret, returns, vols, df


def get_regime(t, prices, sma50, sma200):
    if np.isnan(sma50[t]) or np.isnan(sma200[t]): return 'MILD'
    if prices[t] > sma50[t] and sma50[t] > sma200[t]: return 'BULL'
    elif prices[t] > sma200[t]: return 'MILD'
    return 'BEAR'


def _train_reg(args):
    s, Xt, yt, params = args
    p = dict(params); p.pop('objective', None)
    allowed = {k:v for k,v in p.items() if k in
               ['max_leaves','colsample_bytree','subsample','learning_rate',
                'min_child_weight','reg_alpha','reg_lambda','grow_policy','tree_method']}
    m = xgb.XGBRegressor(n_estimators=p.pop('n_estimators', 200),
                          random_state=s, objective='reg:squarederror',
                          n_jobs=1, verbosity=0, **allowed)
    m.fit(Xt, yt); return m


def _train_cls(args):
    s, Xt, yb, params = args
    rng = np.random.RandomState(s); idx = rng.choice(len(Xt), size=len(Xt), replace=True)
    p = dict(params); p.pop('objective', None)
    allowed = {k:v for k,v in p.items() if k in
               ['max_leaves','colsample_bytree','subsample','learning_rate',
                'min_child_weight','reg_alpha','reg_lambda','grow_policy','tree_method']}
    m = xgb.XGBClassifier(n_estimators=p.pop('n_estimators', 200),
                           random_state=s, objective='binary:logistic',
                           eval_metric='logloss', n_jobs=1, **allowed)
    m.fit(Xt[idx], yb[idx]); return m


def run_one(seed, X_all, target, prices, daily_ret, dates, periods,
             dow, sma50, sma200, rf_daily, n, k_regime):
    params = v22.XGB_PARAMS
    full_allocs = np.full(n, 0.0); prev_alloc = 0.0
    a_s, a_b, a_a, a_r = [], [], [], []
    reg_preds = np.zeros(n); cls_probs = np.full(n, 0.5); strat_ret = np.zeros(n)
    for te, ts, tend in periods:
        gap = max(HORIZON, 5); tm = np.arange(60, te - gap + 1)
        valid = ~np.any(np.isnan(X_all[tm]), axis=1); idx = tm[valid]
        if len(idx) < 100: continue
        Xt = np.nan_to_num(X_all[idx], nan=0.0); yt = target[idx]
        bag_seeds = [seed + i*7 for i in range(BAGS)]
        with ThreadPoolExecutor(max_workers=WORKERS) as ex:
            reg_models = list(ex.map(_train_reg, [(s, Xt, yt, params) for s in bag_seeds]))
        yb = (yt > 0).astype(int)
        with ThreadPoolExecutor(max_workers=WORKERS) as ex:
            cls_models = list(ex.map(_train_cls, [(s, Xt, yb, params) for s in bag_seeds]))
        X_test = np.nan_to_num(X_all[ts:tend+1], nan=0.0)
        rp = np.mean([m.predict(X_test) for m in reg_models], axis=0)
        cp = np.mean([m.predict_proba(X_test)[:,1] for m in cls_models], axis=0)
        reg_preds[ts:tend+1] = rp; cls_probs[ts:tend+1] = cp
        for t in range(ts, tend+1):
            pred = reg_preds[t]; p_up = cls_probs[t]
            conf_factor = 1.0 / (1.0 + np.exp(-abs(p_up - 0.5) * 15))
            is_rebal = dow[t] in [4]
            is_emerg = t > 0 and abs(daily_ret[t]) > EMERGENCY_THRESHOLD
            if not is_rebal and not is_emerg: full_allocs[t] = prev_alloc; continue
            regime = get_regime(t, prices, sma50, sma200)
            raw = pred * k_regime[regime] * conf_factor
            full_allocs[t] = float(np.clip(raw, 0.0, 1.0))
            prev_alloc = full_allocs[t]
        s, b, a = backtest_allocations(daily_ret, full_allocs, ts, tend, cost=COST, rf_daily=rf_daily)
        a_s.extend(s); a_b.extend(b); a_a.extend(a)
        a_r.extend(rf_daily[ts:ts+len(s)])
        for i in range(len(s)): strat_ret[ts+i] = s[i]
        del reg_models, cls_models; gc.collect()
    metrics = v22.metrics_v22(np.array(a_s), np.array(a_b), np.array(a_a), rf_daily=np.array(a_r))
    return metrics, reg_preds, cls_probs, full_allocs, strat_ret


def main():
    t0 = time.time()
    print('='*100, flush=True)
    print('V39 — FINAL 10-seed validation: 2 K variants on E1 no-short', flush=True)
    print('  H1: K=60/30/15 (conservative, max Sortino)', flush=True)
    print('  H2: K=100/50/20 (balanced aggressive, V37 F2)', flush=True)
    print('='*100, flush=True)

    prices, daily_ret, returns, vols, df = load()
    print(f'Data: {len(df)} rows, last={df.date.max()}', flush=True)
    dates = df['date'].values; n = len(prices)
    rf_daily = build_rf_daily(dates, source='auto')
    v9m.RF_DAILY_ARR = rf_daily; v13m.RF_DAILY_ARR = rf_daily
    dow = pd.to_datetime(dates).dayofweek.values
    periods = _get_retrain_periods(dates, n, v22.RETRAIN)
    sma50 = pd.Series(prices).rolling(50).mean().values
    sma200 = pd.Series(prices).rolling(200).mean().values
    target = np.zeros(n)
    for i in range(n - HORIZON): target[i] = (prices[i + HORIZON] - prices[i]) / prices[i]

    feats = list(FEATURES_37)
    X_all, _ = build_ml_features(df, returns, vols, n, feature_cols=feats)
    print(f'Features: {X_all.shape[1]}\n', flush=True)

    results = {}
    def save():
        RESULTS.parent.mkdir(parents=True, exist_ok=True)
        with open(RESULTS, 'w') as f:
            json.dump({'results': results, 'elapsed_min': (time.time()-t0)/60}, f, indent=2)

    for name, K in K_VARIANTS.items():
        print(f"\n{'='*100}\n[{time.strftime('%H:%M:%S')}] {name} K={K} (10 seeds)\n{'='*100}", flush=True)
        outs = []
        for i, s in enumerate(SEEDS_10):
            t1 = time.time()
            print(f"  {i+1}/10 (seed={s})...", flush=True)
            m, rp, cp, al, sr = run_one(s, X_all, target, prices, daily_ret, dates, periods,
                                          dow, sma50, sma200, rf_daily, n, k_regime=K)
            outs.append((m, rp, cp, al, sr))
            print(f"    S={m['sortino']:.2f} Ret={m['total']*100:+.0f}% ({(time.time()-t1)/60:.1f}m)", flush=True)

        S = [o[0]['sortino'] for o in outs]; R = [o[0]['total']*100 for o in outs]
        DD = [o[0]['max_dd']*100 for o in outs]
        SH = [o[0].get('sharpe', 0) for o in outs]
        strat_avg = np.mean([o[4] for o in outs], axis=0)
        alloc_avg = np.mean([o[3] for o in outs], axis=0)
        # YoY
        years = pd.to_datetime(dates).year.values
        yoy_rows = []
        for y in sorted(set(years[years >= 2022])):
            mask = years == y
            strat_y = strat_avg[mask]; bench_y = daily_ret[mask]
            st = np.prod(1 + strat_y) - 1 if len(strat_y) else 0
            bt = np.prod(1 + bench_y) - 1 if len(bench_y) else 0
            yoy_rows.append({'year': int(y),
                             'strat': float(st*100),
                             'btc': float(bt*100),
                             'alloc': float(alloc_avg[mask].mean()),
                             'days': int(mask.sum())})
        results[name] = {
            'K': K,
            'sortino_mean': float(np.mean(S)), 'sortino_std': float(np.std(S)),
            'ret_mean': float(np.mean(R)), 'ret_std': float(np.std(R)),
            'dd_mean': float(np.mean(DD)), 'sharpe_mean': float(np.mean(SH)),
            'yoy': yoy_rows,
            'n_seeds': len(SEEDS_10),
        }
        save()

        print(f"\n  AGG {name}: Sortino={np.mean(S):.3f}+/-{np.std(S):.3f}  "
              f"Ret={np.mean(R):+.0f}% +/- {np.std(R):.0f}%  DD={np.mean(DD):.1f}%  Sharpe={np.mean(SH):.2f}", flush=True)
        for r in yoy_rows:
            print(f"    {r['year']}: strat={r['strat']:+7.1f}%  btc={r['btc']:+7.1f}%  alloc={r['alloc']:+.2f}",
                  flush=True)

    # Final comparison
    print(f"\n{'='*100}\nV39 DONE: {(time.time()-t0)/60:.1f}m\n{'='*100}", flush=True)
    print('\nFINAL COMPARISON (10 seeds each):', flush=True)
    for name, r in results.items():
        print(f"\n  {name} K={r['K']}:", flush=True)
        print(f"    Sortino: {r['sortino_mean']:.3f} ± {r['sortino_std']:.3f}", flush=True)
        print(f"    Return:  {r['ret_mean']:+.0f}% ± {r['ret_std']:.0f}%", flush=True)
        print(f"    DD:      {r['dd_mean']:.1f}%", flush=True)
        print(f"    Sharpe:  {r['sharpe_mean']:.2f}", flush=True)
    save()


if __name__ == '__main__':
    main()
