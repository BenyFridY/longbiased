"""V30: refinements on V29 winner.

Baseline (V29.4 already in production):
  Sortino 5.34+/-0.06, Ret +1165%, 29 features, fracdiff d=0.3

V30 tests:

  T1 — GRANULAR d SWEEP around 0.3: d in {0.2, 0.25, 0.3, 0.35, 0.4}
        Check if 0.3 is truly optimal or if 0.25/0.35 is better.

  T2 — REMOVE MORE FEATURES (top-12 by low importance)
        8 already removed; check if removing 4 more (positions 9-12) helps.

  T3 — ADD FRACDIFF TO MORE FEATURES
        Apply fracdiff to volatility_7d, eth, kpss_stat_30d (features with trend/drift).

All 3 seeds (V29 winner already 10-seed validated, this is exploration).
"""
import sys, time, json, gc
import numpy as np, pandas as pd
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import xgboost as xgb

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

import archive.old_pipelines.pipeline_v22 as v22
from archive.old_pipelines.pipeline_v09 import build_ml_features, backtest_allocations, COST
from scripts.production.training import _get_retrain_periods, _train_one_xgb
from src.features.macro.cdi_rates import build_rf_daily
import archive.old_pipelines.pipeline_v09 as v9m
import archive.old_pipelines.pipeline_v13 as v13m
from scripts.production.config import FEATURES_37, K_REGIME, ALLOC_MIN, ALLOC_MAX, BAGS, HORIZON, WORKERS, EMERGENCY_THRESHOLD

DATASET = ROOT / "outputs" / "feature_selection" / "dataset_enhanced.csv"
SEEDS_3 = [42, 142, 242]
RESULTS = ROOT / "outputs" / "results" / "v30_refinements.json"


def load():
    df = pd.read_csv(DATASET)
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)
    prices = df['price_usd'].values
    n = len(prices)
    daily_ret = np.zeros(n)
    for i in range(1, n):
        daily_ret[i] = (prices[i] - prices[i-1]) / prices[i-1]
    returns, vols = {}, {}
    for w in [1, 3, 5, 7, 10, 14, 20, 21, 30, 45, 60]:
        r = np.zeros(n)
        for i in range(w, n):
            r[i] = (prices[i] - prices[i-w]) / prices[i-w]
        returns[w] = r
    for w in [5, 7, 10, 14, 21, 30]:
        vols[w] = pd.Series(daily_ret).rolling(w).std().fillna(0.02).values
    return prices, daily_ret, returns, vols, df


def fractional_diff(series, d=0.5, thres=0.01):
    w = [1.0]; k = 1
    while abs(w[-1]) > thres and k < len(series):
        w.append(-w[-1] * (d - k + 1) / k); k += 1
    w = np.array(w[::-1])
    arr = series.values if hasattr(series, 'values') else np.asarray(series)
    out = np.full(len(arr), np.nan)
    W = len(w)
    for i in range(W - 1, len(arr)):
        window = arr[i - W + 1:i + 1]
        if np.any(np.isnan(window)): continue
        out[i] = (w * window).sum()
    return out


def get_regime(t, prices, sma50, sma200):
    if np.isnan(sma50[t]) or np.isnan(sma200[t]): return 'MILD'
    if prices[t] > sma50[t] and sma50[t] > sma200[t]: return 'BULL'
    elif prices[t] > sma200[t]: return 'MILD'
    return 'BEAR'


def compute_allocation(pred, regime):
    return float(np.clip(pred * K_REGIME[regime], ALLOC_MIN, ALLOC_MAX))


def run_seed(seed, X_all, target, prices, daily_ret, dates, periods,
             dow, sma50, sma200, rf_daily, n):
    full_allocs = np.full(n, 0.0)
    prev_alloc = 0.0
    a_s, a_b, a_a, a_r = [], [], [], []
    for te, ts, tend in periods:
        gap = max(HORIZON, 5)
        tm = np.arange(60, te - gap + 1)
        valid = ~np.any(np.isnan(X_all[tm]), axis=1)
        idx = tm[valid]
        if len(idx) < 100: continue
        Xt = np.nan_to_num(X_all[idx], nan=0.0)
        yt = target[idx]
        bag_seeds = [seed + i * 7 for i in range(BAGS)]
        with ThreadPoolExecutor(max_workers=WORKERS) as ex:
            models = list(ex.map(_train_one_xgb,
                [(s, Xt, yt, v22.XGB_PARAMS) for s in bag_seeds]))
        for t in range(ts, tend + 1):
            x_t = np.nan_to_num(X_all[t:t + 1].copy(), nan=0.0)
            prediction = float(np.mean([m.predict(x_t)[0] for m in models]))
            is_rebal = dow[t] in [4]
            is_emerg = t > 0 and abs(daily_ret[t]) > EMERGENCY_THRESHOLD
            if not is_rebal and not is_emerg:
                full_allocs[t] = prev_alloc; continue
            regime = get_regime(t, prices, sma50, sma200)
            full_allocs[t] = compute_allocation(prediction, regime)
            prev_alloc = full_allocs[t]
        s, b, a = backtest_allocations(daily_ret, full_allocs, ts, tend,
                                       cost=COST, rf_daily=rf_daily)
        a_s.extend(s); a_b.extend(b); a_a.extend(a)
        a_r.extend(rf_daily[ts:ts + len(s)])
        del models; gc.collect()
    return v22.metrics_v22(np.array(a_s), np.array(a_b), np.array(a_a),
                            rf_daily=np.array(a_r))


def agg(name, metrics_list, n_feats):
    s = np.array([m['sortino'] for m in metrics_list])
    r = np.array([m['total']*100 for m in metrics_list])
    d = np.array([m['max_dd']*100 for m in metrics_list])
    print(f"{name:<28} N={n_feats}  S={s.mean():.2f}+/-{s.std():.2f}  "
          f"Ret={r.mean():+.0f}%+/-{r.std():.0f}%  DD={d.mean():.1f}%")
    return {'name': name, 'n_feats': n_feats,
            'sortino_mean': float(s.mean()), 'sortino_std': float(s.std()),
            'ret_mean': float(r.mean()), 'dd_mean': float(d.mean())}


def main():
    t0 = time.time()
    print("=" * 85)
    print("V30 REFINEMENTS on V29 winner")
    print("Reference V29.4: S=5.34+/-0.06, Ret=+1165%, 29 feats, d=0.3")
    print("=" * 85)

    prices, daily_ret, returns, vols, df = load()
    dates = df['date'].values
    n = len(prices)
    rf_daily = build_rf_daily(dates, source='auto')
    v9m.RF_DAILY_ARR = rf_daily
    v13m.RF_DAILY_ARR = rf_daily
    dow = pd.to_datetime(dates).dayofweek.values
    periods = _get_retrain_periods(dates, n, v22.RETRAIN)
    sma50 = pd.Series(prices).rolling(50).mean().values
    sma200 = pd.Series(prices).rolling(200).mean().values

    # V29 config: 29 features (already applied to config.py)
    feats_v29 = list(FEATURES_37)
    X_v29, fnames = build_ml_features(df, returns, vols, n, feature_cols=feats_v29)

    log_prices = np.log(prices)
    fed_log = np.log(df['fed_balance_sheet'].replace(0, np.nan).values)
    target = np.zeros(n)
    for i in range(n - HORIZON):
        target[i] = (prices[i + HORIZON] - prices[i]) / prices[i]

    results = []
    def save():
        RESULTS.parent.mkdir(parents=True, exist_ok=True)
        with open(RESULTS, 'w') as f:
            json.dump({'results': results, 'elapsed_min': (time.time()-t0)/60}, f, indent=2)

    # ── T1: Granular d sweep ──
    print("\n-- T1: Granular d sweep around 0.3 --")
    for d_val in [0.20, 0.25, 0.30, 0.35, 0.40]:
        X = X_v29.copy()
        if 'price_fracdiff_05' in fnames:
            X[:, fnames.index('price_fracdiff_05')] = fractional_diff(log_prices, d=d_val)
        if 'fed_fracdiff_05' in fnames:
            X[:, fnames.index('fed_fracdiff_05')] = fractional_diff(fed_log, d=d_val)
        mets = [run_seed(s, X, target, prices, daily_ret, dates, periods,
                          dow, sma50, sma200, rf_daily, n) for s in SEEDS_3]
        results.append(agg(f'T1_d{int(d_val*100):03d}', mets, len(feats_v29))); save()

    # ── T2: Remove MORE features ──
    # Recompute importance on V29 set, remove bottom-N more
    print("\n-- T2: Feature importance on V29 set (rank bottom) --")
    idx_tr = np.arange(60, n - 5)
    valid_tr = ~np.any(np.isnan(X_v29[idx_tr]), axis=1)
    idx_tr = idx_tr[valid_tr]
    Xt = np.nan_to_num(X_v29[idx_tr], nan=0.0)
    yt = target[idx_tr]
    p = dict(v22.XGB_PARAMS); p['random_state'] = 42
    ne = p.pop('n_estimators', 200)
    m = xgb.XGBRegressor(n_estimators=ne, **p)
    m.fit(Xt, yt)
    imp = dict(zip(fnames, m.feature_importances_))
    imp_sorted = sorted(imp.items(), key=lambda x: x[1])
    print("  Bottom-6 on V29 set:")
    for feat, val in imp_sorted[:6]:
        print(f"    {feat:<32} {val:.4f}")

    for n_remove in [2, 4, 6]:
        remove_set = set(f for f, _ in imp_sorted[:n_remove])
        keep_idx = [i for i, f in enumerate(fnames) if f not in remove_set]
        X_r = X_v29[:, keep_idx]
        mets = [run_seed(s, X_r, target, prices, daily_ret, dates, periods,
                          dow, sma50, sma200, rf_daily, n) for s in SEEDS_3]
        results.append(agg(f'T2_remove_{n_remove}_more', mets, len(keep_idx))); save()

    # ── T3: Add fracdiff to more features (volatility_7d, eth, kpss_stat_30d) ──
    print("\n-- T3: fracdiff on other features --")
    for feat_name, base_col in [('vol_fracdiff', 'volatility_7d'),
                                 ('eth_fracdiff', 'eth')]:
        if base_col not in df.columns:
            continue
        # Add as new column
        X_aug = np.column_stack([X_v29, fractional_diff(df[base_col], d=0.3)])
        mets = [run_seed(s, X_aug, target, prices, daily_ret, dates, periods,
                          dow, sma50, sma200, rf_daily, n) for s in SEEDS_3]
        results.append(agg(f'T3_add_{feat_name}', mets, X_aug.shape[1])); save()

    print()
    print("=" * 85)
    print(f"V30 TOTAL: {(time.time()-t0)/60:.1f} min")
    print("=" * 85)
    print("\nRanked by Sortino:")
    for r in sorted(results, key=lambda x: -x['sortino_mean']):
        print(f"  {r['name']:<28}  N={r['n_feats']}  S={r['sortino_mean']:.2f}+/-{r['sortino_std']:.2f}  "
              f"Ret={r['ret_mean']:+.0f}%  DD={r['dd_mean']:.1f}%")
    save()


if __name__ == '__main__':
    main()
