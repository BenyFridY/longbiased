"""V36 — 10-seed validation of top candidates on fresh dataset.

Top candidates from V33/V34/V35:
  E0: B0 baseline (V31.7 equiv, 29 features, floor=0, fresh data) — REFERENCE
  E1: B0 + btc_dominance (C1 winner)
  E2: Best D-experiment from V35 (determined at runtime)
  E3: B0 + btc_dominance + best_onchain_mfill (combo)

Each with 10 seeds for statistical rigor.
"""
import sys, time, json, gc
import numpy as np, pandas as pd
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import xgboost as xgb

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

import archive.old_pipelines.pipeline_v22 as v22
from archive.old_pipelines.pipeline_v09 import build_ml_features, backtest_allocations, COST
from scripts.production.training import _get_retrain_periods
from src.features.macro.cdi_rates import build_rf_daily
import archive.old_pipelines.pipeline_v09 as v9m
import archive.old_pipelines.pipeline_v13 as v13m
from scripts.production.config import FEATURES_37, BAGS, HORIZON, WORKERS, EMERGENCY_THRESHOLD

DATASET = ROOT / "scripts" / "production" / "data" / "dataset_production.csv"
NEW_FEATURES = ROOT / "scripts" / "production" / "data" / "v34_features.csv"
V35_RESULTS = ROOT / "outputs" / "results" / "v35_experiments.json"
RESULTS = ROOT / "outputs" / "results" / "v36_validation.json"

SEEDS_10 = [42, 142, 242, 342, 442, 542, 642, 742, 842, 942]
DAY_NAMES = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun']
K_DEFAULT = {'BULL': 60, 'MILD': 30, 'BEAR': 15}


def median_fill(series):
    s = pd.Series(series.values if hasattr(series, 'values') else series)
    first_valid_idx = s.first_valid_index()
    if first_valid_idx is None: return s.values
    available = s.loc[first_valid_idx:].dropna().iloc[:30]
    fill_val = available.median() if len(available) > 0 else 0
    return s.fillna(fill_val).values


def load_data():
    df = pd.read_csv(DATASET); df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)
    new = pd.read_csv(NEW_FEATURES); new['date'] = pd.to_datetime(new['date'])
    df = df.merge(new, on='date', how='left')
    for col in ['sopr','mvrv','puellMultiple','reserveRisk',
                'funding_rate_mean','funding_rate_min','funding_rate_max']:
        if col in df.columns: df[col] = median_fill(df[col])
    df['funding_rate_ma7'] = df['funding_rate_mean'].rolling(7, min_periods=1).mean()
    df['fear_greed_ma7'] = df['fear_greed'].rolling(7, min_periods=1).mean()

    prices = df['price_usd'].values; n = len(prices)
    daily_ret = np.zeros(n)
    for i in range(1, n): daily_ret[i] = (prices[i] - prices[i-1]) / prices[i-1]
    returns, vols = {}, {}
    for w in [1,3,5,7,10,14,20,21,30,45,60]:
        r = np.zeros(n)
        for i in range(w, n): r[i] = (prices[i] - prices[i-w]) / prices[i-w]
        returns[w] = r
    for w in [5,7,10,14,21,30]:
        vols[w] = pd.Series(daily_ret).rolling(w).std().fillna(0.02).values
    return prices, daily_ret, returns, vols, df


def fetch_btc_dominance(min_date, max_date):
    from google.cloud import bigquery
    client = bigquery.Client(project='hdx-data-platform')
    q = f'''
    SELECT reference_date AS date, coin_dominance_with_stablecoins AS btc_dominance
    FROM `hdx-data-platform.refined.messari_total_marketcap_and_coin_dominance`
    WHERE symbol='BTC' AND reference_date BETWEEN '{min_date}' AND '{max_date}'
    ORDER BY reference_date
    '''
    df = client.query(q).to_dataframe()
    df['date'] = pd.to_datetime(df['date'])
    df = df.drop_duplicates('date').sort_values('date').reset_index(drop=True)
    df['btc_dominance'] = df['btc_dominance'].astype(float)
    return df


def _train_reg(args):
    s, Xt, yt, params = args
    p = dict(params); p.pop('objective', None)
    allowed = {k:v for k,v in p.items() if k in
               ['max_leaves','colsample_bytree','subsample','learning_rate',
                'min_child_weight','reg_alpha','reg_lambda','grow_policy','tree_method']}
    m = xgb.XGBRegressor(n_estimators=p.pop('n_estimators', 200),
                          random_state=s, objective='reg:squarederror',
                          n_jobs=1, verbosity=0, **allowed)
    m.fit(Xt, yt); return m


def _train_cls(args):
    s, Xt, yb, params = args
    rng = np.random.RandomState(s); idx = rng.choice(len(Xt), size=len(Xt), replace=True)
    p = dict(params); p.pop('objective', None)
    allowed = {k:v for k,v in p.items() if k in
               ['max_leaves','colsample_bytree','subsample','learning_rate',
                'min_child_weight','reg_alpha','reg_lambda','grow_policy','tree_method']}
    m = xgb.XGBClassifier(n_estimators=p.pop('n_estimators', 200),
                           random_state=s, objective='binary:logistic',
                           eval_metric='logloss', n_jobs=1, **allowed)
    m.fit(Xt[idx], yb[idx]); return m


def get_regime(t, prices, sma50, sma200):
    if np.isnan(sma50[t]) or np.isnan(sma200[t]): return 'MILD'
    if prices[t] > sma50[t] and sma50[t] > sma200[t]: return 'BULL'
    elif prices[t] > sma200[t]: return 'MILD'
    return 'BEAR'


def run_one(seed, X_all, target, prices, daily_ret, dates, periods,
             dow, sma50, sma200, rf_daily, n, alloc_min=0.0):
    params = v22.XGB_PARAMS
    full_allocs = np.full(n, 0.0); prev_alloc = 0.0
    a_s, a_b, a_a, a_r = [], [], [], []
    reg_preds = np.zeros(n); cls_probs = np.full(n, 0.5); strat_ret = np.zeros(n)

    for te, ts, tend in periods:
        gap = max(HORIZON, 5); tm = np.arange(60, te - gap + 1)
        valid = ~np.any(np.isnan(X_all[tm]), axis=1); idx = tm[valid]
        if len(idx) < 100: continue
        Xt = np.nan_to_num(X_all[idx], nan=0.0); yt = target[idx]
        bag_seeds = [seed + i * 7 for i in range(BAGS)]
        with ThreadPoolExecutor(max_workers=WORKERS) as ex:
            reg_models = list(ex.map(_train_reg, [(s, Xt, yt, params) for s in bag_seeds]))
        yb = (yt > 0).astype(int)
        with ThreadPoolExecutor(max_workers=WORKERS) as ex:
            cls_models = list(ex.map(_train_cls, [(s, Xt, yb, params) for s in bag_seeds]))

        X_test = np.nan_to_num(X_all[ts:tend+1], nan=0.0)
        rp = np.mean([m.predict(X_test) for m in reg_models], axis=0)
        cp = np.mean([m.predict_proba(X_test)[:, 1] for m in cls_models], axis=0)
        reg_preds[ts:tend+1] = rp; cls_probs[ts:tend+1] = cp

        for t in range(ts, tend + 1):
            pred = reg_preds[t]; p_up = cls_probs[t]
            conf = abs(p_up - 0.5)
            conf_factor = float(1.0 / (1.0 + np.exp(-conf * 15)))
            is_rebal = dow[t] in [4]
            is_emerg = t > 0 and abs(daily_ret[t]) > EMERGENCY_THRESHOLD
            if not is_rebal and not is_emerg: full_allocs[t] = prev_alloc; continue
            regime = get_regime(t, prices, sma50, sma200)
            raw = pred * K_DEFAULT[regime] * conf_factor
            full_allocs[t] = float(np.clip(raw, alloc_min, 1.0))
            prev_alloc = full_allocs[t]

        s, b, a = backtest_allocations(daily_ret, full_allocs, ts, tend, cost=COST, rf_daily=rf_daily)
        a_s.extend(s); a_b.extend(b); a_a.extend(a)
        a_r.extend(rf_daily[ts:ts+len(s)])
        for i in range(len(s)): strat_ret[ts+i] = s[i]
        del reg_models, cls_models; gc.collect()

    metrics = v22.metrics_v22(np.array(a_s), np.array(a_b), np.array(a_a), rf_daily=np.array(a_r))
    return metrics, reg_preds, cls_probs, full_allocs, strat_ret


def accuracy_per_dow(preds, actuals, dow):
    mask = np.abs(preds) > 1e-6
    out = {'all': float((np.sign(preds[mask]) == np.sign(actuals[mask])).mean()) if mask.sum() else None}
    for d, name in enumerate(DAY_NAMES):
        dmask = mask & (dow == d)
        out[name] = float((np.sign(preds[dmask]) == np.sign(actuals[dmask])).mean()) if dmask.sum() > 10 else None
    return out


def yoy_breakdown(strat_ret, daily_ret, preds, target, dates, dow):
    ds = pd.to_datetime(dates); years = ds.year.values
    rows = []
    for y in sorted(set(years[years >= 2022])):
        mask = years == y
        strat_y = strat_ret[mask]; bench_y = daily_ret[mask]
        preds_y = preds[mask]; tgt_y = target[mask]; dow_y = dow[mask]
        strat_total = np.prod(1 + strat_y) - 1 if len(strat_y) else 0
        bench_total = np.prod(1 + bench_y) - 1 if len(bench_y) else 0
        pmask = np.abs(preds_y) > 1e-6
        acc_all = (np.sign(preds_y[pmask]) == np.sign(tgt_y[pmask])).mean() if pmask.sum() else None
        rows.append({'year': int(y), 'strat_ret': float(strat_total*100),
                     'btc_ret': float(bench_total*100),
                     'acc_all': float(acc_all*100) if acc_all else None,
                     'days': int(mask.sum())})
    return rows


def run_experiment(name, feature_cols, desc, df, prices, daily_ret, returns, vols,
                    dates, n, rf_daily, dow, periods, sma50, sma200, target, alloc_min=0.0):
    print(f"\n{'='*100}\n[{time.strftime('%H:%M:%S')}] {name}: {desc} (10 seeds)\n{'='*100}", flush=True)
    print(f"  {len(feature_cols)} features", flush=True)
    X_all, fnames = build_ml_features(df, returns, vols, n, feature_cols=feature_cols)

    outs = []
    for i, s in enumerate(SEEDS_10):
        t1 = time.time()
        print(f"  {i+1}/10 (seed={s})...", end='', flush=True)
        metrics, rp, cp, allocs, sret = run_one(s, X_all, target, prices, daily_ret,
                                                   dates, periods, dow, sma50, sma200,
                                                   rf_daily, n, alloc_min=alloc_min)
        outs.append((metrics, rp, cp, allocs, sret))
        print(f" S={metrics['sortino']:.2f} ({(time.time()-t1)/60:.1f}m)", flush=True)

    sortinos = [o[0]['sortino'] for o in outs]
    rets = [o[0]['total']*100 for o in outs]
    dds = [o[0]['max_dd']*100 for o in outs]
    preds_avg = np.mean([o[1] * np.array([1.0 / (1.0 + np.exp(-abs(o[2][i] - 0.5) * 15))
                                            for i in range(n)]) for o in outs], axis=0)
    acc = accuracy_per_dow(preds_avg, target, dow)
    yoy = yoy_breakdown(np.mean([o[4] for o in outs], axis=0), daily_ret, preds_avg, target, dates, dow)
    result = {'name': name, 'desc': desc, 'n_features': len(feature_cols), 'n_seeds': 10,
              'alloc_min': alloc_min,
              'sortino_mean': float(np.mean(sortinos)), 'sortino_std': float(np.std(sortinos)),
              'ret_mean': float(np.mean(rets)), 'ret_std': float(np.std(rets)),
              'dd_mean': float(np.mean(dds)), 'dd_std': float(np.std(dds)),
              'acc': acc, 'yoy': yoy}
    acc2026 = next((y['acc_all'] for y in yoy if y['year'] == 2026), None)
    acc2026_s = f"{acc2026:.1f}%" if acc2026 else 'n/a'
    print(f"\n  SUMMARY {name}: S={result['sortino_mean']:.3f}+/-{result['sortino_std']:.3f}  "
          f"Ret={result['ret_mean']:+.0f}% +/- {result['ret_std']:.0f}%  DD={result['dd_mean']:.1f}%  "
          f"all={(acc.get('all') or 0)*100:.2f}%  2026={acc2026_s}", flush=True)
    for row in yoy:
        acc_s = f"{row['acc_all']:.1f}%" if row['acc_all'] else 'n/a'
        print(f"    {row['year']}: ret={row['strat_ret']:+.1f}% btc={row['btc_ret']:+.1f}% acc={acc_s}",
              flush=True)
    return result


def main():
    t0 = time.time()
    print("=" * 100, flush=True)
    print("V36 — 10-seed validation of top candidates on fresh dataset", flush=True)
    print("=" * 100, flush=True)

    prices, daily_ret, returns, vols, df = load_data()
    dom = fetch_btc_dominance(df.date.min().strftime('%Y-%m-%d'),
                                df.date.max().strftime('%Y-%m-%d'))
    df = df.merge(dom, on='date', how='left')
    df['btc_dominance'] = df['btc_dominance'].ffill()

    dates = df['date'].values; n = len(prices)
    rf_daily = build_rf_daily(dates, source='auto')
    v9m.RF_DAILY_ARR = rf_daily; v13m.RF_DAILY_ARR = rf_daily
    dow = pd.to_datetime(dates).dayofweek.values
    periods = _get_retrain_periods(dates, n, v22.RETRAIN)
    sma50 = pd.Series(prices).rolling(50).mean().values
    sma200 = pd.Series(prices).rolling(200).mean().values
    target = np.zeros(n)
    for i in range(n - HORIZON): target[i] = (prices[i + HORIZON] - prices[i]) / prices[i]

    results = []
    def save():
        RESULTS.parent.mkdir(parents=True, exist_ok=True)
        with open(RESULTS, 'w') as f:
            json.dump({'results': results, 'elapsed_min': (time.time()-t0)/60}, f, indent=2)

    base29 = list(FEATURES_37)
    common = dict(df=df, prices=prices, daily_ret=daily_ret, returns=returns, vols=vols,
                   dates=dates, n=n, rf_daily=rf_daily, dow=dow, periods=periods,
                   sma50=sma50, sma200=sma200, target=target)

    # E0: Baseline fresh (V31.7 equiv), 10 seeds
    r = run_experiment('E0_baseline_fresh_10s', base29,
                        'B0 baseline fresh data 10 seeds', alloc_min=0.0, **common)
    results.append(r); save()

    # E1: D7 winner — B0 + reserveRisk + funding_rate_ma7 + puellMultiple (V35 top)
    r = run_experiment('E1_D7combo_10s', base29 + ['reserveRisk', 'funding_rate_ma7', 'puellMultiple'],
                        'B0 + Reserve+Funding+Puell (V35 winner) 10 seeds', alloc_min=0.0, **common)
    results.append(r); save()

    # E2: V29 prod config (with short) on fresh data
    r = run_experiment('E2_V29_withshort_10s', base29,
                        'V29 current prod (with short) on fresh 10 seeds', alloc_min=-0.25, **common)
    results.append(r); save()

    # E3: D7 combo WITH SHORT — test if winner also improves with short
    r = run_experiment('E3_D7combo_withshort_10s', base29 + ['reserveRisk', 'funding_rate_ma7', 'puellMultiple'],
                        'D7 combo + short (floor=-0.25) 10 seeds', alloc_min=-0.25, **common)
    results.append(r); save()

    # E4: B0 + btc_dominance (retest with 10 seeds)
    r = run_experiment('E4_btc_dom_10s', base29 + ['btc_dominance'],
                        'B0 + btc_dominance 10 seeds', alloc_min=0.0, **common)
    results.append(r); save()

    elapsed = (time.time() - t0) / 60
    print(f"\n{'='*100}\nV36 DONE: {elapsed:.1f} min\n{'='*100}", flush=True)
    print("\nFINAL 10-SEED VALIDATION:", flush=True)
    for r in sorted(results, key=lambda x: -x['sortino_mean']):
        acc2026 = next((y['acc_all'] for y in r['yoy'] if y['year'] == 2026), None)
        acc2026_s = f"{acc2026:.1f}%" if acc2026 else 'n/a'
        floor_s = f"floor={r['alloc_min']}"
        print(f"  {r['name']:<26}  n_feat={r['n_features']}  {floor_s:<12}  "
              f"S={r['sortino_mean']:.3f}+/-{r['sortino_std']:.3f}  "
              f"Ret={r['ret_mean']:+.0f}%+/-{r['ret_std']:.0f}%  "
              f"DD={r['dd_mean']:.1f}%  2026={acc2026_s}", flush=True)
    save()


if __name__ == '__main__':
    main()
