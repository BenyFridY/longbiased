"""Sweep over REBAL_DOW — test if Fri is a genuine structural advantage
or an overfit artifact of 2022-2026.

Runs all 7 days (Mon=0..Sun=6) with 3 seeds each on baseline 37 features.
If Fri stands alone as an outlier, it's likely overfit. If it's part of a
cluster (e.g., Thu-Fri-Sat all high), it's structural. If all days are
similar, the day doesn't matter and the pick was noise.
"""
import sys, time
import numpy as np, pandas as pd
from pathlib import Path

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

import archive.old_pipelines.pipeline_v22 as v22
from archive.old_pipelines.pipeline_v09 import load_data, build_ml_features
from scripts.production.training import _get_retrain_periods
from src.features.macro.cdi_rates import build_rf_daily
import archive.old_pipelines.pipeline_v09 as v9m
import archive.old_pipelines.pipeline_v13 as v13m


def main():
    t0 = time.time()
    prices, daily_ret, returns, vols, df = load_data()
    dates = df['date'].values
    n = len(prices)
    rf_daily = build_rf_daily(dates, source='auto')
    v9m.RF_DAILY_ARR = rf_daily
    v13m.RF_DAILY_ARR = rf_daily

    fc = v22.BASE_FEATURES + [f for f in v22.EXTRA_FEATURES if f not in v22.BASE_FEATURES]
    fc = [f for f in fc if f in df.columns]
    X_all, _ = build_ml_features(df, returns, vols, n, feature_cols=fc)

    target = np.zeros(n)
    for i in range(n - v22.HORIZON):
        target[i] = (prices[i + v22.HORIZON] - prices[i]) / prices[i]

    dow = pd.to_datetime(dates).dayofweek
    periods = _get_retrain_periods(dates, n, v22.RETRAIN)
    sma50 = pd.Series(prices).rolling(50).mean().values
    sma200 = pd.Series(prices).rolling(200).mean().values

    print("=" * 75)
    print("DOW SWEEP — baseline 37 features, 3 seeds each day")
    print("=" * 75)

    day_names = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
    seeds = [42, 142, 242]
    results = {}

    for d, name in enumerate(day_names):
        t1 = time.time()
        v22.REBAL_DOW = [d]
        mets = []
        for seed in seeds:
            m = v22.run_single_seed(seed, X_all, target, prices, daily_ret, dates,
                                    periods, dow, sma50, sma200, rf_daily, n)
            mets.append(m)
        s = np.array([m['sortino'] for m in mets])
        r = np.array([m['total']*100 for m in mets])
        d_dd = np.array([m['max_dd']*100 for m in mets])
        results[name] = (s.mean(), s.std(), r.mean(), r.std(), d_dd.mean())
        print(f"  {name}  Sortino {s.mean():.2f}+/-{s.std():.2f}  "
              f"Ret {r.mean():+.0f}%+/-{r.std():.0f}%  "
              f"DD {d_dd.mean():.1f}%  ({(time.time()-t1)/60:.1f}m)")

    print()
    print("=" * 75)
    print(f"SUMMARY — total {(time.time()-t0)/60:.1f} min")
    print("=" * 75)
    # Rank by Sortino
    ranked = sorted(results.items(), key=lambda x: -x[1][0])
    print(f"{'Day':<5} {'Sortino':>12} {'Return':>12} {'DD':>8}  Rank")
    for rank, (name, (s, ss, r, rs, d)) in enumerate(ranked, 1):
        print(f"{name:<5} {s:>5.2f}+/-{ss:<4.2f} {r:>+5.0f}%+/-{rs:<4.0f} {d:>6.1f}%  #{rank}")

    # Overfit diagnostic
    s_values = [v[0] for v in results.values()]
    mu = np.mean(s_values)
    sigma = np.std(s_values)
    print()
    print(f"All-day stats: Sortino mean={mu:.2f}  std={sigma:.2f}")
    for name, (s, *_) in ranked:
        z = (s - mu) / sigma if sigma > 0 else 0
        marker = '!! outlier' if abs(z) > 1.5 else ''
        print(f"  {name}: z={z:+.2f}  {marker}")

    print()
    print("Interpretation guide:")
    print("  - If Fri z > 1.5 AND no other day has z > 1  -> possible overfit")
    print("  - If Fri is top but 2-3 other days are close -> structural (weekend effect)")
    print("  - If spread is small (all Sortinos 3-5)       -> day doesn't matter much")


if __name__ == '__main__':
    main()
