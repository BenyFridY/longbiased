"""
Feb-Mar 2026 Detail — V22 Model Day-by-Day Output
===================================================

Generate day-by-day predictions, allocations, and returns for Feb-Mar 2026
using the V22 production configuration (seed=242).

Shows exactly what the model produced during this critical period.
"""
import sys, gc, numpy as np, pandas as pd
from pathlib import Path
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
import warnings
warnings.filterwarnings('ignore')
sys.stdout.reconfigure(line_buffering=True)

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

from archive.old_pipelines.pipeline_v09 import (
    load_data, build_ml_features, backtest_allocations,
    COST, P, get_year_boundaries,
)
from archive.old_pipelines.pipeline_v10 import MODELS
from archive.old_pipelines.pipeline_v13 import _get_retrain_periods, _train_one_xgb


# ══════════════════════════════════════════════════════════════════════════
# V22 CONFIGURATION (IDENTICAL TO PIPELINE_V22.PY)
# ══════════════════════════════════════════════════════════════════════════

XGB_PARAMS = {
    'max_leaves': 31,
    'grow_policy': 'lossguide',
    'tree_method': 'hist',
    'colsample_bytree': 0.5,
    'subsample': 0.8,
    'learning_rate': 0.05,
    'min_child_weight': 12,
    'n_estimators': 200,
    'objective': 'reg:squarederror',
    'verbosity': 0,
    'nthread': 1,
}

K_REGIME = {'BULL': 50, 'MILD': 30, 'BEAR': 15}
ALLOC_MIN = -0.25
ALLOC_MAX = 1.0
BAGS = 80
HORIZON = 3
RETRAIN = 'semi'
REBAL_DOW = [4]  # Friday
EMERGENCY_THRESHOLD = 0.08
WORKERS = 16
SEED = 242

BASE_FEATURES = [f for f in MODELS['37feat'] if f != 'exchange_netflow_ma7'] + ['basis_pct']
EXTRA_FEATURES = [
    'fed_balance_sheet', 'futures_trade_count',
    'vol_x_regime_duration', 'velocity', 'hash_rate_pctchg_30d',
]


# ══════════════════════════════════════════════════════════════════════════
# REGIME & ALLOCATION
# ══════════════════════════════════════════════════════════════════════════

def get_regime(t, prices, sma50, sma200):
    if np.isnan(sma50[t]) or np.isnan(sma200[t]):
        return 'MILD'
    if prices[t] > sma50[t] and sma50[t] > sma200[t]:
        return 'BULL'
    elif prices[t] > sma200[t]:
        return 'MILD'
    return 'BEAR'


def compute_allocation(prediction, regime):
    K = K_REGIME[regime]
    return np.clip(prediction * K, ALLOC_MIN, ALLOC_MAX)


# ══════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════

def main():
    P("=" * 80)
    P("V22 MODEL — FEB-MAR 2026 DAY-BY-DAY DETAIL")
    P("=" * 80)
    P(f"  Seed: {SEED}")
    P(f"  Bags: {BAGS}")
    P(f"  Horizon: {HORIZON}d")
    P(f"  Retrain: {RETRAIN}-annual")
    P(f"  Rebalance: Friday + emergency {EMERGENCY_THRESHOLD*100:.0f}%")
    P("")

    start = datetime.now()

    P("Loading data...")
    prices, daily_ret, returns, vols, df = load_data()
    dates = df['date'].values
    n = len(prices)
    P(f"  {n} days | {dates[0]} to {dates[-1]}")

    try:
        from src.features.macro.cdi_rates import build_rf_daily
        rf_daily = build_rf_daily(dates, source='auto')
    except Exception:
        from src.features.macro.cdi_rates import build_rf_daily
        rf_daily = build_rf_daily(dates, source='copom')

    import archive.old_pipelines.pipeline_v09 as v9m
    import archive.old_pipelines.pipeline_v13 as v13m
    v9m.RF_DAILY_ARR = rf_daily
    v13m.RF_DAILY_ARR = rf_daily

    fc = BASE_FEATURES + [f for f in EXTRA_FEATURES if f not in BASE_FEATURES]
    fc = [f for f in fc if f in df.columns]
    P(f"  {len(fc)} features")

    X_all, _ = build_ml_features(df, returns, vols, n, feature_cols=fc)

    target = np.zeros(n)
    for i in range(n - HORIZON):
        target[i] = (prices[i + HORIZON] - prices[i]) / prices[i]

    dow = pd.to_datetime(dates).dayofweek
    periods = _get_retrain_periods(dates, n, RETRAIN)
    sma50 = pd.Series(prices).rolling(50).mean().values
    sma200 = pd.Series(prices).rolling(200).mean().values

    P(f"\nRetrain periods ({len(periods)}):")
    for te, ts, tend in periods:
        P(f"  Train end: {dates[te]} | Test: {dates[ts]} to {dates[tend]}")

    # ── Find Feb-Mar 2026 period ──
    feb_start = pd.Timestamp('2026-02-01')
    mar_end = pd.Timestamp('2026-03-31')

    # Get date indices
    date_dt = pd.to_datetime(dates)
    feb_mar_mask = (date_dt >= feb_start) & (date_dt <= mar_end)
    feb_mar_indices = np.where(feb_mar_mask)[0]

    if len(feb_mar_indices) == 0:
        P("\n⚠️  NO DATA FOR FEB-MAR 2026!")
        return

    P(f"\nFeb-Mar 2026 period: {len(feb_mar_indices)} days")
    P(f"  {dates[feb_mar_indices[0]]} to {dates[feb_mar_indices[-1]]}")

    # ── Find which retrain period(s) cover Feb-Mar 2026 ──
    relevant_periods = []
    for te, ts, tend in periods:
        # Check if this period overlaps with Feb-Mar 2026
        if tend >= feb_mar_indices[0] and ts <= feb_mar_indices[-1]:
            relevant_periods.append((te, ts, tend))

    P(f"\nRelevant retrain periods for Feb-Mar 2026: {len(relevant_periods)}")
    for te, ts, tend in relevant_periods:
        P(f"  Train end: {dates[te]} | Test: {dates[ts]} to {dates[tend]}")

    # ── Run full backtest to get allocations ──
    P("\nRunning full backtest (all periods)...")
    full_allocs = np.full(n, 0.0)
    full_predictions = np.full(n, np.nan)
    full_regimes = np.full(n, '', dtype=object)
    prev_alloc = 0.0

    for te, ts, tend in periods:
        gap = max(HORIZON, 5)
        tm = np.arange(60, te - gap + 1)
        valid = ~np.any(np.isnan(X_all[tm]), axis=1)
        idx = tm[valid]
        if len(idx) < 100:
            continue

        Xt = np.nan_to_num(X_all[idx], nan=0.0)
        yt = target[idx]

        P(f"  Training: {dates[te]} ({len(idx)} samples)...")
        bag_seeds = [SEED + i * 7 for i in range(BAGS)]
        with ThreadPoolExecutor(max_workers=WORKERS) as ex:
            models = list(ex.map(_train_one_xgb,
                [(s, Xt, yt, XGB_PARAMS) for s in bag_seeds]))

        for t in range(ts, tend + 1):
            is_rebal = dow[t] in REBAL_DOW
            is_emerg = t > 0 and abs(daily_ret[t]) > EMERGENCY_THRESHOLD

            x_t = np.nan_to_num(X_all[t:t + 1].copy(), nan=0.0)
            prediction = float(np.mean([m.predict(x_t)[0] for m in models]))
            regime = get_regime(t, prices, sma50, sma200)

            full_predictions[t] = prediction
            full_regimes[t] = regime

            if not is_rebal and not is_emerg:
                full_allocs[t] = prev_alloc
            else:
                full_allocs[t] = compute_allocation(prediction, regime)
                prev_alloc = full_allocs[t]

        del models
        gc.collect()

    # ── Build day-by-day output for Feb-Mar 2026 ──
    P("\n" + "=" * 80)
    P("DAY-BY-DAY RESULTS — FEB-MAR 2026")
    P("=" * 80)

    output_rows = []
    cum_strat = 1.0
    cum_btc = 1.0

    # Header
    P(f"{'Date':<12} {'Price':>10} {'BTC Ret':>8} {'Regime':>6} "
      f"{'Pred':>8} {'Alloc':>7} {'Strat Ret':>9} {'Cum Strat':>10} {'Cum BTC':>10}")
    P("-" * 80)

    for i, t in enumerate(feb_mar_indices):
        date_str = str(dates[t])[:10]
        price = prices[t]

        # Daily returns (t to t+1)
        if t + 1 < n:
            btc_ret = daily_ret[t + 1]
            alloc = full_allocs[t]
            regime = full_regimes[t]
            prediction = full_predictions[t]

            # Compute strategy return
            rf_t = rf_daily[t] if isinstance(rf_daily, np.ndarray) else rf_daily
            tc = abs(alloc - (full_allocs[t-1] if t > 0 else 0.5)) * COST * (1.5 if alloc < 0 else 1.0)

            if alloc >= 0:
                strat_ret = alloc * btc_ret + (1 - alloc) * rf_t - tc
            else:
                strat_ret = alloc * btc_ret + 1.0 * rf_t - tc

            cum_strat *= (1 + strat_ret)
            cum_btc *= (1 + btc_ret)

            # Print
            P(f"{date_str:<12} ${price:>9,.0f} {btc_ret*100:>7.2f}% {regime:>6} "
              f"{prediction*100:>7.2f}% {alloc*100:>6.1f}% {strat_ret*100:>8.2f}% "
              f"{cum_strat:>9.3f}x {cum_btc:>9.3f}x")

            output_rows.append({
                'date': date_str,
                'price_usd': float(price),
                'btc_daily_ret': float(btc_ret),
                'regime': regime,
                'prediction': float(prediction),
                'allocation': float(alloc),
                'strategy_daily_ret': float(strat_ret),
                'cum_strategy': float(cum_strat),
                'cum_btc': float(cum_btc),
            })
        else:
            # Last day (no next day return)
            alloc = full_allocs[t]
            regime = full_regimes[t]
            prediction = full_predictions[t]

            P(f"{date_str:<12} ${price:>9,.0f} {'N/A':>8} {regime:>6} "
              f"{prediction*100:>7.2f}% {alloc*100:>6.1f}% {'N/A':>9} "
              f"{cum_strat:>9.3f}x {cum_btc:>9.3f}x")

            output_rows.append({
                'date': date_str,
                'price_usd': float(price),
                'btc_daily_ret': np.nan,
                'regime': regime,
                'prediction': float(prediction),
                'allocation': float(alloc),
                'strategy_daily_ret': np.nan,
                'cum_strategy': float(cum_strat),
                'cum_btc': float(cum_btc),
            })

    # ── Summary metrics for Feb-Mar 2026 ──
    P("\n" + "=" * 80)
    P("SUMMARY — FEB-MAR 2026")
    P("=" * 80)

    # Get actual returns (drop last day if no next-day return)
    valid_rows = [r for r in output_rows if not np.isnan(r['strategy_daily_ret'])]

    if len(valid_rows) > 0:
        strat_rets = np.array([r['strategy_daily_ret'] for r in valid_rows])
        btc_rets = np.array([r['btc_daily_ret'] for r in valid_rows])
        allocs = np.array([r['allocation'] for r in valid_rows])

        total_strat = cum_strat - 1.0
        total_btc = cum_btc - 1.0
        excess = total_strat - total_btc

        # Sharpe / Sortino (annualized, using CDI as rf)
        avg_rf = np.mean(rf_daily[feb_mar_indices[:-1]]) if len(feb_mar_indices) > 1 else 0.0
        excess_daily = strat_rets - avg_rf
        sharpe = np.mean(excess_daily) / (np.std(strat_rets) + 1e-10) * np.sqrt(365)

        downside = np.minimum(excess_daily, 0.0)
        dd_std = np.sqrt(np.mean(downside ** 2))
        sortino = np.mean(excess_daily) / (dd_std + 1e-10) * np.sqrt(365)

        # Drawdown
        cum_arr = np.cumprod(1 + strat_rets)
        peak = np.maximum.accumulate(cum_arr)
        dd = (cum_arr - peak) / (peak + 1e-10)
        max_dd = np.min(dd)

        P(f"  Days:              {len(valid_rows)}")
        P(f"  Strategy Return:   {total_strat*100:+.2f}%")
        P(f"  BTC Return:        {total_btc*100:+.2f}%")
        P(f"  Excess:            {excess*100:+.2f}%")
        P(f"  Sharpe (ann):      {sharpe:.2f}")
        P(f"  Sortino (ann):     {sortino:.2f}")
        P(f"  Max Drawdown:      {max_dd*100:.2f}%")
        P(f"  Avg Allocation:    {np.mean(allocs)*100:.1f}%")
        P(f"  Short Days:        {int((allocs < 0).sum())} / {len(allocs)}")
    else:
        P("  No valid return data available")

    # ── Save to CSV ──
    out_df = pd.DataFrame(output_rows)
    out_path = ROOT / 'outputs' / 'results' / 'feb_mar_2026_detail.csv'
    out_df.to_csv(out_path, index=False)

    elapsed = (datetime.now() - start).total_seconds()
    P(f"\n  Saved: {out_path}")
    P(f"  Elapsed: {elapsed:.1f}s")
    P("=" * 80)


if __name__ == '__main__':
    main()
