"""
V22 Retrain × Rebalance Sweep
Tests combinations of retrain frequency and rebalance schedule.

Hypothesis: more frequent retrain might need different rebalance to work.

Configs:
  Retrain:   semi-annual (baseline), quarterly, monthly
  Rebalance: Fri+emerg8% (baseline), Fri only, Mon+Fri, daily

5 seeds each. Same V22 model otherwise.

Usage:
    python scripts/optimization/v22_retrain_rebal_sweep.py
"""
import sys, gc, json, numpy as np, pandas as pd
from pathlib import Path
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
import warnings; warnings.filterwarnings('ignore')
sys.stdout.reconfigure(line_buffering=True)

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

from archive.old_pipelines.pipeline_v09 import (
    load_data, build_ml_features, backtest_allocations,
    COST, P, convert_numpy, get_year_boundaries,
)
from archive.old_pipelines.pipeline_v10 import MODELS
from archive.old_pipelines.pipeline_v13 import _get_retrain_periods, _train_one_xgb

# V22 config
XGB_PARAMS = {
    'max_leaves': 31, 'grow_policy': 'lossguide', 'tree_method': 'hist',
    'colsample_bytree': 0.5, 'subsample': 0.8, 'learning_rate': 0.05,
    'min_child_weight': 12, 'n_estimators': 200,
    'objective': 'reg:squarederror', 'verbosity': 0, 'nthread': 1,
}
K_REGIME = {'BULL': 50, 'MILD': 30, 'BEAR': 15}
BAGS = 80
HORIZON = 3
WORKERS = 16

BASE_FEATURES = [f for f in MODELS['37feat'] if f != 'exchange_netflow_ma7'] + ['basis_pct']
EXTRA_FEATURES = [
    'fed_balance_sheet', 'futures_trade_count',
    'vol_x_regime_duration', 'velocity', 'hash_rate_pctchg_30d',
]

NUM_SEEDS = 2
SEEDS = [42 + i * 100 for i in range(NUM_SEEDS)]

# Configs: (retrain, rebal_days, emergency_threshold, label)
CONFIGS = [
    # Baseline
    ('semi',      [4],    0.08, "semi + Fri+emerg8% (BASELINE)"),
    # Retrain variations with baseline rebalance
    ('quarterly', [4],    0.08, "quarterly + Fri+emerg8%"),
    ('monthly',   [4],    0.08, "monthly + Fri+emerg8%"),
    # Rebalance variations with baseline retrain
    ('semi',      [4],    0.0,  "semi + Fri only (no emerg)"),
    ('semi',      [0, 4], 0.08, "semi + Mon+Fri+emerg8%"),
    # Cross: quarterly retrain with different rebalance
    ('quarterly', [4],    0.0,  "quarterly + Fri only"),
    ('quarterly', [0, 4], 0.08, "quarterly + Mon+Fri+emerg8%"),
    # Cross: monthly retrain with different rebalance
    ('monthly',   [4],    0.0,  "monthly + Fri only"),
    ('monthly',   [0, 4], 0.08, "monthly + Mon+Fri+emerg8%"),
    # Monthly retrain + daily rebalance (extreme)
    ('monthly',   [0,1,2,3,4], 0.0, "monthly + daily rebal"),
]


def _get_monthly_periods(dates, n):
    """Monthly retrain periods (not in pipeline_v13)."""
    dt_dates = pd.to_datetime(dates)
    periods = []
    for yr in range(2022, 2027):
        for month in range(1, 13):
            mask = (dt_dates.year == yr) & (dt_dates.month == month)
            indices = np.where(mask)[0]
            if len(indices) == 0:
                continue
            test_start = indices[0]
            test_end = indices[-1]
            train_end = test_start - 1
            if train_end >= 60:
                periods.append((train_end, test_start, test_end))
    return periods


def get_regime(t, prices, sma50, sma200):
    if np.isnan(sma50[t]) or np.isnan(sma200[t]):
        return 'MILD'
    if prices[t] > sma50[t] and sma50[t] > sma200[t]:
        return 'BULL'
    elif prices[t] > sma200[t]:
        return 'MILD'
    return 'BEAR'


def metrics_correct(s, b, a, rf_daily=None):
    """Sortino & Price 1994 + Sharpe."""
    if len(s) < 10:
        return None
    if rf_daily is None:
        rf_daily = 0.0
    ts = np.prod(1 + s) - 1
    tb = np.prod(1 + b) - 1
    ex = s - rf_daily
    downside = np.minimum(ex, 0.0)
    dd_std = np.sqrt(np.mean(downside ** 2))
    sortino = np.mean(ex) / (dd_std + 1e-10) * np.sqrt(365)
    sharpe = np.mean(ex) / (np.std(s) + 1e-10) * np.sqrt(365)
    cum = np.cumprod(1 + s)
    pk = np.maximum.accumulate(cum)
    max_dd = np.min((cum - pk) / (pk + 1e-10))
    return {'total': ts, 'sortino': sortino, 'sharpe': sharpe, 'max_dd': max_dd}


def run_seed(seed, X_all, target, prices, daily_ret, dates, n,
             sma50, sma200, rf_daily, dow, retrain_freq, rebal_days, emerg_thresh):
    """Run one seed with given retrain/rebalance config."""
    if retrain_freq == 'monthly':
        periods = _get_monthly_periods(dates, n)
    else:
        periods = _get_retrain_periods(dates, n, retrain_freq)
    full_allocs = np.full(n, 0.0)
    prev_alloc = 0.0
    a_s, a_b, a_a, a_r = [], [], [], []

    for te, ts, tend in periods:
        gap = max(HORIZON, 5)
        tm = np.arange(60, te - gap + 1)
        valid = ~np.any(np.isnan(X_all[tm]), axis=1)
        idx = tm[valid]
        if len(idx) < 100:
            continue

        Xt = np.nan_to_num(X_all[idx], nan=0.0)
        yt = target[idx]

        bag_seeds = [seed + i * 7 for i in range(BAGS)]
        with ThreadPoolExecutor(max_workers=WORKERS) as ex:
            models = list(ex.map(_train_one_xgb,
                [(s, Xt, yt, XGB_PARAMS) for s in bag_seeds]))

        for t in range(ts, tend + 1):
            is_rebal = dow[t] in rebal_days
            is_emerg = emerg_thresh > 0 and t > 0 and abs(daily_ret[t]) > emerg_thresh
            if not is_rebal and not is_emerg:
                full_allocs[t] = prev_alloc
                continue

            x_t = np.nan_to_num(X_all[t:t + 1].copy(), nan=0.0)
            prediction = float(np.mean([m.predict(x_t)[0] for m in models]))
            regime = get_regime(t, prices, sma50, sma200)
            K = K_REGIME[regime]
            full_allocs[t] = np.clip(prediction * K, -0.25, 1.0)
            prev_alloc = full_allocs[t]

        s, b, a = backtest_allocations(daily_ret, full_allocs, ts, tend,
                                       cost=COST, rf_daily=rf_daily)
        a_s.extend(s)
        a_b.extend(b)
        a_a.extend(a)
        a_r.extend(rf_daily[ts:ts + len(s)])

        del models
        gc.collect()

    return metrics_correct(np.array(a_s), np.array(a_b), np.array(a_a),
                           rf_daily=np.array(a_r))


def main():
    P("=" * 80)
    P(f"V22 RETRAIN x REBALANCE SWEEP")
    P(f"  {len(CONFIGS)} configs x {NUM_SEEDS} seeds = {len(CONFIGS) * NUM_SEEDS} runs")
    P("=" * 80)

    start = datetime.now()

    P("\nLoading data...")
    prices, daily_ret, returns, vols, df = load_data()
    dates = df['date'].values
    n = len(prices)

    try:
        from src.features.macro.cdi_rates import build_rf_daily
        rf_daily = build_rf_daily(dates, source='auto')
    except Exception:
        from src.features.macro.cdi_rates import build_rf_daily
        rf_daily = build_rf_daily(dates, source='copom')

    import archive.old_pipelines.pipeline_v09 as v9m
    import archive.old_pipelines.pipeline_v13 as v13m
    v9m.RF_DAILY_ARR = rf_daily
    v13m.RF_DAILY_ARR = rf_daily

    fc = BASE_FEATURES + [f for f in EXTRA_FEATURES if f not in BASE_FEATURES]
    fc = [f for f in fc if f in df.columns]
    P(f"  {len(fc)} features, {n} days")

    X_all, _ = build_ml_features(df, returns, vols, n, feature_cols=fc)

    target = np.zeros(n)
    for i in range(n - HORIZON):
        target[i] = (prices[i + HORIZON] - prices[i]) / prices[i]

    dow = pd.to_datetime(dates).dayofweek
    sma50 = pd.Series(prices).rolling(50).mean().values
    sma200 = pd.Series(prices).rolling(200).mean().values

    all_results = []

    for ci, (retrain, rebal_days, emerg, label) in enumerate(CONFIGS):
        P(f"\n{'─'*60}")
        P(f"[{ci+1}/{len(CONFIGS)}] {label}")
        P(f"{'─'*60}")

        sortinos, sharpes, rets_list, dds = [], [], [], []

        for si, seed in enumerate(SEEDS):
            m = run_seed(seed, X_all, target, prices, daily_ret, dates, n,
                        sma50, sma200, rf_daily, dow, retrain, rebal_days, emerg)
            if m is None:
                P(f"  Seed {seed}: FAILED (too few samples)")
                continue
            sortinos.append(m['sortino'])
            sharpes.append(m['sharpe'])
            rets_list.append(m['total'] * 100)
            dds.append(m['max_dd'] * 100)
            P(f"  Seed {seed}: Sortino={m['sortino']:.2f}  Sharpe={m['sharpe']:.2f}  "
              f"Ret={m['total']*100:+.0f}%  DD={m['max_dd']*100:.1f}%")

        if not sortinos:
            P(f"  => SKIPPED (no valid results)")
            continue
        result = {
            'label': label, 'retrain': retrain,
            'rebal_days': rebal_days, 'emergency': emerg,
            'sortino_avg': float(np.mean(sortinos)),
            'sortino_std': float(np.std(sortinos)),
            'sharpe_avg': float(np.mean(sharpes)),
            'return_avg': float(np.mean(rets_list)),
            'max_dd_avg': float(np.mean(dds)),
        }
        all_results.append(result)
        P(f"  => Sortino={np.mean(sortinos):.2f}±{np.std(sortinos):.2f}  "
          f"Sharpe={np.mean(sharpes):.2f}  Ret={np.mean(rets_list):+.0f}%  DD={np.mean(dds):.1f}%")

    elapsed = (datetime.now() - start).total_seconds() / 60

    # Summary
    P(f"\n{'='*80}")
    P(f"SUMMARY — {NUM_SEEDS} seeds each ({elapsed:.0f} min)")
    P(f"{'='*80}\n")
    P(f"  {'#':<3} {'Config':<42} {'Sortino':>8} {'Sharpe':>8} {'Return':>8} {'MaxDD':>8}")
    P(f"  {'─'*3} {'─'*42} {'─'*8} {'─'*8} {'─'*8} {'─'*8}")

    ranked = sorted(all_results, key=lambda x: x['sortino_avg'], reverse=True)
    for i, r in enumerate(ranked):
        marker = " **" if i == 0 else ""
        P(f"  {i+1:<3} {r['label']:<42} {r['sortino_avg']:>7.2f}  {r['sharpe_avg']:>7.2f}  "
          f"{r['return_avg']:>+7.0f}%  {r['max_dd_avg']:>7.1f}%{marker}")

    baseline = next(r for r in all_results if 'BASELINE' in r['label'])
    best = ranked[0]
    P(f"\n  Best: {best['label']}")
    P(f"  vs baseline: Sortino {best['sortino_avg'] - baseline['sortino_avg']:+.2f}, "
      f"Return {best['return_avg'] - baseline['return_avg']:+.0f}pp, "
      f"MaxDD {best['max_dd_avg'] - baseline['max_dd_avg']:+.1f}pp")

    # Save
    output = {
        'sweep': 'V22_retrain_rebalance',
        'timestamp': datetime.now().isoformat(),
        'elapsed_min': elapsed,
        'n_seeds': NUM_SEEDS,
        'configs': all_results,
        'ranking': [r['label'] for r in ranked],
    }
    out_path = ROOT / 'outputs' / 'results' / 'v22_retrain_rebal_sweep.json'
    with open(out_path, 'w') as f:
        json.dump(output, f, indent=2, default=convert_numpy)
    P(f"\n  Saved: {out_path}")


if __name__ == '__main__':
    main()
