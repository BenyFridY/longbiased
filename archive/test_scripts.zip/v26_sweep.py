"""V26 sweep: comprehensive hyperparameter + feature test battery.

Starting from V25_FINAL baseline (Sortino 4.95, Ret +1007%, DD -9.1%):
  Features = FEATURES_37 (with fracdiff, no OI/FTC, YoY fixed)
  K = 60/30/15
  HORIZON = 3
  BAGS = 80
  RETRAIN = semi

Tests (each 3 seeds except final combo):

  SET A — Smooth rebalance (4 tests)
    A1 — REBAL_DOW = [4] only (baseline Fri)
    A2 — REBAL_DOW = [3, 4] (Thu+Fri) — adjust alloc smoothed over 2 days
    A3 — REBAL_DOW = [3, 4, 0] (Thu+Fri+Mon) — 3-day smoothing
    A4 — Only Fri but position scaled by 0.7 (reduce Fri concentration risk)

  SET B — Fracdiff d sweep (5 tests)
    B1..B5 — d = 0.3, 0.4, 0.5 (current), 0.6, 0.7

  SET C — K_REGIME sweep (6 tests)
    C1 — (40, 20, 10)
    C2 — (50, 25, 15)
    C3 — (60, 30, 15) current
    C4 — (70, 35, 20)
    C5 — (80, 40, 20)
    C6 — (100, 50, 25)

  SET D — HORIZON sweep (4 tests)
    D1..D4 — 2d, 3d (current), 5d, 7d

  SET E — BAGS sweep (4 tests)
    E1..E4 — 40, 80 (current), 100, 150

  SET F — SIGMOID_SCALE sweep (not backtested here — requires classifier)
    Skipped; handled at production inference.

  FINAL G — Best combo from above (10 seeds)

Total: 4+5+6+4+4 = 23 tests × 3 seeds × ~6min = ~7 hours
      + 1 final × 10 seeds ≈ 25 min
Total ~7.5 hours

If too long, trim to core: A, C, D = 14 tests × 3 seeds ≈ 4.2 hours.
"""
import sys, time, json
import numpy as np, pandas as pd
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import xgboost as xgb
import gc

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

# Use pipeline_v22 machinery
import archive.old_pipelines.pipeline_v22 as v22
from archive.old_pipelines.pipeline_v09 import build_ml_features, backtest_allocations, COST
from scripts.production.training import _get_retrain_periods, _train_one_xgb
from src.features.macro.cdi_rates import build_rf_daily
import archive.old_pipelines.pipeline_v09 as v9m
import archive.old_pipelines.pipeline_v13 as v13m

from scripts.production.config import FEATURES_37

DATASET = ROOT / "outputs" / "feature_selection" / "dataset_enhanced.csv"
SEEDS_3 = [42, 142, 242]
SEEDS_10 = [42, 142, 242, 342, 442, 542, 642, 742, 842, 942]
RESULTS_PATH = ROOT / "outputs" / "results" / "v26_sweep.json"


def load():
    df = pd.read_csv(DATASET)
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)
    prices = df['price_usd'].values
    n = len(prices)
    daily_ret = np.zeros(n)
    for i in range(1, n):
        daily_ret[i] = (prices[i] - prices[i-1]) / prices[i-1]
    returns, vols = {}, {}
    for w in [1, 3, 5, 7, 10, 14, 20, 21, 30, 45, 60]:
        r = np.zeros(n)
        for i in range(w, n):
            r[i] = (prices[i] - prices[i-w]) / prices[i-w]
        returns[w] = r
    for w in [5, 7, 10, 14, 21, 30]:
        vols[w] = pd.Series(daily_ret).rolling(w).std().fillna(0.02).values
    return prices, daily_ret, returns, vols, df


def run_single_seed_custom(seed, X_all, target, prices, daily_ret, dates, periods,
                            dow, sma50, sma200, rf_daily, n,
                            K_regime, horizon, bags, rebal_dow, pos_scale=1.0):
    """Custom run_single_seed with overrides for K, HORIZON, BAGS, REBAL_DOW, pos_scale."""
    # Rebuild target with new horizon
    target_custom = np.zeros(n)
    for i in range(n - horizon):
        target_custom[i] = (prices[i + horizon] - prices[i]) / prices[i]

    full_allocs = np.full(n, 0.0)
    prev_alloc = 0.0
    a_s, a_b, a_a, a_r = [], [], [], []

    for te, ts, tend in periods:
        gap = max(horizon, 5)
        tm = np.arange(60, te - gap + 1)
        valid = ~np.any(np.isnan(X_all[tm]), axis=1)
        idx = tm[valid]
        if len(idx) < 100:
            continue

        Xt = np.nan_to_num(X_all[idx], nan=0.0)
        yt = target_custom[idx]

        bag_seeds = [seed + i * 7 for i in range(bags)]
        with ThreadPoolExecutor(max_workers=v22.WORKERS) as ex:
            models = list(ex.map(_train_one_xgb,
                [(s, Xt, yt, v22.XGB_PARAMS) for s in bag_seeds]))

        for t in range(ts, tend + 1):
            is_rebal = dow[t] in rebal_dow
            is_emerg = t > 0 and abs(daily_ret[t]) > v22.EMERGENCY_THRESHOLD
            if not is_rebal and not is_emerg:
                full_allocs[t] = prev_alloc
                continue

            x_t = np.nan_to_num(X_all[t:t + 1].copy(), nan=0.0)
            prediction = float(np.mean([m.predict(x_t)[0] for m in models]))

            # Custom allocation with K_regime
            if np.isnan(sma50[t]) or np.isnan(sma200[t]):
                regime = 'MILD'
            elif prices[t] > sma50[t] and sma50[t] > sma200[t]:
                regime = 'BULL'
            elif prices[t] > sma200[t]:
                regime = 'MILD'
            else:
                regime = 'BEAR'
            K = K_regime[regime]

            raw = prediction * K * pos_scale
            full_allocs[t] = float(np.clip(raw, v22.ALLOC_MIN, v22.ALLOC_MAX))
            prev_alloc = full_allocs[t]

        s, b, a = backtest_allocations(daily_ret, full_allocs, ts, tend,
                                       cost=COST, rf_daily=rf_daily)
        a_s.extend(s)
        a_b.extend(b)
        a_a.extend(a)
        a_r.extend(rf_daily[ts:ts + len(s)])

        del models
        gc.collect()

    return v22.metrics_v22(np.array(a_s), np.array(a_b), np.array(a_a),
                           rf_daily=np.array(a_r))


def run_config(name, feats, df, X_base, prices, daily_ret, dates, periods, dow,
               sma50, sma200, rf_daily, n, K_regime, horizon, bags, rebal_dow,
               pos_scale, seeds):
    mets = []
    for seed in seeds:
        m = run_single_seed_custom(seed, X_base, np.zeros(n), prices, daily_ret,
                                    dates, periods, dow, sma50, sma200, rf_daily, n,
                                    K_regime, horizon, bags, rebal_dow, pos_scale)
        mets.append(m)
    s = np.array([m['sortino'] for m in mets])
    sh = np.array([m['sharpe'] for m in mets])
    r = np.array([m['total']*100 for m in mets])
    dd = np.array([m['max_dd']*100 for m in mets])
    print(f"{name:<28}  Sortino {s.mean():.2f}+/-{s.std():.2f}  "
          f"Sharpe {sh.mean():.2f}+/-{sh.std():.2f}  "
          f"Ret {r.mean():+.0f}%+/-{r.std():.0f}%  "
          f"DD {dd.mean():.1f}%")
    return {'name': name, 'sortino_mean': float(s.mean()), 'sortino_std': float(s.std()),
            'sharpe_mean': float(sh.mean()), 'sharpe_std': float(sh.std()),
            'ret_mean': float(r.mean()), 'ret_std': float(r.std()),
            'dd_mean': float(dd.mean()), 'dd_std': float(dd.std()),
            'n_seeds': len(seeds)}


def fractional_diff(series, d=0.5, thres=0.01):
    w = [1.0]; k = 1
    while abs(w[-1]) > thres and k < len(series):
        w.append(-w[-1] * (d - k + 1) / k)
        k += 1
    w = np.array(w[::-1])
    arr = series.values
    out = np.full(len(arr), np.nan)
    W = len(w)
    for i in range(W - 1, len(arr)):
        window = arr[i - W + 1:i + 1]
        if np.any(np.isnan(window)):
            continue
        out[i] = (w * window).sum()
    return pd.Series(out, index=series.index)


def main():
    t0 = time.time()
    print("=" * 90)
    print("V26 SWEEP — comprehensive hyperparameter + feature tests")
    print("Reference: V25_FINAL+fracdiff (in prod dataset now):")
    print("  Sortino 4.95  Ret +1007%  DD -9.1%  (3 seeds, V22 backtest machinery)")
    print("=" * 90)

    prices, daily_ret, returns, vols, df = load()
    dates = df['date'].values
    n = len(prices)
    rf_daily = build_rf_daily(dates, source='auto')
    v9m.RF_DAILY_ARR = rf_daily
    v13m.RF_DAILY_ARR = rf_daily
    dow = pd.to_datetime(dates).dayofweek
    periods = _get_retrain_periods(dates, n, v22.RETRAIN)
    sma50 = pd.Series(prices).rolling(50).mean().values
    sma200 = pd.Series(prices).rolling(200).mean().values

    # Base X_all with V25_FINAL features
    feats = list(FEATURES_37)  # already has fracdiff, no OI/FTC
    X_base, _ = build_ml_features(df, returns, vols, n, feature_cols=feats)

    K_DEFAULT = {'BULL': 60, 'MILD': 30, 'BEAR': 15}
    results = []

    print("\n" + "=" * 50 + "\nSET A — Smooth rebalance" + "\n" + "=" * 50)
    results.append(run_config('A1_Fri_only', feats, df, X_base, prices, daily_ret, dates,
                               periods, dow, sma50, sma200, rf_daily, n,
                               K_DEFAULT, 3, 80, [4], 1.0, SEEDS_3))
    results.append(run_config('A2_ThuFri', feats, df, X_base, prices, daily_ret, dates,
                               periods, dow, sma50, sma200, rf_daily, n,
                               K_DEFAULT, 3, 80, [3, 4], 1.0, SEEDS_3))
    results.append(run_config('A3_ThuFriMon', feats, df, X_base, prices, daily_ret, dates,
                               periods, dow, sma50, sma200, rf_daily, n,
                               K_DEFAULT, 3, 80, [3, 4, 0], 1.0, SEEDS_3))
    results.append(run_config('A4_Fri_scaled07', feats, df, X_base, prices, daily_ret, dates,
                               periods, dow, sma50, sma200, rf_daily, n,
                               K_DEFAULT, 3, 80, [4], 0.7, SEEDS_3))

    print("\n" + "=" * 50 + "\nSET B — Fracdiff d sweep" + "\n" + "=" * 50)
    # For fracdiff sweep, we need to swap price_fracdiff_05 with fracdiff at different d
    # Build variants once
    log_prices = np.log(prices)
    fed_log = np.log(df['fed_balance_sheet'].replace(0, np.nan))
    for d_val in [0.3, 0.4, 0.5, 0.6, 0.7]:
        # Only swap fracdiff columns; other features stay the same
        df_tmp = df.copy()
        df_tmp['price_fracdiff_05'] = fractional_diff(pd.Series(log_prices), d=d_val)
        df_tmp['fed_fracdiff_05'] = fractional_diff(fed_log, d=d_val)
        X_tmp, _ = build_ml_features(df_tmp, returns, vols, n, feature_cols=feats)
        results.append(run_config(f'B_fracdiff_d{int(d_val*10)}', feats, df_tmp, X_tmp,
                                   prices, daily_ret, dates, periods, dow, sma50, sma200,
                                   rf_daily, n, K_DEFAULT, 3, 80, [4], 1.0, SEEDS_3))

    print("\n" + "=" * 50 + "\nSET C — K_REGIME sweep" + "\n" + "=" * 50)
    for label, k_cfg in [
        ('C1_40_20_10', {'BULL': 40, 'MILD': 20, 'BEAR': 10}),
        ('C2_50_25_15', {'BULL': 50, 'MILD': 25, 'BEAR': 15}),
        ('C3_60_30_15', K_DEFAULT),
        ('C4_70_35_20', {'BULL': 70, 'MILD': 35, 'BEAR': 20}),
        ('C5_80_40_20', {'BULL': 80, 'MILD': 40, 'BEAR': 20}),
        ('C6_100_50_25', {'BULL': 100, 'MILD': 50, 'BEAR': 25}),
    ]:
        results.append(run_config(label, feats, df, X_base, prices, daily_ret, dates,
                                   periods, dow, sma50, sma200, rf_daily, n,
                                   k_cfg, 3, 80, [4], 1.0, SEEDS_3))

    print("\n" + "=" * 50 + "\nSET D — HORIZON sweep" + "\n" + "=" * 50)
    for h in [2, 3, 5, 7]:
        results.append(run_config(f'D_horizon_{h}d', feats, df, X_base, prices, daily_ret,
                                   dates, periods, dow, sma50, sma200, rf_daily, n,
                                   K_DEFAULT, h, 80, [4], 1.0, SEEDS_3))

    print("\n" + "=" * 50 + "\nSET E — BAGS sweep" + "\n" + "=" * 50)
    for b in [40, 80, 100, 150]:
        results.append(run_config(f'E_bags_{b}', feats, df, X_base, prices, daily_ret,
                                   dates, periods, dow, sma50, sma200, rf_daily, n,
                                   K_DEFAULT, 3, b, [4], 1.0, SEEDS_3))

    # Pick best by Sortino
    best = max(results, key=lambda r: r['sortino_mean'])
    print()
    print("=" * 90)
    print(f"Best by Sortino so far: {best['name']}  Sortino {best['sortino_mean']:.2f}")
    print("=" * 90)

    # Save intermediate results
    RESULTS_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(RESULTS_PATH, 'w') as f:
        json.dump({'results': results, 'best_so_far': best['name']}, f, indent=2)

    elapsed = (time.time() - t0) / 60
    print(f"\nTotal: {elapsed:.1f} min")
    print(f"Saved: {RESULTS_PATH}")


if __name__ == '__main__':
    main()
