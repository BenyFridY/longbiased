"""
V23 Feature Test — Intra-week dynamics + prediction feedback

Tests adding new features to the V22 baseline:
  Group A: Intra-week dynamics (5-day patterns)
    - week_range_pct: (max-min)/close of last 5 days
    - week_trend: # of positive days in last 5
    - week_max_dd: worst intraday drawdown in last 5 days
    - week_close_vs_range: where close sits in the week's range (0=low, 1=high)

  Group B: Prediction feedback
    - pred_error_last: last prediction error (predicted - actual 3d return)
    - pred_direction_hit: 1 if last prediction direction was correct, 0 if not
    - pred_cumul_error_5: cumulative prediction error over last 5 predictions

  Configs:
    1. Baseline (V22, 37 features)
    2. +Group A (intra-week)
    3. +Group B (feedback)
    4. +Group A + B (both)

3 seeds each.
"""
import sys, gc, numpy as np, pandas as pd
from pathlib import Path
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
import warnings; warnings.filterwarnings('ignore')
sys.stdout.reconfigure(line_buffering=True)

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

from archive.old_pipelines.pipeline_v09 import (
    load_data, build_ml_features, backtest_allocations,
    COST, P, convert_numpy,
)
from archive.old_pipelines.pipeline_v10 import MODELS
from archive.old_pipelines.pipeline_v13 import _get_retrain_periods, _train_one_xgb

XGB_PARAMS = {
    'max_leaves': 31, 'grow_policy': 'lossguide', 'tree_method': 'hist',
    'colsample_bytree': 0.5, 'subsample': 0.8, 'learning_rate': 0.05,
    'min_child_weight': 12, 'n_estimators': 200,
    'objective': 'reg:squarederror', 'verbosity': 0, 'nthread': 1,
}
K_REGIME = {'BULL': 50, 'MILD': 30, 'BEAR': 15}
BAGS = 80
HORIZON = 3
REBAL_DOW = [4]
EMERGENCY_THRESHOLD = 0.08
WORKERS = 16
NUM_SEEDS = 3
SEEDS = [42, 142, 242]

BASE_FEATURES = [f for f in MODELS['37feat'] if f != 'exchange_netflow_ma7'] + ['basis_pct']
EXTRA_FEATURES = [
    'fed_balance_sheet', 'futures_trade_count',
    'vol_x_regime_duration', 'velocity', 'hash_rate_pctchg_30d',
]


def build_intra_week_features(prices, daily_ret, n):
    """Group A: intra-week dynamics."""
    P("  Building intra-week features...")
    week_range_pct = np.zeros(n)
    week_trend = np.zeros(n)
    week_max_dd = np.zeros(n)
    week_close_vs_range = np.zeros(n)

    for i in range(5, n):
        window = prices[i-4:i+1]  # last 5 days including today
        rets = daily_ret[i-4:i+1]

        hi = np.max(window)
        lo = np.min(window)
        rng = (hi - lo) / (window[-1] + 1e-10)
        week_range_pct[i] = rng

        week_trend[i] = np.sum(rets > 0) / 5.0  # fraction of positive days

        # Max drawdown in window
        cum = np.cumprod(1 + rets)
        pk = np.maximum.accumulate(cum)
        dd = np.min((cum - pk) / (pk + 1e-10))
        week_max_dd[i] = dd

        # Where does close sit in the range
        if hi > lo:
            week_close_vs_range[i] = (window[-1] - lo) / (hi - lo)
        else:
            week_close_vs_range[i] = 0.5

    return {
        'week_range_pct': week_range_pct,
        'week_trend': week_trend,
        'week_max_dd': week_max_dd,
        'week_close_vs_range': week_close_vs_range,
    }


def get_regime(t, prices, sma50, sma200):
    if np.isnan(sma50[t]) or np.isnan(sma200[t]):
        return 'MILD'
    if prices[t] > sma50[t] and sma50[t] > sma200[t]:
        return 'BULL'
    elif prices[t] > sma200[t]:
        return 'MILD'
    return 'BEAR'


def metrics_correct(s, b, a, rf_daily=None):
    if len(s) < 10:
        return None
    if rf_daily is None:
        rf_daily = 0.0
    ts = np.prod(1 + s) - 1
    ex = s - rf_daily
    downside = np.minimum(ex, 0.0)
    dd_std = np.sqrt(np.mean(downside ** 2))
    sortino = np.mean(ex) / (dd_std + 1e-10) * np.sqrt(365)
    sharpe = np.mean(ex) / (np.std(s) + 1e-10) * np.sqrt(365)
    cum = np.cumprod(1 + s)
    pk = np.maximum.accumulate(cum)
    max_dd = np.min((cum - pk) / (pk + 1e-10))
    return {'total': ts, 'sortino': sortino, 'sharpe': sharpe, 'max_dd': max_dd}


def run_seed(seed, X_all, target, prices, daily_ret, dates, periods,
             dow, sma50, sma200, rf_daily, n):
    """Run one seed — generates predictions + feedback features on the fly."""
    full_allocs = np.full(n, 0.0)
    prev_alloc = 0.0
    a_s, a_b, a_a, a_r = [], [], [], []

    # Track predictions for feedback features
    last_pred = 0.0
    last_pred_t = 0
    pred_errors = []  # rolling history of (predicted - actual)

    for te, ts, tend in periods:
        gap = max(HORIZON, 5)
        tm = np.arange(60, te - gap + 1)
        valid = ~np.any(np.isnan(X_all[tm]), axis=1)
        idx = tm[valid]
        if len(idx) < 100:
            continue

        Xt = np.nan_to_num(X_all[idx], nan=0.0)
        yt = target[idx]

        bag_seeds = [seed + i * 7 for i in range(BAGS)]
        with ThreadPoolExecutor(max_workers=WORKERS) as ex:
            models = list(ex.map(_train_one_xgb,
                [(s, Xt, yt, XGB_PARAMS) for s in bag_seeds]))

        for t in range(ts, tend + 1):
            is_rebal = dow[t] in REBAL_DOW
            is_emerg = t > 0 and abs(daily_ret[t]) > EMERGENCY_THRESHOLD
            if not is_rebal and not is_emerg:
                full_allocs[t] = prev_alloc
                continue

            # Compute feedback features before prediction
            if last_pred_t > 0 and t >= last_pred_t + HORIZON:
                actual_3d = (prices[min(last_pred_t + HORIZON, n-1)] - prices[last_pred_t]) / prices[last_pred_t]
                error = last_pred - actual_3d
                pred_errors.append(error)
                direction_hit = 1.0 if (last_pred > 0 and actual_3d > 0) or (last_pred < 0 and actual_3d < 0) else 0.0
            else:
                error = 0.0
                direction_hit = 0.5

            # Build extended feature vector
            x_t = np.nan_to_num(X_all[t:t + 1].copy(), nan=0.0)

            # Append feedback features if config includes them
            n_base = X_all.shape[1]
            if x_t.shape[1] > n_base:
                # Feedback columns are at the end
                fb_start = n_base
                # pred_error_last
                x_t[0, fb_start] = error
                # pred_direction_hit
                x_t[0, fb_start + 1] = direction_hit
                # pred_cumul_error_5
                recent_errors = pred_errors[-5:] if pred_errors else [0]
                x_t[0, fb_start + 2] = np.mean(recent_errors)

            prediction = float(np.mean([m.predict(x_t)[0] for m in models]))
            regime = get_regime(t, prices, sma50, sma200)
            K = K_REGIME[regime]
            full_allocs[t] = np.clip(prediction * K, -0.25, 1.0)
            prev_alloc = full_allocs[t]

            last_pred = prediction
            last_pred_t = t

        s, b, a = backtest_allocations(daily_ret, full_allocs, ts, tend,
                                       cost=COST, rf_daily=rf_daily)
        a_s.extend(s)
        a_b.extend(b)
        a_a.extend(a)
        a_r.extend(rf_daily[ts:ts + len(s)])
        del models; gc.collect()

    return metrics_correct(np.array(a_s), np.array(a_b), np.array(a_a),
                           rf_daily=np.array(a_r))


def main():
    P("=" * 80)
    P("V23 FEATURE TEST — Intra-week + Prediction Feedback")
    P("=" * 80)

    start = datetime.now()

    P("\nLoading data...")
    prices, daily_ret, returns, vols, df = load_data()
    dates = df['date'].values
    n = len(prices)

    try:
        from src.features.macro.cdi_rates import build_rf_daily
        rf_daily = build_rf_daily(dates, source='auto')
    except:
        from src.features.macro.cdi_rates import build_rf_daily
        rf_daily = build_rf_daily(dates, source='copom')

    import archive.old_pipelines.pipeline_v09 as v9m
    import archive.old_pipelines.pipeline_v13 as v13m
    v9m.RF_DAILY_ARR = rf_daily
    v13m.RF_DAILY_ARR = rf_daily

    fc = BASE_FEATURES + [f for f in EXTRA_FEATURES if f not in BASE_FEATURES]
    fc = [f for f in fc if f in df.columns]
    P(f"  {len(fc)} base features, {n} days")

    X_base, _ = build_ml_features(df, returns, vols, n, feature_cols=fc)

    target = np.zeros(n)
    for i in range(n - HORIZON):
        target[i] = (prices[i + HORIZON] - prices[i]) / prices[i]

    dow = pd.to_datetime(dates).dayofweek
    periods = _get_retrain_periods(dates, n, 'semi')
    sma50 = pd.Series(prices).rolling(50).mean().values
    sma200 = pd.Series(prices).rolling(200).mean().values

    # Build intra-week features
    iw = build_intra_week_features(prices, daily_ret, n)
    iw_matrix = np.column_stack([iw['week_range_pct'], iw['week_trend'],
                                  iw['week_max_dd'], iw['week_close_vs_range']])

    # Feedback placeholder (3 columns, filled during run)
    fb_matrix = np.zeros((n, 3))

    # Configs
    configs = [
        ("Baseline (V22, 37 feat)", X_base),
        ("+Intra-week (41 feat)", np.column_stack([X_base, iw_matrix])),
        ("+Feedback (40 feat)", np.column_stack([X_base, fb_matrix])),
        ("+Both (44 feat)", np.column_stack([X_base, iw_matrix, fb_matrix])),
    ]

    all_results = []

    for ci, (label, X_all) in enumerate(configs):
        P(f"\n{'---'*20}")
        P(f"[{ci+1}/{len(configs)}] {label} ({X_all.shape[1]} features)")
        P(f"{'---'*20}")

        sortinos, sharpes, rets_list, dds = [], [], [], []

        for seed in SEEDS:
            m = run_seed(seed, X_all, target, prices, daily_ret, dates, periods,
                        dow, sma50, sma200, rf_daily, n)
            if m is None:
                P(f"  Seed {seed}: FAILED")
                continue
            sortinos.append(m['sortino'])
            sharpes.append(m['sharpe'])
            rets_list.append(m['total'] * 100)
            dds.append(m['max_dd'] * 100)
            P(f"  Seed {seed}: Sortino={m['sortino']:.2f}  Sharpe={m['sharpe']:.2f}  "
              f"Ret={m['total']*100:+.0f}%  DD={m['max_dd']*100:.1f}%")

        if sortinos:
            result = {
                'label': label,
                'sortino_avg': float(np.mean(sortinos)),
                'sharpe_avg': float(np.mean(sharpes)),
                'return_avg': float(np.mean(rets_list)),
                'max_dd_avg': float(np.mean(dds)),
            }
            all_results.append(result)
            P(f"  => Sortino={np.mean(sortinos):.2f}  Sharpe={np.mean(sharpes):.2f}  "
              f"Ret={np.mean(rets_list):+.0f}%  DD={np.mean(dds):.1f}%")

    elapsed = (datetime.now() - start).total_seconds() / 60

    P(f"\n{'='*80}")
    P(f"SUMMARY — {NUM_SEEDS} seeds each ({elapsed:.0f} min)")
    P(f"{'='*80}\n")
    P(f"  {'#':<3} {'Config':<35} {'Sortino':>8} {'Sharpe':>8} {'Return':>8} {'MaxDD':>8}")
    P(f"  {'---':<3} {'---':<35} {'---':>8} {'---':>8} {'---':>8} {'---':>8}")

    ranked = sorted(all_results, key=lambda x: x['sortino_avg'], reverse=True)
    for i, r in enumerate(ranked):
        marker = " **" if i == 0 else ""
        P(f"  {i+1:<3} {r['label']:<35} {r['sortino_avg']:>7.2f}  {r['sharpe_avg']:>7.2f}  "
          f"{r['return_avg']:>+7.0f}%  {r['max_dd_avg']:>7.1f}%{marker}")

    baseline = next(r for r in all_results if 'Baseline' in r['label'])
    best = ranked[0]
    P(f"\n  Best: {best['label']}")
    P(f"  vs baseline: Sortino {best['sortino_avg'] - baseline['sortino_avg']:+.2f}")
    P(f"{'='*80}")


if __name__ == '__main__':
    main()
