"""V29 OOS test: verify V29.4 holds when restricting evaluation to 2025-2026.

Walk-forward already gives OOS, but here we isolate the most recent years to
check if the +0.31 Sortino improvement is uniform across time or concentrated
in older periods (which would indicate overfit to the early data).
"""
import sys, time, gc
import numpy as np, pandas as pd
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import xgboost as xgb

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

import archive.old_pipelines.pipeline_v22 as v22
from archive.old_pipelines.pipeline_v09 import build_ml_features, backtest_allocations, COST
from scripts.production.training import _get_retrain_periods, _train_one_xgb
from src.features.macro.cdi_rates import build_rf_daily
import archive.old_pipelines.pipeline_v09 as v9m
import archive.old_pipelines.pipeline_v13 as v13m
from scripts.production.config import FEATURES_37, K_REGIME, ALLOC_MIN, ALLOC_MAX, BAGS, HORIZON, WORKERS, EMERGENCY_THRESHOLD

DATASET = ROOT / "outputs" / "feature_selection" / "dataset_enhanced.csv"
SEEDS = [42, 142, 242]

BOTTOM_10 = {
    'hash_rate_pctchg_30d', 'price_percentile_1y', 'ou_theta_60d', 'obv_trend',
    'ret_10d', 'macd_histogram', 'trend_strength', 'miners_revenue_ratio',
    'ret_3d', 'vol_x_regime_duration',
}


def fractional_diff(series, d=0.5, thres=0.01):
    w = [1.0]; k = 1
    while abs(w[-1]) > thres and k < len(series):
        w.append(-w[-1] * (d - k + 1) / k); k += 1
    w = np.array(w[::-1])
    arr = series.values if hasattr(series, 'values') else np.asarray(series)
    out = np.full(len(arr), np.nan)
    W = len(w)
    for i in range(W - 1, len(arr)):
        window = arr[i - W + 1:i + 1]
        if np.any(np.isnan(window)): continue
        out[i] = (w * window).sum()
    return out


def load():
    df = pd.read_csv(DATASET)
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)
    prices = df['price_usd'].values
    n = len(prices)
    daily_ret = np.zeros(n)
    for i in range(1, n):
        daily_ret[i] = (prices[i] - prices[i-1]) / prices[i-1]
    returns, vols = {}, {}
    for w in [1, 3, 5, 7, 10, 14, 20, 21, 30, 45, 60]:
        r = np.zeros(n)
        for i in range(w, n):
            r[i] = (prices[i] - prices[i-w]) / prices[i-w]
        returns[w] = r
    for w in [5, 7, 10, 14, 21, 30]:
        vols[w] = pd.Series(daily_ret).rolling(w).std().fillna(0.02).values
    return prices, daily_ret, returns, vols, df


def get_regime(t, prices, sma50, sma200):
    if np.isnan(sma50[t]) or np.isnan(sma200[t]): return 'MILD'
    if prices[t] > sma50[t] and sma50[t] > sma200[t]: return 'BULL'
    elif prices[t] > sma200[t]: return 'MILD'
    return 'BEAR'


def compute_allocation(pred, regime):
    return float(np.clip(pred * K_REGIME[regime], ALLOC_MIN, ALLOC_MAX))


def run_seed_with_split(seed, X_all, target, prices, daily_ret, dates, periods,
                        dow, sma50, sma200, rf_daily, n, split_start_date):
    """Returns metrics per period (list of (period_start, metrics))."""
    full_allocs = np.full(n, 0.0)
    prev_alloc = 0.0
    # Track per-period allocs for split analysis
    period_allocs = []  # list of (ts, tend, slice)

    for te, ts, tend in periods:
        gap = max(HORIZON, 5)
        tm = np.arange(60, te - gap + 1)
        valid = ~np.any(np.isnan(X_all[tm]), axis=1)
        idx = tm[valid]
        if len(idx) < 100: continue
        Xt = np.nan_to_num(X_all[idx], nan=0.0)
        yt = target[idx]
        bag_seeds = [seed + i * 7 for i in range(BAGS)]
        with ThreadPoolExecutor(max_workers=WORKERS) as ex:
            models = list(ex.map(_train_one_xgb,
                [(s, Xt, yt, v22.XGB_PARAMS) for s in bag_seeds]))
        for t in range(ts, tend + 1):
            x_t = np.nan_to_num(X_all[t:t + 1].copy(), nan=0.0)
            prediction = float(np.mean([m.predict(x_t)[0] for m in models]))
            is_rebal = dow[t] in [4]
            is_emerg = t > 0 and abs(daily_ret[t]) > EMERGENCY_THRESHOLD
            if not is_rebal and not is_emerg:
                full_allocs[t] = prev_alloc; continue
            regime = get_regime(t, prices, sma50, sma200)
            full_allocs[t] = compute_allocation(prediction, regime)
            prev_alloc = full_allocs[t]
        period_allocs.append((ts, tend))
        del models; gc.collect()

    # Split metrics: <split_date and >=split_date
    split_idx = np.searchsorted(pd.to_datetime(dates).values,
                                 np.datetime64(split_start_date))

    a_s_early, a_s_late = [], []
    a_r_early, a_r_late = [], []
    for ts, tend in period_allocs:
        s, b, a = backtest_allocations(daily_ret, full_allocs, ts, tend,
                                       cost=COST, rf_daily=rf_daily)
        # Determine split: if period fully before split_idx, append to early; fully after, late; else split
        r_slice = rf_daily[ts:ts + len(s)]
        # simple: split based on position
        for i_off, ret in enumerate(s):
            if ts + i_off < split_idx:
                a_s_early.append(ret); a_r_early.append(r_slice[i_off])
            else:
                a_s_late.append(ret); a_r_late.append(r_slice[i_off])

    early_metrics = v22.metrics_v22(np.array(a_s_early), np.array(a_s_early),
                                    np.array(a_s_early), rf_daily=np.array(a_r_early))
    late_metrics = v22.metrics_v22(np.array(a_s_late), np.array(a_s_late),
                                    np.array(a_s_late), rf_daily=np.array(a_r_late))
    return early_metrics, late_metrics


def main():
    t0 = time.time()
    print("=" * 85)
    print("V29 OOS SPLIT — early (2022-2024) vs late (2025+) period validation")
    print("=" * 85)

    prices, daily_ret, returns, vols, df = load()
    dates = df['date'].values
    n = len(prices)
    rf_daily = build_rf_daily(dates, source='auto')
    v9m.RF_DAILY_ARR = rf_daily
    v13m.RF_DAILY_ARR = rf_daily
    dow = pd.to_datetime(dates).dayofweek.values
    periods = _get_retrain_periods(dates, n, v22.RETRAIN)
    sma50 = pd.Series(prices).rolling(50).mean().values
    sma200 = pd.Series(prices).rolling(200).mean().values

    feats = list(FEATURES_37)
    X_base, fnames = build_ml_features(df, returns, vols, n, feature_cols=feats)
    top_idx = [i for i, f in enumerate(fnames) if f not in BOTTOM_10]
    X_pruned = X_base[:, top_idx]

    # Apply fracdiff d=0.3
    log_prices = np.log(prices)
    fed_log = np.log(df['fed_balance_sheet'].replace(0, np.nan).values)
    pruned_names = [fnames[i] for i in top_idx]
    X_pruned_d03 = X_pruned.copy()
    if 'price_fracdiff_05' in pruned_names:
        idx_p = pruned_names.index('price_fracdiff_05')
        X_pruned_d03[:, idx_p] = fractional_diff(log_prices, d=0.3)
    if 'fed_fracdiff_05' in pruned_names:
        idx_f = pruned_names.index('fed_fracdiff_05')
        X_pruned_d03[:, idx_f] = fractional_diff(fed_log, d=0.3)

    target = np.zeros(n)
    for i in range(n - HORIZON):
        target[i] = (prices[i + HORIZON] - prices[i]) / prices[i]

    SPLIT = '2025-01-01'
    print(f"Split date: {SPLIT}\n")

    print("-- Baseline V25 (full features, d=0.5) --")
    early_bl, late_bl = [], []
    for s in SEEDS:
        e, l = run_seed_with_split(s, X_base, target, prices, daily_ret, dates,
                                    periods, dow, sma50, sma200, rf_daily, n, SPLIT)
        early_bl.append(e); late_bl.append(l)

    s_ebl = np.array([m['sortino'] for m in early_bl])
    s_lbl = np.array([m['sortino'] for m in late_bl])
    print(f"  Early (2022-2024):  Sortino {s_ebl.mean():.2f}+/-{s_ebl.std():.2f}")
    print(f"  Late (2025+):       Sortino {s_lbl.mean():.2f}+/-{s_lbl.std():.2f}")

    print("\n-- V29.4 winner (pruned + d=0.3) --")
    early_v29, late_v29 = [], []
    for s in SEEDS:
        e, l = run_seed_with_split(s, X_pruned_d03, target, prices, daily_ret, dates,
                                    periods, dow, sma50, sma200, rf_daily, n, SPLIT)
        early_v29.append(e); late_v29.append(l)
    s_ev = np.array([m['sortino'] for m in early_v29])
    s_lv = np.array([m['sortino'] for m in late_v29])
    print(f"  Early (2022-2024):  Sortino {s_ev.mean():.2f}+/-{s_ev.std():.2f}")
    print(f"  Late (2025+):       Sortino {s_lv.mean():.2f}+/-{s_lv.std():.2f}")

    print()
    print("=" * 85)
    print("Deltas (V29.4 - baseline):")
    print(f"  Early:  {s_ev.mean() - s_ebl.mean():+.2f}")
    print(f"  Late:   {s_lv.mean() - s_lbl.mean():+.2f}")
    print(f"Total time: {(time.time()-t0)/60:.1f} min")
    print("=" * 85)


if __name__ == '__main__':
    main()
