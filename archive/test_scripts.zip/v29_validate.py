"""V29: validate winners with 10 seeds + test combos of top techniques.

Winners from V26/V27/V28:
  - T1_pruned_bot10: S=5.19 (V28)
  - Baseline: S=5.05

Tests (10 seeds each):

  V29.1 — Baseline V25 (10 seeds) — CONFIRM reference is 5.05±X
  V29.2 — T1_pruned_bot10 (10 seeds) — CONFIRM +0.14 is real
  V29.3 — T1 pruned + reg a=0.1 (new combo!)
  V29.4 — T1 pruned + fracdiff d=0.3 (new combo!)
  V29.5 — T1 pruned + fracdiff d=0.3 + reg a=0.1 (best-of-best combo)

Also compute: accuracy per DOW for each.
"""
import sys, time, json, gc
import numpy as np, pandas as pd
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import xgboost as xgb

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

import archive.old_pipelines.pipeline_v22 as v22
from archive.old_pipelines.pipeline_v09 import build_ml_features, backtest_allocations, COST
from scripts.production.training import _get_retrain_periods, _train_one_xgb
from src.features.macro.cdi_rates import build_rf_daily
import archive.old_pipelines.pipeline_v09 as v9m
import archive.old_pipelines.pipeline_v13 as v13m
from scripts.production.config import FEATURES_37, K_REGIME, ALLOC_MIN, ALLOC_MAX, BAGS, HORIZON, WORKERS, EMERGENCY_THRESHOLD

DATASET = ROOT / "outputs" / "feature_selection" / "dataset_enhanced.csv"
SEEDS_10 = [42, 142, 242, 342, 442, 542, 642, 742, 842, 942]
RESULTS = ROOT / "outputs" / "results" / "v29_validate.json"
DAY_NAMES = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun']

# Bottom-10 features identified by V28 gain importance
BOTTOM_10 = {
    'hash_rate_pctchg_30d', 'price_percentile_1y', 'ou_theta_60d', 'obv_trend',
    'ret_10d', 'macd_histogram', 'trend_strength', 'miners_revenue_ratio',
    'ret_3d', 'vol_x_regime_duration',
}


def load():
    df = pd.read_csv(DATASET)
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)
    prices = df['price_usd'].values
    n = len(prices)
    daily_ret = np.zeros(n)
    for i in range(1, n):
        daily_ret[i] = (prices[i] - prices[i-1]) / prices[i-1]
    returns, vols = {}, {}
    for w in [1, 3, 5, 7, 10, 14, 20, 21, 30, 45, 60]:
        r = np.zeros(n)
        for i in range(w, n):
            r[i] = (prices[i] - prices[i-w]) / prices[i-w]
        returns[w] = r
    for w in [5, 7, 10, 14, 21, 30]:
        vols[w] = pd.Series(daily_ret).rolling(w).std().fillna(0.02).values
    return prices, daily_ret, returns, vols, df


def fractional_diff(series, d=0.5, thres=0.01):
    w = [1.0]; k = 1
    while abs(w[-1]) > thres and k < len(series):
        w.append(-w[-1] * (d - k + 1) / k); k += 1
    w = np.array(w[::-1])
    arr = series.values if hasattr(series, 'values') else np.asarray(series)
    out = np.full(len(arr), np.nan)
    W = len(w)
    for i in range(W - 1, len(arr)):
        window = arr[i - W + 1:i + 1]
        if np.any(np.isnan(window)): continue
        out[i] = (w * window).sum()
    return out


def accuracy_per_dow(preds, actuals, dow):
    mask = np.abs(preds) > 1e-6
    out = {'all': float((np.sign(preds[mask]) == np.sign(actuals[mask])).mean())}
    for d, name in enumerate(DAY_NAMES):
        dmask = mask & (dow == d)
        if dmask.sum() > 10:
            out[name] = float((np.sign(preds[dmask]) == np.sign(actuals[dmask])).mean())
        else:
            out[name] = None
    return out


def get_regime(t, prices, sma50, sma200):
    if np.isnan(sma50[t]) or np.isnan(sma200[t]): return 'MILD'
    if prices[t] > sma50[t] and sma50[t] > sma200[t]: return 'BULL'
    elif prices[t] > sma200[t]: return 'MILD'
    return 'BEAR'


def compute_allocation(pred, regime):
    return float(np.clip(pred * K_REGIME[regime], ALLOC_MIN, ALLOC_MAX))


def run_seed(seed, X_all, target, prices, daily_ret, dates, periods,
             dow, sma50, sma200, rf_daily, n, xgb_params=None):
    params = xgb_params if xgb_params is not None else v22.XGB_PARAMS
    full_allocs = np.full(n, 0.0)
    prev_alloc = 0.0
    a_s, a_b, a_a, a_r = [], [], [], []
    all_preds = np.zeros(n)
    all_actuals = target.copy()

    for te, ts, tend in periods:
        gap = max(HORIZON, 5)
        tm = np.arange(60, te - gap + 1)
        valid = ~np.any(np.isnan(X_all[tm]), axis=1)
        idx = tm[valid]
        if len(idx) < 100: continue
        Xt = np.nan_to_num(X_all[idx], nan=0.0)
        yt = target[idx]
        bag_seeds = [seed + i * 7 for i in range(BAGS)]
        with ThreadPoolExecutor(max_workers=WORKERS) as ex:
            models = list(ex.map(_train_one_xgb,
                [(s, Xt, yt, params) for s in bag_seeds]))
        for t in range(ts, tend + 1):
            x_t = np.nan_to_num(X_all[t:t + 1].copy(), nan=0.0)
            prediction = float(np.mean([m.predict(x_t)[0] for m in models]))
            all_preds[t] = prediction
            is_rebal = dow[t] in [4]
            is_emerg = t > 0 and abs(daily_ret[t]) > EMERGENCY_THRESHOLD
            if not is_rebal and not is_emerg:
                full_allocs[t] = prev_alloc; continue
            regime = get_regime(t, prices, sma50, sma200)
            full_allocs[t] = compute_allocation(prediction, regime)
            prev_alloc = full_allocs[t]
        s, b, a = backtest_allocations(daily_ret, full_allocs, ts, tend,
                                       cost=COST, rf_daily=rf_daily)
        a_s.extend(s); a_b.extend(b); a_a.extend(a)
        a_r.extend(rf_daily[ts:ts + len(s)])
        del models; gc.collect()
    metrics = v22.metrics_v22(np.array(a_s), np.array(a_b), np.array(a_a),
                              rf_daily=np.array(a_r))
    return metrics, all_preds, all_actuals


def aggregate(name, outputs, dow):
    sortinos = [o[0]['sortino'] for o in outputs]
    rets     = [o[0]['total']*100 for o in outputs]
    dds      = [o[0]['max_dd']*100 for o in outputs]
    preds_avg = np.mean([o[1] for o in outputs], axis=0)
    actuals = outputs[0][2]
    acc = accuracy_per_dow(preds_avg, actuals, dow)
    result = {
        'name': name,
        'sortino_mean': float(np.mean(sortinos)), 'sortino_std': float(np.std(sortinos)),
        'ret_mean': float(np.mean(rets)), 'ret_std': float(np.std(rets)),
        'dd_mean': float(np.mean(dds)), 'dd_std': float(np.std(dds)),
        'acc': acc, 'n_seeds': len(outputs),
    }
    print(f"{name:<30}  S={result['sortino_mean']:.2f}+/-{result['sortino_std']:.2f}  "
          f"Ret={result['ret_mean']:+.0f}%+/-{result['ret_std']:.0f}%  "
          f"DD={result['dd_mean']:.1f}%  Fri={acc.get('Fri', 0)*100:.1f}%  "
          f"all={acc['all']*100:.1f}%")
    return result


def main():
    t0 = time.time()
    print("=" * 95)
    print("V29 VALIDATE — 10 seeds on winners + combos")
    print("=" * 95)

    prices, daily_ret, returns, vols, df = load()
    dates = df['date'].values
    n = len(prices)
    rf_daily = build_rf_daily(dates, source='auto')
    v9m.RF_DAILY_ARR = rf_daily
    v13m.RF_DAILY_ARR = rf_daily
    dow = pd.to_datetime(dates).dayofweek.values
    periods = _get_retrain_periods(dates, n, v22.RETRAIN)
    sma50 = pd.Series(prices).rolling(50).mean().values
    sma200 = pd.Series(prices).rolling(200).mean().values

    feats = list(FEATURES_37)
    X_base, fnames = build_ml_features(df, returns, vols, n, feature_cols=feats)

    # Pruned: remove bottom-10 by importance
    top_idx = [i for i, f in enumerate(fnames) if f not in BOTTOM_10]
    X_pruned = X_base[:, top_idx]
    print(f"Full features: {len(fnames)}, pruned: {len(top_idx)}")

    target = np.zeros(n)
    for i in range(n - HORIZON):
        target[i] = (prices[i + HORIZON] - prices[i]) / prices[i]

    # Fracdiff d=0.3 on pruned set
    log_prices = np.log(prices)
    fed_log = np.log(df['fed_balance_sheet'].replace(0, np.nan).values)
    # Find indices in pruned set (fracdiff columns survived pruning if they were high importance)
    pruned_names = [fnames[i] for i in top_idx]
    X_pruned_d03 = X_pruned.copy()
    if 'price_fracdiff_05' in pruned_names:
        idx_p = pruned_names.index('price_fracdiff_05')
        X_pruned_d03[:, idx_p] = fractional_diff(log_prices, d=0.3)
    if 'fed_fracdiff_05' in pruned_names:
        idx_f = pruned_names.index('fed_fracdiff_05')
        X_pruned_d03[:, idx_f] = fractional_diff(fed_log, d=0.3)

    results = []
    def save():
        RESULTS.parent.mkdir(parents=True, exist_ok=True)
        with open(RESULTS, 'w') as f:
            json.dump({'results': results, 'elapsed_min': (time.time()-t0)/60}, f, indent=2)

    # V29.1: Baseline 10 seeds
    print("\n-- V29.1: Baseline V25 (10 seeds) --")
    outs = [run_seed(s, X_base, target, prices, daily_ret, dates, periods,
                     dow, sma50, sma200, rf_daily, n) for s in SEEDS_10]
    results.append(aggregate('V29.1_baseline', outs, dow)); save()

    # V29.2: T1 pruned 10 seeds
    print("\n-- V29.2: T1 pruned (10 seeds) --")
    outs = [run_seed(s, X_pruned, target, prices, daily_ret, dates, periods,
                     dow, sma50, sma200, rf_daily, n) for s in SEEDS_10]
    results.append(aggregate('V29.2_pruned', outs, dow)); save()

    # V29.3: Pruned + reg a=0.1
    print("\n-- V29.3: pruned + reg a=0.1 (10 seeds) --")
    p3 = dict(v22.XGB_PARAMS); p3['reg_alpha'] = 0.1; p3['reg_lambda'] = 0.1
    outs = [run_seed(s, X_pruned, target, prices, daily_ret, dates, periods,
                     dow, sma50, sma200, rf_daily, n, xgb_params=p3) for s in SEEDS_10]
    results.append(aggregate('V29.3_pruned_reg01', outs, dow)); save()

    # V29.4: Pruned + fracdiff d=0.3
    print("\n-- V29.4: pruned + fracdiff d=0.3 (10 seeds) --")
    outs = [run_seed(s, X_pruned_d03, target, prices, daily_ret, dates, periods,
                     dow, sma50, sma200, rf_daily, n) for s in SEEDS_10]
    results.append(aggregate('V29.4_pruned_d03', outs, dow)); save()

    # V29.5: Pruned + d=0.3 + reg (triple combo)
    print("\n-- V29.5: pruned + d=0.3 + reg a=0.1 (10 seeds) --")
    outs = [run_seed(s, X_pruned_d03, target, prices, daily_ret, dates, periods,
                     dow, sma50, sma200, rf_daily, n, xgb_params=p3) for s in SEEDS_10]
    results.append(aggregate('V29.5_triple_combo', outs, dow)); save()

    print()
    print("=" * 95)
    print(f"V29 TOTAL: {(time.time()-t0)/60:.1f} min")
    print("=" * 95)
    print("\nRanked by Sortino:")
    for r in sorted(results, key=lambda x: -x['sortino_mean']):
        acc = r['acc']
        print(f"  {r['name']:<30}  S={r['sortino_mean']:.2f}+/-{r['sortino_std']:.2f}  "
              f"Ret={r['ret_mean']:+.0f}%  DD={r['dd_mean']:.1f}%  Fri={acc.get('Fri', 0)*100:.1f}%")
    save()


if __name__ == '__main__':
    main()
