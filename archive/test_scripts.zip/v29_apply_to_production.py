"""V29: apply winning config to production.

Winner: V29.4 (pruned + fracdiff d=0.3)
  - Remove 8 features with low gain importance from FEATURES_37
  - Change fracdiff d=0.5 -> d=0.3 in build_features.py

Validated results (10 seeds):
  Baseline:   Sortino 5.03+/-0.06  Ret +1092%  DD -9.1%
  V29.4:      Sortino 5.34+/-0.06  Ret +1165%  DD -9.1%
  Delta:      +0.31 Sortino (5 sigma significant)

This script:
  1. Backs up config.py and build_features.py
  2. Edits FEATURES_37 to remove the 8 bottom features
  3. Edits build_features.py to use d=0.3
  4. Prints what changed

After running: user should run `python scripts/production/run_daily.py --retrain`
to apply the changes (retrain model with new feature set).
"""
import shutil
import re
from pathlib import Path

ROOT = Path(__file__).parent.parent.parent
CONFIG = ROOT / "scripts" / "production" / "config.py"
BUILD_FEAT = ROOT / "scripts" / "production" / "build_features.py"

# Bottom 8 features from V28 gain importance (ret_3d/ret_10d are derived, not in 37)
REMOVE = [
    'hash_rate_pctchg_30d',
    'price_percentile_1y',
    'ou_theta_60d',
    'obv_trend',
    'macd_histogram',
    'trend_strength',
    'miners_revenue_ratio',
    'vol_x_regime_duration',
]


def main():
    print("=" * 70)
    print("V29 APPLY TO PRODUCTION")
    print("=" * 70)

    # Backup
    shutil.copy(CONFIG, CONFIG.parent / "config.py.pre_v29")
    shutil.copy(BUILD_FEAT, BUILD_FEAT.parent / "build_features.py.pre_v29")
    print(f"Backups:")
    print(f"  {CONFIG.parent / 'config.py.pre_v29'}")
    print(f"  {BUILD_FEAT.parent / 'build_features.py.pre_v29'}")
    print()

    # ── Edit config.py ──
    src = CONFIG.read_text(encoding='utf-8')
    removed_count = 0
    for feat in REMOVE:
        # Match quoted 'feat' or "feat" possibly followed by comma/space
        pattern = re.compile(rf"'\s*{re.escape(feat)}\s*'\s*,\s*")
        new_src, n = pattern.subn('', src)
        if n > 0:
            src = new_src
            removed_count += 1
            print(f"  Removed: {feat}")
        else:
            print(f"  NOT FOUND: {feat}  (may already be removed)")

    # Update docstring to reflect new count
    src = re.sub(
        r"(# C2_BASE \(19\))",
        "# V29 FINAL: 29 features (removed 8 low-gain from V25)\n    # C2_BASE (19)",
        src, count=1
    )

    CONFIG.write_text(src, encoding='utf-8')
    print(f"\nconfig.py updated ({removed_count} features removed)")

    # ── Edit build_features.py: d=0.5 -> d=0.3 ──
    src = BUILD_FEAT.read_text(encoding='utf-8')
    # Two calls: fractional_diff(..., d=0.5)
    new_src = src.replace("d=0.5", "d=0.3")
    changes = src.count("d=0.5") - new_src.count("d=0.5")
    BUILD_FEAT.write_text(new_src, encoding='utf-8')
    print(f"\nbuild_features.py updated (d=0.5 -> d=0.3, {changes} occurrences)")

    # Verify config.py features count
    import importlib, sys
    sys.path.insert(0, str(ROOT))
    # Reload config
    from scripts.production import config as cfg
    importlib.reload(cfg)
    print(f"\nFEATURES_37 now has {len(cfg.FEATURES_37)} features")
    print(f"Expected: {37 - len(REMOVE)} = 29")

    print()
    print("=" * 70)
    print("TO ACTIVATE:")
    print("  python scripts/production/run_daily.py --retrain")
    print()
    print("TO REVERT:")
    print(f"  cp {CONFIG.parent / 'config.py.pre_v29'} {CONFIG}")
    print(f"  cp {BUILD_FEAT.parent / 'build_features.py.pre_v29'} {BUILD_FEAT}")
    print("  python scripts/production/run_daily.py --retrain")
    print("=" * 70)


if __name__ == '__main__':
    main()
