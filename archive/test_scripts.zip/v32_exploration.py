"""V32 -- Novel Techniques Battery (5h overnight, efficient).

Design insight (user feedback): K regime, sigmoid, floor, ceiling, sizing modes are
post-training multiplications. Train each novel base ONCE, then sweep decision
layer combinations cheaply.

Phases:
  PHASE 1 (~2.5h): Train 10 novel bases x 3 seeds each. Save raw predictions.
  PHASE 2 (~10min): Sweep decision layer for each base (K, sigmoid, floor, sizing).
  PHASE 3 (~1h): Validate TOP 3 with 10 seeds (re-train).

Novel bases (never tested in V2-V31):
  base_baseline     : V31.0 equiv (V29 features, sqerror loss)
  base_huber        : pseudo-Huber loss (reg:pseudohubererror) -- robust fat tails
  base_quantile     : quantile regression at 0.5 (reg:quantileerror)
  base_timedecay    : exp decay sample weights (half-life 2y)
  base_monotone     : monotonic constraints on trend features
  base_per_regime   : 3 separate models (BULL/MILD/BEAR)
  base_log_target   : signed-log return target
  base_rank_target  : rank (percentile) transform
  base_multi_horiz  : adds 7d prediction blended with 3d
  base_calib        : isotonic calibration on classifier

Decision layer sweeps (phase 2, for baseline + top novel bases):
  K regimes: {60/30/15, 70/30/10, 50/30/25, 80/20/0, 100/50/20}
  Sigmoid scale: {no_sigmoid, 5, 10, 15, 20, 25}
  Floor: {-0.25, 0.0}
  Sizing: {linear, vol_target_0.15, vol_target_0.25, kelly, dd_aware}
  Rebal: {normal, threshold_0.1, half_weight}
"""
import sys, time, json, gc
import numpy as np, pandas as pd
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import xgboost as xgb

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

import archive.old_pipelines.pipeline_v22 as v22
from archive.old_pipelines.pipeline_v09 import build_ml_features, backtest_allocations, COST
from scripts.production.training import _get_retrain_periods, _train_one_xgb
from src.features.macro.cdi_rates import build_rf_daily
import archive.old_pipelines.pipeline_v09 as v9m
import archive.old_pipelines.pipeline_v13 as v13m
from scripts.production.config import FEATURES_37, BAGS, HORIZON, WORKERS, EMERGENCY_THRESHOLD

DATASET = ROOT / "outputs" / "feature_selection" / "dataset_enhanced.csv"
RESULTS = ROOT / "outputs" / "results" / "v32_exploration.json"
V31_EXTRAS_JSON = ROOT / "outputs" / "results" / "v31_extras.json"

SEEDS_10 = [42, 142, 242, 342, 442, 542, 642, 742, 842, 942]
SEEDS_3  = [42, 142, 242]
DAY_NAMES = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun']
K_DEFAULT = {'BULL': 60, 'MILD': 30, 'BEAR': 15}


# ===============================================================
# UTILITIES
# ===============================================================

def load_data():
    df = pd.read_csv(DATASET)
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)
    prices = df['price_usd'].values
    n = len(prices)
    daily_ret = np.zeros(n)
    for i in range(1, n):
        daily_ret[i] = (prices[i] - prices[i-1]) / prices[i-1]
    returns, vols = {}, {}
    for w in [1, 3, 5, 7, 10, 14, 20, 21, 30, 45, 60]:
        r = np.zeros(n)
        for i in range(w, n):
            r[i] = (prices[i] - prices[i-w]) / prices[i-w]
        returns[w] = r
    for w in [5, 7, 10, 14, 21, 30]:
        vols[w] = pd.Series(daily_ret).rolling(w).std().fillna(0.02).values
    return prices, daily_ret, returns, vols, df


def get_regime(t, prices, sma50, sma200):
    if np.isnan(sma50[t]) or np.isnan(sma200[t]): return 'MILD'
    if prices[t] > sma50[t] and sma50[t] > sma200[t]: return 'BULL'
    elif prices[t] > sma200[t]: return 'MILD'
    return 'BEAR'


def _train_reg_one(args):
    """Train one regressor. Matches V31 _train_one_xgb (NO bootstrap, uses XGB subsample)."""
    s, Xt, yt, xgb_params, objective, extra_params, sample_weight = args
    p = dict(xgb_params); p.pop('objective', None)
    if extra_params: p.update(extra_params)
    allowed = {k:v for k,v in p.items() if k in
               ['max_leaves','colsample_bytree','subsample','learning_rate',
                'min_child_weight','reg_alpha','reg_lambda','grow_policy',
                'tree_method','quantile_alpha','monotone_constraints',
                'interaction_constraints']}
    m = xgb.XGBRegressor(
        n_estimators=p.pop('n_estimators', 200),
        random_state=s, objective=objective, n_jobs=1, verbosity=0,
        **allowed)
    m.fit(Xt, yt, sample_weight=sample_weight)
    return m


def train_reg_bag(Xt, yt, bag_seeds, xgb_params, sample_weight=None,
                   objective='reg:squarederror', extra_params=None):
    """NO bootstrap (matches V31 production). Ensemble diversity via random_state + XGB subsample.
       Parallelized with ThreadPoolExecutor."""
    args_list = [(s, Xt, yt, xgb_params, objective, extra_params, sample_weight)
                 for s in bag_seeds]
    with ThreadPoolExecutor(max_workers=WORKERS) as ex:
        models = list(ex.map(_train_reg_one, args_list))
    return models


def _train_cls_one(args):
    """Train one classifier WITH bootstrap (matches V31 train_classifier_bag)."""
    s, Xt, yt_bin, xgb_params, sample_weight = args
    rng = np.random.RandomState(s)
    idx = rng.choice(len(Xt), size=len(Xt), replace=True)
    p = dict(xgb_params); p.pop('objective', None)
    allowed = {k:v for k,v in p.items() if k in
               ['max_leaves','colsample_bytree','subsample','learning_rate',
                'min_child_weight','reg_alpha','reg_lambda','grow_policy','tree_method']}
    m = xgb.XGBClassifier(
        n_estimators=p.pop('n_estimators', 200),
        random_state=s, objective='binary:logistic',
        eval_metric='logloss', n_jobs=1, **allowed)
    w = sample_weight[idx] if sample_weight is not None else None
    m.fit(Xt[idx], yt_bin[idx], sample_weight=w)
    return m


def train_cls_bag(Xt, yt_raw, bag_seeds, xgb_params, sample_weight=None):
    """Bootstrap classifier ensemble (matches V31). Parallelized."""
    yt_bin = (yt_raw > 0).astype(int)
    args_list = [(s, Xt, yt_bin, xgb_params, sample_weight) for s in bag_seeds]
    with ThreadPoolExecutor(max_workers=WORKERS) as ex:
        models = list(ex.map(_train_cls_one, args_list))
    return models


# ===============================================================
# TRAINING -- produces per-seed reg_preds[n] and cls_probs[n] arrays
# ===============================================================

def train_base(seeds, X_all, target, prices, daily_ret, dates, periods,
                dow, sma50, sma200, rf_daily, n, fnames,
                reg_objective='reg:squarederror', reg_extra=None,
                sample_weight_fn=None, target_transform=None, calibrate=False,
                multi_horizon_7d=False):
    """Train base model per seed. Return dict:
       {'reg_preds': [n_seeds][n], 'cls_probs': [n_seeds][n]}
    """
    params = v22.XGB_PARAMS
    out_reg = [np.zeros(n) for _ in seeds]
    out_cls = [np.full(n, 0.5) for _ in seeds]

    # Multi-horizon 7d target if requested
    target_7d = None
    if multi_horizon_7d:
        target_7d = np.zeros(n)
        for i in range(n - 7):
            target_7d[i] = (prices[i + 7] - prices[i]) / prices[i]

    for te, ts, tend in periods:
        gap = max(HORIZON, 5)
        tm = np.arange(60, te - gap + 1)
        valid = ~np.any(np.isnan(X_all[tm]), axis=1)
        idx = tm[valid]
        if len(idx) < 100: continue
        Xt = np.nan_to_num(X_all[idx], nan=0.0)
        yt_raw = target[idx]

        # Target transform
        if target_transform == 'log':
            yt = np.sign(yt_raw) * np.log(1 + np.abs(yt_raw))
        elif target_transform == 'rank':
            yt = (pd.Series(yt_raw).rank(pct=True).values - 0.5) * 0.2
        else:
            yt = yt_raw

        sw = sample_weight_fn(idx, dates) if sample_weight_fn else None

        for si, seed in enumerate(seeds):
            bag_seeds = [seed + i * 7 for i in range(BAGS)]
            reg_models = train_reg_bag(Xt, yt, bag_seeds, params, sw,
                                        objective=reg_objective, extra_params=reg_extra)
            cls_models = train_cls_bag(Xt, yt_raw, bag_seeds, params, sw)

            # Optional multi-horizon 7d
            reg_models_7d = None
            if multi_horizon_7d:
                yt_7d = target_7d[idx]
                reg_models_7d = train_reg_bag(Xt, yt_7d, bag_seeds[:40], params, sw)

            # Calibration
            calib = None
            if calibrate:
                from sklearn.isotonic import IsotonicRegression
                half = len(Xt) // 2
                cal_preds = np.mean([m.predict_proba(Xt[half:])[:, 1] for m in cls_models], axis=0)
                y_cal = (yt_raw[half:] > 0).astype(int)
                if len(np.unique(y_cal)) > 1:
                    calib = IsotonicRegression(out_of_bounds='clip').fit(cal_preds, y_cal)

            # Predict for test period
            X_test = np.nan_to_num(X_all[ts:tend + 1], nan=0.0)
            reg_pred = np.mean([m.predict(X_test) for m in reg_models], axis=0)
            cls_prob = np.mean([m.predict_proba(X_test)[:, 1] for m in cls_models], axis=0)

            # Multi-horizon blend (reverse scale 7d -> 3d)
            if reg_models_7d is not None:
                reg_pred_7d = np.mean([m.predict(X_test) for m in reg_models_7d], axis=0)
                reg_pred = 0.5 * reg_pred + 0.5 * reg_pred_7d / (7 / 3)

            # Reverse target transform
            if target_transform == 'log':
                reg_pred = np.sign(reg_pred) * (np.exp(np.abs(reg_pred)) - 1)
            elif target_transform == 'rank':
                reg_pred = reg_pred * 10

            if calib is not None:
                cls_prob = calib.predict(cls_prob)

            out_reg[si][ts:tend + 1] = reg_pred
            out_cls[si][ts:tend + 1] = cls_prob

            del reg_models, cls_models
            if reg_models_7d: del reg_models_7d
            gc.collect()

    return {'reg_preds': out_reg, 'cls_probs': out_cls}


def train_base_per_regime(seeds, X_all, target, prices, daily_ret, dates, periods,
                           dow, sma50, sma200, rf_daily, n, fnames):
    """3 separate models per regime -- needs special predict logic."""
    params = v22.XGB_PARAMS
    out_reg = [np.zeros(n) for _ in seeds]
    out_cls = [np.full(n, 0.5) for _ in seeds]

    for te, ts, tend in periods:
        gap = max(HORIZON, 5)
        tm = np.arange(60, te - gap + 1)
        valid = ~np.any(np.isnan(X_all[tm]), axis=1)
        idx = tm[valid]
        if len(idx) < 100: continue
        Xt = np.nan_to_num(X_all[idx], nan=0.0)
        yt = target[idx]
        regimes_train = np.array([get_regime(i, prices, sma50, sma200) for i in idx])

        for si, seed in enumerate(seeds):
            bag_seeds = [seed + i * 7 for i in range(BAGS)]
            reg_models_rg = {}; cls_models_rg = {}
            for rg in ['BULL', 'MILD', 'BEAR']:
                mask = regimes_train == rg
                if mask.sum() < 50:
                    reg_models_rg[rg] = None; cls_models_rg[rg] = None; continue
                reg_models_rg[rg] = train_reg_bag(Xt[mask], yt[mask], bag_seeds[:40], params)
                cls_models_rg[rg] = train_cls_bag(Xt[mask], yt[mask], bag_seeds[:40], params)

            # Predict per-regime
            for t in range(ts, tend + 1):
                x_t = np.nan_to_num(X_all[t:t+1], nan=0.0)
                regime = get_regime(t, prices, sma50, sma200)
                reg_m = reg_models_rg.get(regime) or reg_models_rg.get('MILD')
                cls_m = cls_models_rg.get(regime) or cls_models_rg.get('MILD')
                if reg_m is None: continue
                out_reg[si][t] = float(np.mean([m.predict(x_t)[0] for m in reg_m]))
                out_cls[si][t] = float(np.mean([m.predict_proba(x_t)[0, 1] for m in cls_m]))
            del reg_models_rg, cls_models_rg; gc.collect()

    return {'reg_preds': out_reg, 'cls_probs': out_cls}


def make_time_decay_weights(half_life_days=730):
    def fn(idx, dates):
        ds = pd.to_datetime(dates[idx])
        newest = ds.max()
        days_old = (newest - ds).days.values
        return np.exp(-np.log(2) * days_old / half_life_days)
    return fn


def make_monotone_constraints(fnames):
    positive = {'cusum_pos', 'adx', 'eth_pctchg_30d', 'basis_pct',
                'structural_break_score', 'bb_position', 'mr_score_30d'}
    negative = {'cusum_neg'}
    arr = []
    for f in fnames:
        if f in positive: arr.append(1)
        elif f in negative: arr.append(-1)
        else: arr.append(0)
    return '(' + ','.join(str(x) for x in arr) + ')'


# ===============================================================
# DECISION LAYER -- cheap sweep over pre-computed predictions
# ===============================================================

def evaluate(reg_preds_list, cls_probs_list, prices, daily_ret, dates, periods,
             dow, sma50, sma200, rf_daily, n,
             k_regime=None, sigmoid_scale=15, use_sigmoid=True,
             alloc_min=-0.25, alloc_max=1.0, sizing='linear',
             vol_target_annual=0.15, rebal_mode='normal', threshold=0.1,
             target=None):
    """Apply decision layer to pre-computed predictions. Returns metrics per seed.
       No XGBoost training. Cheap."""
    K = k_regime if k_regime is not None else K_DEFAULT
    n_seeds = len(reg_preds_list)

    # Realized vol (for sizing)
    pred_var = pd.Series(daily_ret).rolling(30).std().fillna(0.02).values ** 2
    pred_var = np.maximum(pred_var, 1e-6)

    per_seed_metrics = []
    per_seed_preds = []
    for si in range(n_seeds):
        reg_preds = reg_preds_list[si]
        cls_probs = cls_probs_list[si]
        full_allocs = np.full(n, 0.0)
        prev_alloc = 0.0
        peak_eq = 1.0; cur_eq = 1.0
        a_s, a_b, a_a, a_r = [], [], [], []
        all_preds = np.zeros(n)

        for te, ts, tend in periods:
            for t in range(ts, tend + 1):
                prediction = reg_preds[t]
                p_up = cls_probs[t]

                if use_sigmoid:
                    conf = abs(p_up - 0.5)
                    conf_factor = float(1.0 / (1.0 + np.exp(-conf * sigmoid_scale)))
                else:
                    conf_factor = 1.0
                all_preds[t] = prediction * conf_factor

                is_rebal = dow[t] in [4]
                is_emerg = t > 0 and abs(daily_ret[t]) > EMERGENCY_THRESHOLD
                if not is_rebal and not is_emerg:
                    full_allocs[t] = prev_alloc; continue

                regime = get_regime(t, prices, sma50, sma200)
                Kv = K[regime]

                if sizing == 'kelly':
                    var_ann = pred_var[t] * 252
                    raw = prediction / max(var_ann, 0.01) * conf_factor
                elif sizing == 'vol_target':
                    vol_ann = np.sqrt(pred_var[t] * 252)
                    size = vol_target_annual / max(vol_ann, 0.05)
                    raw = np.sign(prediction) * size * min(abs(prediction) * 10, 1.0) * conf_factor
                elif sizing == 'dd_aware':
                    current_dd = (cur_eq - peak_eq) / peak_eq if peak_eq > 0 else 0
                    raw = prediction * Kv * conf_factor
                    if current_dd < -0.05: raw *= 0.5
                else:  # linear
                    raw = prediction * Kv * conf_factor

                target_alloc = float(np.clip(raw, alloc_min, alloc_max))

                if rebal_mode == 'threshold':
                    if abs(target_alloc - prev_alloc) < threshold:
                        full_allocs[t] = prev_alloc; continue
                elif rebal_mode == 'half_weight':
                    target_alloc = prev_alloc + 0.5 * (target_alloc - prev_alloc)

                full_allocs[t] = target_alloc
                prev_alloc = target_alloc

            s, b, a = backtest_allocations(daily_ret, full_allocs, ts, tend,
                                           cost=COST, rf_daily=rf_daily)
            a_s.extend(s); a_b.extend(b); a_a.extend(a)
            a_r.extend(rf_daily[ts:ts + len(s)])

            # Track equity for DD-aware
            if sizing == 'dd_aware':
                for r in a:
                    cur_eq *= (1 + r)
                    peak_eq = max(peak_eq, cur_eq)

        metrics = v22.metrics_v22(np.array(a_s), np.array(a_b), np.array(a_a),
                                  rf_daily=np.array(a_r))
        per_seed_metrics.append(metrics)
        per_seed_preds.append(all_preds)

    # Aggregate
    sortinos = [m['sortino'] for m in per_seed_metrics]
    rets = [m['total']*100 for m in per_seed_metrics]
    dds = [m['max_dd']*100 for m in per_seed_metrics]
    sharpes = [m.get('sharpe', 0) for m in per_seed_metrics]
    # DOW accuracy
    preds_avg = np.mean(per_seed_preds, axis=0)
    mask = np.abs(preds_avg) > 1e-6
    acc = {}
    if mask.sum() > 0 and target is not None:
        acc['all'] = float((np.sign(preds_avg[mask]) == np.sign(target[mask])).mean())
        for d, name in enumerate(DAY_NAMES):
            dm = mask & (dow == d)
            acc[name] = float((np.sign(preds_avg[dm]) == np.sign(target[dm])).mean()) if dm.sum() > 10 else None

    return {
        'sortino_mean': float(np.mean(sortinos)), 'sortino_std': float(np.std(sortinos)),
        'ret_mean': float(np.mean(rets)), 'ret_std': float(np.std(rets)),
        'dd_mean': float(np.mean(dds)), 'dd_std': float(np.std(dds)),
        'sharpe_mean': float(np.mean(sharpes)),
        'acc': acc,
    }


def wait_for_v31_extras(max_wait_sec=5400):
    print(f"[V32] Waiting for v31_extras.json (max {max_wait_sec}s)...", flush=True)
    waited = 0
    while not V31_EXTRAS_JSON.exists() and waited < max_wait_sec:
        time.sleep(30); waited += 30
        if waited % 300 == 0:
            print(f"[V32] Waited {waited/60:.0f}min, still waiting...", flush=True)
    if V31_EXTRAS_JSON.exists():
        print(f"[V32] V31 extras done after {waited/60:.1f}min. Starting V32.", flush=True)
        time.sleep(5)
    else:
        print(f"[V32] Timeout. Starting V32 anyway.", flush=True)


# ===============================================================
# MAIN
# ===============================================================

def main():
    t0 = time.time()
    print("=" * 100, flush=True)
    print("V32 -- NOVEL TECHNIQUES BATTERY (5h)", flush=True)
    print("  Phase 1: Train 10 novel bases x 3 seeds", flush=True)
    print("  Phase 2: Decision-layer sweep (cheap, post-hoc)", flush=True)
    print("  Phase 3: 10-seed validation of TOP 3", flush=True)
    print("=" * 100, flush=True)

    wait_for_v31_extras(max_wait_sec=5400)

    print(f"\n[{time.strftime('%H:%M:%S')}] Loading data...", flush=True)
    prices, daily_ret, returns, vols, df = load_data()
    dates = df['date'].values
    n = len(prices)
    rf_daily = build_rf_daily(dates, source='auto')
    v9m.RF_DAILY_ARR = rf_daily
    v13m.RF_DAILY_ARR = rf_daily
    dow = pd.to_datetime(dates).dayofweek.values
    periods = _get_retrain_periods(dates, n, v22.RETRAIN)
    sma50 = pd.Series(prices).rolling(50).mean().values
    sma200 = pd.Series(prices).rolling(200).mean().values
    target = np.zeros(n)
    for i in range(n - HORIZON):
        target[i] = (prices[i + HORIZON] - prices[i]) / prices[i]

    feats_v29 = list(FEATURES_37)
    X_v29, fnames = build_ml_features(df, returns, vols, n, feature_cols=feats_v29)
    print(f"  {n} rows, {X_v29.shape[1]} features\n", flush=True)

    results = {'bases_training': {}, 'decision_sweep': [], 'validation_10s': []}

    def save():
        RESULTS.parent.mkdir(parents=True, exist_ok=True)
        with open(RESULTS, 'w') as f:
            json.dump({'results': results, 'elapsed_min': (time.time()-t0)/60}, f, indent=2)

    # =============== PHASE 1: Train novel bases ===============
    print(f"\n{'='*100}\n[{time.strftime('%H:%M:%S')}] PHASE 1: Training 10 novel bases x 3 seeds\n{'='*100}", flush=True)

    bases = {}
    phase1_specs = [
        ('baseline',    'V31.0 equiv',           {}),
        ('huber',       'pseudo-Huber loss',     {'reg_objective': 'reg:pseudohubererror'}),
        ('quantile',    'quantile reg 0.5',      {'reg_objective': 'reg:quantileerror',
                                                   'reg_extra': {'quantile_alpha': 0.5}}),
        ('timedecay',   'exp decay half-life 2y', {'sample_weight_fn': make_time_decay_weights(730)}),
        ('monotone',    'monotone constraints',  {'reg_extra': {'monotone_constraints': make_monotone_constraints(fnames)}}),
        ('log_target',  'signed-log target',     {'target_transform': 'log'}),
        ('rank_target', 'rank transform',        {'target_transform': 'rank'}),
        ('multi_horiz', '3d+7d blend',           {'multi_horizon_7d': True}),
        ('calib',       'isotonic calib',        {'calibrate': True}),
    ]
    # per_regime handled separately

    for bname, desc, kwargs in phase1_specs:
        t1 = time.time()
        print(f"\n[{time.strftime('%H:%M:%S')}] Training base '{bname}' ({desc}) x 3 seeds...", flush=True)
        base = train_base(SEEDS_3, X_v29, target, prices, daily_ret, dates, periods,
                          dow, sma50, sma200, rf_daily, n, fnames, **kwargs)
        bases[bname] = base
        results['bases_training'][bname] = {'desc': desc, 'elapsed_min': (time.time()-t1)/60}
        save()
        # Quick default eval
        r = evaluate(base['reg_preds'], base['cls_probs'], prices, daily_ret, dates,
                     periods, dow, sma50, sma200, rf_daily, n, target=target)
        print(f"  [{bname}] default eval: S={r['sortino_mean']:.3f}+/-{r['sortino_std']:.3f}  "
              f"Ret={r['ret_mean']:+.0f}%  DD={r['dd_mean']:.1f}%  "
              f"Fri={(r['acc'].get('Fri') or 0)*100:.1f}%  ({(time.time()-t1)/60:.1f}m)", flush=True)

    # Per-regime (special training)
    t1 = time.time()
    print(f"\n[{time.strftime('%H:%M:%S')}] Training base 'per_regime' (3 models) x 3 seeds...", flush=True)
    bases['per_regime'] = train_base_per_regime(SEEDS_3, X_v29, target, prices, daily_ret,
                                                  dates, periods, dow, sma50, sma200,
                                                  rf_daily, n, fnames)
    results['bases_training']['per_regime'] = {'desc': '3 regime models', 'elapsed_min': (time.time()-t1)/60}
    save()
    r = evaluate(bases['per_regime']['reg_preds'], bases['per_regime']['cls_probs'],
                 prices, daily_ret, dates, periods, dow, sma50, sma200, rf_daily, n, target=target)
    print(f"  [per_regime] default eval: S={r['sortino_mean']:.3f}+/-{r['sortino_std']:.3f}  "
          f"Ret={r['ret_mean']:+.0f}%  DD={r['dd_mean']:.1f}%  "
          f"({(time.time()-t1)/60:.1f}m)", flush=True)

    phase1_elapsed = (time.time() - t0) / 60
    print(f"\n[{time.strftime('%H:%M:%S')}] PHASE 1 DONE: {phase1_elapsed:.1f}m ({len(bases)} bases)", flush=True)

    # =============== PHASE 2: Decision layer sweep ===============
    print(f"\n{'='*100}\n[{time.strftime('%H:%M:%S')}] PHASE 2: Decision layer sweep\n{'='*100}", flush=True)

    # For baseline, do full sweep; for others, compare key variants
    k_variants = [
        ('K60/30/15', {'BULL': 60, 'MILD': 30, 'BEAR': 15}),  # current prod
        ('K70/30/10', {'BULL': 70, 'MILD': 30, 'BEAR': 10}),
        ('K50/30/25', {'BULL': 50, 'MILD': 30, 'BEAR': 25}),
        ('K80/20/0',  {'BULL': 80, 'MILD': 20, 'BEAR': 0}),
        ('K100/50/20',{'BULL': 100,'MILD': 50, 'BEAR': 20}),
    ]
    sigmoid_variants = [
        ('sig=15', {'sigmoid_scale': 15}),
        ('no_sig', {'use_sigmoid': False}),
        ('sig=10', {'sigmoid_scale': 10}),
        ('sig=20', {'sigmoid_scale': 20}),
    ]
    floor_variants = [('floor=-0.25', {'alloc_min': -0.25}), ('floor=0', {'alloc_min': 0.0})]
    sizing_variants = [
        ('linear',       {'sizing': 'linear'}),
        ('vol_tgt_15%',  {'sizing': 'vol_target', 'vol_target_annual': 0.15}),
        ('vol_tgt_25%',  {'sizing': 'vol_target', 'vol_target_annual': 0.25}),
        ('kelly',        {'sizing': 'kelly'}),
        ('dd_aware',     {'sizing': 'dd_aware'}),
    ]
    rebal_variants = [
        ('normal',     {'rebal_mode': 'normal'}),
        ('threshold10',{'rebal_mode': 'threshold', 'threshold': 0.10}),
        ('half_weight',{'rebal_mode': 'half_weight'}),
    ]

    def sweep_one(base_name, base):
        """Sweep decision layer for one base. Returns list of results."""
        out = []
        # Default (K, sig=15, floor=-0.25, linear, normal) then sweep one axis at a time
        default = {'k_regime': K_DEFAULT, 'sigmoid_scale': 15, 'alloc_min': -0.25,
                   'alloc_max': 1.0, 'use_sigmoid': True, 'sizing': 'linear',
                   'rebal_mode': 'normal'}
        # Baseline eval
        r = evaluate(base['reg_preds'], base['cls_probs'], prices, daily_ret, dates,
                     periods, dow, sma50, sma200, rf_daily, n, target=target, **default)
        r['name'] = f"{base_name}_default"; r['base'] = base_name; r['config'] = 'default'
        out.append(r)

        # K sweep (only for baseline to save time)
        if base_name == 'baseline':
            for kname, K in k_variants[1:]:  # skip K default
                cfg = dict(default); cfg['k_regime'] = K
                r = evaluate(base['reg_preds'], base['cls_probs'], prices, daily_ret, dates,
                             periods, dow, sma50, sma200, rf_daily, n, target=target, **cfg)
                r['name'] = f"{base_name}_{kname}"; r['base'] = base_name; r['config'] = kname
                out.append(r)
            # Sigmoid sweep
            for sname, sig_kw in sigmoid_variants[1:]:
                cfg = dict(default); cfg.update(sig_kw)
                r = evaluate(base['reg_preds'], base['cls_probs'], prices, daily_ret, dates,
                             periods, dow, sma50, sma200, rf_daily, n, target=target, **cfg)
                r['name'] = f"{base_name}_{sname}"; r['base'] = base_name; r['config'] = sname
                out.append(r)
            # Floor
            cfg = dict(default); cfg['alloc_min'] = 0.0
            r = evaluate(base['reg_preds'], base['cls_probs'], prices, daily_ret, dates,
                         periods, dow, sma50, sma200, rf_daily, n, target=target, **cfg)
            r['name'] = f"{base_name}_floor0"; r['base'] = base_name; r['config'] = 'floor=0'
            out.append(r)
            # Sizing
            for sname, sz in sizing_variants[1:]:
                cfg = dict(default); cfg.update(sz)
                r = evaluate(base['reg_preds'], base['cls_probs'], prices, daily_ret, dates,
                             periods, dow, sma50, sma200, rf_daily, n, target=target, **cfg)
                r['name'] = f"{base_name}_{sname}"; r['base'] = base_name; r['config'] = sname
                out.append(r)
            # Rebal
            for rname, rb in rebal_variants[1:]:
                cfg = dict(default); cfg.update(rb)
                r = evaluate(base['reg_preds'], base['cls_probs'], prices, daily_ret, dates,
                             periods, dow, sma50, sma200, rf_daily, n, target=target, **cfg)
                r['name'] = f"{base_name}_{rname}"; r['base'] = base_name; r['config'] = rname
                out.append(r)
        else:
            # For novel bases, also test floor=0 and best K from baseline (after sweep)
            cfg = dict(default); cfg['alloc_min'] = 0.0
            r = evaluate(base['reg_preds'], base['cls_probs'], prices, daily_ret, dates,
                         periods, dow, sma50, sma200, rf_daily, n, target=target, **cfg)
            r['name'] = f"{base_name}_floor0"; r['base'] = base_name; r['config'] = 'floor=0'
            out.append(r)
        return out

    for bname, base in bases.items():
        t1 = time.time()
        rs = sweep_one(bname, base)
        results['decision_sweep'].extend(rs)
        save()
        print(f"\n[{bname}] {len(rs)} configs tested ({(time.time()-t1):.1f}s)", flush=True)
        for r in rs:
            print(f"  {r['name']:<34}  S={r['sortino_mean']:.3f}+/-{r['sortino_std']:.3f}  "
                  f"Ret={r['ret_mean']:+.0f}%  DD={r['dd_mean']:.1f}%", flush=True)

    phase2_elapsed = (time.time() - t0) / 60 - phase1_elapsed
    print(f"\n[{time.strftime('%H:%M:%S')}] PHASE 2 DONE: {phase2_elapsed:.1f}m ({len(results['decision_sweep'])} configs)", flush=True)

    # =============== PHASE 3: Validate TOP 3 with 10 seeds ===============
    print(f"\n{'='*100}\n[{time.strftime('%H:%M:%S')}] PHASE 3: Validate TOP 3 (10 seeds)\n{'='*100}", flush=True)

    top_3 = sorted(results['decision_sweep'], key=lambda x: -x['sortino_mean'])[:3]
    print(f"\nTOP 3 from Phase 2:", flush=True)
    for i, r in enumerate(top_3):
        print(f"  #{i+1} {r['name']:<40} S={r['sortino_mean']:.3f}  Ret={r['ret_mean']:+.0f}%", flush=True)

    # Check which bases need 7 more seeds (seeds 342-942)
    bases_needed = set(r['base'] for r in top_3)
    extra_seeds = [342, 442, 542, 642, 742, 842, 942]
    bases_extra = {}
    for bname in bases_needed:
        t1 = time.time()
        print(f"\n[{time.strftime('%H:%M:%S')}] Training '{bname}' x 7 extra seeds for 10-seed validation...", flush=True)
        # Find the spec for this base
        if bname == 'per_regime':
            bases_extra[bname] = train_base_per_regime(extra_seeds, X_v29, target, prices, daily_ret,
                                                         dates, periods, dow, sma50, sma200, rf_daily, n, fnames)
        else:
            spec = next(s for s in phase1_specs if s[0] == bname)
            _, _, kwargs = spec
            bases_extra[bname] = train_base(extra_seeds, X_v29, target, prices, daily_ret, dates, periods,
                                             dow, sma50, sma200, rf_daily, n, fnames, **kwargs)
        print(f"  ({(time.time()-t1)/60:.1f}m)", flush=True)

    # For each top-3, combine 3 + 7 = 10 seeds, evaluate with same decision params
    for r_top in top_3:
        bname = r_top['base']
        # Combine preds from 3 seeds + 7 extra seeds
        all_reg = bases[bname]['reg_preds'] + bases_extra[bname]['reg_preds']
        all_cls = bases[bname]['cls_probs'] + bases_extra[bname]['cls_probs']

        # Recreate decision params from name
        default = {'k_regime': K_DEFAULT, 'sigmoid_scale': 15, 'alloc_min': -0.25,
                   'alloc_max': 1.0, 'use_sigmoid': True, 'sizing': 'linear',
                   'rebal_mode': 'normal', 'vol_target_annual': 0.15, 'threshold': 0.1}
        cfg = dict(default)
        # Parse r_top['config']
        conf = r_top['config']
        if conf.startswith('K'):
            K_name = conf
            K = dict(k_variants)[K_name]
            cfg['k_regime'] = K
        elif conf == 'no_sig':
            cfg['use_sigmoid'] = False
        elif conf.startswith('sig='):
            cfg['sigmoid_scale'] = int(conf.split('=')[1])
        elif conf == 'floor=0':
            cfg['alloc_min'] = 0.0
        elif conf in ['vol_tgt_15%','vol_tgt_25%','kelly','dd_aware']:
            cfg['sizing'] = {'vol_tgt_15%': 'vol_target', 'vol_tgt_25%': 'vol_target',
                              'kelly': 'kelly', 'dd_aware': 'dd_aware'}[conf]
            if conf == 'vol_tgt_25%': cfg['vol_target_annual'] = 0.25
        elif conf == 'threshold10':
            cfg['rebal_mode'] = 'threshold'
        elif conf == 'half_weight':
            cfg['rebal_mode'] = 'half_weight'

        r_10s = evaluate(all_reg, all_cls, prices, daily_ret, dates, periods,
                         dow, sma50, sma200, rf_daily, n, target=target, **cfg)
        r_10s['name'] = f"{r_top['name']}_10s"; r_10s['base'] = bname
        r_10s['config'] = r_top['config']; r_10s['n_seeds'] = 10
        results['validation_10s'].append(r_10s)
        save()
        print(f"  {r_10s['name']:<40} 10s: S={r_10s['sortino_mean']:.3f}+/-{r_10s['sortino_std']:.3f}  "
              f"Ret={r_10s['ret_mean']:+.0f}%  DD={r_10s['dd_mean']:.1f}%  "
              f"Fri={(r_10s['acc'].get('Fri') or 0)*100:.1f}%", flush=True)

    # =============== FINAL REPORT ===============
    elapsed = (time.time() - t0) / 60
    print(f"\n{'='*100}\nV32 DONE: {elapsed:.1f}m\n{'='*100}", flush=True)

    print(f"\nTOP 10 FINAL (by Sortino from all {len(results['decision_sweep'])} configs):", flush=True)
    all_configs = results['decision_sweep'] + results['validation_10s']
    for r in sorted(all_configs, key=lambda x: -x['sortino_mean'])[:10]:
        n_seeds = r.get('n_seeds', 3)
        print(f"  {r['name']:<40}  n={n_seeds:<2}  S={r['sortino_mean']:.3f}+/-{r['sortino_std']:.3f}  "
              f"Ret={r['ret_mean']:+.0f}%  DD={r['dd_mean']:.1f}%  "
              f"Fri={(r['acc'].get('Fri') or 0)*100:.1f}%", flush=True)
    save()
    print(f"\nResults: {RESULTS}", flush=True)


if __name__ == '__main__':
    main()
