"""
V18 Final Model — Comprehensive Analysis
==========================================
Generates PNG charts + full statistical analysis to determine
if the model is genuinely good or just lucky.
"""

import sys
import gc
import numpy as np
import pandas as pd
from pathlib import Path
import warnings
import json
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.gridspec import GridSpec

warnings.filterwarnings('ignore')
sys.stdout.reconfigure(line_buffering=True)

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

from archive.old_pipelines.pipeline_v09 import (
    load_data, build_ml_features, backtest_allocations,
    metrics, get_year_boundaries,
    SEEDS_10, COST, P, _seed_summary, convert_numpy,
)
from archive.old_pipelines.pipeline_v10 import MODELS
from archive.old_pipelines.pipeline_v11 import DEFAULT_XGB_PARAMS
from archive.old_pipelines.pipeline_v13 import _get_retrain_periods, _train_one_xgb

W = 16
RF_DAILY_ARR = None

def get_clean_feats():
    return [f for f in MODELS['37feat'] if f != 'exchange_netflow_ma7'] + ['basis_pct']


def compute_garch_persistence(daily_ret, n):
    from arch import arch_model
    P("  Computing GARCH persistence...")
    ret_pct = daily_ret * 100
    pers = np.full(n, np.nan)
    for t in range(252, n):
        try:
            if t % 20 == 0 or t == 252:
                data = ret_pct[max(0, t-756):t]
                res = arch_model(data, vol='Garch', p=1, q=1, mean='Zero', rescale=False).fit(disp='off', show_warning=False)
            params = res.params
            if 'alpha[1]' in params.index and 'beta[1]' in params.index:
                pers[t] = params['alpha[1]'] + params['beta[1]']
        except:
            if t > 0: pers[t] = pers[t-1]
        if t % 500 == 0: P(f"    {t}/{n} ({t/n*100:.0f}%)")
    pers = pd.Series(pers).ffill().fillna(0.95).values
    P(f"  GARCH done")
    return pers


def run_detailed(daily_ret, returns, vols, df, dates, n, feature_cols, garch_pers,
                 n_bags=80, base_seed=42, K_bull=50, K_mild=30, K_bear=15):
    """Run backtest and return per-Friday details for analysis."""
    xgb_params = dict(DEFAULT_XGB_PARAMS)
    prices = df['price_usd'].values
    X_all, _ = build_ml_features(df, returns, vols, n, feature_cols=feature_cols)
    X_all = np.column_stack([X_all, garch_pers])

    target = np.zeros(n)
    for i in range(n - 3): target[i] = (prices[i+3] - prices[i]) / prices[i]

    dow = pd.to_datetime(dates).dayofweek
    sma50 = pd.Series(prices).rolling(50).mean().values
    sma200 = pd.Series(prices).rolling(200).mean().values
    periods = _get_retrain_periods(dates, n, 'semi')

    rows = []
    full_allocs = np.full(n, 0.0)
    is_rf = isinstance(RF_DAILY_ARR, np.ndarray)
    a_s, a_b, a_a, a_r, a_i = [], [], [], [], []
    prev_alloc = 0.0

    for te, ts, tend in periods:
        gap = 5
        tm = np.arange(60, te - gap + 1)
        v = ~np.any(np.isnan(X_all[tm]), axis=1)
        idx = tm[v]
        if len(idx) < 100: continue
        Xt, yt = np.nan_to_num(X_all[idx], nan=0.0), target[idx]
        seeds = [base_seed + i*7 for i in range(n_bags)]
        with ThreadPoolExecutor(max_workers=W) as ex:
            models = list(ex.map(_train_one_xgb, [(s, Xt, yt, xgb_params) for s in seeds]))
        if not models: continue

        for t in range(ts, tend + 1):
            if dow[t] != 4:
                full_allocs[t] = prev_alloc; continue
            x_t = np.nan_to_num(X_all[t:t+1].copy(), nan=0.0)
            preds = [m.predict(x_t)[0] for m in models]
            avg_pred = np.mean(preds)
            pred_std = np.std(preds)

            if not np.isnan(sma50[t]) and not np.isnan(sma200[t]):
                if prices[t] > sma50[t] and sma50[t] > sma200[t]: regime = 'BULL'
                elif prices[t] > sma200[t]: regime = 'MILD'
                else: regime = 'BEAR'
            else: regime = 'MILD'

            K = {'BULL': K_bull, 'MILD': K_mild, 'BEAR': K_bear}[regime]
            raw = np.clip(avg_pred * K, -0.25, 1.0)
            full_allocs[t] = raw
            prev_alloc = raw

            actual_3d = target[t] if t + 3 < n else 0
            actual_1w = (prices[min(t+5,n-1)] - prices[t]) / prices[t] if t+1 < n else 0
            strat_1w = 0
            for d in range(1, min(6, n-t)):
                strat_1w = (1+strat_1w) * (1 + raw * daily_ret[t+d]) - 1

            rows.append({
                'date': str(dates[t])[:10], 'price': prices[t], 'regime': regime,
                'pred': avg_pred, 'pred_std': pred_std, 'actual_3d': actual_3d,
                'actual_1w': actual_1w, 'alloc': raw, 'strat_1w': strat_1w,
                'btc_1w': actual_1w,
                'pred_dir': 'UP' if avg_pred > 0 else 'DOWN',
                'actual_dir': 'UP' if actual_3d > 0 else 'DOWN',
                'correct': (avg_pred > 0) == (actual_3d > 0),
            })

        s, b, a = backtest_allocations(daily_ret, full_allocs, ts, tend, cost=COST, rf_daily=RF_DAILY_ARR)
        a_s.extend(s); a_b.extend(b); a_a.extend(a)
        a_i.extend(range(ts, ts + len(s)))
        nd = len(s)
        a_r.extend(RF_DAILY_ARR[ts:ts+nd] if is_rf else [0.0]*nd)

    df_weeks = pd.DataFrame(rows)
    df_weeks['date'] = pd.to_datetime(df_weeks['date'])
    return df_weeks, np.array(a_s), np.array(a_b), np.array(a_i)


def main():
    P("=" * 80)
    P("V18 FINAL — COMPREHENSIVE ANALYSIS")
    P("=" * 80)
    start = datetime.now()

    prices, daily_ret, returns, vols, df = load_data()
    dates = df['date'].values; n = len(prices)

    global RF_DAILY_ARR
    import archive.old_pipelines.pipeline_v09 as v9m
    import archive.old_pipelines.pipeline_v13 as v13m
    try:
        from src.features.macro.cdi_rates import build_rf_daily
        RF_DAILY_ARR = build_rf_daily(dates, source='auto')
    except: RF_DAILY_ARR = build_rf_daily(dates, source='copom')
    v9m.RF_DAILY_ARR = RF_DAILY_ARR; v13m.RF_DAILY_ARR = RF_DAILY_ARR

    fc = get_clean_feats()
    extra = ['fed_balance_sheet','futures_trade_count','vol_x_regime_duration','velocity','hash_rate_pctchg_30d']
    fc = fc + [f for f in extra if f in df.columns and f not in fc]

    garch = compute_garch_persistence(daily_ret, n)

    P("\n  Running detailed backtest (seed=42)...")
    wk, strat_d, btc_d, idx = run_detailed(daily_ret, returns, vols, df, dates, n, fc, garch)
    P(f"  {len(wk)} weeks collected")

    out = ROOT / 'outputs/charts'
    out.mkdir(parents=True, exist_ok=True)

    dt_dates = pd.to_datetime(dates)
    chart_dates = [dt_dates[int(i)] for i in idx]
    strat_cum = np.cumprod(1 + strat_d)
    btc_cum = np.cumprod(1 + btc_d)

    # ================================================================
    # FIGURE 1: CUMULATIVE PERFORMANCE (big, main chart)
    # ================================================================
    P("\n  Generating charts...")
    fig, axes = plt.subplots(3, 1, figsize=(16, 14), gridspec_kw={'height_ratios': [3, 1, 1]})

    ax1 = axes[0]
    ax1.semilogy(chart_dates, strat_cum, 'b-', linewidth=1.5, label='V18 Strategy')
    ax1.semilogy(chart_dates, btc_cum, color='orange', linewidth=1.5, label='Buy & Hold BTC', alpha=0.7)
    ax1.set_title('V18 Final (38 feat + GARCH persistence) — Cumulative Performance', fontsize=14, fontweight='bold')
    ax1.set_ylabel('Cumulative Return (log scale)')
    ax1.legend(fontsize=12)
    ax1.grid(True, alpha=0.3)
    for yr in range(2022, 2027):
        ax1.axvline(pd.Timestamp(f'{yr}-01-01'), color='gray', linestyle='--', alpha=0.3)

    # Drawdown
    ax2 = axes[1]
    sp = np.maximum.accumulate(strat_cum)
    sdd = (strat_cum - sp) / sp * 100
    bp = np.maximum.accumulate(btc_cum)
    bdd = (btc_cum - bp) / bp * 100
    ax2.fill_between(chart_dates, sdd, 0, alpha=0.4, color='blue', label='Strategy DD')
    ax2.fill_between(chart_dates, bdd, 0, alpha=0.3, color='orange', label='BTC DD')
    ax2.set_ylabel('Drawdown (%)')
    ax2.legend(fontsize=10)
    ax2.grid(True, alpha=0.3)

    # Allocation
    ax3 = axes[2]
    fri_dates = wk['date'].values
    fri_alloc = wk['alloc'].values * 100
    colors = ['green' if a > 0 else 'red' for a in fri_alloc]
    ax3.bar(fri_dates, fri_alloc, width=5, color=colors, alpha=0.6)
    ax3.axhline(0, color='black', linewidth=0.5)
    ax3.set_ylabel('Allocation (%)')
    ax3.set_xlabel('Date')
    ax3.grid(True, alpha=0.3)

    plt.tight_layout()
    fig.savefig(str(out / 'v18_cumulative.png'), dpi=150, bbox_inches='tight')
    plt.close()
    P("  [1/7] v18_cumulative.png")

    # ================================================================
    # FIGURE 2: MONTHLY PERFORMANCE TABLE
    # ================================================================
    wk['year'] = wk['date'].dt.year
    wk['month'] = wk['date'].dt.month

    monthly = wk.groupby(['year','month']).agg(
        strat=('strat_1w', lambda x: (1+x).prod()-1),
        btc=('btc_1w', lambda x: (1+x).prod()-1),
        accuracy=('correct', 'mean'),
        n_weeks=('correct', 'count'),
    ).reset_index()
    monthly['excess'] = monthly['strat'] - monthly['btc']

    fig, ax = plt.subplots(figsize=(16, 6))
    pivot = monthly.pivot(index='year', columns='month', values='excess')
    mn = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
    im = ax.imshow(pivot.values * 100, cmap='RdYlGn', aspect='auto', vmin=-20, vmax=20)
    ax.set_xticks(range(12)); ax.set_xticklabels(mn)
    ax.set_yticks(range(len(pivot.index))); ax.set_yticklabels(pivot.index)
    for i in range(pivot.shape[0]):
        for j in range(pivot.shape[1]):
            val = pivot.values[i, j]
            if not np.isnan(val):
                ax.text(j, i, f'{val*100:.1f}%', ha='center', va='center', fontsize=9,
                       color='black' if abs(val*100) < 15 else 'white', fontweight='bold')
    plt.colorbar(im, label='Excess Return (%)')
    ax.set_title('Monthly Excess Return (Strategy - BTC)', fontsize=14, fontweight='bold')
    plt.tight_layout()
    fig.savefig(str(out / 'v18_monthly_excess.png'), dpi=150, bbox_inches='tight')
    plt.close()
    P("  [2/7] v18_monthly_excess.png")

    # ================================================================
    # FIGURE 3: ACCURACY BY REGIME & YEAR
    # ================================================================
    fig, axes = plt.subplots(1, 3, figsize=(16, 5))

    # By regime
    for i, regime in enumerate(['BULL', 'MILD', 'BEAR']):
        mask = wk['regime'] == regime
        if mask.sum() == 0: continue
        acc = wk.loc[mask, 'correct'].mean() * 100
        n_r = mask.sum()
        axes[0].bar(i, acc, color={'BULL':'green','MILD':'gold','BEAR':'red'}[regime], alpha=0.7)
        axes[0].text(i, acc + 1, f'{acc:.1f}%\n({n_r}w)', ha='center', fontsize=10)
    axes[0].set_xticks([0,1,2]); axes[0].set_xticklabels(['BULL','MILD','BEAR'])
    axes[0].set_ylabel('Accuracy (%)'); axes[0].set_title('Accuracy by Regime')
    axes[0].set_ylim(0, 80); axes[0].axhline(50, color='red', linestyle='--', alpha=0.5, label='50% (random)')
    axes[0].legend()

    # By year
    yearly = wk.groupby('year').agg(acc=('correct','mean'), n=('correct','count')).reset_index()
    axes[1].bar(yearly['year'].astype(str), yearly['acc']*100, color='steelblue', alpha=0.7)
    for i, row in yearly.iterrows():
        axes[1].text(i, row['acc']*100+1, f'{row["acc"]*100:.1f}%\n({row["n"]}w)', ha='center', fontsize=9)
    axes[1].set_ylabel('Accuracy (%)'); axes[1].set_title('Accuracy by Year')
    axes[1].set_ylim(0, 80); axes[1].axhline(50, color='red', linestyle='--', alpha=0.5)

    # Accuracy vs return scatter
    monthly_acc = wk.groupby(wk['date'].dt.to_period('M')).agg(
        acc=('correct','mean'), strat=('strat_1w', lambda x: (1+x).prod()-1)).reset_index()
    axes[2].scatter(monthly_acc['acc']*100, monthly_acc['strat']*100, alpha=0.6, c='steelblue')
    axes[2].axhline(0, color='black', linewidth=0.5); axes[2].axvline(50, color='red', linestyle='--', alpha=0.5)
    axes[2].set_xlabel('Monthly Accuracy (%)'); axes[2].set_ylabel('Monthly Strat Return (%)')
    axes[2].set_title('Accuracy vs Return (monthly)')
    # Correlation
    valid = monthly_acc.dropna()
    if len(valid) > 5:
        corr = valid['acc'].corr(valid['strat'])
        axes[2].text(0.05, 0.95, f'corr={corr:.2f}', transform=axes[2].transAxes, fontsize=11)

    plt.tight_layout()
    fig.savefig(str(out / 'v18_accuracy.png'), dpi=150, bbox_inches='tight')
    plt.close()
    P("  [3/7] v18_accuracy.png")

    # ================================================================
    # FIGURE 4: WEEKLY RETURNS COMPARISON
    # ================================================================
    fig, axes = plt.subplots(2, 1, figsize=(16, 8))

    axes[0].bar(wk['date'], wk['strat_1w']*100, width=5, color='blue', alpha=0.6, label='Strategy')
    axes[0].bar(wk['date'], wk['btc_1w']*100, width=5, color='orange', alpha=0.3, label='BTC')
    axes[0].set_ylabel('Weekly Return (%)'); axes[0].set_title('Weekly Returns: Strategy vs BTC')
    axes[0].legend(); axes[0].grid(True, alpha=0.3)
    axes[0].set_ylim(-20, 25)

    # Excess
    excess = wk['strat_1w'] - wk['btc_1w']
    colors = ['green' if e > 0 else 'red' for e in excess]
    axes[1].bar(wk['date'], excess*100, width=5, color=colors, alpha=0.6)
    axes[1].axhline(0, color='black', linewidth=0.5)
    axes[1].set_ylabel('Weekly Excess (%)'); axes[1].set_title('Weekly Excess Return (Strategy - BTC)')
    axes[1].grid(True, alpha=0.3)
    pos = (excess > 0).sum(); neg = (excess <= 0).sum()
    axes[1].text(0.02, 0.95, f'Positive: {pos}/{len(excess)} ({pos/len(excess)*100:.0f}%)',
                transform=axes[1].transAxes, fontsize=11, color='green')

    plt.tight_layout()
    fig.savefig(str(out / 'v18_weekly.png'), dpi=150, bbox_inches='tight')
    plt.close()
    P("  [4/7] v18_weekly.png")

    # ================================================================
    # FIGURE 5: ROLLING METRICS
    # ================================================================
    fig, axes = plt.subplots(3, 1, figsize=(16, 10))
    window = 26  # ~6 months in weeks

    # Rolling Sortino
    roll_sort = []
    for i in range(window, len(wk)):
        s = wk['strat_1w'].iloc[i-window:i].values
        down = s[s < 0]
        if len(down) > 0:
            ds = np.sqrt(np.mean(down**2)) * np.sqrt(52)
            ann = (np.prod(1+s)**(52/window) - 1)
            roll_sort.append(min(ann/ds if ds > 0 else 10, 10))
        else:
            roll_sort.append(10)
    axes[0].plot(wk['date'].iloc[window:], roll_sort, 'g-', linewidth=1.5)
    axes[0].axhline(2, color='red', linestyle='--', alpha=0.5, label='Sortino = 2')
    axes[0].axhline(0, color='black', linewidth=0.5)
    axes[0].set_ylabel('Sortino'); axes[0].set_title('Rolling 26-Week Sortino')
    axes[0].legend(); axes[0].grid(True, alpha=0.3)

    # Rolling accuracy
    roll_acc = wk['correct'].rolling(window).mean() * 100
    axes[1].plot(wk['date'], roll_acc, 'b-', linewidth=1.5)
    axes[1].axhline(50, color='red', linestyle='--', alpha=0.5, label='50% (random)')
    axes[1].set_ylabel('Accuracy (%)'); axes[1].set_title('Rolling 26-Week Accuracy')
    axes[1].legend(); axes[1].grid(True, alpha=0.3); axes[1].set_ylim(30, 85)

    # Rolling excess cumulative
    roll_excess = (1 + wk['strat_1w']).cumprod() / (1 + wk['btc_1w']).cumprod()
    axes[2].plot(wk['date'], roll_excess, 'purple', linewidth=1.5)
    axes[2].axhline(1.0, color='red', linestyle='--', alpha=0.5, label='Break-even vs BTC')
    axes[2].set_ylabel('Relative Performance'); axes[2].set_title('Cumulative Strategy / BTC (>1 = outperforming)')
    axes[2].legend(); axes[2].grid(True, alpha=0.3)

    plt.tight_layout()
    fig.savefig(str(out / 'v18_rolling.png'), dpi=150, bbox_inches='tight')
    plt.close()
    P("  [5/7] v18_rolling.png")

    # ================================================================
    # FIGURE 6: PREDICTION ANALYSIS
    # ================================================================
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))

    # Pred vs Actual scatter
    axes[0,0].scatter(wk['pred']*100, wk['actual_3d']*100, alpha=0.3, c='steelblue', s=20)
    axes[0,0].axhline(0, color='black', linewidth=0.5); axes[0,0].axvline(0, color='black', linewidth=0.5)
    lim = max(abs(wk['pred']).max(), abs(wk['actual_3d']).max()) * 100 * 1.1
    axes[0,0].set_xlim(-lim, lim); axes[0,0].set_ylim(-lim, lim)
    axes[0,0].plot([-lim,lim], [-lim,lim], 'r--', alpha=0.3, label='Perfect prediction')
    corr = wk['pred'].corr(wk['actual_3d'])
    axes[0,0].set_xlabel('Predicted 3d Return (%)'); axes[0,0].set_ylabel('Actual 3d Return (%)')
    axes[0,0].set_title(f'Prediction vs Actual (corr={corr:.3f})'); axes[0,0].legend()

    # Pred distribution
    axes[0,1].hist(wk['pred']*100, bins=40, alpha=0.6, color='blue', label='Predictions', density=True)
    axes[0,1].hist(wk['actual_3d']*100, bins=40, alpha=0.4, color='orange', label='Actuals', density=True)
    axes[0,1].set_xlabel('Return (%)'); axes[0,1].set_title('Distribution: Predicted vs Actual')
    axes[0,1].legend()

    # Confidence (pred_std) vs accuracy
    wk['confidence'] = 1 - np.clip(wk['pred_std'] / 0.03, 0, 1)
    bins = pd.qcut(wk['confidence'], 4, duplicates='drop')
    conf_acc = wk.groupby(bins)['correct'].mean() * 100
    axes[1,0].bar(range(len(conf_acc)), conf_acc.values, color='teal', alpha=0.7)
    axes[1,0].set_xticks(range(len(conf_acc)))
    axes[1,0].set_xticklabels([f'Q{i+1}' for i in range(len(conf_acc))])
    axes[1,0].set_ylabel('Accuracy (%)'); axes[1,0].set_xlabel('Confidence Quartile (Q1=low, Q4=high)')
    axes[1,0].set_title('Accuracy by Model Confidence'); axes[1,0].axhline(50, color='red', linestyle='--', alpha=0.5)

    # Allocation distribution by regime
    for regime, color in [('BULL','green'),('MILD','gold'),('BEAR','red')]:
        mask = wk['regime'] == regime
        if mask.sum() > 0:
            axes[1,1].hist(wk.loc[mask, 'alloc']*100, bins=30, alpha=0.5, color=color, label=regime, density=True)
    axes[1,1].set_xlabel('Allocation (%)'); axes[1,1].set_title('Allocation Distribution by Regime')
    axes[1,1].legend()

    plt.tight_layout()
    fig.savefig(str(out / 'v18_predictions.png'), dpi=150, bbox_inches='tight')
    plt.close()
    P("  [6/7] v18_predictions.png")

    # ================================================================
    # FIGURE 7: YEAR-BY-YEAR DETAILED
    # ================================================================
    years = sorted(wk['year'].unique())
    fig, axes = plt.subplots(len(years), 1, figsize=(16, 4*len(years)))
    if len(years) == 1: axes = [axes]

    for i, yr in enumerate(years):
        mask = wk['year'] == yr
        wd = wk[mask]
        s_cum = (1 + wd['strat_1w']).cumprod()
        b_cum = (1 + wd['btc_1w']).cumprod()
        axes[i].plot(wd['date'], s_cum*100, 'b-', linewidth=2, label='Strategy')
        axes[i].plot(wd['date'], b_cum*100, color='orange', linewidth=2, label='BTC', alpha=0.7)
        acc = wd['correct'].mean() * 100
        s_ret = (s_cum.iloc[-1] - 1) * 100
        b_ret = (b_cum.iloc[-1] - 1) * 100
        axes[i].set_title(f'{yr}: Strat={s_ret:+.1f}% BTC={b_ret:+.1f}% Excess={s_ret-b_ret:+.1f}% Acc={acc:.0f}%',
                         fontsize=12, fontweight='bold')
        axes[i].set_ylabel('Cumulative (%)')
        axes[i].legend(loc='upper left'); axes[i].grid(True, alpha=0.3)
        axes[i].axhline(100, color='black', linewidth=0.5, linestyle='--')

    plt.tight_layout()
    fig.savefig(str(out / 'v18_yearly.png'), dpi=150, bbox_inches='tight')
    plt.close()
    P("  [7/7] v18_yearly.png")

    # ================================================================
    # STATISTICAL SUMMARY
    # ================================================================
    P(f"\n{'='*80}")
    P("COMPREHENSIVE STATISTICAL ANALYSIS")
    P("=" * 80)

    total_acc = wk['correct'].mean() * 100
    P(f"\n  ACCURACY:")
    P(f"    Overall: {wk['correct'].sum()}/{len(wk)} ({total_acc:.1f}%)")
    for regime in ['BULL','MILD','BEAR']:
        m = wk['regime'] == regime
        if m.sum() > 0:
            P(f"    {regime}: {wk.loc[m,'correct'].sum()}/{m.sum()} ({wk.loc[m,'correct'].mean()*100:.1f}%)")
    for yr in years:
        m = wk['year'] == yr
        P(f"    {yr}: {wk.loc[m,'correct'].sum()}/{m.sum()} ({wk.loc[m,'correct'].mean()*100:.1f}%)")

    P(f"\n  PREDICTION QUALITY:")
    P(f"    Pred-Actual correlation: {wk['pred'].corr(wk['actual_3d']):.4f}")
    P(f"    Pred mean: {wk['pred'].mean()*100:+.3f}%")
    P(f"    Actual mean: {wk['actual_3d'].mean()*100:+.3f}%")
    P(f"    Pred std: {wk['pred'].std()*100:.3f}%")
    P(f"    Actual std: {wk['actual_3d'].std()*100:.3f}%")
    P(f"    Pred > 0: {(wk['pred']>0).sum()}/{len(wk)} ({(wk['pred']>0).mean()*100:.1f}%)")
    P(f"    Actual > 0: {(wk['actual_3d']>0).sum()}/{len(wk)} ({(wk['actual_3d']>0).mean()*100:.1f}%)")

    P(f"\n  RETURNS:")
    strat_total = (1 + wk['strat_1w']).prod() - 1
    btc_total = (1 + wk['btc_1w']).prod() - 1
    P(f"    Strategy cumulative: {strat_total*100:+.1f}%")
    P(f"    BTC cumulative: {btc_total*100:+.1f}%")
    P(f"    Excess: {(strat_total-btc_total)*100:+.1f}%")

    excess_weekly = wk['strat_1w'] - wk['btc_1w']
    P(f"    Weeks beating BTC: {(excess_weekly>0).sum()}/{len(wk)} ({(excess_weekly>0).mean()*100:.1f}%)")
    P(f"    Avg weekly excess: {excess_weekly.mean()*100:+.3f}%")

    P(f"\n  YEAR-BY-YEAR:")
    for yr in years:
        m = wk['year'] == yr
        s = (1+wk.loc[m,'strat_1w']).prod()-1
        b = (1+wk.loc[m,'btc_1w']).prod()-1
        P(f"    {yr}: strat={s*100:+.1f}% btc={b*100:+.1f}% excess={(s-b)*100:+.1f}% acc={wk.loc[m,'correct'].mean()*100:.1f}%")

    P(f"\n  REGIME PERFORMANCE:")
    for regime in ['BULL','MILD','BEAR']:
        m = wk['regime'] == regime
        if m.sum() == 0: continue
        s = (1+wk.loc[m,'strat_1w']).prod()-1
        b = (1+wk.loc[m,'btc_1w']).prod()-1
        avg_alloc = wk.loc[m,'alloc'].mean()*100
        P(f"    {regime}: strat={s*100:+.1f}% btc={b*100:+.1f}% excess={(s-b)*100:+.1f}% avg_alloc={avg_alloc:.1f}% acc={wk.loc[m,'correct'].mean()*100:.1f}%")

    P(f"\n  RISK:")
    P(f"    Max weekly loss (strat): {wk['strat_1w'].min()*100:.2f}%")
    P(f"    Max weekly loss (btc): {wk['btc_1w'].min()*100:.2f}%")
    P(f"    Worst month (strat): {monthly['strat'].min()*100:.1f}%")
    P(f"    Max drawdown (strat): {sdd.min():.1f}%")
    P(f"    Max drawdown (btc): {bdd.min():.1f}%")

    # Win/loss analysis
    wins = wk[wk['correct']]
    losses = wk[~wk['correct']]
    P(f"\n  WIN/LOSS ANALYSIS:")
    P(f"    Avg return when correct: {wins['strat_1w'].mean()*100:+.3f}%")
    P(f"    Avg return when wrong: {losses['strat_1w'].mean()*100:+.3f}%")
    P(f"    Avg |pred| when correct: {wins['pred'].abs().mean()*100:.3f}%")
    P(f"    Avg |pred| when wrong: {losses['pred'].abs().mean()*100:.3f}%")
    P(f"    Win/Loss ratio: {abs(wins['strat_1w'].mean()/losses['strat_1w'].mean()):.2f}")

    # Statistical tests
    from scipy import stats
    P(f"\n  STATISTICAL TESTS:")
    # Binomial test: is accuracy significantly > 50%?
    n_correct = wk['correct'].sum()
    n_total = len(wk)
    binom_res = stats.binomtest(n_correct, n_total, 0.5, alternative='greater')
    binom_p = binom_res.pvalue
    P(f"    Binomial test (acc > 50%): p={binom_p:.6f} {'SIGNIFICANT' if binom_p < 0.05 else 'NOT significant'}")

    # t-test: is mean weekly excess > 0?
    t_stat, t_p = stats.ttest_1samp(excess_weekly, 0)
    P(f"    t-test (excess > 0): t={t_stat:.3f}, p={t_p/2:.6f} {'SIGNIFICANT' if t_p/2 < 0.05 else 'NOT significant'}")

    # Wilcoxon signed-rank test (non-parametric)
    w_stat, w_p = stats.wilcoxon(excess_weekly)
    P(f"    Wilcoxon (excess != 0): W={w_stat:.0f}, p={w_p:.6f} {'SIGNIFICANT' if w_p < 0.05 else 'NOT significant'}")

    elapsed = (datetime.now() - start).total_seconds() / 60
    P(f"\n  Charts saved to: {out}")
    P(f"  Done in {elapsed:.1f} min")


if __name__ == '__main__':
    main()
