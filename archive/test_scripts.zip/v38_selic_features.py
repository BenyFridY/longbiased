"""V38 — Add Selic/CDI rate as feature.

User insight: model doesn't see BR rates. Selic went from 2% (COVID) to 15% (now).
Potential signal: BR investor flow to/from BTC based on Selic level.

Tests (3 seeds each, base = E1 D7 combo no-short, 32 features):
  G1: E1 + selic_ann (Selic annualized)
  G2: E1 + selic_change_30d (Selic trend 30d)
  G3: E1 + selic_ann + selic_change_30d (combo)
  G4: E1 + us10y (if available in enhanced)
  G5: E1 + best G1-G4 combo
"""
import sys, time, gc, json
import numpy as np, pandas as pd
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import xgboost as xgb

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

import archive.old_pipelines.pipeline_v22 as v22
from archive.old_pipelines.pipeline_v09 import build_ml_features, backtest_allocations, COST
from scripts.production.training import _get_retrain_periods
from src.features.macro.cdi_rates import build_rf_daily
import archive.old_pipelines.pipeline_v09 as v9m
import archive.old_pipelines.pipeline_v13 as v13m
from scripts.production.config import FEATURES_37, BAGS, HORIZON, WORKERS, EMERGENCY_THRESHOLD

DATASET = ROOT / "scripts" / "production" / "data" / "dataset_production.csv"
ENHANCED = ROOT / "outputs" / "feature_selection" / "dataset_enhanced.csv"
RESULTS = ROOT / "outputs" / "results" / "v38_experiments.json"
SEEDS = [42, 142, 242]
K_REGIME = {'BULL': 60, 'MILD': 30, 'BEAR': 15}


def load():
    df = pd.read_csv(DATASET)
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)

    # Add CDI-derived features
    rf = build_rf_daily(df['date'].values, source='auto')
    # Annualize ONLY business day CDI values (zeros = weekends/holidays, skip them)
    cdi = pd.Series(rf, index=df['date'])
    # Replace 0 values with NaN, then ffill: weekends/holidays inherit last business day rate
    cdi_nz = cdi.mask(cdi == 0).ffill().bfill()
    df['selic_ann'] = ((1 + cdi_nz.values) ** 252 - 1)  # annualized, no weekend gaps
    # Use diff (subtraction) instead of pct_change to avoid inf when prev is 0
    df['selic_change_30d'] = pd.Series(df['selic_ann']).diff(30).fillna(0).replace([np.inf, -np.inf], 0).values
    df['cdi_daily'] = cdi_nz.values  # forward-filled (weekend = Friday rate)
    # Clean any remaining inf/nan
    for col in ['selic_ann', 'selic_change_30d', 'cdi_daily']:
        df[col] = pd.Series(df[col]).replace([np.inf, -np.inf], np.nan).ffill().fillna(0).values

    # Try to add us10y from enhanced
    try:
        enh = pd.read_csv(ENHANCED)
        enh['date'] = pd.to_datetime(enh['date'])
        if 'us10y' in enh.columns:
            df = df.merge(enh[['date', 'us10y']], on='date', how='left')
            df['us10y'] = df['us10y'].ffill().fillna(0)
            print(f'  us10y added: {df["us10y"].iloc[-1]:.2f}% (last)')
    except Exception as e:
        print(f'  us10y not available: {e}')

    prices = df['price_usd'].values
    n = len(prices)
    daily_ret = np.zeros(n)
    for i in range(1, n): daily_ret[i] = (prices[i] - prices[i-1]) / prices[i-1]
    returns, vols = {}, {}
    for w in [1,3,5,7,10,14,20,21,30,45,60]:
        r = np.zeros(n)
        for i in range(w, n): r[i] = (prices[i] - prices[i-w]) / prices[i-w]
        returns[w] = r
    for w in [5,7,10,14,21,30]:
        vols[w] = pd.Series(daily_ret).rolling(w).std().fillna(0.02).values
    return prices, daily_ret, returns, vols, df, rf


def get_regime(t, prices, sma50, sma200):
    if np.isnan(sma50[t]) or np.isnan(sma200[t]): return 'MILD'
    if prices[t] > sma50[t] and sma50[t] > sma200[t]: return 'BULL'
    elif prices[t] > sma200[t]: return 'MILD'
    return 'BEAR'


def _train_reg(args):
    s, Xt, yt, params = args
    p = dict(params); p.pop('objective', None)
    allowed = {k:v for k,v in p.items() if k in
               ['max_leaves','colsample_bytree','subsample','learning_rate',
                'min_child_weight','reg_alpha','reg_lambda','grow_policy','tree_method']}
    m = xgb.XGBRegressor(n_estimators=p.pop('n_estimators', 200),
                          random_state=s, objective='reg:squarederror',
                          n_jobs=1, verbosity=0, **allowed)
    m.fit(Xt, yt); return m


def _train_cls(args):
    s, Xt, yb, params = args
    rng = np.random.RandomState(s); idx = rng.choice(len(Xt), size=len(Xt), replace=True)
    p = dict(params); p.pop('objective', None)
    allowed = {k:v for k,v in p.items() if k in
               ['max_leaves','colsample_bytree','subsample','learning_rate',
                'min_child_weight','reg_alpha','reg_lambda','grow_policy','tree_method']}
    m = xgb.XGBClassifier(n_estimators=p.pop('n_estimators', 200),
                           random_state=s, objective='binary:logistic',
                           eval_metric='logloss', n_jobs=1, **allowed)
    m.fit(Xt[idx], yb[idx]); return m


def run_one(seed, X_all, target, prices, daily_ret, dates, periods,
             dow, sma50, sma200, rf_daily, n):
    params = v22.XGB_PARAMS
    full_allocs = np.full(n, 0.0); prev_alloc = 0.0
    a_s, a_b, a_a, a_r = [], [], [], []
    reg_preds = np.zeros(n); cls_probs = np.full(n, 0.5); strat_ret = np.zeros(n)
    for te, ts, tend in periods:
        gap = max(HORIZON, 5); tm = np.arange(60, te - gap + 1)
        valid = ~np.any(np.isnan(X_all[tm]), axis=1); idx = tm[valid]
        if len(idx) < 100: continue
        Xt = np.nan_to_num(X_all[idx], nan=0.0); yt = target[idx]
        bag_seeds = [seed + i*7 for i in range(BAGS)]
        with ThreadPoolExecutor(max_workers=WORKERS) as ex:
            reg_models = list(ex.map(_train_reg, [(s, Xt, yt, params) for s in bag_seeds]))
        yb = (yt > 0).astype(int)
        with ThreadPoolExecutor(max_workers=WORKERS) as ex:
            cls_models = list(ex.map(_train_cls, [(s, Xt, yb, params) for s in bag_seeds]))
        X_test = np.nan_to_num(X_all[ts:tend+1], nan=0.0)
        rp = np.mean([m.predict(X_test) for m in reg_models], axis=0)
        cp = np.mean([m.predict_proba(X_test)[:,1] for m in cls_models], axis=0)
        reg_preds[ts:tend+1] = rp; cls_probs[ts:tend+1] = cp
        for t in range(ts, tend+1):
            pred = reg_preds[t]; p_up = cls_probs[t]
            conf_factor = 1.0 / (1.0 + np.exp(-abs(p_up - 0.5) * 15))
            is_rebal = dow[t] in [4]
            is_emerg = t > 0 and abs(daily_ret[t]) > EMERGENCY_THRESHOLD
            if not is_rebal and not is_emerg: full_allocs[t] = prev_alloc; continue
            regime = get_regime(t, prices, sma50, sma200)
            raw = pred * K_REGIME[regime] * conf_factor
            full_allocs[t] = float(np.clip(raw, 0.0, 1.0))
            prev_alloc = full_allocs[t]
        s, b, a = backtest_allocations(daily_ret, full_allocs, ts, tend, cost=COST, rf_daily=rf_daily)
        a_s.extend(s); a_b.extend(b); a_a.extend(a)
        a_r.extend(rf_daily[ts:ts+len(s)])
        for i in range(len(s)): strat_ret[ts+i] = s[i]
        del reg_models, cls_models; gc.collect()
    metrics = v22.metrics_v22(np.array(a_s), np.array(a_b), np.array(a_a), rf_daily=np.array(a_r))
    return metrics, reg_preds, cls_probs, full_allocs, strat_ret


def yoy(strat_ret, daily_ret, dates, years_min=2022):
    ds = pd.to_datetime(dates); years = ds.year.values
    rows = []
    for y in sorted(set(years[years >= years_min])):
        mask = years == y
        st = np.prod(1 + strat_ret[mask]) - 1 if mask.sum() else 0
        bt = np.prod(1 + daily_ret[mask]) - 1 if mask.sum() else 0
        rows.append({'year': int(y), 'strat': float(st*100), 'btc': float(bt*100)})
    return rows


def run_exp(name, desc, feature_cols, df, prices, daily_ret, returns, vols,
             dates, n, rf_daily, dow, periods, sma50, sma200, target):
    print(f"\n[{time.strftime('%H:%M:%S')}] {name}: {desc}", flush=True)
    print(f"  {len(feature_cols)} features", flush=True)
    new_feats = [f for f in feature_cols if f not in list(FEATURES_37)]
    if new_feats:
        for f in new_feats:
            if f in df.columns:
                print(f"    {f}: last={df[f].iloc[-1]:.4f}, mean={df[f].mean():.4f}", flush=True)
    X_all, _ = build_ml_features(df, returns, vols, n, feature_cols=feature_cols)
    outs = []
    for s in SEEDS:
        t1 = time.time()
        print(f"  seed {s}...", flush=True)
        m, rp, cp, al, sr = run_one(s, X_all, target, prices, daily_ret, dates, periods,
                                      dow, sma50, sma200, rf_daily, n)
        outs.append((m, rp, cp, al, sr))
        print(f"    S={m['sortino']:.2f} Ret={m['total']*100:+.0f}% ({(time.time()-t1)/60:.1f}m)", flush=True)
    S = [o[0]['sortino'] for o in outs]; R = [o[0]['total']*100 for o in outs]
    DD = [o[0]['max_dd']*100 for o in outs]
    strat_avg = np.mean([o[4] for o in outs], axis=0)
    y_rows = yoy(strat_avg, daily_ret, dates)
    result = {'name': name, 'desc': desc, 'n_features': len(feature_cols),
              'sortino': float(np.mean(S)), 'sortino_std': float(np.std(S)),
              'ret': float(np.mean(R)), 'dd': float(np.mean(DD)), 'yoy': y_rows}
    print(f"\n  SUMMARY {name}: S={result['sortino']:.3f}+/-{result['sortino_std']:.3f}  "
          f"Ret={result['ret']:+.0f}%  DD={result['dd']:.1f}%", flush=True)
    for y in y_rows:
        print(f"    {y['year']}: strat={y['strat']:+.1f}% btc={y['btc']:+.1f}%", flush=True)
    return result


def main():
    t0 = time.time()
    print('='*100, flush=True)
    print('V38 — Selic/CDI as feature (user insight: model ignores BR rate)', flush=True)
    print('='*100, flush=True)

    prices, daily_ret, returns, vols, df, rf_daily = load()
    print(f'Data: {len(df)} rows, features loaded', flush=True)
    has_us10y = 'us10y' in df.columns
    print(f'selic_ann range: {df.selic_ann.min()*100:.1f}% - {df.selic_ann.max()*100:.1f}%', flush=True)
    print(f'us10y available: {has_us10y}', flush=True)

    dates = df['date'].values; n = len(prices)
    v9m.RF_DAILY_ARR = rf_daily; v13m.RF_DAILY_ARR = rf_daily
    dow = pd.to_datetime(dates).dayofweek.values
    periods = _get_retrain_periods(dates, n, v22.RETRAIN)
    sma50 = pd.Series(prices).rolling(50).mean().values
    sma200 = pd.Series(prices).rolling(200).mean().values
    target = np.zeros(n)
    for i in range(n - HORIZON): target[i] = (prices[i + HORIZON] - prices[i]) / prices[i]

    results = []
    def save():
        RESULTS.parent.mkdir(parents=True, exist_ok=True)
        with open(RESULTS, 'w') as f:
            json.dump({'results': results, 'elapsed_min': (time.time()-t0)/60}, f, indent=2)

    common = dict(df=df, prices=prices, daily_ret=daily_ret, returns=returns, vols=vols,
                   dates=dates, n=n, rf_daily=rf_daily, dow=dow, periods=periods,
                   sma50=sma50, sma200=sma200, target=target)
    base32 = list(FEATURES_37)

    # G1: +selic_ann
    r = run_exp('G1_selic_ann', 'E1 + Selic annualized', base32 + ['selic_ann'], **common)
    results.append(r); save()

    # G2: +selic_change_30d
    r = run_exp('G2_selic_change', 'E1 + Selic change 30d', base32 + ['selic_change_30d'], **common)
    results.append(r); save()

    # G3: combo both
    r = run_exp('G3_selic_both', 'E1 + Selic ann + change', base32 + ['selic_ann','selic_change_30d'], **common)
    results.append(r); save()

    # G4: +us10y (if available)
    if has_us10y:
        r = run_exp('G4_us10y', 'E1 + US 10Y yield', base32 + ['us10y'], **common)
        results.append(r); save()

    # G5: best combo
    best = max(results, key=lambda x: x['sortino'])
    if best['sortino'] > 6.12:  # better than E1 baseline
        # Keep the winning features
        best_feats = [f for f in ['selic_ann','selic_change_30d','us10y']
                      if f in best['name'].lower() or f in best['desc'].lower()]
        print(f"\nBest G1-G4: {best['name']} (S={best['sortino']:.3f})")

    elapsed = (time.time() - t0) / 60
    print(f'\n{"="*100}\nV38 DONE: {elapsed:.1f}m\n{"="*100}', flush=True)
    print('Reference (E1 baseline): S=6.441, Ret=+860%\n', flush=True)
    for r in sorted(results, key=lambda x: -x['sortino']):
        print(f"  {r['name']:<22}  S={r['sortino']:.3f}+/-{r['sortino_std']:.3f}  "
              f"Ret={r['ret']:+.0f}%  DD={r['dd']:.1f}%", flush=True)
    save()


if __name__ == '__main__':
    main()
