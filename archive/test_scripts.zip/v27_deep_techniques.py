"""V27: deeper techniques that V26 didn't cover.

Reference (V26): T1_baseline Sortino 5.05, Ret +1098%, Fri acc 62.2%

V27 tests:

  T1  — META-LABELING FORMAL (AFML Ch. 3)
        Primary regressor predicts direction.
        Secondary XGBClassifier predicts P(primary acts correctly).
        Size = primary × P(correct). Should improve accuracy in active positions.

  T2  — REGULARIZATION SWEEP
        Test reg_alpha (L1) and reg_lambda (L2) at 0.1, 1.0, 5.0.

  T3  — MIN_CHILD_WEIGHT sweep (current 12 → test 6, 20, 50)
        Controls tree complexity / overfit.

  T4  — STACKING (2-level)
        Level 1: XGB + LightGBM (predict 3d ret)
        Level 2: XGB meta-learner on [pred_xgb, pred_lgbm, top features]

  T5  — ROLLING WINDOW TRAINING (3-year)
        Current: expanding window. Test rolling 3y.
        Should be more responsive to regime changes.

  T6  — CLASSIFICATION (sign prediction)
        XGBClassifier on binary target (return > 0).
        Position = P(up) * K * sign. Cleaner than regression.

  T7  — QUANTILE REGRESSION
        Predict 3 quantiles (25/50/75).
        Position = f(median, spread).

  T8  — CLOSEST K TO SIGNAL (rule-based):
        Take avg prediction and map to K using regime thresholds.
        Replaces K_REGIME with data-driven K. (skipped — user said K scaling is overfit-prone)

  T9  — FEATURE PRUNING via GAIN IMPORTANCE
        Run baseline, sort features by gain importance, remove bottom 10.

  T10 — CALIBRATED CLASSIFIER
        XGBClassifier + Isotonic calibration. Gives reliable P(up).

Each 3 seeds. Total ~3-4h.
"""
import sys, time, json, gc
import numpy as np, pandas as pd
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import xgboost as xgb

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

import archive.old_pipelines.pipeline_v22 as v22
from archive.old_pipelines.pipeline_v09 import build_ml_features, backtest_allocations, COST
from scripts.production.training import _get_retrain_periods, _train_one_xgb
from src.features.macro.cdi_rates import build_rf_daily
import archive.old_pipelines.pipeline_v09 as v9m
import archive.old_pipelines.pipeline_v13 as v13m
from scripts.production.config import FEATURES_37, K_REGIME, ALLOC_MIN, ALLOC_MAX, BAGS, HORIZON, WORKERS, EMERGENCY_THRESHOLD

DATASET = ROOT / "outputs" / "feature_selection" / "dataset_enhanced.csv"
SEEDS_3 = [42, 142, 242]
RESULTS = ROOT / "outputs" / "results" / "v27_deep.json"
DAY_NAMES = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun']


def load():
    df = pd.read_csv(DATASET)
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)
    prices = df['price_usd'].values
    n = len(prices)
    daily_ret = np.zeros(n)
    for i in range(1, n):
        daily_ret[i] = (prices[i] - prices[i-1]) / prices[i-1]
    returns, vols = {}, {}
    for w in [1, 3, 5, 7, 10, 14, 20, 21, 30, 45, 60]:
        r = np.zeros(n)
        for i in range(w, n):
            r[i] = (prices[i] - prices[i-w]) / prices[i-w]
        returns[w] = r
    for w in [5, 7, 10, 14, 21, 30]:
        vols[w] = pd.Series(daily_ret).rolling(w).std().fillna(0.02).values
    return prices, daily_ret, returns, vols, df


def accuracy_per_dow(preds, actuals, dow):
    mask = np.abs(preds) > 1e-6
    out = {'all': float((np.sign(preds[mask]) == np.sign(actuals[mask])).mean())}
    for d, name in enumerate(DAY_NAMES):
        dmask = mask & (dow == d)
        if dmask.sum() > 10:
            out[name] = float((np.sign(preds[dmask]) == np.sign(actuals[dmask])).mean())
        else:
            out[name] = None
    return out


def compute_allocation(prediction, regime):
    K = K_REGIME[regime]
    return float(np.clip(prediction * K, ALLOC_MIN, ALLOC_MAX))


def get_regime(t, prices, sma50, sma200):
    if np.isnan(sma50[t]) or np.isnan(sma200[t]):
        return 'MILD'
    if prices[t] > sma50[t] and sma50[t] > sma200[t]:
        return 'BULL'
    elif prices[t] > sma200[t]:
        return 'MILD'
    return 'BEAR'


# ═══════════════════════════════════════════════════════════════
# T1: META-LABELING FORMAL
# ═══════════════════════════════════════════════════════════════

def run_meta_labeling(seed, X_all, target, prices, daily_ret, dates, periods,
                       dow, sma50, sma200, rf_daily, n):
    full_allocs = np.full(n, 0.0)
    prev_alloc = 0.0
    a_s, a_b, a_a, a_r = [], [], [], []
    all_preds = np.zeros(n)
    all_actuals = target.copy()

    for te, ts, tend in periods:
        gap = max(HORIZON, 5)
        tm = np.arange(60, te - gap + 1)
        valid = ~np.any(np.isnan(X_all[tm]), axis=1)
        idx = tm[valid]
        if len(idx) < 100:
            continue
        Xt = np.nan_to_num(X_all[idx], nan=0.0)
        yt = target[idx]

        # Primary: regression (smaller ensemble to be fast)
        bag_seeds = [seed + i * 7 for i in range(BAGS)]
        with ThreadPoolExecutor(max_workers=WORKERS) as ex:
            primary = list(ex.map(_train_one_xgb,
                [(s, Xt, yt, v22.XGB_PARAMS) for s in bag_seeds]))

        # Secondary: classifier on "primary direction correct"
        # Meta-label = 1 if sign(primary_pred) == sign(actual), 0 otherwise
        primary_preds_train = np.mean([m.predict(Xt) for m in primary], axis=0)
        meta_y = ((np.sign(primary_preds_train) == np.sign(yt)).astype(int))

        meta_clf_params = dict(v22.XGB_PARAMS)
        meta_clf_params.pop('objective', None)
        meta_clf = xgb.XGBClassifier(
            n_estimators=200, objective='binary:logistic',
            eval_metric='logloss', random_state=seed, n_jobs=1,
            max_leaves=meta_clf_params['max_leaves'],
            colsample_bytree=meta_clf_params['colsample_bytree'],
            subsample=meta_clf_params['subsample'],
            learning_rate=meta_clf_params['learning_rate'],
            min_child_weight=meta_clf_params['min_child_weight'],
        )
        meta_clf.fit(Xt, meta_y)

        for t in range(ts, tend + 1):
            x_t = np.nan_to_num(X_all[t:t + 1].copy(), nan=0.0)
            prediction = float(np.mean([m.predict(x_t)[0] for m in primary]))
            p_correct = float(meta_clf.predict_proba(x_t)[0, 1])
            # Size = prediction × P(correct)
            adjusted = prediction * p_correct
            all_preds[t] = adjusted

            is_rebal = dow[t] in [4]
            is_emerg = t > 0 and abs(daily_ret[t]) > EMERGENCY_THRESHOLD
            if not is_rebal and not is_emerg:
                full_allocs[t] = prev_alloc
                continue
            regime = get_regime(t, prices, sma50, sma200)
            full_allocs[t] = compute_allocation(adjusted, regime)
            prev_alloc = full_allocs[t]

        s, b, a = backtest_allocations(daily_ret, full_allocs, ts, tend,
                                       cost=COST, rf_daily=rf_daily)
        a_s.extend(s); a_b.extend(b); a_a.extend(a)
        a_r.extend(rf_daily[ts:ts + len(s)])
        del primary, meta_clf; gc.collect()

    metrics = v22.metrics_v22(np.array(a_s), np.array(a_b), np.array(a_a),
                              rf_daily=np.array(a_r))
    return metrics, all_preds, all_actuals


# ═══════════════════════════════════════════════════════════════
# Generic run: default XGB with custom params override
# ═══════════════════════════════════════════════════════════════

def run_seed_custom(seed, X_all, target, prices, daily_ret, dates, periods,
                    dow, sma50, sma200, rf_daily, n,
                    xgb_params=None, rolling_years=None, classifier=False,
                    calibrate=False):
    full_allocs = np.full(n, 0.0)
    prev_alloc = 0.0
    a_s, a_b, a_a, a_r = [], [], [], []
    all_preds = np.zeros(n)
    all_actuals = target.copy()

    params = xgb_params if xgb_params is not None else v22.XGB_PARAMS

    for te, ts, tend in periods:
        gap = max(HORIZON, 5)
        tm = np.arange(60, te - gap + 1)
        valid = ~np.any(np.isnan(X_all[tm]), axis=1)
        idx = tm[valid]
        if rolling_years is not None:
            window_days = int(rolling_years * 252)
            if len(idx) > window_days:
                idx = idx[-window_days:]
        if len(idx) < 100:
            continue
        Xt = np.nan_to_num(X_all[idx], nan=0.0)
        yt = target[idx]

        bag_seeds = [seed + i * 7 for i in range(BAGS)]
        if classifier:
            # Train classifier on binary target (sign)
            yt_bin = (yt > 0).astype(int)
            models = []
            for s in bag_seeds:
                p = dict(params)
                p.pop('objective', None)
                m = xgb.XGBClassifier(
                    n_estimators=p.pop('n_estimators', 200),
                    random_state=s, objective='binary:logistic',
                    eval_metric='logloss', n_jobs=1,
                    **{k:v for k,v in p.items() if k in
                       ['max_leaves','colsample_bytree','subsample','learning_rate',
                        'min_child_weight','reg_alpha','reg_lambda','grow_policy','tree_method']})
                m.fit(Xt, yt_bin)
                models.append(m)
        else:
            with ThreadPoolExecutor(max_workers=WORKERS) as ex:
                models = list(ex.map(_train_one_xgb,
                    [(s, Xt, yt, params) for s in bag_seeds]))

        for t in range(ts, tend + 1):
            x_t = np.nan_to_num(X_all[t:t + 1].copy(), nan=0.0)
            if classifier:
                # prediction ∈ [-1, +1] from P(up)
                p_up = float(np.mean([m.predict_proba(x_t)[0, 1] for m in models]))
                prediction = (p_up - 0.5) * 2.0 * 0.03  # scale to ~return magnitude
            else:
                prediction = float(np.mean([m.predict(x_t)[0] for m in models]))
            all_preds[t] = prediction

            is_rebal = dow[t] in [4]
            is_emerg = t > 0 and abs(daily_ret[t]) > EMERGENCY_THRESHOLD
            if not is_rebal and not is_emerg:
                full_allocs[t] = prev_alloc
                continue
            regime = get_regime(t, prices, sma50, sma200)
            full_allocs[t] = compute_allocation(prediction, regime)
            prev_alloc = full_allocs[t]

        s, b, a = backtest_allocations(daily_ret, full_allocs, ts, tend,
                                       cost=COST, rf_daily=rf_daily)
        a_s.extend(s); a_b.extend(b); a_a.extend(a)
        a_r.extend(rf_daily[ts:ts + len(s)])
        del models; gc.collect()

    metrics = v22.metrics_v22(np.array(a_s), np.array(a_b), np.array(a_a),
                              rf_daily=np.array(a_r))
    return metrics, all_preds, all_actuals


def aggregate(name, outputs, dow):
    sortinos = [o[0]['sortino'] for o in outputs]
    rets     = [o[0]['total']*100 for o in outputs]
    dds      = [o[0]['max_dd']*100 for o in outputs]
    preds_avg = np.mean([o[1] for o in outputs], axis=0)
    actuals = outputs[0][2]
    acc = accuracy_per_dow(preds_avg, actuals, dow)
    result = {
        'name': name,
        'sortino_mean': float(np.mean(sortinos)), 'sortino_std': float(np.std(sortinos)),
        'ret_mean': float(np.mean(rets)), 'ret_std': float(np.std(rets)),
        'dd_mean': float(np.mean(dds)), 'dd_std': float(np.std(dds)),
        'acc': acc,
    }
    acc_str = f"all={acc['all']*100:.1f}%"
    for day in ['Mon','Wed','Fri','Sun']:
        if acc.get(day) is not None:
            acc_str += f" {day}={acc[day]*100:.1f}%"
    print(f"{name:<30}  S={result['sortino_mean']:.2f}  Ret={result['ret_mean']:+.0f}%  "
          f"DD={result['dd_mean']:.1f}%  {acc_str}")
    return result


def main():
    t0 = time.time()
    print("=" * 95)
    print("V27 DEEP TECHNIQUES")
    print("Reference: baseline Sortino 5.05, Ret +1098%, Fri acc 62.2%")
    print("=" * 95)

    prices, daily_ret, returns, vols, df = load()
    dates = df['date'].values
    n = len(prices)
    rf_daily = build_rf_daily(dates, source='auto')
    v9m.RF_DAILY_ARR = rf_daily
    v13m.RF_DAILY_ARR = rf_daily
    dow = pd.to_datetime(dates).dayofweek.values
    periods = _get_retrain_periods(dates, n, v22.RETRAIN)
    sma50 = pd.Series(prices).rolling(50).mean().values
    sma200 = pd.Series(prices).rolling(200).mean().values

    feats = list(FEATURES_37)
    X_base, _ = build_ml_features(df, returns, vols, n, feature_cols=feats)

    target = np.zeros(n)
    for i in range(n - HORIZON):
        target[i] = (prices[i + HORIZON] - prices[i]) / prices[i]

    results = []
    def save():
        RESULTS.parent.mkdir(parents=True, exist_ok=True)
        with open(RESULTS, 'w') as f:
            json.dump({'results': results, 'elapsed_min': (time.time()-t0)/60}, f, indent=2)

    # T1 — META-LABELING
    print("\n-- T1: META-LABELING --")
    outs = [run_meta_labeling(s, X_base, target, prices, daily_ret, dates, periods,
                               dow, sma50, sma200, rf_daily, n) for s in SEEDS_3]
    results.append(aggregate('T1_meta_labeling', outs, dow)); save()

    # T2 — REGULARIZATION SWEEP
    print("\n-- T2: REGULARIZATION SWEEP --")
    for alpha, lam in [(0.1, 0.1), (1.0, 1.0), (5.0, 5.0)]:
        p = dict(v22.XGB_PARAMS); p['reg_alpha'] = alpha; p['reg_lambda'] = lam
        outs = [run_seed_custom(s, X_base, target, prices, daily_ret, dates, periods,
                                 dow, sma50, sma200, rf_daily, n, xgb_params=p)
                for s in SEEDS_3]
        results.append(aggregate(f'T2_reg_a{alpha}_l{lam}', outs, dow)); save()

    # T3 — MIN_CHILD_WEIGHT SWEEP
    print("\n-- T3: MIN_CHILD_WEIGHT SWEEP --")
    for mcw in [6, 20, 50]:
        p = dict(v22.XGB_PARAMS); p['min_child_weight'] = mcw
        outs = [run_seed_custom(s, X_base, target, prices, daily_ret, dates, periods,
                                 dow, sma50, sma200, rf_daily, n, xgb_params=p)
                for s in SEEDS_3]
        results.append(aggregate(f'T3_mcw_{mcw}', outs, dow)); save()

    # T5 — ROLLING WINDOW
    print("\n-- T5: ROLLING WINDOW (3y) --")
    outs = [run_seed_custom(s, X_base, target, prices, daily_ret, dates, periods,
                             dow, sma50, sma200, rf_daily, n, rolling_years=3)
            for s in SEEDS_3]
    results.append(aggregate('T5_rolling_3y', outs, dow)); save()

    # T6 — CLASSIFIER (binary sign)
    print("\n-- T6: CLASSIFIER (binary sign) --")
    outs = [run_seed_custom(s, X_base, target, prices, daily_ret, dates, periods,
                             dow, sma50, sma200, rf_daily, n, classifier=True)
            for s in SEEDS_3]
    results.append(aggregate('T6_classifier', outs, dow)); save()

    # Final summary
    print()
    print("=" * 95)
    print(f"V27 TOTAL: {(time.time()-t0)/60:.1f} min")
    print("=" * 95)
    print("\nRanked by Sortino:")
    for r in sorted(results, key=lambda x: -x['sortino_mean']):
        acc = r['acc']
        print(f"  {r['name']:<30}  S={r['sortino_mean']:.2f}  Ret={r['ret_mean']:+.0f}%  "
              f"DD={r['dd_mean']:.1f}%  acc_Fri={acc.get('Fri', 0)*100:.1f}%")
    save()


if __name__ == '__main__':
    main()
