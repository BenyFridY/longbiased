"""V24 accuracy check: compute prediction accuracy at rebalance days for the
top sets (V0 baseline vs V6 fracdiff vs V9 combo).

Accuracy = how often sign(prediction) matches sign(actual 3-day future return),
but only on Friday rebalance days (that's where the model makes decisions).
"""
import sys, time, gc
import numpy as np, pandas as pd
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

import archive.old_pipelines.pipeline_v22 as v22
from archive.old_pipelines.pipeline_v09 import build_ml_features
from scripts.production.training import _get_retrain_periods, _train_one_xgb
from src.features.macro.cdi_rates import build_rf_daily
import archive.old_pipelines.pipeline_v09 as v9m
import archive.old_pipelines.pipeline_v13 as v13m

from scripts.production.config import FEATURES_37

DATASET = ROOT / "outputs" / "feature_selection" / "dataset_v24.csv"


def load_v24():
    df = pd.read_csv(DATASET)
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)
    prices = df['price_usd'].values
    n = len(prices)
    daily_ret = np.zeros(n)
    for i in range(1, n):
        daily_ret[i] = (prices[i] - prices[i-1]) / prices[i-1]
    returns, vols = {}, {}
    for w in [1, 3, 5, 7, 10, 14, 20, 21, 30, 45, 60]:
        r = np.zeros(n)
        for i in range(w, n):
            r[i] = (prices[i] - prices[i-w]) / prices[i-w]
        returns[w] = r
    for w in [5, 7, 10, 14, 21, 30]:
        vols[w] = pd.Series(daily_ret).rolling(w).std().fillna(0.02).values
    return prices, daily_ret, returns, vols, df


def run_accuracy(seed, X_all, target, prices, dates, periods, dow, n):
    """Like run_single_seed but returns (pred, actual, is_rebal) for each test day."""
    preds, actuals, rebals = [], [], []
    for te, ts, tend in periods:
        gap = max(v22.HORIZON, 5)
        tm = np.arange(60, te - gap + 1)
        valid = ~np.any(np.isnan(X_all[tm]), axis=1)
        idx = tm[valid]
        if len(idx) < 100:
            continue
        Xt = np.nan_to_num(X_all[idx], nan=0.0)
        yt = target[idx]
        bag_seeds = [seed + i * 7 for i in range(v22.BAGS)]
        with ThreadPoolExecutor(max_workers=v22.WORKERS) as ex:
            models = list(ex.map(_train_one_xgb,
                [(s, Xt, yt, v22.XGB_PARAMS) for s in bag_seeds]))

        for t in range(ts, tend + 1):
            is_rebal = dow[t] in v22.REBAL_DOW
            x_t = np.nan_to_num(X_all[t:t + 1].copy(), nan=0.0)
            pred = float(np.mean([m.predict(x_t)[0] for m in models]))
            actual = target[t]  # 3-day forward return
            preds.append(pred)
            actuals.append(actual)
            rebals.append(is_rebal)

        del models
        gc.collect()

    return np.array(preds), np.array(actuals), np.array(rebals)


BASELINE = list(FEATURES_37)
SETS = {
    'V0_baseline': BASELINE,
    'V6_fracdiff': BASELINE + ['price_fracdiff_05', 'fed_fracdiff_05'],
    'V9_combo':    [f for f in BASELINE if f not in ('open_interest','futures_trade_count')]
                   + ['price_fracdiff_05', 'fed_fracdiff_05'],
}


def main():
    t0 = time.time()
    prices, daily_ret, returns, vols, df = load_v24()
    dates = df['date'].values
    n = len(prices)
    rf_daily = build_rf_daily(dates, source='auto')
    v9m.RF_DAILY_ARR = rf_daily
    v13m.RF_DAILY_ARR = rf_daily
    v22.REBAL_DOW = [4]
    dow = pd.to_datetime(dates).dayofweek
    periods = _get_retrain_periods(dates, n, v22.RETRAIN)
    target = np.zeros(n)
    for i in range(n - v22.HORIZON):
        target[i] = (prices[i + v22.HORIZON] - prices[i]) / prices[i]

    print("=" * 75)
    print("V24 ACCURACY CHECK — 3 seeds each")
    print("=" * 75)

    results = {}
    for name, feats in SETS.items():
        X_all, _ = build_ml_features(df, returns, vols, n, feature_cols=feats)
        all_preds, all_actuals, all_rebals = [], [], []
        for seed in [42, 142, 242]:
            p, a, r = run_accuracy(seed, X_all, target, prices, dates, periods, dow, n)
            all_preds.append(p); all_actuals.append(a); all_rebals.append(r)

        # Aggregate across seeds (same positions)
        preds = np.mean(all_preds, axis=0)
        actuals = all_actuals[0]
        rebals = all_rebals[0]

        # Accuracy on ALL days
        mask_all = np.abs(preds) > 1e-6  # skip zero preds
        acc_all = (np.sign(preds[mask_all]) == np.sign(actuals[mask_all])).mean()

        # Accuracy on REBALANCE days (Fridays)
        mask_rebal = rebals & mask_all
        acc_rebal = (np.sign(preds[mask_rebal]) == np.sign(actuals[mask_rebal])).mean()

        # High-confidence accuracy (|pred| > 0.01)
        mask_hc = np.abs(preds) > 0.01
        acc_hc = (np.sign(preds[mask_hc]) == np.sign(actuals[mask_hc])).mean() if mask_hc.sum() > 0 else 0

        results[name] = {'all': acc_all, 'rebal': acc_rebal, 'hc': acc_hc,
                         'n_rebal': int(mask_rebal.sum()), 'n_total': int(mask_all.sum())}

        print(f"{name:<18}  acc_all={acc_all*100:.1f}%  acc_rebal={acc_rebal*100:.1f}%  "
              f"acc_hc={acc_hc*100:.1f}%  (n_rebal={int(mask_rebal.sum())})")

    elapsed = (time.time() - t0) / 60
    print(f"\nTotal: {elapsed:.1f} min")


if __name__ == '__main__':
    main()
