"""
V22 Early Stopping Sweep
Tests different patience values + no early stopping baseline.
5 seeds each, reports which patience is best.

Usage:
    python scripts/optimization/v22_es_sweep.py
"""
import sys, gc, json, numpy as np, pandas as pd
import xgboost as xgb
from pathlib import Path
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
import warnings; warnings.filterwarnings('ignore')
sys.stdout.reconfigure(line_buffering=True)

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

from archive.old_pipelines.pipeline_v09 import (
    load_data, build_ml_features, backtest_allocations,
    COST, P, convert_numpy,
)
from archive.old_pipelines.pipeline_v10 import MODELS
from archive.old_pipelines.pipeline_v13 import _get_retrain_periods, _train_one_xgb


# ═══════════════════════════════════════════════════════════════════════
# CONFIG (same as V21)
# ═══════════════════════════════════════════════════════════════════════

XGB_BASE = {
    'max_leaves': 31, 'grow_policy': 'lossguide', 'tree_method': 'hist',
    'colsample_bytree': 0.5, 'subsample': 0.8, 'learning_rate': 0.05,
    'min_child_weight': 12, 'objective': 'reg:squarederror',
    'verbosity': 0, 'nthread': 1,
}

K_REGIME = {'BULL': 50, 'MILD': 30, 'BEAR': 15}
ALLOC_MIN, ALLOC_MAX = -0.25, 1.0
BAGS = 80
HORIZON = 3
RETRAIN = 'semi'
REBAL_DOW = [4]
EMERGENCY_THRESHOLD = 0.08
WORKERS = 16

BASE_FEATURES = [f for f in MODELS['37feat'] if f != 'exchange_netflow_ma7'] + ['basis_pct']
EXTRA_FEATURES = [
    'fed_balance_sheet', 'futures_trade_count',
    'vol_x_regime_duration', 'velocity', 'hash_rate_pctchg_30d',
]

# Configs to test: (n_estimators, early_stopping_rounds, val_fraction, label)
CONFIGS = [
    (200,  None, 0.0, "baseline (V21: 200 trees, no ES)"),
    (500,  10,   0.2, "ES patience=10, val=20%"),
    (500,  20,   0.2, "ES patience=20, val=20%"),
    (500,  30,   0.2, "ES patience=30, val=20%"),
    (500,  50,   0.2, "ES patience=50, val=20%"),
    (500,  20,   0.15,"ES patience=20, val=15%"),
    (500,  20,   0.25,"ES patience=20, val=25%"),
]

NUM_SEEDS = 5
SEEDS = [42 + i * 100 for i in range(NUM_SEEDS)]


# ═══════════════════════════════════════════════════════════════════════
# FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════

def train_one(args):
    """Train XGB with or without early stopping."""
    seed, Xt, yt, n_est, es_rounds, val_frac = args
    p = dict(XGB_BASE)
    p['random_state'] = seed

    if es_rounds is None or val_frac == 0:
        # No early stopping — train all n_est trees
        m = xgb.XGBRegressor(n_estimators=n_est, **p)
        m.fit(Xt, yt)
        return m, n_est

    # Early stopping with temporal validation split
    n_train = int(len(Xt) * (1 - val_frac))
    X_tr, X_val = Xt[:n_train], Xt[n_train:]
    y_tr, y_val = yt[:n_train], yt[n_train:]

    m = xgb.XGBRegressor(
        n_estimators=n_est,
        early_stopping_rounds=es_rounds,
        **p,
    )
    m.fit(X_tr, y_tr, eval_set=[(X_val, y_val)], verbose=False)

    best = m.best_iteration + 1 if hasattr(m, 'best_iteration') and m.best_iteration is not None else n_est
    return m, best


def get_regime(t, prices, sma50, sma200):
    if np.isnan(sma50[t]) or np.isnan(sma200[t]):
        return 'MILD'
    if prices[t] > sma50[t] and sma50[t] > sma200[t]:
        return 'BULL'
    elif prices[t] > sma200[t]:
        return 'MILD'
    return 'BEAR'


def metrics_correct(s, b, a, rf_daily=None):
    if len(s) < 10:
        return None
    if rf_daily is None:
        rf_daily = 0.0
    ts = np.prod(1 + s) - 1
    tb = np.prod(1 + b) - 1
    ex = s - rf_daily
    ds = ex[ex < 0]
    dd_rms = np.sqrt(np.mean(ds ** 2)) if len(ds) > 0 else 1e-10
    sortino = np.mean(ex) / (dd_rms + 1e-10) * np.sqrt(365)
    sharpe = np.mean(ex) / (np.std(s) + 1e-10) * np.sqrt(365)
    cum = np.cumprod(1 + s)
    pk = np.maximum.accumulate(cum)
    max_dd = np.min((cum - pk) / (pk + 1e-10))
    return {'total': ts, 'sortino': sortino, 'sharpe': sharpe, 'max_dd': max_dd}


def run_seed(seed, X_all, target, prices, daily_ret, dates, periods,
             dow, sma50, sma200, rf_daily, n, n_est, es_rounds, val_frac):
    full_allocs = np.full(n, 0.0)
    prev_alloc = 0.0
    a_s, a_b, a_a, a_r = [], [], [], []
    all_trees = []

    for te, ts, tend in periods:
        gap = max(HORIZON, 5)
        tm = np.arange(60, te - gap + 1)
        valid = ~np.any(np.isnan(X_all[tm]), axis=1)
        idx = tm[valid]
        if len(idx) < 100:
            continue

        Xt = np.nan_to_num(X_all[idx], nan=0.0)
        yt = target[idx]

        bag_seeds = [seed + i * 7 for i in range(BAGS)]
        args_list = [(s, Xt, yt, n_est, es_rounds, val_frac) for s in bag_seeds]

        with ThreadPoolExecutor(max_workers=WORKERS) as ex:
            results = list(ex.map(train_one, args_list))

        models = [r[0] for r in results]
        all_trees.extend([r[1] for r in results])

        for t in range(ts, tend + 1):
            is_rebal = dow[t] in REBAL_DOW
            is_emerg = t > 0 and abs(daily_ret[t]) > EMERGENCY_THRESHOLD
            if not is_rebal and not is_emerg:
                full_allocs[t] = prev_alloc
                continue

            x_t = np.nan_to_num(X_all[t:t + 1].copy(), nan=0.0)
            prediction = float(np.mean([m.predict(x_t)[0] for m in models]))
            regime = get_regime(t, prices, sma50, sma200)
            K = K_REGIME[regime]
            full_allocs[t] = np.clip(prediction * K, ALLOC_MIN, ALLOC_MAX)
            prev_alloc = full_allocs[t]

        s, b, a = backtest_allocations(daily_ret, full_allocs, ts, tend,
                                       cost=COST, rf_daily=rf_daily)
        a_s.extend(s)
        a_b.extend(b)
        a_a.extend(a)
        a_r.extend(rf_daily[ts:ts + len(s)])

        del models
        gc.collect()

    m = metrics_correct(np.array(a_s), np.array(a_b), np.array(a_a),
                        rf_daily=np.array(a_r))
    if m is not None:
        m['avg_trees'] = float(np.mean(all_trees))
    return m


# ═══════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════

def main():
    P("=" * 80)
    P("V22 EARLY STOPPING SWEEP")
    P(f"  {len(CONFIGS)} configs x {NUM_SEEDS} seeds = {len(CONFIGS) * NUM_SEEDS} runs")
    P("=" * 80)

    start = datetime.now()

    P("\nLoading data...")
    prices, daily_ret, returns, vols, df = load_data()
    dates = df['date'].values
    n = len(prices)
    P(f"  {n} days | {dates[0]} to {dates[-1]}")

    try:
        from src.features.macro.cdi_rates import build_rf_daily
        rf_daily = build_rf_daily(dates, source='auto')
    except Exception:
        from src.features.macro.cdi_rates import build_rf_daily
        rf_daily = build_rf_daily(dates, source='copom')

    import archive.old_pipelines.pipeline_v09 as v9m
    import archive.old_pipelines.pipeline_v13 as v13m
    v9m.RF_DAILY_ARR = rf_daily
    v13m.RF_DAILY_ARR = rf_daily

    fc = BASE_FEATURES + [f for f in EXTRA_FEATURES if f not in BASE_FEATURES]
    fc = [f for f in fc if f in df.columns]
    P(f"  {len(fc)} features")

    X_all, _ = build_ml_features(df, returns, vols, n, feature_cols=fc)

    target = np.zeros(n)
    for i in range(n - HORIZON):
        target[i] = (prices[i + HORIZON] - prices[i]) / prices[i]

    dow = pd.to_datetime(dates).dayofweek
    periods = _get_retrain_periods(dates, n, RETRAIN)
    sma50 = pd.Series(prices).rolling(50).mean().values
    sma200 = pd.Series(prices).rolling(200).mean().values

    # Run all configs
    all_results = []

    for ci, (n_est, es_rounds, val_frac, label) in enumerate(CONFIGS):
        P(f"\n{'─'*60}")
        P(f"[{ci+1}/{len(CONFIGS)}] {label}")
        P(f"{'─'*60}")

        sortinos, sharpes, rets_list, dds, trees_list = [], [], [], [], []

        for si, seed in enumerate(SEEDS):
            P(f"  Seed {seed} ({si+1}/{NUM_SEEDS})...", end="")
            m = run_seed(seed, X_all, target, prices, daily_ret, dates,
                        periods, dow, sma50, sma200, rf_daily, n,
                        n_est, es_rounds, val_frac)
            sortinos.append(m['sortino'])
            sharpes.append(m['sharpe'])
            rets_list.append(m['total'] * 100)
            dds.append(m['max_dd'] * 100)
            trees_list.append(m['avg_trees'])
            P(f"  Sortino={m['sortino']:.2f}  Sharpe={m['sharpe']:.2f}  "
              f"Ret={m['total']*100:+.0f}%  DD={m['max_dd']*100:.1f}%  "
              f"Trees={m['avg_trees']:.0f}")

        result = {
            'label': label,
            'n_est': n_est,
            'es_rounds': es_rounds,
            'val_frac': val_frac,
            'sortino_avg': float(np.mean(sortinos)),
            'sortino_std': float(np.std(sortinos)),
            'sharpe_avg': float(np.mean(sharpes)),
            'sharpe_std': float(np.std(sharpes)),
            'return_avg': float(np.mean(rets_list)),
            'max_dd_avg': float(np.mean(dds)),
            'avg_trees': float(np.mean(trees_list)),
        }
        all_results.append(result)

        P(f"  => Sortino={np.mean(sortinos):.2f}±{np.std(sortinos):.2f}  "
          f"Sharpe={np.mean(sharpes):.2f}  Ret={np.mean(rets_list):+.0f}%  "
          f"DD={np.mean(dds):.1f}%  Trees={np.mean(trees_list):.0f}")

    elapsed = (datetime.now() - start).total_seconds() / 60

    # Summary table
    P(f"\n{'='*80}")
    P(f"SUMMARY — {NUM_SEEDS} seeds each ({elapsed:.0f} min total)")
    P(f"{'='*80}")
    P("")
    P(f"  {'Config':<40} {'Sortino':>8} {'Sharpe':>8} {'Return':>8} {'MaxDD':>8} {'Trees':>6}")
    P(f"  {'─'*40} {'─'*8} {'─'*8} {'─'*8} {'─'*8} {'─'*6}")

    # Sort by Sortino
    ranked = sorted(all_results, key=lambda x: x['sortino_avg'], reverse=True)
    for r in ranked:
        P(f"  {r['label']:<40} {r['sortino_avg']:>7.2f}  {r['sharpe_avg']:>7.2f}  "
          f"{r['return_avg']:>+7.0f}%  {r['max_dd_avg']:>7.1f}%  {r['avg_trees']:>5.0f}")

    best = ranked[0]
    baseline = next(r for r in all_results if r['es_rounds'] is None)
    P(f"\n  Best: {best['label']}")
    P(f"  vs baseline: Sortino {best['sortino_avg'] - baseline['sortino_avg']:+.2f}, "
      f"Return {best['return_avg'] - baseline['return_avg']:+.0f}pp, "
      f"MaxDD {best['max_dd_avg'] - baseline['max_dd_avg']:+.1f}pp")

    # Save
    output = {
        'sweep': 'V22_early_stopping',
        'timestamp': datetime.now().isoformat(),
        'elapsed_min': elapsed,
        'n_seeds': NUM_SEEDS,
        'configs': all_results,
        'ranking': [r['label'] for r in ranked],
    }
    out_path = ROOT / 'outputs' / 'results' / 'v22_es_sweep.json'
    with open(out_path, 'w') as f:
        json.dump(output, f, indent=2, default=convert_numpy)
    P(f"\n  Saved: {out_path}")


if __name__ == '__main__':
    main()
