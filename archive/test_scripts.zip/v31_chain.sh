#!/bin/bash
# Wait for main V31 to finish, then run extras
cd "C:/Users/Beny_Hashdex/Documents/GitHub/longbiased-beny"
# Monitor the output file — when file has "V31 TOTAL" it means main finished
while ! grep -q "V31 TOTAL" /tmp/v31_main_done.flag 2>/dev/null; do
    sleep 30
done
echo "Main V31 done, running extras..."
python archive/test_scripts/v31_extras.py
