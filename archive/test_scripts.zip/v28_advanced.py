"""V28: advanced techniques not yet tested.

Reference: baseline Sortino 5.05, Ret +1098%, Fri acc 62.2%

V28 tests:

  T1  — FEATURE PRUNING via XGBoost gain importance
        Train baseline, sort features by gain, remove bottom 10.

  T2  — TOP-N FEATURES sweep
        Try top 20, 25, 30 features only.

  T3  — PER-DOW ENSEMBLE
        Train 5 separate models (one per weekday).
        Inference: use only the model for that day.

  T4  — STACKING (2-level, formal)
        Level 1: XGB regressor + XGB classifier (prob up)
        Level 2: XGB meta on [pred_reg, prob_up, top-5 features]

  T5  — COMBO: reg α=0.1 + mcw=6 + fracdiff d=0.3
        Combine the modest gains from V26/V27.

  T6  — ASYMMETRIC LOSS (pseudo-Huber / quantile regression)
        Penalize wrong direction more than magnitude error.

  T7  — AUGMENTED SEEDS (10 seeds on best config)
        Validate the best combo with more seeds.

Each 3 seeds. ~2-3h.
"""
import sys, time, json, gc
import numpy as np, pandas as pd
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import xgboost as xgb

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

import archive.old_pipelines.pipeline_v22 as v22
from archive.old_pipelines.pipeline_v09 import build_ml_features, backtest_allocations, COST
from scripts.production.training import _get_retrain_periods, _train_one_xgb
from src.features.macro.cdi_rates import build_rf_daily
import archive.old_pipelines.pipeline_v09 as v9m
import archive.old_pipelines.pipeline_v13 as v13m
from scripts.production.config import FEATURES_37, K_REGIME, ALLOC_MIN, ALLOC_MAX, BAGS, HORIZON, WORKERS, EMERGENCY_THRESHOLD

DATASET = ROOT / "outputs" / "feature_selection" / "dataset_enhanced.csv"
SEEDS_3 = [42, 142, 242]
SEEDS_10 = [42, 142, 242, 342, 442, 542, 642, 742, 842, 942]
RESULTS = ROOT / "outputs" / "results" / "v28_advanced.json"
DAY_NAMES = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun']


def load():
    df = pd.read_csv(DATASET)
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)
    prices = df['price_usd'].values
    n = len(prices)
    daily_ret = np.zeros(n)
    for i in range(1, n):
        daily_ret[i] = (prices[i] - prices[i-1]) / prices[i-1]
    returns, vols = {}, {}
    for w in [1, 3, 5, 7, 10, 14, 20, 21, 30, 45, 60]:
        r = np.zeros(n)
        for i in range(w, n):
            r[i] = (prices[i] - prices[i-w]) / prices[i-w]
        returns[w] = r
    for w in [5, 7, 10, 14, 21, 30]:
        vols[w] = pd.Series(daily_ret).rolling(w).std().fillna(0.02).values
    return prices, daily_ret, returns, vols, df


def fractional_diff(series, d=0.5, thres=0.01):
    w = [1.0]; k = 1
    while abs(w[-1]) > thres and k < len(series):
        w.append(-w[-1] * (d - k + 1) / k); k += 1
    w = np.array(w[::-1])
    arr = series.values if hasattr(series, 'values') else np.asarray(series)
    out = np.full(len(arr), np.nan)
    W = len(w)
    for i in range(W - 1, len(arr)):
        window = arr[i - W + 1:i + 1]
        if np.any(np.isnan(window)): continue
        out[i] = (w * window).sum()
    return out


def accuracy_per_dow(preds, actuals, dow):
    mask = np.abs(preds) > 1e-6
    out = {'all': float((np.sign(preds[mask]) == np.sign(actuals[mask])).mean())}
    for d, name in enumerate(DAY_NAMES):
        dmask = mask & (dow == d)
        if dmask.sum() > 10:
            out[name] = float((np.sign(preds[dmask]) == np.sign(actuals[dmask])).mean())
        else:
            out[name] = None
    return out


def get_regime(t, prices, sma50, sma200):
    if np.isnan(sma50[t]) or np.isnan(sma200[t]): return 'MILD'
    if prices[t] > sma50[t] and sma50[t] > sma200[t]: return 'BULL'
    elif prices[t] > sma200[t]: return 'MILD'
    return 'BEAR'


def compute_allocation(pred, regime):
    return float(np.clip(pred * K_REGIME[regime], ALLOC_MIN, ALLOC_MAX))


# ═══════════════════════════════════════════════════════════════
# Standard run with custom X
# ═══════════════════════════════════════════════════════════════

def run_seed(seed, X_all, target, prices, daily_ret, dates, periods,
             dow, sma50, sma200, rf_daily, n, xgb_params=None):
    params = xgb_params if xgb_params is not None else v22.XGB_PARAMS
    full_allocs = np.full(n, 0.0)
    prev_alloc = 0.0
    a_s, a_b, a_a, a_r = [], [], [], []
    all_preds = np.zeros(n)
    all_actuals = target.copy()

    for te, ts, tend in periods:
        gap = max(HORIZON, 5)
        tm = np.arange(60, te - gap + 1)
        valid = ~np.any(np.isnan(X_all[tm]), axis=1)
        idx = tm[valid]
        if len(idx) < 100: continue
        Xt = np.nan_to_num(X_all[idx], nan=0.0)
        yt = target[idx]

        bag_seeds = [seed + i * 7 for i in range(BAGS)]
        with ThreadPoolExecutor(max_workers=WORKERS) as ex:
            models = list(ex.map(_train_one_xgb,
                [(s, Xt, yt, params) for s in bag_seeds]))

        for t in range(ts, tend + 1):
            x_t = np.nan_to_num(X_all[t:t + 1].copy(), nan=0.0)
            prediction = float(np.mean([m.predict(x_t)[0] for m in models]))
            all_preds[t] = prediction

            is_rebal = dow[t] in [4]
            is_emerg = t > 0 and abs(daily_ret[t]) > EMERGENCY_THRESHOLD
            if not is_rebal and not is_emerg:
                full_allocs[t] = prev_alloc; continue
            regime = get_regime(t, prices, sma50, sma200)
            full_allocs[t] = compute_allocation(prediction, regime)
            prev_alloc = full_allocs[t]

        s, b, a = backtest_allocations(daily_ret, full_allocs, ts, tend,
                                       cost=COST, rf_daily=rf_daily)
        a_s.extend(s); a_b.extend(b); a_a.extend(a)
        a_r.extend(rf_daily[ts:ts + len(s)])
        del models; gc.collect()

    metrics = v22.metrics_v22(np.array(a_s), np.array(a_b), np.array(a_a),
                              rf_daily=np.array(a_r))
    return metrics, all_preds, all_actuals


# ═══════════════════════════════════════════════════════════════
# T3: Per-DOW ensemble
# ═══════════════════════════════════════════════════════════════

def run_per_dow(seed, X_all, target, prices, daily_ret, dates, periods,
                 dow, sma50, sma200, rf_daily, n):
    full_allocs = np.full(n, 0.0)
    prev_alloc = 0.0
    a_s, a_b, a_a, a_r = [], [], [], []
    all_preds = np.zeros(n)
    all_actuals = target.copy()

    for te, ts, tend in periods:
        gap = max(HORIZON, 5)
        tm = np.arange(60, te - gap + 1)
        valid = ~np.any(np.isnan(X_all[tm]), axis=1)
        idx = tm[valid]
        if len(idx) < 100: continue
        Xt_all = np.nan_to_num(X_all[idx], nan=0.0)
        yt_all = target[idx]
        dow_t = dow[idx]

        # Train one model per DOW (5 trading days: Mon-Fri = 0-4)
        models_per_dow = {}
        for d in range(7):
            mask = dow_t == d
            if mask.sum() < 50: continue
            Xd = Xt_all[mask]; yd = yt_all[mask]
            # Use smaller ensemble per dow to keep runtime reasonable
            bag_seeds = [seed + i * 7 for i in range(BAGS // 2)]
            with ThreadPoolExecutor(max_workers=WORKERS) as ex:
                models_per_dow[d] = list(ex.map(_train_one_xgb,
                    [(s, Xd, yd, v22.XGB_PARAMS) for s in bag_seeds]))

        for t in range(ts, tend + 1):
            d_t = dow[t]
            if d_t not in models_per_dow:
                # Fallback: any model
                d_fb = list(models_per_dow.keys())[0]
                models = models_per_dow[d_fb]
            else:
                models = models_per_dow[d_t]
            x_t = np.nan_to_num(X_all[t:t + 1].copy(), nan=0.0)
            prediction = float(np.mean([m.predict(x_t)[0] for m in models]))
            all_preds[t] = prediction

            is_rebal = dow[t] in [4]
            is_emerg = t > 0 and abs(daily_ret[t]) > EMERGENCY_THRESHOLD
            if not is_rebal and not is_emerg:
                full_allocs[t] = prev_alloc; continue
            regime = get_regime(t, prices, sma50, sma200)
            full_allocs[t] = compute_allocation(prediction, regime)
            prev_alloc = full_allocs[t]

        s, b, a = backtest_allocations(daily_ret, full_allocs, ts, tend,
                                       cost=COST, rf_daily=rf_daily)
        a_s.extend(s); a_b.extend(b); a_a.extend(a)
        a_r.extend(rf_daily[ts:ts + len(s)])
        del models_per_dow; gc.collect()

    metrics = v22.metrics_v22(np.array(a_s), np.array(a_b), np.array(a_a),
                              rf_daily=np.array(a_r))
    return metrics, all_preds, all_actuals


# ═══════════════════════════════════════════════════════════════
# T1: Compute feature importance (once, for pruning)
# ═══════════════════════════════════════════════════════════════

def compute_feature_importance(X_all, target, feats, n):
    """Train baseline XGBoost on full data and return gain importance per feature."""
    # Use a single train (not walk-forward) for quick importance
    idx = np.arange(60, n - 5)
    valid = ~np.any(np.isnan(X_all[idx]), axis=1)
    idx = idx[valid]
    Xt = np.nan_to_num(X_all[idx], nan=0.0)
    yt = target[idx]

    p = dict(v22.XGB_PARAMS)
    p['random_state'] = 42
    ne = p.pop('n_estimators', 200)
    m = xgb.XGBRegressor(n_estimators=ne, **p)
    m.fit(Xt, yt)
    imp = m.feature_importances_  # gain by default
    return dict(zip(feats, imp))


# ═══════════════════════════════════════════════════════════════
# Aggregate
# ═══════════════════════════════════════════════════════════════

def aggregate(name, outputs, dow):
    sortinos = [o[0]['sortino'] for o in outputs]
    rets     = [o[0]['total']*100 for o in outputs]
    dds      = [o[0]['max_dd']*100 for o in outputs]
    preds_avg = np.mean([o[1] for o in outputs], axis=0)
    actuals = outputs[0][2]
    acc = accuracy_per_dow(preds_avg, actuals, dow)
    result = {
        'name': name,
        'sortino_mean': float(np.mean(sortinos)), 'sortino_std': float(np.std(sortinos)),
        'ret_mean': float(np.mean(rets)), 'ret_std': float(np.std(rets)),
        'dd_mean': float(np.mean(dds)), 'dd_std': float(np.std(dds)),
        'acc': acc, 'n_seeds': len(outputs),
    }
    acc_str = f"all={acc['all']*100:.1f}%"
    for day in ['Mon','Wed','Fri','Sun']:
        if acc.get(day) is not None:
            acc_str += f" {day}={acc[day]*100:.1f}%"
    print(f"{name:<30}  S={result['sortino_mean']:.2f}  Ret={result['ret_mean']:+.0f}%  "
          f"DD={result['dd_mean']:.1f}%  {acc_str}")
    return result


def main():
    t0 = time.time()
    print("=" * 95)
    print("V28 ADVANCED — feature pruning, per-DOW models, combos")
    print("Reference: baseline Sortino 5.05, Ret +1098%, Fri acc 62.2%")
    print("=" * 95)

    prices, daily_ret, returns, vols, df = load()
    dates = df['date'].values
    n = len(prices)
    rf_daily = build_rf_daily(dates, source='auto')
    v9m.RF_DAILY_ARR = rf_daily
    v13m.RF_DAILY_ARR = rf_daily
    dow = pd.to_datetime(dates).dayofweek.values
    periods = _get_retrain_periods(dates, n, v22.RETRAIN)
    sma50 = pd.Series(prices).rolling(50).mean().values
    sma200 = pd.Series(prices).rolling(200).mean().values

    feats = list(FEATURES_37)
    X_base, fnames = build_ml_features(df, returns, vols, n, feature_cols=feats)
    target = np.zeros(n)
    for i in range(n - HORIZON):
        target[i] = (prices[i + HORIZON] - prices[i]) / prices[i]

    results = []
    def save():
        RESULTS.parent.mkdir(parents=True, exist_ok=True)
        with open(RESULTS, 'w') as f:
            json.dump({'results': results, 'elapsed_min': (time.time()-t0)/60}, f, indent=2)

    # T1 — Feature importance + pruning
    print("\n-- T1: FEATURE PRUNING (remove bottom-10 by gain importance) --")
    imp = compute_feature_importance(X_base, target, fnames, n)
    imp_sorted = sorted(imp.items(), key=lambda x: x[1])
    print("  Bottom-10 features by gain importance:")
    for feat, val in imp_sorted[:10]:
        print(f"    {feat:<32}  {val:.4f}")
    bottom_10 = set(f for f, _ in imp_sorted[:10])
    top_feats = [f for f in fnames if f not in bottom_10]
    top_idx = [fnames.index(f) for f in top_feats]
    X_pruned = X_base[:, top_idx]
    outs = [run_seed(s, X_pruned, target, prices, daily_ret, dates, periods,
                     dow, sma50, sma200, rf_daily, n) for s in SEEDS_3]
    results.append(aggregate('T1_pruned_bot10', outs, dow)); save()

    # T2 — Top-N sweep
    print("\n-- T2: TOP-N FEATURES sweep --")
    for n_top in [20, 25, 30]:
        top_n_feats = [f for f, _ in imp_sorted[-n_top:]]  # top N by importance
        idx_n = [fnames.index(f) for f in top_n_feats]
        X_n = X_base[:, idx_n]
        outs = [run_seed(s, X_n, target, prices, daily_ret, dates, periods,
                         dow, sma50, sma200, rf_daily, n) for s in SEEDS_3]
        results.append(aggregate(f'T2_top{n_top}', outs, dow)); save()

    # T3 — Per-DOW ensemble
    print("\n-- T3: PER-DOW ENSEMBLE --")
    outs = [run_per_dow(s, X_base, target, prices, daily_ret, dates, periods,
                       dow, sma50, sma200, rf_daily, n) for s in SEEDS_3]
    results.append(aggregate('T3_per_dow', outs, dow)); save()

    # T5 — COMBO: reg α=0.1 + mcw=6 + fracdiff d=0.3
    print("\n-- T5: COMBO (reg 0.1 + mcw 6 + fracdiff d=0.3) --")
    X_combo = X_base.copy()
    log_prices = np.log(prices)
    fed_log = np.log(df['fed_balance_sheet'].replace(0, np.nan).values)
    idx_pf = fnames.index('price_fracdiff_05')
    idx_ff = fnames.index('fed_fracdiff_05')
    X_combo[:, idx_pf] = fractional_diff(log_prices, d=0.3)
    X_combo[:, idx_ff] = fractional_diff(fed_log, d=0.3)
    p_combo = dict(v22.XGB_PARAMS)
    p_combo['reg_alpha'] = 0.1
    p_combo['reg_lambda'] = 0.1
    p_combo['min_child_weight'] = 6
    outs = [run_seed(s, X_combo, target, prices, daily_ret, dates, periods,
                     dow, sma50, sma200, rf_daily, n, xgb_params=p_combo)
            for s in SEEDS_3]
    results.append(aggregate('T5_combo_best', outs, dow)); save()

    # T5b — COMBO with more aggressive combination
    print("\n-- T5b: COMBO (reg 0.1 + fracdiff d=0.3, keep mcw=12) --")
    p_combo2 = dict(v22.XGB_PARAMS)
    p_combo2['reg_alpha'] = 0.1
    p_combo2['reg_lambda'] = 0.1
    outs = [run_seed(s, X_combo, target, prices, daily_ret, dates, periods,
                     dow, sma50, sma200, rf_daily, n, xgb_params=p_combo2)
            for s in SEEDS_3]
    results.append(aggregate('T5b_combo_d03_reg', outs, dow)); save()

    # Final summary
    print()
    print("=" * 95)
    print(f"V28 TOTAL: {(time.time()-t0)/60:.1f} min")
    print("=" * 95)
    print("\nRanked by Sortino:")
    for r in sorted(results, key=lambda x: -x['sortino_mean']):
        acc = r['acc']
        print(f"  {r['name']:<30}  S={r['sortino_mean']:.2f}  Ret={r['ret_mean']:+.0f}%  "
              f"DD={r['dd_mean']:.1f}%  Fri={acc.get('Fri', 0)*100:.1f}%")
    save()


if __name__ == '__main__':
    main()
