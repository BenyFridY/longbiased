"""Analyze model error patterns — what can we learn?"""
import sys, gc, numpy as np, pandas as pd
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor

ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT))

from archive.old_pipelines.pipeline_v09 import load_data, build_ml_features
from archive.old_pipelines.pipeline_v10 import MODELS
from archive.old_pipelines.pipeline_v13 import _get_retrain_periods, _train_one_xgb
from scripts.production.config import K_REGIME, XGB_PARAMS, BAGS, EMERGENCY_THRESHOLD

prices, daily_ret, returns, vols, df = load_data()
dates = df['date'].values
n = len(prices)
try:
    from src.features.macro.cdi_rates import build_rf_daily
    rf_daily = build_rf_daily(dates, source='auto')
except:
    from src.features.macro.cdi_rates import build_rf_daily
    rf_daily = build_rf_daily(dates, source='copom')
import archive.old_pipelines.pipeline_v09 as v9m
import archive.old_pipelines.pipeline_v13 as v13m
v9m.RF_DAILY_ARR = rf_daily
v13m.RF_DAILY_ARR = rf_daily

fc = [f for f in MODELS['37feat'] if f != 'exchange_netflow_ma7'] + ['basis_pct'] + [
    'fed_balance_sheet', 'futures_trade_count', 'vol_x_regime_duration', 'velocity', 'hash_rate_pctchg_30d']
fc = [f for f in fc if f in df.columns]
X_all, _ = build_ml_features(df, returns, vols, n, feature_cols=fc)
target = np.zeros(n)
for i in range(n - 3):
    target[i] = (prices[i + 3] - prices[i]) / prices[i]
sma50 = pd.Series(prices).rolling(50).mean().values
sma200 = pd.Series(prices).rolling(200).mean().values
periods = _get_retrain_periods(dates, n, 'semi')
dow = pd.to_datetime(dates).dayofweek
dt_dates = pd.to_datetime(dates)

seed = 242
friday_data = []
print("Collecting Friday predictions...")

for te, ts, tend in periods:
    gap = 5
    tm = np.arange(60, te - gap + 1)
    valid = ~np.any(np.isnan(X_all[tm]), axis=1)
    idx = tm[valid]
    if len(idx) < 100:
        continue
    Xt = np.nan_to_num(X_all[idx], nan=0.0)
    yt = target[idx]
    bag_seeds = [seed + i * 7 for i in range(BAGS)]
    with ThreadPoolExecutor(max_workers=16) as ex:
        models = list(ex.map(_train_one_xgb, [(s, Xt, yt, XGB_PARAMS) for s in bag_seeds]))

    for t in range(ts, tend + 1):
        if dow[t] != 4:
            continue
        x_t = np.nan_to_num(X_all[t:t + 1], nan=0.0)
        pred = float(np.mean([m.predict(x_t)[0] for m in models]))
        if np.isnan(sma50[t]) or np.isnan(sma200[t]):
            regime = 'MILD'
        elif prices[t] > sma50[t] and sma50[t] > sma200[t]:
            regime = 'BULL'
        elif prices[t] > sma200[t]:
            regime = 'MILD'
        else:
            regime = 'BEAR'
        K = K_REGIME[regime]
        alloc = float(np.clip(pred * K, -0.25, 1.0))
        nf = min(t + 7, n - 1)
        actual_week = (prices[nf] - prices[t]) / prices[t]
        actual_3d = (prices[min(t + 3, n - 1)] - prices[t]) / prices[t]
        dir_correct = (pred > 0 and actual_3d > 0) or (pred < 0 and actual_3d < 0)
        prev_week = (prices[t] - prices[max(t - 7, 0)]) / prices[max(t - 7, 0)]

        friday_data.append({
            'date': str(dt_dates[t].date()),
            'price': prices[t], 'regime': regime,
            'pred': pred, 'alloc': alloc,
            'actual_3d': actual_3d, 'actual_week': actual_week,
            'dir_correct': dir_correct, 'prev_week_ret': prev_week,
            'month': dt_dates[t].month, 'year': dt_dates[t].year,
        })
    del models
    gc.collect()

fd = pd.DataFrame(friday_data)

print()
print("ANALYSIS OF MODEL ERRORS")
print("=" * 70)
print(f"Total Fridays OOS: {len(fd)}")
print(f"Direction correct: {fd.dir_correct.sum()}/{len(fd)} ({fd.dir_correct.mean()*100:.0f}%)")

# 1. Big errors: max short but BTC up
print()
print("--- WORST ERRORS: max short but BTC up >3% ---")
bad_short = fd[(fd.alloc <= -0.20) & (fd.actual_week > 0.03)].sort_values('actual_week', ascending=False)
print(f"  Count: {len(bad_short)}/{len(fd)}")
for _, r in bad_short.head(5).iterrows():
    print(f"  {r.date} | alloc={r.alloc*100:+.0f}% | BTC week={r.actual_week*100:+.1f}% | prev_week={r.prev_week_ret*100:+.1f}%")

# 2. Big errors: long >75% but BTC dropped
print()
print("--- WORST ERRORS: long >75% but BTC down >3% ---")
bad_long = fd[(fd.alloc > 0.75) & (fd.actual_week < -0.03)].sort_values('actual_week')
print(f"  Count: {len(bad_long)}/{len(fd)}")
for _, r in bad_long.head(5).iterrows():
    print(f"  {r.date} | alloc={r.alloc*100:+.0f}% | BTC week={r.actual_week*100:+.1f}% | prev_week={r.prev_week_ret*100:+.1f}%")

# 3. Accuracy by previous week
print()
print("--- ACCURACY BY PREVIOUS WEEK RETURN ---")
bins = [(-1, -0.05), (-0.05, -0.02), (-0.02, 0.02), (0.02, 0.05), (0.05, 1)]
labels = ['prev<-5%', '-5% to -2%', '-2% to +2%', '+2% to +5%', 'prev>+5%']
for (lo, hi), label in zip(bins, labels):
    mask = (fd.prev_week_ret >= lo) & (fd.prev_week_ret < hi)
    sub = fd[mask]
    if len(sub) > 5:
        acc = sub.dir_correct.mean() * 100
        print(f"  {label:>12}: {len(sub):>3} wks | accuracy={acc:.0f}% | avg BTC next={sub.actual_week.mean()*100:+.1f}%")

# 4. Accuracy by regime
print()
print("--- ACCURACY BY REGIME ---")
for regime in ['BULL', 'MILD', 'BEAR']:
    sub = fd[fd.regime == regime]
    if len(sub) > 0:
        acc = sub.dir_correct.mean() * 100
        print(f"  {regime:>6}: {len(sub):>3} wks | accuracy={acc:.0f}% | avg_pred={sub.pred.mean()*100:+.2f}% | avg_actual={sub.actual_3d.mean()*100:+.2f}%")

# 5. After error, does next predict improve?
print()
print("--- AFTER ERROR: DOES MODEL SELF-CORRECT? ---")
fd['prev_correct'] = fd.dir_correct.shift(1)
after_error = fd[fd.prev_correct == False]
after_correct = fd[fd.prev_correct == True]
print(f"  After error:   accuracy={after_error.dir_correct.mean()*100:.0f}% ({len(after_error)} wks)")
print(f"  After correct: accuracy={after_correct.dir_correct.mean()*100:.0f}% ({len(after_correct)} wks)")
print(f"  Difference:    {(after_error.dir_correct.mean() - after_correct.dir_correct.mean())*100:+.0f}pp")

# 6. Streak analysis: consecutive errors
print()
print("--- ERROR STREAKS ---")
streaks = []
current_streak = 0
for _, r in fd.iterrows():
    if not r.dir_correct:
        current_streak += 1
    else:
        if current_streak > 0:
            streaks.append(current_streak)
        current_streak = 0
if current_streak > 0:
    streaks.append(current_streak)
if streaks:
    print(f"  Max error streak: {max(streaks)} weeks")
    print(f"  Avg error streak: {np.mean(streaks):.1f} weeks")
    print(f"  Streaks >3 weeks: {sum(1 for s in streaks if s > 3)}")

# 7. Mean reversion of errors: after big miss, does model overcompensate?
print()
print("--- MEAN REVERSION OF ERRORS ---")
fd['pred_error'] = fd.pred - fd.actual_3d
fd['prev_error'] = fd.pred_error.shift(1)
corr = fd['pred_error'].corr(fd['prev_error'])
print(f"  Correlation between consecutive errors: {corr:.3f}")
print(f"  (negative = model overcompensates, positive = errors persist)")

# 8. The 06/03 case
print()
print("--- 06/03/2026 CASE ---")
case = fd[fd.date == '2026-03-06']
if len(case) > 0:
    r = case.iloc[0]
    print(f"  Pred: {r.pred*100:+.3f}% | Regime: {r.regime}")
    print(f"  Alloc: {r.alloc*100:+.1f}% | Prev week: {r.prev_week_ret*100:+.1f}%")
    print(f"  Actual 3d: {r.actual_3d*100:+.1f}% | Actual week: {r.actual_week*100:+.1f}%")
    print(f"  Pattern: BTC crashed prev week, model predicted continuation, got bounce instead")

print()
print("=" * 70)
